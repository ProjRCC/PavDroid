# PavDroid V1.0.12 — Collapsible Settings and Timer Reset to Defaults

Android application ID: `com.projrcc.pavdroid` · `versionName 1.0.12` · `versionCode 112`.

## Baseline and boundaries

Built by modifying the archived complete **PavDroid V1.0.11 `project.zip`** (36 files). This release does **not** alter the separate Pavlok Control V3.0.3 backup app, PavDroid's native alarm scheduling, Bluetooth reconnection, music playback engine, or zap-stimulus engine. The original four-tab interface remains in place.

## V1.0.12 changes

- Settings main sections **Music, Watch, Defaults, Android, and About** use understated **− / +** collapse controls. Inside Defaults, **New alarms / New timers** and their **Stimuli / Zaps / Music** groups independently expand/collapse. Each fold state is saved locally and does not change setting values. Parent collapse preserves child state.
- Consistent heading hierarchy: Settings > main sections > New alarms / New timers > Stimuli / Zaps / Music > individual fields. Default layout: Music and Defaults open, New alarms open, New timers / Watch / Android / About closed; nested groups start expanded.
- **Smart Timeout** is moved into the **Stimuli** subsection for new-alarm and new-timer defaults. It is still an independently saved toggle.
- Alarm and Timer editor **Snooze time** labels are aligned closely to their minus/value/plus steppers; the existing input, validation, and save behavior are reused.
- The Timer **Ready** badge is replaced *while idle* by **Reset to defaults**, at the top right of the Timer header. This button loads saved **Timer default** stimulus, zap, music, snooze, and Smart Timeout settings **without changing the selected MM:SS duration or preset**. While a timer or alarm is active, the button is hidden and the normal Timer phase badge remains visible.
- Timer configuration is retained independently of saved *new-timer defaults* while idle. Manual changes survive Timer duration changes and are stored locally for screen reopening. Editing a new-timer default in Settings no longer silently resets the current Timer: tap **Reset to defaults** when desired. The user's existing **Include Music** selection is preserved because Settings has no default for enabling/disabling music.
- Fresh-install default values match the supplied Settings screenshot. **New alarms:** 5 buzz / 5 beep / 1 zap, 8s interval, 7min snooze, 40% max zap, zaps after 1 snooze, music after 0 snoozes, music starts 20%, rises +15% every 5s, Smart Timeout on. **New timers:** 3 buzz / 3 beep / 1 zap, 6s interval, 1min snooze; remaining Zap/Music/Smart Timeout values match alarm defaults. **Existing saved defaults are preserved** during an upgrade instead of being overwritten.

## Validation and limits

- JavaScript parser checks passed; the existing Java source files were unchanged.
- Simulated Chromium WebView tests passed for section folding, heading structure, Smart Timeout placement, defaults save, timer-config persistence, Timer time preservation on reset, active-session button guard, and compact Alarm Snooze spacing.
- These are *source/browser checks only*. APK compilation must run through GitHub Actions; actual Alarm/Timer/Snooze/BLE/MP3 and visual behavior require installation on the phone and physical watch.

## Release procedure

Upload the complete **`project.zip`** to the root of `ProjRCC/PavDroid`, replacing only the previous ZIP. The existing `.github/workflows/build-apk.yml` extracts that ZIP and runs `:app:assembleDebug`; unchanged README/workflow files need not be uploaded separately. Preserve all older version-numbered Google Drive folders. The independent Pavlok Control source remains untouched.

**Signing limitation:** The current GitHub workflow still uses ephemeral debug signing. A stable key for in-place Android upgrades is a separate unfinished task.
