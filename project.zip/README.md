# PavDroid V1.0.11 — Matched Alarm / Timer controls and Timer zap hold-off

Android application ID: `com.projrcc.pavdroid` · `versionName 1.0.11` · `versionCode 111`.

## Baseline and boundaries

This complete source is based on the archived, exact PavDroid **V1.0.10** `project.zip`. The original **Pavlok Control V3.0.3** backup application remains separate and unchanged. Android remains the alarm/timer scheduler; the Shock Clock 3 is the native BLE stimulus/button accessory. There is no watch-firmware alarm programming in PavDroid.

## V1.0.11 changes

- Both configuration editors follow the same vertical sequence after Alarm days/time or Timer duration/presets: **Snooze time → Music → stimulus counts + interval → full-width maximum Zap intensity slider → Zaps after → Smart Timeout → Preview**. Existing controls are relocated, not recreated, so current settings and save handlers are retained.
- Fixed the Timer's `Zaps after` UI being accidentally inserted **inside the hold-to-adjust slider container**, which squeezed the slider into the left half of the row. It is now a separate full-width row beneath the slider.
- The Timer's optional **Buzz on start (30%)** control is removed. The existing 30%-buzz acknowledgment is **always requested** on a successful Timer Start with a connected watch. If Bluetooth is disconnected, physical delivery cannot be guaranteed.
- Timer native stimulus code adds an explicit **pre-threshold zap suppression** safeguard, in addition to the existing `sequenceLength()` exclusion. Connection logs record when zaps are being held pending the chosen Snooze count, and when they first become eligible. This does not modify the escalation ramp, the 12-zap-per-firing safety limit, or watch-button Snooze/Stop handling.
- Settings defaults headings **New alarms** and **New timers** are larger. Each Zap defaults block now fills the former empty grid space with an **Escalation Setting** explanation: **Start at 10%. Increase to Max XX%.** The maximum tracks the selected intensity value.

## Features preserved

The four-tab dark-blue UI, Music library, per-firing Media volume ramp, 10-second music start delay, music/zap Snooze thresholds, indefinite Snooze counts, Smart Timeout, History, notification actions, alarm schedule, Bluetooth reconnection, and 30% timer-start acknowledgment remain in place. The Music section still expands/collapses without changing its saved settings. This release does not change native alarm firing or music playback code.

## Build / release

Upload this complete **`project.zip`** to the root of `ProjRCC/PavDroid`, replacing only the previous root ZIP. The existing `.github/workflows/build-apk.yml` extracts it and builds with `:app:assembleDebug`. No separate README/workflow upload is needed if unchanged. Save each version's ZIP in its own version-numbered Google Drive folder; never overwrite V1.0.10 or earlier archives.

The GitHub workflow still uses a temporary debug-signing key. Consistent signing for in-place updates remains a **separate, unfinished** task. APK build success, in-app rendering, and physical watch stimulus output must be validated independently. Use low-intensity testing first; keep an independent wake-up alarm during reliability trials.
