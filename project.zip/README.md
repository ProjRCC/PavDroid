# PavDroid 2.0.9 — REfresh (source-only test build)

**Status: V2.0.10 contextual-navigation and Music Library source candidate. V2.0.0 was compiled through GitHub Actions and user-installed; V2.0.6 still requires its own APK and real-watch checks.**

## Why this release exists

V1.0.19 failed at JavaScript initialization and exposed the old Pavlok Control firmware-alarm page. V1.0.20 (`preREfresh`) fixed that startup failure and is user-confirmed functional. This one-time REfresh moves PavDroid onto a clean, Android-only UI and package so that the old UI cannot reappear. No firmware alarm-list UI, Code Red, old watch timer configuration, firmware alarm programming, or hidden fallback page is included.

**V1.0.20 is untouched.** Its source ZIP and installed app remain the behavioral, hardware and visual reference. This project has a separate test application ID so both may be installed simultaneously, but do **not** connect both apps to the same watch simultaneously.

## Identity and source

- Version: **2.0.9**, versionCode **207**.
- Package / applicationId: `com.projrcc.pavdroid.refresh` (test-only; deliberately distinct from V1.x).
- Java namespace: `com.projrcc.pavdroid` (new, not `com.projectrcc.pavlokcontrol`).
- Architecture: Android's `AlarmManager` owns alarms and the native timer engine owns timers. The native service owns GATT background reconnection, button events, direct watch stimulation, audio/TTS, notifications, saved History.
- UI is now **only** `assets/index.html`, `styles.css`, `transport.js`, `app.js`. A separate CSS/JS model is provided from scratch and no longer uses the original control page as fallback.
- Existing working native algorithms from V1.0.20 for BLE GATT, Android alarm schedules, timer/stimulus, watch-button Snooze/Stop, music/TTS and notifications are intentionally *selectively reused* instead of riskily reverse-engineering another hardware protocol. Unnecessary legacy classes and firmware control operations were removed.
- Alarm and Timer options: **three equally spaced checkbox rows** for Safe Max (visible at >=60%), Time Readout, Smart Timeout; small inline info icons, subtle border, no internal dividers, directly above Preview. The Alarm editor has only bottom Cancel / Save actions.

## Building

The complete source is a root-level `project.zip`. This version supersedes V2.0.0 source as the next test candidate, without deleting either V2.0.0 or V1.0.20 archives. Use the preexisting GitHub repository workflow (which extracts that ZIP) to compile an Android debug APK:

1. Keep the V1.0.20 `preREfresh` source/archive and installed app as a separate fallback.
2. To test V2 source, use the established ChatGPT Work / GitHub Actions workflow to upload this V2.0.10 `project.zip` to PavDroid `main` and retrieve the built APK; leave the V1.0.20 archive and original Pavlok Control repository untouched.
3. Use JDK 17, Gradle 8.11.1, compile SDK 35, Android build tools 35.0.0; build `:app:assembleDebug`.
4. Install the test APK alongside V1.0.20. Android treats the two package IDs as distinct; this V2 test APK starts with separate local data (no automatic migration of alarms, MP3 permissions, History, or selected settings).
5. Grant Bluetooth, exact alarms and notification permissions; pair and configure the test app independently. Never use both simultaneously to drive the same watch.

The ZIP includes `.github/workflows/build-apk.yml` as a reference. If your repository already contains the unchanged wrapper workflow, it remains sufficient; only its display artifact label may still say V1.0.1.

## Important limitations

- Browser UI integration tests are not equivalent to a Java/Gradle build, an installed-phone test, or physical watch stimulation.
- Verify native behavior with safe, short buzz/beep-only tests first; do not use V2 as your only critical wake-up alarm until background reconnect, exact schedules, MP3/TTS, Snooze/Stop and repeated launches are checked on-device.
- The charging bolt only appears when the watch exposes a supported charging-status characteristic.
- Safe Max (50%) is not a medically validated electrical safety guarantee. Snooze/Stop and Smart Timeout continue to be available.
- Migration into the production V1.x package or replacement of the existing source is explicitly deferred pending user-approved physical verification.

See `TEST_PLAN.md` for per-feature acceptance cases.

## V2.0.6 visual parity and navigation corrections

Source audit against V1.0.20 plus the user's 67-second Zoom 2 screen recording identified unintended V2.0.0 presentation changes. This release restores:

- Settings starts with Defaults expanded, New alarms and New timers individually collapsed; other sections Music, Watch, Android, Advanced, About collapsed. Reopening Settings always resets this display state. Separate Stimuli / Zaps / Music grouped controls appear inside each type's Defaults; no flattened long grid. Section icons and compact +/- controls.
- Consistent Snooze time placement directly after time/presets and before Music, in Alarm and Timer; original one-line watch-button hint.
- Checking Include Music opens the entire music configuration; manual fold can close it, and unchecking doesn't discard settings.
- Button sizing/spacing, colored intensity borders (green <=30%, amber 40-50%, red >=60%; white border/red face at 90-100%), slider/thumb treatment, and clean editor reopening at top after Cancel/X.
- Watch tab on first-ever launch. Active Alarm or Timer opens its respective tab; a Stop recorded in native History within five minutes selects History on reopening; otherwise previous manual tab is remembered. UI Stop buttons also open History directly.
- Battery percentage is a tap target in the header and Watch card. Foreground BLE battery polling at most every 30 seconds when there is no active session. A white charge bolt appears only when the watch reports charging through standard GATT 2A1A or 2BED. A brief spinner/checkmark acknowledges manual battery refresh even when the percentage is unchanged. If neither characteristic is available, a Watch event-log diagnostic explains why the bolt cannot appear. Physical Shock Clock 3 support remains unverified.
- Popup-only protection for starting overlapping Alarms/Timers: buttons stay tappable, with native busy check and warning.
- Timer Reset to Defaults restored beside heading, preserving duration and no redundant confirmation; removed the inherited 30% Buzz on start checkbox/extra action absent in V1.0.20.

The native alarm, timer, scheduler, stimulation, audio and session engines remain unchanged. Native BLE battery read allowlisting adds one read-only standardized charging-state characteristic (2BED); no new watch write commands were added. An existing permission hook re-arms exact alarms once granted.

**Verified locally:** JS syntax; mock-native regression tests for alarm create/edit/copy, timer start/stop/reset, music auto-expansion, settings initial/reopen hierarchy, safe intensity border, battery manual refresh and charging-bit conditional rendering, editor top-reset, and tab priority (first/Alarm/Timer/recent Stop). These tests DO NOT verify actual watch charging status, APK compilation, physical stimuli, background reconnect, or production wake-up reliability.

## V2.0.6 alarm-list and input refinements (Nov 23)

- Alarm list now contains only Edit (largest button), Copy, Delete. Copy +30 is removed from both visible controls and unused copy-time implementation. Copy by itself still works.
- Enabled alarms are displayed first, then ascending by scheduled time. This is *display ordering only*: native alarm array order, original edit indices and stored schedules remain unchanged.
- Disabled alarm time and name are muted gray, while controls remain usable. Larger music note and separate `TTS` indicator are displayed only when configured.
- Redundant on-phone explanatory line underneath Scheduled Alarms is hidden when precise alarm permission exists; required-permission warnings remain visible.
- Timer duration field selects its whole prior value when tapped. Plain digits represent seconds (`5` becomes `0:05` on blur); colon input is minutes:seconds. Invalid text reverts to the last valid duration.
- History selection checkbox is at the right side of the header, preserving label position when Select is toggled.
- Existing charging indicator is conditional on explicit BLE Battery Power State reporting, which remains unverified on the hardware. This build does not guess charging from percentage alone.

Automated browser tests (mock Android bridge, Zoom-2-like viewport) confirm the three-button widths, enabled-first ordering without storage index mismatch, disabled style, MP3/TTS labels, timer field 5 → 0:05, and history header stability. Physical device behavior and APK compilation remain unverified for V2.0.6.

## V2.0.6 follow-up fixes — exact alarms, Timer entry, charging diagnostics

- Missing **Alarms & reminders** permission: a clear **Allow exact alarms** button appears on Watch; Settings > Android now opens the exact-alarm permission page directly instead of generic App info. The recurring Scheduled Alarms notice is rendered by a single function, eliminating permission flicker. A grant broadcast re-arms saved exact schedules after Android enables permission.
- Typed Timer digits format immediately in the field, not only after blur: `5` -> `0:05`, then `50` -> `0:50`, then `500` -> `5:00`; Backspace steps backwards. A keypad edit is separate from saved countdown duration; zero is not runnable.
- On disabled alarms, **Once / Weekdays / Weekends / Every day** continues to show after **Disabled**, with muted music-note and TTS indicators alongside the already-muted name/time.
- Battery Power State `0x2A1A` decoding corrected: bits **5–4** equal binary **11** for *Charging*; the older readout incorrectly interpreted bits 3–2 (discharging). When real charging is positively reported, the Watch battery card always keeps the **Battery** label, and only the small white lightning bolt beside the percentage appears. On unsupported characteristic, the app leaves both unmarked and writes one diagnostic to the Watch event log. No percentage-trend inference and no fabricated charging status.
- Exact-alarm grant/rearm and BLE charge availability must be tested on the phone/watch: local browser tests use injected native mocks.

## V2.0.6 focused correction
- Watch panel label stays **Battery** under all conditions. No separate **Charging** word or line.
- Existing small white lightning bolt remains immediately adjacent to battery percentage only when verified BLE charging state is present.
- No other application behavior changed; V2.0.3 engine kept intact.


## V2.0.6 History, defaults, Timer input

- Reproduced the V1.0.20 History presentation in the clean Android-owned PDH History implementation: temporal start/end labels, real-time-scaled segments (blue activation, gold snooze), 25% gridlines, clock ticks, elapsed duration, user-origin snooze markers, black STOP dot, automatic legend, and full-width event expand/collapse. No firmware-alarm or Code Red dependencies were copied.
- Added independently saved **Time Readout** default checkboxes to Settings → Defaults → New alarms and New timers; new alarm/timer profiles inherit the checked state. No migration/reset of existing saved alarms.
- Timer duration input resets visually to `0:00` on focus and positions the caret at the far right, with mm:ss formatting as digits are entered. Leaving the input empty restores the last valid duration.
- Repeat-day presets (Once, Weekdays, Weekends, Every day) and seven day buttons now use consistent font size/weight.
- History selection mode disables Delete/Export when no sessions are selected; expanded event lists remain expanded during the foreground refresh.

## V2.0.6 additional battery refresh / charging correction

- Tapping either battery percentage triggers a new real BLE level read, or queues a follow-up read if a poll is already running; displays a small rotating refresh marker, then a checkmark on success or `!` on failure. Disconnected manual taps explain that the watch must be connected. This gives feedback even when a reading remains 100%.
- Standard **Battery Power State 0x2A1A** is checked first. If absent or unreadable, read-only **Battery Level Status 0x2BED** is attempted using its little-endian Power State field (charge state bits 5–6). No app-level battery percentage changes, Android phone charging, or elapsed-time heuristics are used to guess charging.
- The bolt stays next to the percentage only when a supported GATT field confirms charging. The Watch card label is always **Battery**, with no additional Charging text or row. If both optional characteristics are absent, that fact is recorded once per BLE session in the Watch event log; a manual refresh also logs the fresh percentage and whether charge status was confirmed.
- The optional charging status protocol may not be provided by this watch/firmware. Real phone + watch verification remains required. Bluetooth status reads are lower priority than critical alarm/timer watch stimuli.
- Browser-only test coverage: legacy GATT 2A1A charging, newer GATT 2BED charging, both absent, and a double-tap during a pending read; no physical BLE link was available for these tests.

## V2.0.6 confirmation/dialog, reconnection, and manual charge diagnostic

- Watch > Disconnect restores the confirmation dialog. The warning correctly states that disconnect disables direct watch stimuli, while Android-owned alarms/timers remain scheduled or active. Cancel performs no native call.
- With a connected watch, Reconnect watch is disabled and muted rather than remaining blue; Disconnect is a distinct muted-red action. When disconnected, Reconnect watch returns to the blue primary action.
- Watch Event log restores the count on the collapsed/expanded control, exactly as in the established V1.0.20 UI. Session History event counts remain available on each session's expand/collapse control.
- The official Pavlok app displays a charging indicator for the watch, but V2.0.5 showed neither standard GATT charging-status characteristic. V2.0.6 adds a manual, **read-only** Bluetooth characteristic inventory and up-to-12-candidate snapshot tool inside the expanded Event log. Capture once charging, unplug, capture again, and copy the Event log; comparing bytes identifies *candidates* for investigation, not confirmed charging state. No stimulation write, firmware command, or new characteristic subscription is added. The diagnostic is blocked during alarms/timers.
- Charging lightning bolt remains conservative: visible **only** on positively decoded charging status. No invented charging signal or permanent "Charging" label.

## V2.0.9 — fast charging diagnostics and opening-tab logic

- Live charging monitor is opt-in under Settings > Watch > Diagnostics (collapsed by default). It subscribes only to selected existing proprietary notification/indication streams, requiring BLE CCCD descriptor writes to enable/disable **notifications only** (not watch firmware alarm/timer commands or stimulation). It never attempts to infer or display a charging bolt from unverified values.
- Start the test once; when ready, plug/unplug at intervals as short as a couple seconds. The single marker button alternates between Mark plugged in and Mark unplugged, timestamping each change. Finish test, close Settings, and tap Watch > Event Log > Copy all. There is no full-snapshot UI. If no notifications appear, that is still diagnostic evidence, not proof that no charging signal exists.
- Monitoring refuses to start while Alarm or Timer is active and suspends logging on an active session; it stops on page background/disconnect. Existing native watch-button event subscription is preserved.
- Tab priority on app opening: active Alarm -> Alarms; active Timer -> Timer; newly stopped Alarm/Timer -> History **once per stopped session**, acknowledged persistently; first-ever launch -> Watch; otherwise -> Timer. Opening during an active session never consumes a History acknowledgment. Manual navigation remains available.
- No changes to native Alarm/Timer engines, stimulation ramp, scheduling, Snooze/Stop, or V1.0.20 archive.
- Browser mock tests passed startup and subsequent idle navigation, one-shot History, active alarm, explicit monitoring/marking, duplicate suppression, and stopping; APK compile and physical watch remain unverified.


## V2.0.9 UI simplification
- Watch Event Log retains Copy all, Clear, and Expand with event count; all charging test controls moved to Settings > Watch > Diagnostics.
- Removed the full snapshot UI and separate Plugged/Unplugged marker buttons.
- Single Start test / Finish test control plus one alternating Mark plugged in / Mark unplugged control.
- Start test enabled state refreshes on actual BLE connection events.
- Start with charger unplugged; optional diagnostic only, with watch status data retained in copied log.


### V2.0.9 Watch diagnostics placement
- All charging test controls are under Settings → Watch → Diagnostics, in a nested section collapsed by default.
- Watch Event Log has only its standard Expand/Collapse, Copy all, and Clear controls.
- Finishing or leaving Settings stops test monitoring; the event log remains intact and can be copied from Watch.
- Reopening Settings resets Diagnostics to collapsed. No Bluetooth write other than optional notification CCCD subscriptions/unsubscriptions; no watch alarm/timer write or stimulation.


## V2.0.9 charging/status/navigation/defaults update
- Native Android service passively subscribes to watch 0001 notifications after physical button stream. Four-byte packets end in 00 (unplugged) / 01 (plugged) based on ON/OFF cycle test.
- No watch firmware writes added. Charging indication only when a valid notification has been received on current connection. Disconnect clears state. Diagnostics may never unsubscribe the live charging stream.
- Battery reads do not wipe known native charge state. Watch and header use existing small white lightning bolts.
- First-ever installation stays on Watch for entire initial WebView visit; later idle start uses Timer. History after completed session still once.
- Fresh defaults: time readout enabled in Alarm and Timer, Time Readout start 40%, rise 10%/snooze. Existing saved defaults remain untouched.
- New alarm/timer notification channel IDs intentionally ensure sound None/vibration Off for existing installations; high-importance alert display and alarm/timer audio unchanged.
- Version code 209; Android applicationId remains com.projrcc.pavdroid.refresh.

## V2.0.10 release details
See `V2.0.10_NOTES.md` and the V2.0.10 test plan. This package is still source-only until the permanent-signing GitHub build succeeds; do not uninstall V2.0.9. The 2 new bundled PavDroid synthetic alarm sounds are intentionally not labeled or represented as the exact Freesound originals.


V2.0.21 acceptance: verify 10-second built-ins, real-time sequential rotation and no volume reset, local/global Add-from-Library previews, Enter action, and single Settings pulse.
