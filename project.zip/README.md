# PavDroid V1.0.15 — responsive layout at different zoom levels

Android app ID `com.projrcc.pavdroid` · `versionName 1.0.15` · `versionCode 115`.

## Baseline and scope

Complete native Android source based on **V1.0.14**. This update is intentionally **presentation-only**: the proven alarm, timer, watch BLE, music volume, zap ramp, scheduling, Snooze, Stop, and overlap-safety logic are unchanged. The original separate Pavlok Control V3.0.3 is not modified. The full-screen alarm concept is not included.

## UI adjustments

- Removed unused `SHOCK CLOCK 3 · NATIVE BLUETOOTH` eyebrow from app header. Retained PavDroid, version, battery, Settings gear.
- Renamed the navigation label **Connection → Watch** (the underlying tab ID remains `connection` to avoid behavioral changes); increased all four tab label sizes evenly.
- Timer preset **5m / 10m / 20m / 25m** labels now use larger, consistent text. Preset buttons wrap into additional rows when needed.
- **Tap middle button to snooze, hold to stop** now appears immediately under **Snooze time** inside both Alarm editor and Timer setup, not constrained to the narrow Timer heading.
- Alarm list description is split into two semantic lines, organized as schedule/stimulus counts then `Zaps Max 50% 2nd Launch · Music 2nd Launch` when enabled. Suppress irrelevant Zap/Music details; never use ellipsis that obscures configuration.
- Music/Zaps **Launch** stepper displays the ordinal on the first line and `Launch` on the second. Small superscript suffix retained; stepper boxes and adjacent buttons retain their previous heights.
- Responsive wraps for alarm/history actions, Timer presets, repeat/day presets, stimulation counts, Settings defaults and music volume pairs. No split +/- controls. At narrower widths, groups reflow and editor dialogs remain scrollable.
- Display version / Settings About / History export headers updated to V1.0.15. Notification channel IDs and Android category preferences are unchanged.

## Release workflow

Keep the 36-file source ZIP named **`project.zip`**. Replace only that ZIP in the root of `https://github.com/ProjRCC/PavDroid`; existing GitHub Actions builds the APK. Archive each release in its own Google Drive folder. Do not overwrite V1.0.14 or V1.0.13.

Source syntax and responsive browser tests do **not** substitute for GitHub APK compilation, testing the app on Samsung at all zoom/font sizes, or physical Shock Clock 3 tests. Debug signing-key changes may still require uninstall/reinstall separately from this UI change.
