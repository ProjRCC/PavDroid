# PavDroid V1.0.8 — Editor layout and music limits

Application ID: `com.projrcc.pavdroid`  
Version: `1.0.8` (`versionCode 108`)

**Baseline:** The complete tested-and-archived V1.0.7 source ZIP. Original Pavlok Control and all older PavDroid releases are unchanged. Android owns alarm/timer scheduling and sessions; watch BLE is only for stimuli and middle-button input.

## Changes

- Move **Preview** to the very bottom of both the alarm editor and timer configuration, *after* Snooze and Smart Timeout. Retain the existing live stimulus-preview content and styling.
- Add a small **Save alarm** button in the alarm editor's sticky top header, while retaining the original bottom **Save alarm**. Both use the exact same validated save operation, with a double-tap guard.
- Increase spacing between Snooze and Smart Timeout and above the bottom preview cards. Keep the original four-tab dark design.
- Link **Start volume** and **Increase per snooze** controls in alarms, timers, and both sets of new-item defaults so their sum cannot exceed **100%**. Example: starting at 80% limits increase to +20%; raising Start to 90% clamps Increase to +10%. Decreasing Start expands the allowed Increase range again. The increment control retains its previous 0–50%, 5-point step range, subject to the combined cap.
- Validate combined music values before saving an alarm or starting a timer. Defaults are auto-saved. Pre-existing scheduled alarms and active timer sessions are not bulk rewritten on upgrade; editing an older alarm normalizes out-of-range values.

## Build and test

Upload **only** the complete `project.zip` to the root of `ProjRCC/PavDroid`. The existing GitHub workflow remains `.github/workflows/build-apk.yml` and extracts the complete source. No separate README/workflow upload is required if they are unchanged at GitHub root.

JavaScript syntax, browser UI interactions (using a mock Android bridge), source diff, and ZIP integrity have been checked. The GitHub Actions APK compile and the physical phone/watch test still need to be completed by the user. Keep an independent wake-up alarm until longer unattended reliability is proven.
