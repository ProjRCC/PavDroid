# PavDroid V1.0.6 — Timer status and header cleanup

Application ID `com.projrcc.pavdroid` | `versionCode 106` | `versionName 1.0.6`

This is a complete Android project ZIP based directly on V1.0.5. V1.0.5 is a source-only candidate; V1.0.3 is the latest hardware-confirmed release. The separate original Pavlok Control V3.0.3 project must stay untouched.

## Changes in V1.0.6

- Settings control moved to the far-right end of the header **after the version label**.
- Replaced the prominent blue circular Unicode gear with a smaller **outlined gear** on a transparent button, retaining its tap target and Settings behavior.
- Hid the duplicate Timer heading status line. The existing Timer phase badge communicates Ready, Running, Snoozing, etc.; no longer show the extra Ready below the watch-button hint.
- Removed the other redundant Timer Ready status box, while preserving errors and meaningful timer messages. Changing a Timer preset clears stale status text.
- Preserved all V1.0.5 Settings, music, timer, alarm, History and BLE logic, IDs and stored preferences without modification.

## Build / source of truth

Replace only `project.zip` at the root of `ProjRCC/PavDroid`. The existing unchanged workflow stays at `.github/workflows/build-apk.yml`. Do not upload redundant README or workflow files.

Static source checks are not an Android APK build or a physical Shock Clock 3 test. See TEST_PLAN.md. Use a backup alarm until the new build is verified on the phone and watch.
