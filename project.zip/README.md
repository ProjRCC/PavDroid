# PavDroid V1.0.4 — Settings and music control

Application ID: `com.projrcc.pavdroid` | versionCode 104 | versionName 1.0.4

This is a targeted continuation of physically tested V1.0.3; the original Pavlok Control V3.0.3 repository and files are separate and unchanged.

## Changes

- Top-right Settings gear opens a compact modal (no new tab). Music library, Watch, Notifications, Defaults and About sections.
- Music: select multiple MP3 files using the Android document picker (persisted URI grants); select one globally active song, remove songs from the list, and preview playback. Change a song in Settings without editing individual alarms. The active song is synchronized to Android SharedPreferences for background alarm/timer starts. Old last-chosen or saved-alarm MP3 can be offered automatically after upgrade. Existing V1.0.3 alarms retain their full-volume, non-escalating music defaults until individually edited.
- Every music-enabled alarm starts music 10 seconds into its eligible firing. Choose "Play after N snoozes" (0 = initial firing). It plays again at each subsequent firing after Snooze. Per-alarm starting volume (10–100%) and per-snooze increase (+0–50 percentage points) cap at 100%. No separate Escalate checkbox. STOP or Snooze immediately silences audio and restores prior alarm-stream volume.
- Timers also offer "Play after N snoozes", with the same fixed 10-second delay and a Timer / Preview volume configured in Settings (default 100% for compatibility). There is no timer music-escalation setting in this release.
- New-alarm and new-timer Defaults: Buzzes, Beeps, Zaps, interval, zap intensity, snooze duration, and Smart Timeout. Changing defaults does not rewrite existing alarms or modify running sessions.
- Watch section includes in-app low battery warning threshold, low-intensity test controls (10% zap requires confirmation), and connection diagnostics shortcut. Red battery text below 15% remains unchanged. Android notification Settings shortcuts are in Notifications; Samsung controls notification presentation.
- Alarm active card: centered name and firing/snooze status in original dark UI; removed duplicate Snoozes/Snooze remaining boxes and obsolete watch-firmware reminder text.
- Alarm and timer notifications: compact Snoozing text "MM:SS remaining", STOP on left, Snooze/Mute on right during firing; timer Times Up body updated to "PavDroid timer is up". Connection tab retains detailed diagnostics while other screens have shorter text.
- GitHub Actions workflow stays in `.github/workflows/build-apk.yml` unchanged. The APK artifact label in it is older; Android version is defined by `app/build.gradle`.

## Build and release workflow

1. Upload **only `project.zip`** to the root of private GitHub repo `ProjRCC/PavDroid` (replace previous root archive). Do **not** replace the original Pavlok Control project.
2. GitHub Actions extracts `project.zip` and builds `:app:assembleDebug`.
3. Install/test Android APK with Shock Clock 3; inspect notifications, background snooze re-fires, music volume and source, BLE reconnection, session lock, and saved History.
4. Save this complete source ZIP under `/Pavlok/PavDroid/V1.0.4/` in Google Drive. Keep V1.0.3 and earlier version folders untouched.

## Evidence boundaries

Static checks / ZIP validation are not an APK build or hardware validation. Keep an independent backup alarm until multi-snooze overnight, reboot, Doze, audio routes, music volume restoration, and notification actions have been tested on the phone/watch. Preview volume uses the phone alarm audio route and can differ with OS volume policy.
