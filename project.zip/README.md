# PavDroid V1.0.2 — Native Bluetooth reconnection

**App ID:** `com.projrcc.pavdroid` · **Version:** 1.0.2 (code 102)  
**Baseline:** the user's preserved PavDroid V1.0.1 `project.zip` (323,709 bytes; SHA-256 `482764c748ef1f68f93dedf5f63882f71bba71f74302d3028db6ac9a2c07a5cd`), stored at `/Pavlok/PavDroid/V1.0.1/` in Google Drive.

PavDroid is a separate Android-owned alarm/timer app for Shock Clock 3. The original working **Pavlok Control V3.0.3**, its private repository, and the user-supplied Drive baseline are not modified.

## What changed in V1.0.2

- **Native Bluetooth reconnect:** The `WatchMonitorService`/`NativeBleBridge` own a single GATT connection. Initial direct connect stays fast; after a normal link loss, the native callback promptly registers a passive Android `autoConnect=true` request. During a normal out-of-range disconnect, the passive GATT stays registered so Android can reconnect when the watch returns, including while the page is hidden. Unexpected GATT failures close the failed client and schedule a bounded native re-arm; Android Doze can still delay that recovery timer. The WebView no longer runs a competing reconnect timer.
- **Native connection history:** Log GATT start/re-arm, errors, disconnects and successful native reconnects even without a visible WebView. Store last successful link and last disconnect timestamps locally. Connection status displays the native state, recorded timestamps, and a live *approximate* re-arm countdown when one is actually scheduled. While `autoConnect` is armed, the UI says Android is waiting for the saved watch instead of displaying a bogus static countdown.
- **No alarm-specific reconnect windows:** Removed two-minute pre-alarm BLE acceleration and the ten-minute disconnected-watch grace period. Alarm wakeups now start the Android alarm session immediately, whether or not the watch is connected. The phone shows a disconnected-watch warning, and any watch beep/buzz/zap can be sent only after normal native reconnection **while that session is still firing**. Stopped alarms never resume. Alarms skipped because another session is already active are still recorded as missed. Reboot, clock-change and package-update schedules carry the *actual scheduled due timestamp* to the receiver.
- **Icon:** Uses the previously generated square Android-watch/lightning artwork as the source for a shape-masked Android adaptive launcher icon (round, squircle, etc.), while keeping a square PNG fallback.
- **Version only:** The UI's typography, dark four-tab layout, History, timer/editor controls, alarm/timer settings, MP3, unlimited snoozes and Smart Timeout are carried forward unchanged from V1.0.1. Firmware-programmed watch alarm schedules remain independent and are not written by PavDroid.

## Important constraints

- A native `autoConnect` request is **not** a guarantee of instant reconnection or reliable overnight operation. Android may restrict foreground service execution, kill the app process, defer delayed callbacks or interrupt BLE. A *force-stopped* app cannot keep running. Explicit user Disconnect still disconnects.
- The Bluetooth service must be running with Nearby Devices permission and a previously chosen watch. Keep the **Watch connection** notification category allowed (Silent is fine) and on Samsung use an unrestricted battery setting during testing.
- For safety, PavDroid currently retains its original alarm/timer stimulus counts, interval, zap limits, manual stop controls and Smart Timeout. Disconnected alarm sessions cannot stimulate the watch until it reconnects. No firmware alarm is silently programmed as a backup.
- Validation for this source release is syntax, packaged assets, source checks and simulated WebView behavior **only**. The actual GitHub APK compilation and long locked-phone/watch-range tests have **not** been performed here. Retain a separate reliable backup alarm.

## Upload and release layout

- `project.zip` — complete Android Studio/Gradle source. Its filename must remain **exactly `project.zip`** in the GitHub repository root.
- `README.md` — this release's details; optional to update on GitHub.
- `.github/workflows/build-apk.yml` — existing working workflow retained unchanged in V1.0.2. Its artifact *label* can still say V1.0.1 even though the compiled APK itself is V1.0.2; do not mistake the artifact's filename for the Gradle version. A build-workflow edit is not needed for this release.

Google Drive version folder: `/Pavlok/PavDroid/V1.0.2/`. Do not overwrite `/Pavlok/PavDroid/V1.0.1/`, the baseline folder, or the original Pavlok Control files. Only `project.zip` needs replacement in the GitHub root for this release.
