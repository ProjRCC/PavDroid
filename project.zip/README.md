# PavDroid V1.0.7 — Small UI and music-control update

Application ID: `com.projrcc.pavdroid`  
Version: `1.0.7` (`versionCode 107`)

Complete Android source project. This release is built from the canonical V1.0.6 `project.zip` rather than from screenshots. Upload `project.zip` **alone** to the root of `ProjRCC/PavDroid` if the existing GitHub Actions workflow and README remain unchanged. The workflow is inside the archive at `.github/workflows/build-apk.yml`.

## What's changed

- **Music Settings:** Rename `Play selected` to `Preview selected`. Preview volume now changes the Android **Alarm** volume stream while preview is playing, instead of only scaling the MediaPlayer internally. The previous Alarm stream level is restored upon Stop, natural completion, or Activity exit.
- **Timer music:** Show the same compact `Start volume` and `Increase per snooze` steppers as Alarm. Save both values as part of each native timer session; escalating volume begins with the first eligible music firing and increases on each later Snooze, capped at 100%.
- **Settings defaults:** Separate `Music start` and `Music / snooze` values for newly created alarms and ready timers. Alarm defaults stay 30% +20%; timer defaults preserve the V1.0.6 timer-volume preference (normally 100%), with +0% increase unless changed. Changing defaults does not retroactively change a running session or saved alarm.
- **Watch test:** Choose 10–100% zap-test strength with an enclosed stepper (10% increments; default 10%) and confirm each zap. Test buzz/beep remain unchanged.
- **Smart Timeout:** Move to the bottom of both Alarm and Timer configuration, with a small information button revealing its 1h/2h behavior.
- **Zap behavior:** Replace the oversized Android dropdown popup with compact `Escalate` / `Full` buttons in the alarm editor, retaining the same saved `escalate` boolean.
- **Timer UI:** Remove redundant `Times Up` status text beneath the timer controls; preserve the `ALERTING` badge, notification, and real error messages.
- **Touch feedback:** Add a subtle pressed visual state on enabled buttons. Preserve the pre-existing Android-side short haptic tick on clickable controls.
- **Spacing:** Normalize spacing between the new music labels, steppers, and controls.

## Preservation / testing boundary

Do not modify `ProjRCC/Pavlok-Control-Native-Android` or any historical PavDroid version folder. Scheduled alarms and Android-owned sessions still belong to `PavDroidAlarmEngine` / `NativeTimerEngine`; Bluetooth remains owned by the foreground service. No change to the watch alarm schedule or firmware is included.

The source and browser checks are not an APK build or a physical-watch test. Run GitHub Actions and test on the actual Shock Clock 3 before relying on this version for waking. Keep an independent backup alarm until extended reliability passes. See `TEST_PLAN.md`.
