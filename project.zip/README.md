# PavDroid V1.0.14 — Terminology alignment (V1.0.13 preserved)

Android app ID `com.projrcc.pavdroid` · `versionName 1.0.14` · `versionCode 114`.

## Baseline and boundaries

This is a **targeted text and label update** based on the complete, watch-tested PavDroid V1.0.13 archive. The separately protected original Pavlok Control V3.0.3 is **not modified**. The full-screen interface is **not** implemented. Watch protocols, alarm/timer phase keys, scheduling, intervals, volume/zap logic, snooze/Stop logic, notification actions, and Settings values are unchanged.

## Changes

- User-facing alarm alert status uses **Alarm Activated**, not *Alarm Firing*. A scheduled, enabled alarm remains distinct from an alarm currently activated.
- User-facing completed timer alert uses **Time Expired**, not *Times Up* or *Timer Firing*. Countdown/snooze/stopped statuses are preserved.
- Music and Zap thresholds now read **Music starts: 1st Launch**, **Zaps start: 2nd Launch**, etc. Zero completed snoozes maps to **1st Launch**; one maps to **2nd Launch**, and so forth. This is display-only; storage fields `musicAfterSnoozes` and `zapsAfterSnoozes` are unchanged. The `st/nd/rd/th` suffix is smaller and raised without changing stepper dimensions or hit targets.
- The same wording is applied to the Alarm and Timer editors, Settings defaults, active status displays, native Android notification titles and channel display names, and History labels/exports. Internal machine states (e.g. `firing` and `alerting`) remain unchanged for compatibility.
- Notification **channel IDs are unchanged** (`pavdroid_active_alarm`, `pavlok_timer_finished_v218`, `pavlok_timer_progress_v218`). The user's existing per-category sound, vibration, priority, and pop-up choices are therefore not reset by newly created channels. Android may update the existing channel's display name while retaining the channel's user configuration.
- History exports now identify the build as **V1.0.14**, not the outdated V1.0.10 label. Historic V1.0.13 session events remain readable; their native stored state keys are not rewritten. Textual presentation can use the new terminology for old records.

## Release and verification

Source tree and ZIP retain the existing 36-file GitHub Actions layout. The existing `.github/workflows/build-apk.yml` extracts root `project.zip` and assembles the APK. Replace only that file in the repo root; do not change the original separate Android project. Keep previous version folders untouched.

JavaScript and HTML inline-script syntax were checked; a mocked Chromium WebView layout test opened Settings and Timer and verified `1st Launch` / `2nd Launch` labels without errors. **No local Android SDK** was present for actual APK compilation. Build using GitHub Actions, then validate notifications and behavior on the actual Shock Clock 3. A browser simulation cannot validate BLE electrical delivery or Android notification preferences on-device.

Signing remains a separate issue: if the GitHub debug signing key changes between builds, installing over the prior APK may require uninstalling. Do not confuse that with the text changes.
