# PavDroid 2.0.0 — REfresh (source-only test build)

**Status: rebuild candidate, not yet validated as an APK or with a Shock Clock 3.**

## Why this release exists

V1.0.19 failed at JavaScript initialization and exposed the old Pavlok Control firmware-alarm page. V1.0.20 (`preREfresh`) fixed that startup failure and is user-confirmed functional. This one-time REfresh moves PavDroid onto a clean, Android-only UI and package so that the old UI cannot reappear. No firmware alarm-list UI, Code Red, old watch timer configuration, firmware alarm programming, or hidden fallback page is included.

**V1.0.20 is untouched.** Its source ZIP and installed app remain the behavioral, hardware and visual reference. This project has a separate test application ID so both may be installed simultaneously, but do **not** connect both apps to the same watch simultaneously.

## Identity and source

- Version: **2.0.0**, versionCode **200**.
- Package / applicationId: `com.projrcc.pavdroid.refresh` (test-only; deliberately distinct from V1.x).
- Java namespace: `com.projrcc.pavdroid` (new, not `com.projectrcc.pavlokcontrol`).
- Architecture: Android's `AlarmManager` owns alarms and the native timer engine owns timers. The native service owns GATT background reconnection, button events, direct watch stimulation, audio/TTS, notifications, saved History.
- UI is now **only** `assets/index.html`, `styles.css`, `transport.js`, `app.js`. A separate CSS/JS model is provided from scratch and no longer uses the original control page as fallback.
- Existing working native algorithms from V1.0.20 for BLE GATT, Android alarm schedules, timer/stimulus, watch-button Snooze/Stop, music/TTS and notifications are intentionally *selectively reused* instead of riskily reverse-engineering another hardware protocol. Unnecessary legacy classes and firmware control operations were removed.
- Alarm and Timer options: **three equally spaced checkbox rows** for Safe Max (visible at >=60%), Time Readout, Smart Timeout; small inline info icons, subtle border, no internal dividers, directly above Preview. The Alarm editor has only bottom Cancel / Save actions.

## Building

The complete source is a root-level `project.zip`. Use the preexisting GitHub repository workflow (which extracts that ZIP) to compile an Android debug APK:

1. Keep the V1.0.20 `preREfresh` source/archive and installed app as a separate fallback.
2. To test V2 source, upload **only** this `project.zip` to a separate GitHub test branch or temporary build workspace, rather than replacing the current main-branch V1.0.20 ZIP.
3. Use JDK 17, Gradle 8.11.1, compile SDK 35, Android build tools 35.0.0; build `:app:assembleDebug`.
4. Install the test APK alongside V1.0.20. Android treats the two package IDs as distinct; this V2 test APK starts with separate local data (no automatic migration of alarms, MP3 permissions, History, or selected settings).
5. Grant Bluetooth, exact alarms and notification permissions; pair and configure the test app independently. Never use both simultaneously to drive the same watch.

The ZIP includes `.github/workflows/build-apk.yml` as a reference. If your repository already contains the unchanged wrapper workflow, it remains sufficient; only its display artifact label may still say V1.0.1.

## Important limitations

- Browser UI integration tests are not equivalent to a Java/Gradle build, an installed-phone test, or physical watch stimulation.
- Verify native behavior with safe, short buzz/beep-only tests first; do not use V2 as your only critical wake-up alarm until background reconnect, exact schedules, MP3/TTS, Snooze/Stop and repeated launches are checked on-device.
- The charging bolt only appears when the watch exposes a supported charging-status characteristic.
- Safe Max (50%) is not a medically validated electrical safety guarantee. Snooze/Stop and Smart Timeout continue to be available.
- Migration into the production V1.x package or replacement of the existing source is explicitly deferred pending user-approved physical verification.

See `TEST_PLAN.md` for per-feature acceptance cases.
