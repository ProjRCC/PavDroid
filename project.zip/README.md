# PavDroid V1.0.10 — Music / Zap escalation and grouped defaults

Android application ID: `com.projrcc.pavdroid` · `versionName 1.0.10` · `versionCode 110`.

## Baseline

This complete source is derived from the approved PavDroid V1.0.9 `project.zip`. The separate **Pavlok Control V3.0.3** reference app/repository is untouched. Android still owns scheduled alarms, timer state, Snooze, Stop, music, and repeated watch stimuli; the Shock Clock 3 remains the BLE watch/button accessory.

## V1.0.10 changes

- **Music escalation within a firing:** Each Alarm and Timer editor has `Play after` (number of completed Snoozes), `Start volume`, `Increase by` (percentage points), and `Increase every` (seconds, in 5-second steps, 5–120 seconds). Music starts 10 seconds into an eligible firing, increases repeatedly at the selected interval while playing up to 100%, then stops immediately on Snooze/Stop. Escalation restarts from Start volume on subsequent firings. Media volume uses Android's reported stream level, which may be quantized to discrete steps, and the previous Media volume is restored on Stop/Snooze.
- **Native zap escalation:** Zaps may be held until a configured count of completed Snoozes. Once eligible, each firing starts at 10% and increases by 10 percentage points per queued zap, capped at the user's configured **maximum zap intensity**. The existing native 12-zap-per-firing limit and queue cancellation on Snooze/Stop remain; physical delivery must be tested separately from queued commands. Buzz and beep counts are unchanged.
- **Settings defaults:** Separate per-new-Alarm and per-new-Timer groups for **Stimuli**, **Zaps** (count, maximum intensity, Snoozes before zaps), and **Music** (Snoozes before music, Start, Increase by, Increase every). Defaults are auto-saved and affect new configurations only; they do not overwrite existing scheduled alarms or active timers.
- **Music editor:** Expanded by default when enabled, with a small **−** control to collapse and **+** to expand without changing saved settings.
- **Android shortcuts:** Settings contains App info and Notifications buttons that open Android's own application settings pages.
- **History:** The structured/legacy double-count guard prevents a phantom duplicate Timer History session in the specific overlapping-start case. The export header now identifies V1.0.10.

## Package / build

The source ZIP **must be named exactly `project.zip`** and uploaded to the root of `ProjRCC/PavDroid`, replacing only the prior root ZIP. The existing GitHub Actions workflow remains at `.github/workflows/build-apk.yml` and uses `:app:assembleDebug`. Do not re-upload unchanged README or workflow files outside the ZIP.

**Signing note:** The current debug workflow does not yet use a persistent signing key, so an APK built on a new GitHub runner may not install over the existing app. Do not uninstall without first exporting History and considering saved settings. The planned consistent-signing workflow change is separate, not included in this release.

## Verification status

The 36-file project, Java syntax parse, JavaScript syntax, and browser/UI mock tests may be checked without an Android SDK. These checks do not prove APK compilation, notification reliability, actual watch pulse intensity, Media volume changes, or unattended wake-up behavior. Test with low-intensity zaps only after buzz/beep behavior is established and keep a backup wake-up alarm during validation.
