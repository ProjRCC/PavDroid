# PavDroid V1.0.13 — Settings layout and dynamic interval minimum

Android app ID `com.projrcc.pavdroid` · `versionName 1.0.13` · `versionCode 113`.

## Baseline

This is a targeted modification of the complete archived PavDroid **V1.0.12** source. The original Pavlok Control V3.0.3 is a separate protected reference and has not been modified. The existing alarm, timer, music and BLE architecture is preserved except for the stimulus-interval validation change described below.

## Changes

- **Settings always opens** in the requested order: **Defaults**, **Music**, **Watch**, **Android**, **About**, each with one small matching icon. Defaults is expanded; New alarms and New timers are collapsed; all other main sections are collapsed. Section folding is presentation-only and resets to this opening layout each time Settings opens; it no longer persists collapse preferences.
- Expanding New alarms or New timers shows all three groups — **Stimuli, Zaps, Music** — fully expanded at once. They have no separate +/− fold controls. Smart Timeout remains inside Stimuli.
- **Stimulus interval** for Android-owned alarms and timers is allowed from a dynamic minimum up to 30 seconds. **Minimum = max(3 seconds, max(buzz count, beep count) + 1 second)**. Do **not** sum Buzzes and Beeps. Examples: 5 buzz/5 beep → 6s min; 5 buzz/2 beep → 6s; 3 buzz/2 beep → 4s; 2 buzz/2 beep → 3s; 0 buzz/0 beep with zaps → 3s. Changing a count raises a now-too-low interval automatically, but lowering counts does not shorten a deliberately longer interval. Native alarm and timer engines also clamp intervals on loading/starting; Settings defaults and both editors use the same constraint.
- **Music volume increase every** supports 3s and the existing 5s, 10s, 15s...120s sequence in Settings defaults and the Alarm/Timer editors, with corresponding native 3s lower bounds.
- Previously stored defaults and alarm configuration are retained, except a previously stored interval is raised when it cannot satisfy the new count-dependent minimum. No other session behavior is intentionally changed.

## Test evidence and limitations

- JavaScript and inline-script syntax checked; isolated Chromium tests passed the Settings open/reopen behavior, icon order, subsections, dynamic interval min, reset-to-defaults behavior, and special 3/5/10s music increase sequence.
- The ZIP and source tree are complete. Full Android compilation has **not** run locally because an Android SDK is unavailable. A successful GitHub Actions build, installed APK, and physical Shock Clock 3 tests remain necessary.
- Keep a separate backup alarm during endurance and new timing tests. Physical BLE delivery is not established by source/browser tests alone.

## Release procedure

Upload/replace only the complete **`project.zip`** at the root of `ProjRCC/PavDroid`. Its existing `.github/workflows/build-apk.yml` extracts the archive and builds the APK. No need to re-upload unchanged README/workflow files separately. Store each complete ZIP in its own version-numbered Google Drive folder and keep older versions untouched.

**Uninstall-free upgrades:** Stable APK signing remains an unresolved separate workflow task. The current debug-build signing may require uninstalling an APK signed by a different key.
