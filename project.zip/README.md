# PavDroid V1.0.3 — notification safety and UI refinement

**Application:** `com.projrcc.pavdroid` · **Version:** 1.0.3 (code 103)

**Baseline:** user's tested **PavDroid V1.0.2** `project.zip` from `/Pavlok/PavDroid/V1.0.2/` in Google Drive. V1.0.2 physically passed automatic Bluetooth reconnection with phone locked/app swiped away/Watch connection notification disabled, as well as scheduled alarm with buzz, beep, zap and music started on schedule in locked-phone tests.

## V1.0.3 changes

- **Notification actions:** When firing, the native Android alarm and timer notification actions are now **STOP** first (left), **Snooze / Mute** second (right) when MP3 is configured, or **Snooze** when no music is configured. Snooze already stops MP3 immediately and restores volume. Timer countdown notification keeps Pause/Resume; its STOP is also first. During snooze, only STOP is available. Android/Samsung owns the actual action button widths; 30/70 widths cannot be guaranteed using native notification actions, and a custom notification layout was intentionally avoided to preserve high-priority/lockscreen behavior.
- **Remove obsolete alarm notification system:** The old watch-firmware `Alarm alerts` and `Alarm snooze` channels were not used by PavDroid’s Android-owned alarms. Deleted the dormant `AlarmNotifications.java` implementation, its unused watch-alarm notification action handler, and the automatic creation of those channels. On upgrade, PavDroid retires both old Android notification channel IDs exactly once; the active `pavdroid_active_alarm` channel and its user preferences are preserved. The old SnoozeGuard telemetry ledger is retained for historical watch event diagnostics, but cannot create a legacy watch alarm notification.
- **Channel grouping:** Existing `pavdroid_active_alarm` channel is now assigned to the **Alarm** group when Android allows it. Its ID is retained so system user settings are not reset. Notification Settings group order is controlled by Android/Samsung; the app cannot reliably rearrange Connections, Alarm, Timer, Other.
- **Timer History:** Timer chart begins at **Times Up**, excluding the initial countdown from colored timeline and legend. Original countdown/start events and duration remain in each session's expanded event log and summary. Alarm timelines are unchanged.
- **Battery colors:** Header and Connection battery label/value are white at 15–100%, red below 15%, and white/dash when disconnected.
- **Launcher icon:** Uses user-approved blue/white flat watch/Android/lightning icon, with square legacy asset and adaptive launcher foreground/background for Android masks.

## Unchanged

- V1.0.2 native background automatic GATT reconnection, logs, alarm scheduling, one-session safety rules, music timing and stopping, Smart Timeout, seven-minute default snooze, watch middle-button Snooze/Stop, native watch stimuli, four-tab UI, and saved History system.
- Pavlok Control V3.0.3 and the original project are untouched.

## Build and deployment

Replace **only `project.zip`** at the root of `ProjRCC/PavDroid` GitHub repo. The current `README.md` and `.github/workflows/build-apk.yml` in GitHub need not be replaced for APK compilation; source ZIP carries updated README and TEST_PLAN. The existing workflow may retain an old artifact filename (V1.0.1) even when the APK is V1.0.3. Do not upload a second workflow at repo root.

All three archival release files are placed together in `/Pavlok/PavDroid/V1.0.3/`. Prior version folders are preserved.

## Validation limits

Source syntax checks, ZIP integrity, and visual asset checks do not constitute Android APK compilation or physical watch tests. After GitHub Actions builds, verify both alarm and timer native notification action order/labels on the device, notification channel grouping in Samsung Settings, battery colors, and history timelines without losing V1.0.2 background behavior. A native action may be visually equal-width regardless of label length; STOP remains left as the safer layout.
