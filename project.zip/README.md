# Pavlok Control V3.0.3 — native Android source

**Source release:** 20 November 2026. **Installable APK not included.** Build the APK using `.github/workflows/build-apk.yml` (Android 35 / Gradle 8.11.1 / Java 17). All releases of the complete source must be named **`project.zip`**.

## Scope

V3.0 is a **reliability reset** of the V2.0.50 source, **not a wholesale replacement of working hardware protocols**. The app is an offline native Android APK with a WebView presentation layer. It preserves the established Connection, Alarms, Timer and History screens, watch BLE protocol, firmware alarm editing, notifications, and pulse/zap settings. The only intentional layout redesign is the full-width, slim **+ New alarm** action: fixed at 39 px, independent of text wrapping, so saved alarms remain visible.

## Four separate responsibilities

1. **Connection:** `NativeBleBridge` + `WatchMonitorService` own the GATT watch connection, subscription and background monitoring. Bluetooth **Connected** is not proof that the watch-alarm list was read.
2. **Alarms:** the watch owns stored alarms, five-minute snoozes and firmware's thirty-minute automatic cutoff. Whole-list writes require a fresh, trusted readback and are forbidden while an alarm or timer is active. An unexpected `0 alarms` response **does not replace** a nonempty verified view or modify phone Code Red configuration. It is labeled **Unverified**; a user can independently confirm a truly empty watch. Empty confirmed after a deliberate delete-all write is allowed.
3. **Timer:** `NativeTimerEngine` owns the phone-side countdown, notification controls, watch stimuli, snooze, reset and zap cap. Existing timers cannot be overwritten by a new manual timer or Code Red. Watch stimuli require Bluetooth, but the Android countdown itself is persisted.
4. **History:** persistent `EventJournal` is separate from the clearable Connection log. Snooze dots remain gold; white outline = phone, black outline = watch (watch origin inferred when no phone request is logged). Parent Code Red backup is one alarm session. An unconfirmed backup is clearly distinguished from a completed session.

## Code Red contract — V3

- New alarm checkbox `ⓘ Code Red 🔴 [Enable]` defaults off. Checking Enable reveals `Play MP3 after [10] seconds without user input`; checking that reveals **Select MP3**. No disclosure arrow. The optional MP3 never substitutes for the watch backup timer.
- At the **first watch-confirmed FIRING**, the Android service freezes a **persisted episode configuration**. The **first confirmed SNOOZED** arms the handoff; subsequent snoozes do not move the first firing timestamp. Alarm may be FIRING or SNOOZING at its firmware cutoff.
- Intended handoff at **30:05 after first firing** (five seconds after watch cutoff): start an independent **300 s** Android timer. Code Red settings are independent of manual timer preferences: 3 buzzes, 3 beeps, 1 zap at 60%, stimulus interval 8 s, optional 30% confirmation buzz. At Times Up, watch stimuli follow the existing timer engine; MP3 can play if selected. Manual or physical Stop ends the timer.
- Alarm-list refreshes, Bluetooth loss and WebView recreation **cannot mutate the frozen episode configuration**. A zero read cannot turn an armed backup into the retired MP3-only path. When the timer actually enters countdown, the one-shot completion is committed; a thrown start exception is logged and retried while inside the existing 10-minute recovery window. If another timer owns the slot, no overwrite occurs and an explicit failure is logged.
- `Alarms & reminders` access enables precise Android wake-up scheduling. Without it, the inexact fallback can run late; exact access is **not** a guarantee of execution. Background/locked-phone and real watch verification are required. Do not rely on this prototype as the only wake-up alarm.
- If the phone has stale watch FIRING/SNOOZED state after firmware cutoff, a separately verified armed Code Red episode can still start its own timer; that timer retains physical/notification Snooze/Stop authority. This exception **does not** relax normal manual alarm/timer mutual exclusion.

## Diagnosing the November 20 failure

The 2:54:05 PM alarm was armed at 2:54:10, was subsequently read as zero multiple times, and reached firmware cutoff at 3:24:05. Android delivered the 3:24:10 handoff on time, but V2 logged `Code Red MP3-only handoff skipped: no readable audio file configured`. V3 removes that path for enabled Code Red, protects the initial snapshot, and marks unexpected zero reads as unverified instead of propagating them to native configuration. These are source-level changes, **not** an observed successful real thirty-minute handoff.

## Reconnect and event logging

`native-ble.js` clears previous WebView characteristic listeners on each new BLE connection and suppresses duplicate identical indications received within 200 ms. Genuine firmware repeats separated by seconds still arrive. This addresses the source of multiplied `Alarm 1 snoozed` / `Alarm 1 firing` entries after repeated reconnects without rewriting native GATT handling.

## Validation and installation

Completed locally: JS syntax checks; browser layout and Code Red progressive-disclosure interactions at 320, 380 and 412 px; duplicate-BLE-listener regression simulation; ZIP integrity checks. **Not performed:** Gradle/Android Java compilation, APK installation, phone permission round-trip, full BLE/watch write-read verification, real Code Red 30:05 test, screen-off/Doze timing, MP3 hardware playback, and physical watch Snooze/Stop tests. Use the provided `TEST_PLAN.md` to verify. Prefer installing over the current package, not uninstalling, to retain local history and MP3 URI permissions when compatible.

## V3.0.2 notification defaults (fresh installation)

The *Connections* notification group's **Timer connection warning** channel is created with `IMPORTANCE_NONE` (Off). **Watch connection** is also initially created with `IMPORTANCE_NONE` to honor the requested default, **but it is the mandatory foreground-service notification** for background Bluetooth monitoring. Android can automatically elevate such a channel back to LOW when the foreground service starts, so the displayed toggle is **not guaranteed to remain Off**. Do not suppress the foreground service or its required notification to force this UI preference. The alarm, alarm snooze, upcoming alarm, Code Red music, timer alert, and timer countdown channels are unchanged.

The user normally uninstalls before each test, so these are fresh-channel defaults. Uninstalling deletes on-phone history, settings, locally chosen MP3 URI permissions and saved Code Red metadata. The GitHub workflow creates a debug APK on a fresh runner, which normally has a different debug signing key and therefore **cannot update** the previously installed debug APK in place. Stable signing would require a persistent protected signing key.


## V3.0.2 — History selection and connection notification

- History now labels the unfiltered action **Export All**. After choosing one or more session checkboxes, the controls read **Delete Selected** / **Export Selected**. Clearing selection restores **Delete All** / **Export All**. The existing export filtering is preserved. Selection is disabled when there are zero saved sessions, so an empty History never says Done.
- The **Watch connection** foreground-service notification is no longer forcibly marked `ongoing`. Android 13+ may let a user swipe it away; the BLE monitoring foreground service remains in place. This does **not** guarantee the system will keep it hidden, since Android controls foreground-service notification behavior and reconnect/status changes may post it again. The notification channel itself is still requested `IMPORTANCE_NONE` at creation; Android can elevate it for a foreground service.
- No watch BLE, Code Red scheduler, alarm, timer, or archive logic changed. Android build and physical-device behavior remain unverified.

## V3.0.3 — alarm names and stop-origin audit

- When a verified watch-alarm list is read, the Android service stores **all alarm names** independently of whether Code Red is enabled. At the first watch-confirmed firing it journals `Watch alarm identity #N: <name> (verified name snapshot)`. History uses that episode-specific name for the session heading and export; it retains `(watch #N)` in the export for BLE diagnostics. The raw append-only event file preserves the original watch slot number. Existing history from older versions without an identity snapshot can only resolve a name while the corresponding current watch alarm is still known.
- Watch `DISMISSED` does not include a reason. V3.0.3 records an explicit classification: `PHONE_STOP_CONFIRMED` (recent phone Stop request plus watch confirmation), `WATCH_LONG_PRESS_CONFIRMED` (physical long-button packet received), `WATCH_STOP_INFERRED` (early dismissal without a phone Stop or a matching long-press packet), `AUTO_CUTOFF_INFERRED` (near firmware's thirty-minute limit), or `UNKNOWN`. **Inference is never presented as a verified button press.** The native timer event observer now logs long presses even during a watch alarm, without hijacking the alarm or starting a timer.
- A late physical long-press packet, arriving within five seconds after `DISMISSED`, produces an upgraded confirmed source record. History includes that diagnostic while keeping the actual session end time at the original dismissal; no separate session is created.
- An early dismissal of an armed Code Red episode records `Code Red CANCELED` **before** the final dismissal line, including whether the scheduled 30:05 wake-up was canceled or an owned timer reset. The familiar Code Red automatic-cutoff path remains unchanged. This helps distinguish an intentionally stopped short test from a failed handoff.
- **Export All / Delete All** remain the default History actions. Checking one or more sessions changes the labels to **Export Selected / Delete Selected**. In selection mode with no checked sessions the actions are disabled, so pressing Select cannot accidentally Delete All. Empty history also disables the actions.
- Source-level and simulated WebView tests at 320 / 380 / 412 px cover names, stop-source attribution (including a delayed long press), cancellation messages, selected-session export, and action safety. **Not yet verified:** Android/Gradle compilation, phone-side native diagnostics and any physical-watch test. Do not depend on this prototype as the only wake-up mechanism.
