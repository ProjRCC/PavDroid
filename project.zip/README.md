# PavDroid V1.0.17 - Repeating stimulus correction

Android app ID `com.projrcc.pavdroid` | `versionName 1.0.17` | `versionCode 117`.

## Why this correction exists

V1.0.16 improved responsive layouts, notification channels, nine-hour Alarm Upcoming reminders and the optional Safe Max control. It **did not** correct the 12-zap-per-launch cutoff exposed by a real V1.0.15 November 22 alarm. During that alarm, 12 zap commands were queued between 7:09:48 and 7:14:12 AM, but the alarm remained active until 8:42:11 AM. Music was disabled. The user explicitly requested that repeated alert stimulus scheduling not silently cease at the 12th zap.

**V1.0.17 corrects the native alarm and timer engines** instead of hiding the issue or changing a notification display. For enabled zaps, the stimulation pattern continues through successive cycles rather than stopping after a fixed 12-pulse count. An alarm or timer is still interrupted by Snooze or ended by Stop/Smart Timeout; it is not an independent always-on shock mode. An unchecked Smart Timeout removes the automatic session cutoff, so extended exposure risk must be understood.

## Exact native sequence semantics

- Each alert Launch starts with fresh zap counter **0**, including after a real Snooze and reactivation.
- Intensity begins **10%**, increments **10 percentage points per successfully queued zap** until reaching the user-selected Maximum Zap Intensity; subsequent zaps remain at that chosen maximum if Safe Max is unchecked.
- `Safe Max (50%)` is **shown only when selected Maximum Zap Intensity is at least 60%**. If checked, the initial ramp reaches the selected maximum **once**, and subsequent queued zaps use **50%**, a repeated-pulse intensity ceiling. This is not a medically validated safety threshold.
- Each native engine now persists the actual running zap count with **no 12-count clamp**, avoids multiplication overflow in intensity calculations, and logs `Zap NN% queued (#N this launch)` instead of `N/12`.
- Timer-only-zap profiles no longer automatically end when 12 pulses have been sent. Both engines maintain the existing stimulus-group spacing, BT queue guard, no-zap-before-user-selected-Launch rule, Snooze, Stop and Smart Timeout paths.
- The legacy browser fallback had its redundant 12-count cutoff removed for source consistency; the **native Android engines** are the supported PavDroid runtime.

## Unchanged V1.0.16 features (pending physical verification)

- Same Alarm and Timer layout/control structure, 0.2-second intensity slider hold, 60-80% red presentation, >=90% white ring and red/high-contrast intensity steppers, optional Safe Max control, and Smart Timeout below Preview.
- Readable large-font/responsive layouts and button wrapping; Watch / Alarms / Timer / History navigation.
- `Alarm Upcoming` quiet notification starting nine hours before the next enabled Android-owned alarm; shared quiet `Snooze Countdown` category; existing native notification channel IDs retained to protect prior sound, vibration, and popup choices.
- Native Android owns alarms/timers; watch supplies BLE stimuli and middle-button tap Snooze / long hold Stop. One active session. Music volume ramp/restoration and local History remain unchanged.

## Safety / evidence boundary

The chosen intensity maximum and optional 50% repeated-pulse ceiling are **not** proof of medical safety under frequent or prolonged electrical stimulation. The 12-pulse cutoff removal increases possible exposure; Smart Timeout should remain enabled for unattended use. Begin testing with buzz/beep or very low zap settings, verify physical Stop, Snooze and Smart Timeout before considering any long session. Never assume a logged `queued` stimulus was delivered to the wrist. Use an independent backup alarm for critical mornings while evaluating releases.

V1.0.17 is a **source release only** until a real GitHub Gradle build and phone/watch acceptance tests have passed. Static JS checks, source review and ZIP integrity do not establish APK compilation or physical watch behavior. In-place debug APK updates may be blocked by changing signing keys; exporting History before uninstall prevents loss of saved test evidence.

## Release workflow

- Canonical source: complete ZIP named **`project.zip`**, in its own `/Pavlok/PavDroid/V1.0.17/` Drive folder. Keep V1.0.16 and V1.0.15 untouched.
- User manually replaces only the root `project.zip` in <https://github.com/ProjRCC/PavDroid>; the existing `.github/workflows/build-apk.yml` builds a debug APK.
- Original separate Pavlok Control V3.0.3 code, firmware-owned alarms and archives are never edited in this release.

## Prior V1.0.16 work retained

The previous release introduced the new notification channel structure, nine-hour upcoming-alarm reminder, editor safety controls, matching Alarm/Timer editors, and larger-font layout improvements. This corrective release retains those changes; it does not add a full-screen alarm interface or alter the watch firmware alarm protocol.
