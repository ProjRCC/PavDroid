**V1.0.20 hotfix (November 23, 2026):** Fix the PavDroid WebView adapter startup regression introduced in V1.0.19. Music change listeners referenced an uninitialized const and stopped all subsequent native-alarm UI hooks, leaving the inherited firmware UI active and producing misleading blocked-firmware-command warnings. The handlers are now attached after the function is initialized. No changes to native alarm/timer timing or Bluetooth stimulus handling. Source-only verification; install/watch tests pending.

# PavDroid V1.0.20 — Time Readout and editor options

Android app ID `com.projrcc.pavdroid` | `versionName 1.0.20` | `versionCode 120`.

**Status:** Complete source candidate. The original V1.0.18 physical tests do NOT verify these new changes. GitHub Gradle APK compilation, phone TTS, BLE charging indicator and physical watch tests are pending.

## Changes since V1.0.18

- Alarm and Timer editors now have a compact shared options group **directly above Preview**: conditional Safe Max (50%), Time Readout, and Smart Timeout. Each has an info button directly after the label. Time Readout's info includes a functional Go to Settings shortcut, preserving an unsaved alarm editor across the Settings visit.
- The existing `Include Music` option shows an actionable Go to Settings → Music prompt if enabled without a selected track. Closing Settings restores an unsaved alarm editor, without silently saving or dismissing its input.
- Time Readout is an optional checkbox on each Alarm and Timer (off by default for existing and new configurations). On a **confirmed Snooze**, immediately after stopping the selected MP3, Android TextToSpeech says the ordinal Snooze number and **actual current phone time**, e.g. "First snooze. 6:40 AM.". Its output uses phone audio only; Snooze timing, repeated BLE stimulus, Stop and music relaunch behavior are untouched. Stop cancels ongoing speech. No TTS engine or downloaded offline voice means playback may be unavailable; the snooze still works.
- Settings **Advanced**, placed directly below Android, controls Time Readout global **Starting volume** 10–100% (default 20%) and **Increase per Snooze** 0–50 points in steps of 10 (default +10). First Snooze uses starting level; later Snoozes increase by configured increments to a 100% ceiling. Starting level + increase never exceeds 100%; raising start to 100 reduces increase to 0, lowering start later restores the stored preferred increase when possible. The phone's prior MEDIA volume is restored after speech finishes or stops. These volume controls are not duplicated in the editors.
- A new Alarm/Timer configuration with selected maximum intensity >=60% starts with the Safe Max checkbox checked automatically; configurations at <=50% hide the checkbox. Existing saved alarm and timer choices, particularly a saved unchecked Safe Max at high intensity, are preserved. On a fresh configuration, increasing the slider to 60% auto-checks until the user manually chooses otherwise.
- Battery percentage is refreshed on return to the app and approximately every 15 seconds while the visible screen is connected and no alarm/timer/stimulus command is active. No background battery-poll loop was introduced. A small white bolt appears next to the percentage in the header and Watch card **only when supported BLE Battery Power State 0x2A1A explicitly reports Charging**. This is an optional/deprecated characteristic and its availability on the Shock Clock 3 is NOT confirmed; the UI does not infer charging from percentage increases.
- The Android TTS engine is initialized when first used, with a pending speech phrase while initialization finishes. TTS configuration is persisted in native preferences, independent of WebView lifetime, and the app declares the Android 11+ TTS-service query.

## Preserved from V1.0.18

- The four-tab navy user interface, responsive days and timer preset layouts, day-mask highlights, MP3 per-Launch playback and ramp, seven-minute standard alarm Snooze, 0.2s intensity hold protection, Smart Timeout rules, native BLE reconnection, watch tap=Snooze/hold=Stop, direct watch stimulation and accurate alarm schedule.
- The no-12-zap-cutoff logic introduced in V1.0.17 is unchanged; do not treat it as endurance-tested beyond #12.
- One active alarm or timer at a time, including the real 6:40 AM Nov 23 scheduled WakeUp miss during an existing Timer Snooze; no auto-overlap substitution.
- All original Pavlok Control V3.0.3 files/repository untouched.

## Release procedure and evidence boundary

Package the **complete** source project as exactly `project.zip` in a dedicated `/Pavlok/PavDroid/V1.0.20/` folder, never overwrite earlier versions. Upload ONLY the root ZIP to `ProjRCC/PavDroid`, then run GitHub Actions `:app:assembleDebug`, install on Samsung, and test on the real watch. `queued` zap commands do not demonstrate delivered electrical pulses. A repeated 50% shock level is not medically validated as safe. Use a backup wake-up alarm while validating the new build. Battery charge icon is intentionally absent when charge telemetry is unsupported.

---

# PavDroid V1.0.18 (previous release) - Responsive alarm days and timer presets

Android app ID `com.projrcc.pavdroid` | `versionName 1.0.18` | `versionCode 118`.


## V1.0.18 changes (UI and alarm-editor feedback only)

- Alarm day presets: ONCE, Weekdays, Weekends on the first row at normal compact widths; **Every day** uses a thinner full-width second row. All four sit on one row if their real text widths comfortably fit at the current font size. Buttons remain responsive at larger Android text / display zoom.
- Preset highlights are **derived from the selected weekday mask**, never from last touched button: ONCE iff no weekdays selected, Weekdays iff all Monday-Friday selected, Weekends iff both Saturday and Sunday selected, Every day iff all seven are selected. More than one qualifying preset may highlight at once. One or two arbitrary selected days do **not** mean ONCE. Time and AM/PM are independent.
- Timer presets: exactly 1m, 5m, 10m / 15m, 20m, 25m in a fixed three-column/two-row grid. Timer remains 5m by default.
- No change to native alarms, timers, BLE, zap limits/intensity, notification channels, Snooze, Stop, Smart Timeout or history mechanisms other than release labels.

## V1.0.17 behavior preserved

## Why this correction exists

V1.0.16 improved responsive layouts, notification channels, nine-hour Alarm Upcoming reminders and the optional Safe Max control. It **did not** correct the 12-zap-per-launch cutoff exposed by a real V1.0.15 November 22 alarm. During that alarm, 12 zap commands were queued between 7:09:48 and 7:14:12 AM, but the alarm remained active until 8:42:11 AM. Music was disabled. The user explicitly requested that repeated alert stimulus scheduling not silently cease at the 12th zap.

**V1.0.17 corrects the native alarm and timer engines** instead of hiding the issue or changing a notification display. For enabled zaps, the stimulation pattern continues through successive cycles rather than stopping after a fixed 12-pulse count. An alarm or timer is still interrupted by Snooze or ended by Stop/Smart Timeout; it is not an independent always-on shock mode. An unchecked Smart Timeout removes the automatic session cutoff, so extended exposure risk must be understood.

## Exact native sequence semantics

- Each alert Launch starts with fresh zap counter **0**, including after a real Snooze and reactivation.
- Intensity begins **10%**, increments **10 percentage points per successfully queued zap** until reaching the user-selected Maximum Zap Intensity; subsequent zaps remain at that chosen maximum if Safe Max is unchecked.
- `Safe Max (50%)` is **shown only when selected Maximum Zap Intensity is at least 60%**. If checked, the initial ramp reaches the selected maximum **once**, and subsequent queued zaps use **50%**, a repeated-pulse intensity ceiling. This is not a medically validated safety threshold.
- Each native engine now persists the actual running zap count with **no 12-count clamp**, avoids multiplication overflow in intensity calculations, and logs `Zap NN% queued (#N this launch)` instead of `N/12`.
- Timer-only-zap profiles no longer automatically end when 12 pulses have been sent. Both engines maintain the existing stimulus-group spacing, BT queue guard, no-zap-before-user-selected-Launch rule, Snooze, Stop and Smart Timeout paths.
- The legacy browser fallback had its redundant 12-count cutoff removed for source consistency; the **native Android engines** are the supported PavDroid runtime.

## Unchanged V1.0.16 features (pending physical verification)

- Same Alarm and Timer layout/control structure, 0.2-second intensity slider hold, 60-80% red presentation, >=90% white ring and red/high-contrast intensity steppers, optional Safe Max control, and Smart Timeout below Preview.
- Readable large-font/responsive layouts and button wrapping; Watch / Alarms / Timer / History navigation.
- `Alarm Upcoming` quiet notification starting nine hours before the next enabled Android-owned alarm; shared quiet `Snooze Countdown` category; existing native notification channel IDs retained to protect prior sound, vibration, and popup choices.
- Native Android owns alarms/timers; watch supplies BLE stimuli and middle-button tap Snooze / long hold Stop. One active session. Music volume ramp/restoration and local History remain unchanged.

## Safety / evidence boundary

The chosen intensity maximum and optional 50% repeated-pulse ceiling are **not** proof of medical safety under frequent or prolonged electrical stimulation. The 12-pulse cutoff removal increases possible exposure; Smart Timeout should remain enabled for unattended use. Begin testing with buzz/beep or very low zap settings, verify physical Stop, Snooze and Smart Timeout before considering any long session. Never assume a logged `queued` stimulus was delivered to the wrist. Use an independent backup alarm for critical mornings while evaluating releases.

V1.0.18 is a **source release only** until a real GitHub Gradle build and phone/watch acceptance tests have passed. Static JS checks, source review and ZIP integrity do not establish APK compilation or physical watch behavior. In-place debug APK updates may be blocked by changing signing keys; exporting History before uninstall prevents loss of saved test evidence.

## Release workflow

- Canonical source: complete ZIP named **`project.zip`**, in its own `/Pavlok/PavDroid/V1.0.18/` Drive folder. Keep V1.0.17 and earlier versions untouched.
- User manually replaces only the root `project.zip` in <https://github.com/ProjRCC/PavDroid>; the existing `.github/workflows/build-apk.yml` builds a debug APK.
- Original separate Pavlok Control V3.0.3 code, firmware-owned alarms and archives are never edited in this release.

## Prior V1.0.16 work retained

The previous release introduced the new notification channel structure, nine-hour upcoming-alarm reminder, editor safety controls, matching Alarm/Timer editors, and larger-font layout improvements. This corrective release retains those changes; it does not add a full-screen alarm interface or alter the watch firmware alarm protocol.
