# PavDroid V1.0.1 — Android-controlled Shock Clock 3

**Application ID:** `com.projrcc.pavdroid`  
**Source baseline:** PavDroid V1.0.0 `project.zip` (317,984 bytes) copied from the user's Google Drive `/Pavlok/PavDroid` folder. That V1.0.0 build was originally derived from the user-provided Pavlok Control V3.0.3 source, rather than an inaccessible private GitHub repository.

PavDroid is a separate Android application from **Pavlok Control V3.0.3**. It schedules and runs alarms/timers on the phone and uses Bluetooth for direct watch buzz/beep/zap commands and middle-button events. It does **not** program scheduled firmware alarms or start firmware timers. The working Pavlok Control repository and Drive files are untouched.

## V1.0.1 changes

- **History repaired:** The existing History screen now recognizes PavDroid's Android-owned alarm/timer sessions instead of looking for old watch-firmware event messages. Each session records start, alert, snooze, re-fire, stop reason and/or missed state; timer pause/resume and MP3 attempts are included. The separate saved History archive survives clearing the Connection event log. Selection, export, deletion and original timeline visuals remain.
- **Reconnect timing:** When disconnected, watch reconnection gets priority beginning **two minutes before** the next enabled Android alarm. If the watch is disconnected at the scheduled time, the alarm is held for up to **ten minutes** and delivered upon reconnect; after that the alarm is recorded as **missed** and does not fire late. Outside the urgent window, reconnection retries back off to limit needless Bluetooth activity. The timing uses Android exact alarms where available.
- **Unlimited snoozes:** Removed all Maximum Snoozes controls and engine limits for alarms and timers. Smart Timeout remains optional and enabled by default: one-hour initial timeout, extended to two hours from each snooze. It never ends in the middle of a snooze.
- **Music:** Optional MP3 playback begins after each **firing** begins. The **− / +** setting defaults to **15 seconds** (steps of five seconds, range 0–120 seconds) for alarms and timers. Snoozing or stopping immediately stops MP3 playback and restores the prior alarm-stream volume. After snooze ends, a new 15-second delay begins. Session History distinguishes successful MP3 starts from failures.
- **Notifications and UI:** Alarm snooze notification displays the remaining `M:SS` countdown. The timer's Snooze action no longer says a hard-coded five minutes. Music-enabled alarms show a small ♫ in the existing alarm listing. The battery indicator clears to `—` upon disconnection. The original V3.0.3 timer keypad, presets, steppers, sliders, alarm cards, History layout and color scheme are retained.
- **Build identity:** Android version code 101, version name 1.0.1; the existing working-style GitHub workflow is unchanged except for the artifact's V1.0.1 name.

## Limits and testing

**Source release for a first V1.0.1 device test.** ZIP integrity, JavaScript syntax, and synthetic session-history parsing were checked. This environment does not include the Android SDK, so an APK compilation and physical wake-up/MP3/Bluetooth tests have **not** been performed here. Do not rely on PavDroid as your sole alarm until you verify scheduled wakeups, reconnects, notifications and actual watch stimulation on your phone and watch.

The watch must be reachable over Bluetooth to deliver buzz/beep/zap commands. An alarm waiting for a disconnected watch will not deliver those watch stimuli until reconnection. Android background limits, permissions, force-stop, or power management may interrupt scheduling or BLE. Watch firmware alarms previously programmed by Pavlok Control remain independent and could still fire.

## Canonical three GitHub files

1. `project.zip` — complete Gradle Android source; **exact filename required**.
2. `README.md` — this document.
3. `.github/workflows/build-apk.yml` — GitHub Actions build workflow. Google Drive stores its standalone copy as `build-apk.yml`.

To upload in GitHub, `project.zip` and `README.md` go in the repository root. The workflow replaces the existing file **inside `.github/workflows/`**. Do not upload a duplicate at repository root.

All three V1.0.1 release files are grouped in `/Pavlok/PavDroid/V1.0.1/` in Google Drive. The prior version in `/Pavlok/PavDroid/` is preserved as a separate baseline.
