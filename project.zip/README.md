# PavDroid V1.0.9 — Media volume, compact Music, and intensity colors

Android app ID: `com.projrcc.pavdroid` · `versionName 1.0.9` · `versionCode 109`.
Complete ZIP: `project.zip`.

## Baseline and protections

Built from the complete PavDroid **V1.0.8** source. Android still owns alarms and timers; Shock Clock 3 still supplies Bluetooth stimuli and middle-button Snooze/Stop. The four-tab layout, scheduled alarm data and saved History stay in place. No changes to the separate original Pavlok Control project.

## Changes

- **Music card** in both Alarm and Timer is collapsed by default with a small **+** control at the upper right, expands with **−**, and keeps Include Music plus a concise selected-song/settings summary visible while collapsed. Folding never changes whether music is enabled, the selected song, or playback/snooze timing.
- **MP3 playback and preview use Android Media volume** (`STREAM_MUSIC` and `USAGE_MEDIA`), so Samsung's visible Media volume responds. Restore the saved Media volume on Snooze/Stop and after preview. Report requested percentage and actual Android-reported Media level (including discrete volume step counts) in Connection log; alarm and timer History music events include the actual level reported at playback start. This must be verified on a phone.
- **Intensity colors:** 10–30% green, 40–60% gold, 70–100% red. Applies to Settings > Test Zap / Defaults intensity stepper borders and Alarm/Timer intensity slider filled portion and thumb. The unfilled slider track remains neutral.
- **Music explanation:** 10 seconds into each eligible firing, stops immediately at Snooze or Stop. Per-alarm and per-timer counts, starting music volume, and per-Snooze increase are unchanged except for the preferred-step behavior below.
- **Preferred escalation:** Preserve a +20%-point default increase as Start approaches 100%. Effective increase always fits inside 100% (100%+0, 90%+10, 80%+20), and changing Start back down restores the preferred increase. Manual +0 remains selectable and is preserved when explicitly chosen.
- Continue using both alarm editor Save buttons and existing native alarm/timer services.

## Build and installation

Replace **only** root `project.zip` in `ProjRCC/PavDroid`; the existing workflow unpacks the archive and builds `:app:assembleDebug`. The workflow itself lives at `.github/workflows/build-apk.yml`, not root. The artifact label in that existing workflow may still mention an older version; Gradle and the in-app version are authoritative.

**In-place APK upgrades are not yet fixed by this ZIP.** GitHub ephemeral runners may sign `assembleDebug` with different debug keys. To enable upgrade-in-place later, configure a permanent signing key via GitHub Actions secrets and a one-time workflow change (never commit/upload the private key to GitHub or Drive). Switching away from the current debug key may require one last uninstall. Back up History before that transition if needed.

## Validation boundary

Browser interactions and JavaScript syntax are not evidence of APK compilation, physical watch delivery, Android Media volume movement or unattended reliability. Run GitHub Actions and the phone/watch regression tests in `TEST_PLAN.md`. Keep a separate backup wake-up alarm until extended tests pass.
