# PavDroid 2.0.1 — REfresh (source-only test build)

**Status: V2.0.1 visual-parity candidate. V2.0.0 was compiled through GitHub Actions and user-installed; V2.0.1 still requires its own APK and real-watch checks.**

## Why this release exists

V1.0.19 failed at JavaScript initialization and exposed the old Pavlok Control firmware-alarm page. V1.0.20 (`preREfresh`) fixed that startup failure and is user-confirmed functional. This one-time REfresh moves PavDroid onto a clean, Android-only UI and package so that the old UI cannot reappear. No firmware alarm-list UI, Code Red, old watch timer configuration, firmware alarm programming, or hidden fallback page is included.

**V1.0.20 is untouched.** Its source ZIP and installed app remain the behavioral, hardware and visual reference. This project has a separate test application ID so both may be installed simultaneously, but do **not** connect both apps to the same watch simultaneously.

## Identity and source

- Version: **2.0.1**, versionCode **201**.
- Package / applicationId: `com.projrcc.pavdroid.refresh` (test-only; deliberately distinct from V1.x).
- Java namespace: `com.projrcc.pavdroid` (new, not `com.projectrcc.pavlokcontrol`).
- Architecture: Android's `AlarmManager` owns alarms and the native timer engine owns timers. The native service owns GATT background reconnection, button events, direct watch stimulation, audio/TTS, notifications, saved History.
- UI is now **only** `assets/index.html`, `styles.css`, `transport.js`, `app.js`. A separate CSS/JS model is provided from scratch and no longer uses the original control page as fallback.
- Existing working native algorithms from V1.0.20 for BLE GATT, Android alarm schedules, timer/stimulus, watch-button Snooze/Stop, music/TTS and notifications are intentionally *selectively reused* instead of riskily reverse-engineering another hardware protocol. Unnecessary legacy classes and firmware control operations were removed.
- Alarm and Timer options: **three equally spaced checkbox rows** for Safe Max (visible at >=60%), Time Readout, Smart Timeout; small inline info icons, subtle border, no internal dividers, directly above Preview. The Alarm editor has only bottom Cancel / Save actions.

## Building

The complete source is a root-level `project.zip`. This version supersedes V2.0.0 source as the next test candidate, without deleting either V2.0.0 or V1.0.20 archives. Use the preexisting GitHub repository workflow (which extracts that ZIP) to compile an Android debug APK:

1. Keep the V1.0.20 `preREfresh` source/archive and installed app as a separate fallback.
2. To test V2 source, use the established ChatGPT Work / GitHub Actions workflow to upload this V2.0.1 `project.zip` to PavDroid `main` and retrieve the built APK; leave the V1.0.20 archive and original Pavlok Control repository untouched.
3. Use JDK 17, Gradle 8.11.1, compile SDK 35, Android build tools 35.0.0; build `:app:assembleDebug`.
4. Install the test APK alongside V1.0.20. Android treats the two package IDs as distinct; this V2 test APK starts with separate local data (no automatic migration of alarms, MP3 permissions, History, or selected settings).
5. Grant Bluetooth, exact alarms and notification permissions; pair and configure the test app independently. Never use both simultaneously to drive the same watch.

The ZIP includes `.github/workflows/build-apk.yml` as a reference. If your repository already contains the unchanged wrapper workflow, it remains sufficient; only its display artifact label may still say V1.0.1.

## Important limitations

- Browser UI integration tests are not equivalent to a Java/Gradle build, an installed-phone test, or physical watch stimulation.
- Verify native behavior with safe, short buzz/beep-only tests first; do not use V2 as your only critical wake-up alarm until background reconnect, exact schedules, MP3/TTS, Snooze/Stop and repeated launches are checked on-device.
- The charging bolt only appears when the watch exposes a supported charging-status characteristic.
- Safe Max (50%) is not a medically validated electrical safety guarantee. Snooze/Stop and Smart Timeout continue to be available.
- Migration into the production V1.x package or replacement of the existing source is explicitly deferred pending user-approved physical verification.

See `TEST_PLAN.md` for per-feature acceptance cases.

## V2.0.1 visual parity and navigation corrections

Source audit against V1.0.20 plus the user's 67-second Zoom 2 screen recording identified unintended V2.0.0 presentation changes. This release restores:

- Settings starts with Defaults expanded, New alarms and New timers individually collapsed; other sections Music, Watch, Android, Advanced, About collapsed. Reopening Settings always resets this display state. Separate Stimuli / Zaps / Music grouped controls appear inside each type's Defaults; no flattened long grid. Section icons and compact +/- controls.
- Consistent Snooze time placement directly after time/presets and before Music, in Alarm and Timer; original one-line watch-button hint.
- Checking Include Music opens the entire music configuration; manual fold can close it, and unchecking doesn't discard settings.
- Button sizing/spacing, colored intensity borders (green <=30%, amber 40-50%, red >=60%; white border/red face at 90-100%), slider/thumb treatment, and clean editor reopening at top after Cancel/X.
- Watch tab on first-ever launch. Active Alarm or Timer opens its respective tab; a Stop recorded in native History within five minutes selects History on reopening; otherwise previous manual tab is remembered. UI Stop buttons also open History directly.
- Battery percentage is a tap target in the header and Watch card. Foreground BLE battery polling at most every 30 seconds when there is no active session. A white charge bolt appears only when `0x2A1A` reports actual charging; if unsupported, no bolt is guessed. Hardware support is NOT yet verified.
- Popup-only protection for starting overlapping Alarms/Timers: buttons stay tappable, with native busy check and warning.
- Timer Reset to Defaults restored beside heading, preserving duration and no redundant confirmation; removed the inherited 30% Buzz on start checkbox/extra action absent in V1.0.20.

The native BLE/session/scheduler/audio/history sources are unchanged in V2.0.1; this update is concentrated in HTML/CSS/JS, release metadata and documentation.

**Verified locally:** JS syntax; mock-native regression tests for alarm create/edit/copy, timer start/stop/reset, music auto-expansion, settings initial/reopen hierarchy, safe intensity border, battery manual refresh and charging-bit conditional rendering, editor top-reset, and tab priority (first/Alarm/Timer/recent Stop). These tests DO NOT verify actual watch charging status, APK compilation, physical stimuli, background reconnect, or production wake-up reliability.
