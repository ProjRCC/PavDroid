# PavDroid V1.0.1 — focused hardware test

1. Install the GitHub Actions debug APK, grant Bluetooth/notifications/exact alarm access, and connect the watch. Verify battery displays a percentage, then becomes `—` if disconnected.
2. Start a short timer. Verify the original timer keypad, ± controls and presets. At Times Up, tap the watch middle button to snooze, then hold to stop. Open **History**: see one Timer session, elapsed Times Up, snooze, Stop reason, and the timeline. Export and check event details.
3. Create a short Android alarm and test the same snooze/stop cycle. History should show the alarm name, firing, snoozes and stop source. Confirm no firmware alarm is created on the watch.
4. Enable music with the 15-second default. Verify the MP3 starts 15 seconds after **each firing**, stops immediately on each snooze, and resumes only after the next firing's new delay. Verify alarm-stream volume restores on snooze and Stop.
5. Test longer snooze runs: no Maximum Snoozes limit should appear or block a snooze. Check Smart Timeout default; test disabled state separately.
6. Observe notification snooze remaining M:SS. Test both phone and watch actions, including app background and screen off.
7. Disconnect the watch. Verify battery blanks and normal auto-reconnect occurs on return. For a scheduled alarm, begin with the watch disconnected and observe the two-minute preconnect window. Reconnect within ten minutes after due time and verify the alarm fires late; outside that window verify **Missed** History and no stale firing. Compare timestamps with Connection event log.
8. Observe behavior after restarting the app, rebooting the phone and encountering temporary Bluetooth loss. Watch connection, background work and exact-alarm behavior require real device verification.

Do not rely on PavDroid as the only wake-up alarm until these checks succeed. GitHub compilation alone does not verify real Bluetooth delivery.
