# PavDroid V1.0.6 acceptance checks

1. Build complete `project.zip` via existing GitHub Actions; install debug APK and verify header **V1.0.6 · ANDROID**.
2. Header: version pill precedes a small outline Settings gear on the **far right**. Confirm Settings still opens/closes, remains reachable on a narrow phone, and the four tabs do not shift or wrap.
3. Timer idle: heading and watch-button instructions appear, the single **Ready** badge remains. There is no extra `Ready` beneath instructions and no status box repeating `Ready` under controls.
4. Choose Timer presets and edit duration: no stale Ready notices. Start, Pause, Resume, Snooze, and Stop; confirm important error messages still appear and no timer engine behavior changed.
5. Check Settings Music / Watch / Defaults / About and all the V1.0.5 stepped controls remain functional, including live preview volume updates.
6. Confirm alarms schedule/re-fire, 10-second music start, per-alarm volume escalation, Snooze cancellation, History, background Bluetooth reconnect, and watch-button inputs remain functional. Use a backup alarm.

This update is intentionally UI/status-only; the physical watch and Android build are not tested by source checks.
