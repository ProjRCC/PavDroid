# PavDroid V1.0.8 — Regression checklist

## Build / upgrade
- GitHub Actions compiles `project.zip` and produces an installable APK labeled internally `V1.0.8 · ANDROID` (`versionCode 108`).
- Install over V1.0.7; verify scheduled alarms, selected MP3, timer defaults, saved History, notification buttons and BLE pairing are retained.

## Alarm editor
- Open a new alarm. **Save alarm** appears in the sticky header next to Close; the original bottom Save remains.
- With no changes beyond a valid name/time, top Save commits exactly one alarm. Repeat with bottom Save. Rapid double tap never duplicates the alarm.
- Edit an existing alarm, use either Save, verify exact existing alarm is changed and there is no accidental duplicate.
- Scroll to the bottom: Snooze, then Smart Timeout (with `i` help), then Preview, spaced apart and not overlapping; the sticky bottom action bar remains fully usable.

## Timer editor
- With timer ready, Preview appears below Snooze and Smart Timeout. Preserve timer presets, countdown, Snooze/Stop and music controls.
- During a running timer and an alert, ensure the configuration-only Preview stays hidden and native timer behavior is unchanged.

## Music limits
- Alarm with Start 80%, Increase +20%: + button is disabled at +20%. Start 90% automatically clamps increase to +10%; Start 100% clamps to +0%.
- Lower Start back to 80% and verify Increase can be raised again to +20%; try all combinations using +/- controls.
- Repeat on Timer and under Settings > Defaults > New alarms / New timers. Reopen Settings and confirm changed defaults persist.
- When editing an older alarm saved with Start 100% and Increase +20% (possible before V1.0.8), confirm editor displays +0%; cancel leaves the existing alarm alone; saving validates and normalizes the combination.
- Confirm current-session music still begins 10 seconds into eligible firings, silences immediately on Snooze/Stop and restores Alarm volume; physical output and audio volume require phone/watch testing.

## Background / safety
- Verify app-closed Android scheduled alarm, short watch-button Snooze, long-hold Stop, actual re-firing after snooze, no concurrent sessions, reconnect, and History export.
- Keep the separate Pavlok Control reference untouched. Do not mistake browser or source checks for APK or physical-device verification.
