# PavDroid 2.0.7 REfresh — acceptance ledger

## Automated/local checks

- [x] New page renders at 390 CSS pixels; no old firmware-alarm UI or Code Red settings elements.
- [x] JavaScript parses successfully; browser startup has zero uncaught errors.
- [x] Mock-native integration: create and save Android alarm, edit and Copy, and verify the saved `intensity` and `timeReadout` fields are sent to native alarm engine.
- [x] Mock-native integration: Alarm editor state preserved when opening Advanced via Time Readout info and returning.
- [x] Mock-native integration: Timer presets, protected slider to 70%, Safe Max auto-check, Timer start profile, Timer Stop and Reset to Defaults while preserving selected duration.
- [x] Mock-native integration: Advanced TTS starting volume changes are passed to the native bridge.
- [x] Native source audit: old firmware-list browser interface, Code Red classes and other unused components absent; BLE writing API accepts only direct buzz/beep/zap UUIDs.
- [x] V2.0.0 APK built and installed through Work/GitHub per user report.
- [x] V2.0.6 mock-native/UI parity tests: defaults hierarchy, folded states, battery tap, verified charging-bit conditional display, music auto-expand, Snooze location, editor top reset, startup tab priority, low/high intensity colors.
- [ ] V2.0.6 APK compilation, installation and physical watch test.

## Real device checks (all pending)

1. Build APK with GitHub Actions; verify package `com.projrcc.pavdroid.refresh`, versionName 2.0.6, and separate installation without uninstalling V1.0.20.
2. Reconnect watch via BLE with the phone unlocked; verify battery percentage and charge bolt only when reported. Then lock the phone, swipe the app from Recents and verify automatic BLE reconnection on returning to range.
3. Add an Android-owned alarm using Alarm editor; verify day-mask presets, time keypad, Save, Edit, Copy, Delete and pending nine-hour notification. Check scheduled 1-minute alert with screen locked.
4. Send short **buzz/beep only** Timer and Alarm patterns; verify cadence and watch middle tap Snooze, middle long-hold Stop; ensure one-active-session lock prevents overlapping sessions.
5. Allow seven-minute Alarm Snooze and configured Timer Snooze to expire, check rerun, music reset on every Launch and cancellation on Stop. Check notification actions and distinct Snooze Countdown channel.
6. Verify Time Readout speaks on Snooze **after MP3 stops** and uses Android Media volume with TTS starting 20%, +10 percentage points per Snooze capped at 100%; volume restored afterward.
7. Exercise compact Safe Max, Time Readout and Smart Timeout checkboxes in both editors at 50% and 60% thresholds; verify saved unchecked choice stays unchecked on subsequent editing.
8. Test MP3 library import and selected song, one per alarm/timer, editor return after Settings, actual audio volume ramps on the phone and background audio behavior.
9. Export History independently from Connection log, clear the latter without losing the former, verify one timeline per session and correct 21+ Snooze tracking.
10. Test alarm app restart, Android restart, 9-hour upcoming reminder, Doze/reconnection, permissions and battery optimizations before using V2 as sole wake-up alarm.
11. If testing long sessions, remain cautious about repeated electrical stimulation; queued BLE writes are not proof of delivered electrical output and exposure safety is unverified.

**Production gate**: Keep V1.0.20 as the visual/behavioral reference; do not replace it or migrate its data until V2.0.6 passes phone/watch acceptance.

## V2.0.6 additional acceptance tests

1. At Samsung Zoom 2 compare Alarm and Timer editors visually with V1.0.20; test all expand/collapse controls, long labels, intensity values at 30,40,50,60,70,90,100 and Safe Max.
2. Settings should open Defaults expanded, New alarms (+), New timers (+), all other sections closed. Expand Music and New alarms, close Settings, reopen; confirm natural initial layout returns.
3. In Alarm editor, enable Music: controls expand immediately. Collapse manually, Cancel and reopen editor; confirm it starts at the top with clean new-alarm defaults. Repeat Timer.
4. Watch fully disconnected/reconnected, tap battery percentage in both places. Confirm actual polling and percent fresh. If charging bolt fails during charging, capture BLE/Watch log; 2A1A may be unsupported. Do not fake charging status.
5. Cold launch Watch on fresh test app, active Alarm->Alarms, active Timer->Timer, session Stop->History, normal relaunch->last selected tab. No forced History for long-completed sessions.
6. Start an overlapping alarm/timer: see a warning rather than grayed New Alarm/Start. No session overwritten.
7. Retest all V2.0.0 core workflows and avoid using as sole important wake-up alarm until physical regression passes.

## V2.0.6 specific checks

- [x] Browser: Edit > Copy = Delete button widths (148 / 87 / 87 pixels at 390 CSS px viewport); no Copy +30 button or code path.
- [x] Browser: enabled 7:30 above disabled 7:00, original stored index used when editing/copying.
- [x] Browser: gray disabled alarm name and time; music note and TTS indicator shown only for configured alarms.
- [x] Browser: numeric Timer input `5` replaces prior duration and formats to `0:05` when blurred.
- [x] Browser: History selection checkbox appears without shifting the details column.
- [ ] Android/GitHub APK build and install; repeat checks at Samsung Zoom 2.
- [ ] Actual watch charging-state characteristic availability; no charging bolt is guaranteed where the watch reports only battery level.

## V2.0.6 follow-up UI / permission acceptance

- [x] Mock-native browser: missing exact-alarm permission shows Watch button and stable Alarm notice after 1.8 sec, Android settings button calls permission API.
- [x] Mock-native browser: enabled 7:30 precedes disabled 7:00; disabled row keeps `Disabled · Weekdays` and gray note/TTS.
- [x] Mock-native browser: 0x2A1A charging (`0x30`) shows only the bolt next to the percentage (label remains Battery); unconfirmed state does not fabricate it.
- [x] Mock-native browser: Timer keypad `5` -> `0:05`, `500` -> `5:00`, Backspace -> `0:50`.
- [x] Native source audit: Android exact-alarm grant broadcast receiver installed and calls the existing native rearm path.
- [ ] Confirm Samsung V2.0.6 physical permission flow, wake schedule, timer keyboard, and Watch charging characteristic behavior.

## V2.0.6 targeted acceptance
- [x] Static check: battery label is always 'Battery'; verified-charging controls only the two existing lightning bolts.
- [ ] Verify on physical charging Shock Clock 3; display depends on actual BLE charging-state support.


## V2.0.6 acceptance
- [ ] Android: tap Timer duration, immediately see `0:00` and caret on far right; type `5` → `0:05`; `500` → `5:00`; blur without typing restores previous duration.
- [ ] Settings → Defaults → New alarms / New timers: Time Readout setting persists independently and applies to new configurations, without modifying existing alarms.
- [ ] History: timer plot begins at Time Expired, not initial countdown; blue/gold segments are time scaled; display START/END clock ticks, elapsed time, Snooze and Stop dots, color legend.
- [ ] History: full-width Expand events button toggles while retaining state across one-second refreshes; selecting zero sessions cannot delete the archive.
- [ ] At Zoom 2: week presets and individual weekdays use matching 14px font size.
- [ ] Verify APK build and physical Android screenshots; browser source checks are not hardware validation.

## V2.0.6 manual battery refresh / charge-status acceptance

- [x] Mock BLE returns 2A1A charging power state: only a white bolt beside both percentages; no Charging text.
- [x] Mock BLE has no 2A1A but reports 2BED battery charge state `Charging`: bolt visible.
- [x] Mock BLE has neither optional characteristic: bolt hidden, Watch log says charging status unavailable.
- [x] Tap battery % twice while a poll is active: a second full battery level read occurs. A rotating refresh marker appears, then a checkmark even when the percentage remains unchanged.
- [ ] Samsung Zoom 2: verify taps genuinely update the connected watch battery % and show temporary feedback.
- [ ] Shock Clock 3 charging while connected: export Watch event log if the bolt does not appear to identify unsupported GATT status. Do not infer from changes in percentage alone.
- [ ] Confirm alarms/timers and watch Snooze/Stop remain reliable with periodic/background BLE reads; use backup wake-up alarm until physically verified.

## V2.0.6 targeted checks
- [ ] Android: while connected tap Disconnect; confirmation appears, Cancel retains link, Confirm stops monitoring (native watch stimuli unavailable) while existing Android alarm and timer schedule persists.
- [ ] Android: connected Reconnect watch appears muted and disabled; disconnected Reconnect watch returns blue; no extra click commands during active watch use.
- [ ] Watch Event log button shows exact count (including 0/1 events), collapsed and expanded, refreshing when new entries arrive.
- [ ] With no active alarm/timer, expand Event log and Capture charging BLE snapshot once with charger plugged, once unplugged. Check candidate UUID/hex differences, do not treat a difference as proven charging.
- [ ] While alarm/timer active, diagnostic refuses a snapshot and cannot delay direct watch buzz/beep/zap.
- [ ] Tests require physical Android APK; Java compile, service discovery and actual charge signal not proven by browser mocks.

## V2.0.9 checks before accepting as working

- [x] Mock UI: first-ever opening Watch, subsequent idle opening Timer, new stopped session History exactly once, active Alarm Alarms.
- [x] Mock UI: start live monitor, subscribe, event logging only for changed packet values, rapid Plugged/Unplugged markers, stop/unsubscribe.
- [ ] GitHub Actions `gradle :app:assembleDebug` succeeds from `project.zip`.
- [ ] Real watch: Start live monitor while idle. Wait for **monitor ready** (only once), then rapidly plug, tap Mark plugged in; unplug, Mark unplugged; repeat without a 10-second dwell. Copy all Event log. Compare property changes, but do not turn on charging bolt until actually confirmed.
- [ ] Real watch: inactive notifications remain passive; physical Watch button Snooze/Stop, background reconnect, Android scheduling and stimuli operate unchanged after diagnostic ends.
- [ ] Real phone: stop a session; after next app opening History shown one time, then Timer on the following opening; active Alarm or Timer overrides other destinations.
- [ ] Diagnostic monitor refuses to run with an active Alarm/Timer and does not delay watch stimulation.


## V2.0.9 regression
- Upon BLE connect, Start test is enabled without opening another page.
- Start unplugged; mark plugged, unplugged, plugged: button alternates and each event has correct timestamp/state.
- Finish test restores Start test, Copy all includes manual marks and Bluetooth status notifications.
- Expanding the log no longer exposes full snapshots or two independent state markers.
- Test cannot start with an active alarm or timer; test stops if session activates, without affecting session engine.


### V2.0.9 Watch diagnostics placement
- All charging test controls are under Settings → Watch → Diagnostics, in a nested section collapsed by default.
- Watch Event Log has only its standard Expand/Collapse, Copy all, and Clear controls.
- Finishing or leaving Settings stops test monitoring; the event log remains intact and can be copied from Watch.
- Reopening Settings resets Diagnostics to collapsed. No Bluetooth write other than optional notification CCCD subscriptions/unsubscriptions; no watch alarm/timer write or stimulation.


## V2.0.9 charging/status/navigation/defaults update
- Native Android service passively subscribes to watch 0001 notifications after physical button stream. Four-byte packets end in 00 (unplugged) / 01 (plugged) based on ON/OFF cycle test.
- No watch firmware writes added. Charging indication only when a valid notification has been received on current connection. Disconnect clears state. Diagnostics may never unsubscribe the live charging stream.
- Battery reads do not wipe known native charge state. Watch and header use existing small white lightning bolts.
- First-ever installation stays on Watch for entire initial WebView visit; later idle start uses Timer. History after completed session still once.
- Fresh defaults: time readout enabled in Alarm and Timer, Time Readout start 40%, rise 10%/snooze. Existing saved defaults remain untouched.
- New alarm/timer notification channel IDs intentionally ensure sound None/vibration Off for existing installations; high-importance alert display and alarm/timer audio unchanged.
- Version code 209; Android applicationId remains com.projrcc.pavdroid.refresh.

## V2.0.10 checks (new)

1. Verify app ID `com.projrcc.pavdroid.refresh` and versionCode 210. Use existing permanent-signing GitHub Actions workflow and verify signature. Install over V2.0.9 without uninstalling; existing alarms/History/defaults must survive.
2. On first launch after update, Watch stays selected while Settings or Android permission pages are opened; on subsequent idle launch, Timer. Active session and unseen completed session retain launch priority.
3. Bottom tab row is visible when browsing. Timer editing begins only after touching setup; footer Back/Start Timer replaces navigation and old inline Start is gone. Back restores navigation without starting. Active timer controls remain in their existing body.
4. Alarm editor uses Back/Save alarm footer; Back with unsaved edits asks confirmation. Shortcut from alarm to Settings Music returns directly to editor with unfinished alarm preserved. Native Android Back follows context.
5. Verify `Settings > Music` library: user-added items first, built-ins below, track selection and inclusion, rotate flag, drag-to-reorder within group, preview selected, private-copy persistence after source MP3 moved/deleted. Built-ins are newly generated PavDroid originals, NOT downloaded Freesound recordings.
6. Verify native rotation: alarm first launch uses selected library sound, first snooze re-fire uses next included sound, wraps around; repeat for timer and after process death/restoration.
7. Verify centralized music playback settings persist and influence new sessions. Existing saved per-profile volume remains until music playback settings are explicitly edited. No related change to TTS defaults (40%, +10%).
8. Advanced Safe Max defaults to 50%, changes repeat ceiling to configured value on alarm and timer, never exceeds selected max. No unexpected physical stimulation on UI changes.
9. Next-alarm countdown respects repeat weekdays, DST and enabled ordering, refreshes without replacing list DOM each second.
10. Preserve the V2.0.9 connected-watch charge indicator and BLE reconnection/physical Snooze/Stop. Verify History timeline remains unchanged.
