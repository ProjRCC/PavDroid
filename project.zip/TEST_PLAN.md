# PavDroid V1.0.7 — Regression test plan

## 1. Package / upgrade
1. Upload the complete `project.zip` to the root of `ProjRCC/PavDroid`; run GitHub Actions. Confirm the APK builds, installs over V1.0.6, and shows `V1.0.7 · ANDROID`.
2. Confirm the four dark-blue tabs, alarm schedules, saved History, selected MP3, and watch reconnection are retained. The independent Pavlok Control app remains unchanged.

## 2. Music preview (phone, not watch)
1. In Settings select an MP3 and tap **Preview selected**. Test 10%, 40%, 100% and verify Android's **Alarm** stream volume slider changes accordingly and audibly. Moving the controls during playback should update the system volume.
2. Tap Stop and confirm playback stops and the original Alarm volume setting returns. Repeat by letting the MP3 finish, closing Settings, and closing the Activity.
3. With an alarm/timer active, preview must be blocked. Do not rely on preview success to prove background music playback.

## 3. Music in alarm and timer sessions
1. Confirm per-alarm **Start volume** and **Increase per snooze** controls; create one alarm with `Play after 0`, `Start volume 30%`, `Increase +20%`.
2. Verify music begins 10 seconds into initial firing; Snooze silences it immediately and restores prior Alarm volume; re-fire plays at 50%, then 70%, capped at 100%.
3. Verify `Play after 2`: the first two firings have no music, first eligible re-firing uses the **starting** volume, later rounds escalate. Test alarm long-hold Stop and notification Stop.
4. Timer now has the same two controls. Test 0/1 snooze thresholds, audio on Times Up, timer Snooze, and notification STOP. Stop must cancel audio.
5. Check an older saved alarm with no new music settings still uses its prior 100% / non-escalating behavior; a previously configured timer-volume percentage remains available as the new timer default.

## 4. Settings / editors
1. Settings Watch: adjust Test Zap intensity in 10-point steps, then confirm before sending a **low-strength** zap; check no zap can be tested while a session is active.
2. Change Alarm and Timer defaults, close/reopen Settings, and verify they persist. Existing saved alarms and active sessions must not be changed.
3. Alarm editor: Escalate/Full inline buttons must toggle actual saved behavior and the configuration preview, with no Android dropdown popup.
4. Smart Timeout appears at bottom of both editors; its `i` button toggles the concise explanation. Existing 1h initial / 2h after Snooze engine behavior remains unchanged.
5. Buttons provide subtle visual press feedback and short phone haptic where permitted; they must never send unintended watch stimuli.
6. Timer alert screen shows the `ALERTING` badge, countdown, and correct Snooze/Stop actions without the extra `Times Up` status box; real errors remain visible.

## 5. Reliability regression (physical device)
1. Exact Android-scheduled alarm while locked/app removed from Recents; physical buzz/beep/zap; watch tap Snooze and hold Stop; History export.
2. Full Snooze expiration and re-firing, including beyond 30 minutes of session time. Keep another wake-up method during testing.
3. Lock/background Bluetooth reconnection, MP3 timing, repeated snoozes, timer countdown, no overlapping sessions, Smart Timeout, reboot recovery, and battery restrictions.

**Evidence levels:** JavaScript/browser/source checks are not GitHub Actions compilation; GitHub success is not a physical watch pass. Mark each separately.
