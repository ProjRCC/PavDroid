# PavDroid V1.0.4 regression plan

## Build and baseline
- Confirm `app/build.gradle` versionCode 104 / versionName 1.0.4, installed app displays V1.0.4, GitHub Actions compiles. Verify original V3.0.3 Pavlok Control unchanged.
- Confirm four-tab dark interface retains Connection, Alarms, Timer, History; top-right gear opens/closes Settings.
- V1.0.3 historical alarms and sessions remain after upgrade; pre-existing MP3 alarms retain full-volume, non-escalating playback until edited. No firmware alarm slots are written by PavDroid.

## Music Settings / alarm playback
- Import two MP3 files from Android document picker, select one radio item, preview and stop, switch to second, reopen app, verify selection retained.
- After creating alarm with Include Music, change global selected song WITHOUT editing alarm. Confirm next scheduled alarm uses new song.
- For each alarm setting: music activation 0 => first firing+10s; 1 => first re-fire+10s; 3 => third re-fire+10s. Music MUST NOT play on earlier rounds.
- Start 30%, +20% per snooze => first eligible firing 30%, subsequent 50%, 70%, 90%, 100% cap. +0 stays fixed. Confirm player remains silent until delay and stops immediately on any Snooze/Stop; prior phone alarm-stream volume restored.
- Leave screen locked, swipe app from Recents (do not Force stop), check song, repeated rounds, notifications, History and Bluetooth reconnection. Restore app during active snooze and re-check persisted counters and music settings.
- Missing/deleted external song provider must be reported via Connection/History; watch alarm and Stop must keep working without audio.

## Timer music / notifications
- Timer Include Music with after 0 and after 2 snoozes; verify fixed +10s delay and immediate music stop on Snooze/Stop.
- Timer Snoozing notification: "MM:SS remaining" with STOP only; timer Times Up body "PavDroid timer is up", STOP left/Snooze or Snooze-Mute right. Pause/Resume during countdown only.
- Alarm Snoozing notification shows "MM:SS remaining" and STOP only. Firing action Snooze or Snooze/Mute right, STOP left. Android/Samsung decides button width.

## Settings/defaults/UX
- Gear > Watch: warning threshold 5–50 only affects in-app warning; header/Connection battery text red only <15%; disconnected dash white. Test Buzz/Beep at low intensity, test Zap only with confirmation and with a real watch connected.
- Gear > Notifications opens respective Android channel controls; check old categories after upgrade without resetting active channel settings.
- Save distinct alarm/timer stimulus defaults, reopen Settings, create new alarm and timer: confirm they are populated; verify OLD alarms not altered.
- Check centered ALARM FIRING and SNOOZING (N) · MM:SS left, no duplicate snooze stats or firmware warning; check four-tab proportions and compact wording.
- Run 2–3 snooze cycles and >30 min elapsed; verify one continuous History session and no regression to original 32:40 min V1.0.3 watch test.

## Reliability / safeguards
- Do not permit concurrent alarm/timer, changing alarms while active, or unsafe watch test stimuli while active.
- Verify Smart Timeout: 1h without Snooze; 2h from latest Snooze; OFF disables cutoff. Test seven-minute default and 15-minute custom Snooze.
- Reboot recovery, exact alarm permission, Doze and Samsung battery management remain live-hardware validation items.

No static test proves APK compilation or physical watch stimulus delivery.
