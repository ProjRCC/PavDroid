# PavDroid V1.0.13 — Test checklist

## Build and installation

- [ ] GitHub Actions `:app:assembleDebug` passes; install the resulting APK. Verify app header and About show **V1.0.13**.
- [ ] Preserve existing alarm schedules, song selections, History and timer settings where signing permits in-place upgrades. If a different debug key blocks installation, record the signing issue; do not call it a code regression.

## Settings layout

- [ ] On every new open, show main sections **Defaults (expanded), Music, Watch, Android, About (collapsed)**, in that order, each with exactly one icon and appropriately scaled heading.
- [ ] New alarms and New timers are collapsed at initial open. Expanding one displays **Stimuli, Zaps, Music** completely; there are no separate +/− controls on these inner groups. Smart Timeout is inside Stimuli.
- [ ] Collapse/open Defaults, then close/reopen Settings. Verify the preferred opening layout returns, and saved values do not change.

## Dynamic stimulus interval — Alarm and Timer

- [ ] Buzz 5, Beep 5: minimum **6s**, not 11s. Buzz 5, Beep 2: still **6s**.
- [ ] Buzz 3, Beep 2: minimum **4s**. Buzz 2, Beep 2: minimum **3s**. Buzz 0, Beep 0, Zap 1: minimum **3s**.
- [ ] Increase either Buzzes or Beeps to 5 while interval is 3s: interval rises to **6s** automatically.
- [ ] Decrease counts afterward: interval stays 6s until explicitly reduced.
- [ ] Enforce max **30s** for new settings and keep the chosen interval when valid.
- [ ] Verify both Settings default controls, new Alarm editor, and Timer controls follow these same rules. Verify native engine receives a valid interval after save/start and when restored from preferences.

## Music interval

- [ ] Music increase every follows **3s → 5s → 10s → 15s ... 120s** in new-alarm defaults, new-timer defaults, Alarm editor and Timer editor. Decrease from 5s goes directly to 3s.
- [ ] Keep existing 10-second first-music delay, per-Snooze threshold, gradual Media volume increase, previous Media volume restoration, and immediate Snooze/Stop cancellation.

## Regression and physical watch

- [ ] Test buzz/beep-only groups at valid 3s, 4s and 6s minimums; observe actual watch pacing, watch-button Snooze/Stop and pending command cancellation.
- [ ] With low-intensity sample zaps, test Zap-after-X-Snoozes gate and 10%-to-configured-maximum ramp. Retain the existing 12-zap-per-firing cap.
- [ ] Alarm and Timer operate independently of watch-firmware scheduled alarm slots; one active session at a time. Check locked-phone operation, BLE reconnect, timer reset while idle, notifications and History export.

**Evidence tiers:** Source/browser validation does not prove APK build success or physical stimulus timing. Keep a backup alarm until longer testing is complete.
