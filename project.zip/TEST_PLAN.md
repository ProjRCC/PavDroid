**V1.0.20 hotfix (November 23, 2026):** Fix the PavDroid WebView adapter startup regression introduced in V1.0.19. Music change listeners referenced an uninitialized const and stopped all subsequent native-alarm UI hooks, leaving the inherited firmware UI active and producing misleading blocked-firmware-command warnings. The handlers are now attached after the function is initialized. No changes to native alarm/timer timing or Bluetooth stimulus handling. Source-only verification; install/watch tests pending.

# V1.0.20 — New regression gates (all PENDING phone/watch validation)

- Build the ZIP with Gradle Java 17 / SDK 35 and inspect actual APK identity `com.projrcc.pavdroid`, `1.0.20` / 120. Source syntax alone is not an APK build.
- In BOTH Alarm and Timer editors: Safe Max (only >=60%), Time Readout, Smart Timeout grouped directly ABOVE Preview, info controls immediately beside their labels; three help panels open/close without losing settings. Inspect with larger Samsung zoom and text.
- Creating new 60% max alarm/timer checks Safe Max; at <=50% hidden; increasing from <=50 to >=60 checks automatically only until user intervenes. Editing existing 60% unchecked saved alarm/timer must NOT turn it on. Reset timer to defaults retains duration.
- Check Time Readout in Alarm/Timer, ensure info button opens Advanced with visible TTS controls and returns to the same unsaved alarm editor. Include Music with no song must show actionable shortcut to Settings → Music; cancel song selection returns without corrupting data.
- Verify Advanced TTS starting volume 10–100 by 10, default 20; rise default +10; set start to 100 causes +0, lower back to 90 restores +10, raise to 80 retains +10. Change increase, ensure start+increase never exceeds 100; persists across app process restart and overnight.
- With MP3 enabled: let it play, press phone Snooze and watch tap separately; music silences immediately and spoken phrase occurs after the accepted Snooze at correct actual time; 1st at 20%, 2nd at 30%, etc., cap at 100%; media volume restored after speech. Test time readout without MP3; with checkbox off; and press Stop during a spoken phrase to ensure speech halts.
- Keep original 7-minute alarm and timer Snooze deadlines, watch long-hold Stop, smartphone Stop, Smart Timeout 1h/2h, all notification IDs, no-overlap protection and no new watch firmware alarm writes.
- While unlocked and connected, verify battery refresh after charging without reopening the app; during alerting avoid extra battery BLE requests. Confirm icon only appears from supported charging state and disappears when not charging; if the watch exposes only 2A19, icon must stay hidden rather than falsely claiming charging.
- Re-test app swiped away/locked phone in an overnight scenario with backup; TTS may be affected by installed voices/audio route and battery/device policies. A logged speech request is not proof it was audible.

---

# PavDroid V1.0.18 - Acceptance and regression tests

This is a source release; each unchecked item needs GitHub APK and/or real-device evidence. Do not treat accepted Bluetooth writes as proof of physical watch stimulation.

## Build and data preservation

- [ ] Verify Gradle `versionCode 118`, `versionName 1.0.18`, in-app version, History export version and full `project.zip` ZIP archive.
- [ ] GitHub Actions successfully compiles `:app:assembleDebug`, APK installs, watch connects, and original Pavlok Control V3.0.3 stays unmodified.
- [ ] Export stored History before uninstall. Confirm saved alarms, Defaults, selected MP3, notification preferences and timer configuration survive if APK signing permits in-place update.

## Key correction - both native engines, first use low-risk inputs

- [ ] Static assertions: no `MAX_ZAPS = 12`, `zapSent >= 12`, `zapsSent >= 12`, `/12 this launch`, or other legacy 12-count stop in active alarm/timer/fallback paths.
- [ ] With buzz/beep only and no zaps, run an alert past the equivalent of 12 stimulus cycles and confirm it remains active until Snooze or Stop; check timing and native log.
- [ ] With **low chosen zap max (e.g. 10-20%)** and explicit supervision, if appropriate, verify a 13th (and later) scheduled zap appears in the log, at the configured interval, without an automatic Stop or silent skip. Do not start with 60%-100% tests.
- [ ] Zaps-only timer does not auto-stop due to the removed 12-count limit; Stop and Snooze still work. Test using a safe/no-output instrumented path before physical shock exposure.
- [ ] Each new reactivation after Snooze resets escalation from 10%, rather than continuing at previous launch's maximum. The launch counter and per-launch zap number are clear in History.
- [ ] With 40% max, expected levels are 10, 20, 30, 40, 40, 40...; with 70% selected max and Safe Max checked, expected levels are 10, 20, 30, 40, 50, 60, 70, 50, 50... (derive in code review; do not use high output on wrist just to validate a sequence).
- [ ] At selected 50%, Safe Max checkbox hidden; at 60% or above, shown; per-Alarm and Timer choices persist independently. Unchecked maintains selected maximum, never exceeds it.
- [ ] Snooze immediately stops queued stimuli and music; watch middle-button hold Stop shuts the alert down and cancels all pending work. No automatic restart from stale callbacks.
- [ ] Smart Timeout remains initially 1 hour and becomes 2 hours after the latest snooze; OFF means no automatic session deadline. The absence of a 12-zap cap means prolonged electrical exposure is possible when OFF.
- [ ] With disconnected/reconnected watch, no stale backlog of queued zaps should be replayed; rejoining ongoing session continues only if that session is still active.

## V1.0.16 regression work (not yet verified by device)

- [ ] Samsung zoom 2/3/4 and huge fonts: header no overlap, alarm day buttons wrap, History actions and presets wrap cleanly, 3+1 singleton centered; dialogs scroll and fixed Save buttons remain available.
- [ ] Alarm/Timer editor identical zap + Music stepper styling; intensity slider hold 0.2s, no visible hold instruction; 60-80% red and >=90% white thumb ring; Smart Timeout below Preview.
- [ ] Shared silent Snooze Countdown category covers both alarm and timer; previous Alarm Activated and Time Expired notification preferences stay unchanged on update.
- [ ] Alarm Upcoming quiet notification appears nine hours before next Android-owned enabled alarm, updates on edits/disables/launch/reboot/time changes; does not create firmware alarm.
- [ ] Music start timing, volume ramp, restore on Snooze/Stop, quiet notifications and independent History/connection logs work as in earlier verified releases.
- [ ] Session overlap still blocked with popups, not graying an unrelated active operation. Timer Reset to Defaults preserves selected timer duration.

## Known evidence limitations

V1.0.15's Nov 22 History proves a 12th zap command was **queued** at 7:14:12 AM, then no further logged zap requests while the alarm remained active until 8:42:11 AM. It does **not** independently prove physical wrist delivery or continuous buzz/beep after zap 12. This release changes that scheduling behavior in code; the true observed fix requires a subsequent installed-build test. The 50% ceiling is a user-configured intensity rule, not a medical safety certification.

## V1.0.18 UI-specific checks

- [ ] Day presets at Samsung display zoom 2 and text 3/10: ONCE / Weekdays / Weekends on row 1 and thinner, full-width Every day on row 2. Large fonts never overlap labels; if enough width, all 4 may occupy row 1.
- [ ] No days: ONCE selected. Only Monday: all presets deselected. Saturday and Sunday: Weekends selected. Add Monday: still Weekends, not ONCE/Weekdays. All seven: Weekdays, Weekends, and Every day selected. Remove Monday: only Weekends remains selected.
- [ ] Day bitmask, native alarm next-occurrence rules and AM/PM time remain unaffected by preset visual selection; edit/save/reopen the same day mask.
- [ ] Timer six equal presets are 1m, 5m, 10m / 15m, 20m, 25m. Each sets the correct MM:SS, while active countdown preset changes remain blocked. At default 5m, 5m is highlighted.
- [ ] Confirm no regressions in existing Watch/Alarms/Timer/History views and launch/Stop/Snooze logic.
