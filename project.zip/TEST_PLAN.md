# PavDroid V1.0.14 — Regression test plan

## Build
- [ ] GitHub Actions `:app:assembleDebug` succeeds after replacing **only** root `project.zip`.
- [ ] Installed APK shows **V1.0.14** in its header and Settings → About.
- [ ] Existing alarms/defaults/music library/History remain available if the APK can be installed in place. Do not mistake a changed debug signing key for an app regression.

## Terminology / display
- [ ] Alarm ongoing state: **ALARM ACTIVATED** with the same red border. Snooze retains its gold border. An enabled but not-launched alarm does not show as an ongoing alarm.
- [ ] Timer countdown continues normally. Timer reaching zero shows **Time Expired**; Snoozing / Stop remain intact.
- [ ] In Settings Defaults → New alarms and New timers: **Music starts**, **Zaps start**, and stepper values **1st Launch**, **2nd Launch**. Ordinal suffix small/raised, one line, original stepper width.
- [ ] Same stepper labels appear in Alarm editor and Timer setup. Plus/minus still move exactly one threshold: 1st Launch = 0 snoozes; 2nd = 1; 3rd = 2. A saved previous `after 1 snooze` alarm must show `2nd Launch` without changing its threshold.
- [ ] Each alert's Android notification title matches the app: **Alarm Activated** / **Time Expired**. Snoozing remains Snoozing. Existing Stop/Snooze notification actions still work.
- [ ] Android Settings → PavDroid → Notification categories shows existing Alarm/Timer channel entries under their updated names while retaining chosen Silent sound, Vibrate OFF, Alert importance and pop-up choices. No channel ID migration.
- [ ] History timeline summary and exported text use new wording; export header says **V1.0.14**. Previously recorded sessions remain visible and accurate.

## Physical-watch safeguards
- [ ] Compare with tested V1.0.13: original schedule and Timer countdown precision, BLE reconnection, music start at 10s, selected 3/5/10s media-volume increases, volume restoration on Snooze/Stop.
- [ ] Physical short middle-button tap snoozes once and long hold stops during both alarm/timer (including snoozing), with History matching.
- [ ] Zap threshold is unchanged (1st Launch means zaps eligible immediately; 2nd means after 1 completed snooze); ramp +10% per zap, cap at configured maximum, <=12 zap commands per launch.
- [ ] No simultaneous alarm/timer sessions and no changes to watch-firmware alarm slots.

No full-screen interface is included. Preserve V1.0.13 as rollback baseline until the new APK and actual watch pass.
