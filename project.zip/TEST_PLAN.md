# PavDroid V1.0.17 - Acceptance and regression tests

This is a source release; each unchecked item needs GitHub APK and/or real-device evidence. Do not treat accepted Bluetooth writes as proof of physical watch stimulation.

## Build and data preservation

- [ ] Verify Gradle `versionCode 117`, `versionName 1.0.17`, in-app version, History export version and full `project.zip` ZIP archive.
- [ ] GitHub Actions successfully compiles `:app:assembleDebug`, APK installs, watch connects, and original Pavlok Control V3.0.3 stays unmodified.
- [ ] Export stored History before uninstall. Confirm saved alarms, Defaults, selected MP3, notification preferences and timer configuration survive if APK signing permits in-place update.

## Key correction - both native engines, first use low-risk inputs

- [ ] Static assertions: no `MAX_ZAPS = 12`, `zapSent >= 12`, `zapsSent >= 12`, `/12 this launch`, or other legacy 12-count stop in active alarm/timer/fallback paths.
- [ ] With buzz/beep only and no zaps, run an alert past the equivalent of 12 stimulus cycles and confirm it remains active until Snooze or Stop; check timing and native log.
- [ ] With **low chosen zap max (e.g. 10-20%)** and explicit supervision, if appropriate, verify a 13th (and later) scheduled zap appears in the log, at the configured interval, without an automatic Stop or silent skip. Do not start with 60%-100% tests.
- [ ] Zaps-only timer does not auto-stop due to the removed 12-count limit; Stop and Snooze still work. Test using a safe/no-output instrumented path before physical shock exposure.
- [ ] Each new reactivation after Snooze resets escalation from 10%, rather than continuing at previous launch's maximum. The launch counter and per-launch zap number are clear in History.
- [ ] With 40% max, expected levels are 10, 20, 30, 40, 40, 40...; with 70% selected max and Safe Max checked, expected levels are 10, 20, 30, 40, 50, 60, 70, 50, 50... (derive in code review; do not use high output on wrist just to validate a sequence).
- [ ] At selected 50%, Safe Max checkbox hidden; at 60% or above, shown; per-Alarm and Timer choices persist independently. Unchecked maintains selected maximum, never exceeds it.
- [ ] Snooze immediately stops queued stimuli and music; watch middle-button hold Stop shuts the alert down and cancels all pending work. No automatic restart from stale callbacks.
- [ ] Smart Timeout remains initially 1 hour and becomes 2 hours after the latest snooze; OFF means no automatic session deadline. The absence of a 12-zap cap means prolonged electrical exposure is possible when OFF.
- [ ] With disconnected/reconnected watch, no stale backlog of queued zaps should be replayed; rejoining ongoing session continues only if that session is still active.

## V1.0.16 regression work (not yet verified by device)

- [ ] Samsung zoom 2/3/4 and huge fonts: header no overlap, alarm day buttons wrap, History actions and presets wrap cleanly, 3+1 singleton centered; dialogs scroll and fixed Save buttons remain available.
- [ ] Alarm/Timer editor identical zap + Music stepper styling; intensity slider hold 0.2s, no visible hold instruction; 60-80% red and >=90% white thumb ring; Smart Timeout below Preview.
- [ ] Shared silent Snooze Countdown category covers both alarm and timer; previous Alarm Activated and Time Expired notification preferences stay unchanged on update.
- [ ] Alarm Upcoming quiet notification appears nine hours before next Android-owned enabled alarm, updates on edits/disables/launch/reboot/time changes; does not create firmware alarm.
- [ ] Music start timing, volume ramp, restore on Snooze/Stop, quiet notifications and independent History/connection logs work as in earlier verified releases.
- [ ] Session overlap still blocked with popups, not graying an unrelated active operation. Timer Reset to Defaults preserves selected timer duration.

## Known evidence limitations

V1.0.15's Nov 22 History proves a 12th zap command was **queued** at 7:14:12 AM, then no further logged zap requests while the alarm remained active until 8:42:11 AM. It does **not** independently prove physical wrist delivery or continuous buzz/beep after zap 12. This release changes that scheduling behavior in code; the true observed fix requires a subsequent installed-build test. The 50% ceiling is a user-configured intensity rule, not a medical safety certification.
