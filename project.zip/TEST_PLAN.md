# PavDroid 2.0.0 REfresh — acceptance ledger

## Automated/local checks

- [x] New page renders at 390 CSS pixels; no old firmware-alarm UI or Code Red settings elements.
- [x] JavaScript parses successfully; browser startup has zero uncaught errors.
- [x] Mock-native integration: create and save Android alarm, edit and Copy+30, and verify the saved `intensity` and `timeReadout` fields are sent to native alarm engine.
- [x] Mock-native integration: Alarm editor state preserved when opening Advanced via Time Readout info and returning.
- [x] Mock-native integration: Timer presets, protected slider to 70%, Safe Max auto-check, Timer start profile, Timer Stop and Reset to Defaults while preserving selected duration.
- [x] Mock-native integration: Advanced TTS starting volume changes are passed to the native bridge.
- [x] Native source audit: old firmware-list browser interface, Code Red classes and other unused components absent; BLE writing API accepts only direct buzz/beep/zap UUIDs.
- [ ] Actual Android Gradle build and install (cannot be validated by browser tests).

## Real device checks (all pending)

1. Build APK with GitHub Actions; verify package `com.projrcc.pavdroid.refresh`, versionName 2.0.0, and separate installation without uninstalling V1.0.20.
2. Reconnect watch via BLE with the phone unlocked; verify battery percentage and charge bolt only when reported. Then lock the phone, swipe the app from Recents and verify automatic BLE reconnection on returning to range.
3. Add an Android-owned alarm using Alarm editor; verify day-mask presets, time keypad, Save, Edit, Copy+30, Delete and pending nine-hour notification. Check scheduled 1-minute alert with screen locked.
4. Send short **buzz/beep only** Timer and Alarm patterns; verify cadence and watch middle tap Snooze, middle long-hold Stop; ensure one-active-session lock prevents overlapping sessions.
5. Allow seven-minute Alarm Snooze and configured Timer Snooze to expire, check rerun, music reset on every Launch and cancellation on Stop. Check notification actions and distinct Snooze Countdown channel.
6. Verify Time Readout speaks on Snooze **after MP3 stops** and uses Android Media volume with TTS starting 20%, +10 percentage points per Snooze capped at 100%; volume restored afterward.
7. Exercise compact Safe Max, Time Readout and Smart Timeout checkboxes in both editors at 50% and 60% thresholds; verify saved unchecked choice stays unchecked on subsequent editing.
8. Test MP3 library import and selected song, one per alarm/timer, editor return after Settings, actual audio volume ramps on the phone and background audio behavior.
9. Export History independently from Connection log, clear the latter without losing the former, verify one timeline per session and correct 21+ Snooze tracking.
10. Test alarm app restart, Android restart, 9-hour upcoming reminder, Doze/reconnection, permissions and battery optimizations before using V2 as sole wake-up alarm.
11. If testing long sessions, remain cautious about repeated electrical stimulation; queued BLE writes are not proof of delivered electrical output and exposure safety is unverified.

**Production gate**: Keep V1.0.20 as the reference; do not replace it or migrate its data until V2.0.0 passes phone/watch acceptance.
