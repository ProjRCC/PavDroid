# PavDroid V1.0.10 — Focused test plan

## Build and first launch

1. GitHub Actions `:app:assembleDebug` must pass; install the APK and confirm `V1.0.10 · ANDROID`, original four tabs, Bluetooth connection/battery, and existing alarms/history. A stable signing key is **not** in this version.
2. Open Settings, check per-new-Alarm and per-new-Timer grouped Stimuli / Zaps / Music values and auto-save after closing/reopening. Use the App info and Notifications shortcuts to verify Android opens the correct PavDroid pages.
3. Open an Alarm editor and Timer configuration: enable Music; all controls should be visible until pressing **−**. Use **+** to expand again. Check the `Increase every` stepper displays seconds and persists after save. Check top and bottom Alarm Save buttons remain equivalent.

## Low-risk physical checks first

4. Without zaps (Zaps=0), choose a short Snooze, music starting immediately, start 30%, increase +20% every 15 seconds. Allow firing past 10s, 25s, 40s. Compare logged requested Media percentages with actual Android stream levels. Confirm Snooze interrupts and restores prior Media volume. Allow re-firing and verify volume starts again at 30% before rising.
5. Repeat on Timer with the same configured intervals and test notification Snooze/Stop, History event timeline, and Media level restoration. Use distinct Timer and Alarm default values to ensure they stay separate.
6. Set Music after 2 Snoozes: verify music is silent during the first two firing rounds, then starts exactly 10 seconds into the next eligible firing and increases at the configured interval.

## Zap gating (low-intensity, physical watch)

7. With Buzz and Beep configured and **Zaps after 1 Snooze**, verify the first firing has **no zaps** but buzzes/beeps and watch Snooze work normally. On re-firing, each queued zap should request 10%, 20%, 30%, etc., up to the configured maximum. Observe on watch; queued does not prove delivered.
8. Check a low maximum (e.g. 20%) never exceeds that limit. Stop/Snooze must discard unsent commands. The native 12-zap safety cap must remain effective per firing.
9. Repeat a short timer case with delayed zaps to ensure Timer behavior matches Alarm behavior. Keep a backup wake-up alarm; no high-intensity testing until pacing/cancellation are confirmed.

## Data and regressions

10. Export History and verify that the same Timer start is not duplicated by an older `Timer status notification: countdown` record alongside structured history. Header should read V1.0.10; Connection log stays separate.
11. Test existing V1.0.9 alarms survive the upgrade without silent settings rewrites; Music/Watch connection, repeated Snooze, and background operation still need longer physical reliability tests.

**Evidence levels:** Syntax/browser pass ≠ GitHub APK build ≠ physical watch delivery. Record actual phone version, Android notification permission, watch battery, and timestamps when reporting results.
