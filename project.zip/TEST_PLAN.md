# PavDroid V1.0.11 — targeted regression tests

## Build and upgrade

- [ ] GitHub Actions `:app:assembleDebug` succeeds and installed APK shows **V1.0.11** in the header and About.
- [ ] Export History before installing if Android requires a one-time uninstall due to differing debug signatures; do not assume an in-place upgrade until consistent signing is configured.
- [ ] V1.0.10 saved alarms, music selection, defaults, and History remain intact when upgrading without uninstalling.

## Interface layout (Alarm and Timer)

- [ ] After days/name/time or timer duration/presets, both editors show **Snooze time, Music, stimulus counts and interval, full-width Zap slider, Zaps after, Smart Timeout, Preview**, in that order.
- [ ] Sliders occupy their own full-width row; **Zaps after** never appears alongside the slider (even at narrow width).
- [ ] No elements collide with Smart Timeout, Preview, or sticky Save/Cancel footer while scrolling.
- [ ] Alarm top and bottom Save buttons still use the same validation and save path.
- [ ] Music expands/collapses; toggling its display does not alter Music enablement or saved percentages/timing.
- [ ] Timer no longer displays **Buzz on start** checkbox; starting a Timer with the watch connected produces the familiar low-strength 30% confirmation buzz.

## Settings

- [ ] New alarms and New timers titles are visually larger, while default values still auto-save and affect **new** sessions only.
- [ ] In each Zap group, the fourth cell reads **Escalation Setting / Start at 10%. / Increase to Max 40%.** (or selected value); changing Max to 50% updates that text to 50%.
- [ ] The intensity steppers, Music library/preview, Android App info and Notifications shortcuts still work.

## Native Timer Zap hold-off (physical watch required)

- [ ] Configure 3 buzz, 3 beep, 1 zap, max 20% and **Zaps after 1 snooze**. Start a short countdown with a connected Shock Clock 3.
- [ ] At first Times Up, verify buzz/beep groups occur but **no physical zap** is delivered, including through several repeating stimulus cycles. Connection log should say zaps are held at **0/1 snoozes**.
- [ ] Snooze using the watch or notification. After the Snooze duration expires, verify the first eligible physical zap occurs at **10%**, followed by 20% at most (with the existing inter-group pacing).
- [ ] Verify each Snooze cancels queued stimuli, resets the per-firing zap count, and the existing 12-zap-per-firing limit remains.
- [ ] Repeat with **Zaps after 0** (zaps eligible immediately), with Zaps count 0 (no zaps), and with a timer configured for only zaps while hold-off is active. Confirm no unintended zap before the threshold.
- [ ] Test both active Alarm and Timer sessions for no simultaneous overlap, middle-button tap Snooze, long-hold Stop, notification Stop, History, and native Bluetooth reconnection.

## Evidence quality

JavaScript syntax, ZIP integrity, and browser-mock layout checks do **not** establish a successful Android APK build or real Bluetooth delivery. Record physical-watch observations separately from queued/stored event messages; use a backup wake-up alarm.
