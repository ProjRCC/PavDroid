# PavDroid V1.0.12 — Test checklist

## Build / installation (required)

- [ ] GitHub Actions `:app:assembleDebug` passes, APK installs, app shows **V1.0.12** in the header and About.
- [ ] Check existing saved alarms, music library and History survive an in-place update if the installed APK has a compatible signature. Do not assume signing compatibility.

## Settings and defaults

- [ ] Open Settings: Music/Defaults initially open; Watch/Android/About initially collapsed (unless previously changed). Toggling any − / + reveals/hides only its own content.
- [ ] New alarms and New timers collapse independently. Stimuli/Zaps/Music each collapse independently, and a parent retains its children's states after reopening.
- [ ] Smart Timeout is in **Stimuli**, not underneath Music. Verify Alarm and Timer switches save independently.
- [ ] Text sizes descend from page title to main section to New alarms/New timers to group to field. Verify no overlaps on the Samsung phone at normal and large font scales.
- [ ] On a *fresh install*, verify screenshot defaults: alarm 5/5/1, 8s, 7min, 40%, zap after 1 Snooze, music after 0, 20% +15% every 5s, Smart ON; timer 3/3/1, 6s, 1min and the same other defaults. Existing saved user defaults should not be unexpectedly replaced on upgrade.
- [ ] Modify a Settings default and reopen: saved value remains. Ensure collapsing a section changes no value.

## Timer controls

- [ ] When Timer is ready, the upper-right **Reset to defaults** button appears instead of Ready.
- [ ] Choose 20:00, alter timer buzz/beep/zap settings, snooze, music, intensity and interval. Change the duration to 10:00; the current settings should remain.
- [ ] Tap **Reset to defaults**: timer controls return to saved Timer defaults, but **10:00** stays selected. Repeat with a custom MM:SS entry. Confirm the selected preset stays selected when appropriate.
- [ ] Change Timer defaults inside Settings and close it: the current Timer does not change until Reset is tapped.
- [ ] Close/reopen the app when Timer is idle: current Timer options (not necessarily its duration) remain available.
- [ ] Start a timer: reset button disappears, ordinary Running / Alerting / Snoozing badge and Snooze/Stop actions work. It returns in Ready after Stop, without changing settings unexpectedly.

## Alarm controls

- [ ] New alarm uses saved Alarm defaults. Edit an existing alarm and confirm its custom settings do not reset.
- [ ] Verify the Snooze label is near its stepper for both Alarm and Timer, without touching/overlapping other sections.
- [ ] Top and bottom Save alarm buttons still use the same validated action, and alarm-editor controls remain usable with keyboard and scrolling.

## Regression — physical Shock Clock 3 testing

- [ ] One active alarm or timer at a time; Alarm / Timer Watch middle-button tap Snoozes and long hold Stops.
- [ ] New 10-second MP3 delay, selected snooze threshold, Media volume escalation and restoration, and history events remain functional.
- [ ] Zap-after-Snoozes gate and rising 10%→maximum intensity on physical watch remain correct. Start with buzz/beep-only and low-intensity tests. Retain existing 12-zap-per-firing limit.
- [ ] Locked-phone alarm, native BLE automatic reconnection, Timer notifications, and exported History show no regressions.

**Evidence tiers:** Source syntax/browser tests are not APK build proof. APK build success is not proof of real stimulus delivery or overnight alarm reliability. Keep an independent wake-up backup while testing.
