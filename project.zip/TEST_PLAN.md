# Pavlok Control V3.0.2 — release verification plan

**Build gate** — GitHub Actions `Build Native Pavlok Control APK` must compile cleanly. Install over V2.0.49/50 if possible; do not uninstall until exporting any history you want to retain. Verify the UI displays **V3.0.2 · ANDROID**. Source checks alone are not a substitute for an APK build or hardware test.

## Essential tests (use a separate reliable alarm)

1. **Watch connection:** Pair once, disconnect/reconnect several times, background/foreground the app. Battery and watch name should remain sensible. Connection `Connected` and alarm-list `X read` represent separate facts. Each physical Snooze should appear only once in the log, even after reconnects.
2. **Read a populated alarm list:** Save and verify a normal watch alarm. Trigger an alarm while reading the list. If the watch reports zero despite prior verified nonempty alarms, the app must say **Unverified**, retain the list only as a noneditable display, and **not** clear Code Red metadata or upcoming reminders. Record the diagnostic raw packet length and prefix from the Connection log.
3. **True empty list:** Confirm alarm deletion when safe and use the deliberate empty-list workflow. The app must not block every legitimate fresh zero read; **never** assume a zero reply is proof of deletion during an active episode. Read back and write the first new alarm safely.
4. **No-Code-Red baseline:** Run an ordinary watch alarm, Snooze and Stop via watch and phone. The watch should operate exactly as it did in V2.0.49; no new timer should start after thirty minutes with Code Red disabled.
5. **Code Red full run:** Enable Code Red, no MP3 required; set a real alarm. Observe first FIRING at T0, first confirmed SNOOZED at T1, multiple Snoozes/refires, and at T0+30:00 the watch firmware dismissal. At **T0+30:05**, expect `Code Red handoff callback ...`, `Code Red started independent 300s native timer ...`, and an ongoing timer countdown. The earliest snooze must control T0; later snoozes must not shift it. The backup must never be skipped for missing MP3.
6. **Disconnection and zero-read mid-episode:** With a safe alarm run, allow Bluetooth to reconnect and deliberately trigger a read. A zero result must not cancel the frozen backup. Export Connection log after T0+30:05; note the callback time, lateness, and whether `NativeTimerEngine` actually reached countdown.
7. **Backup Times Up:** After its five-minute countdown, verify buzz/beep/zap settings at safe intensity. Tap middle button to Snooze: timer resets to a single five-minute phone countdown. Additional short taps during countdown must **not** reset the deadline. Hold middle button to Stop; confirm one shared stop/reset. Verify phone notification Stop/Snooze and that alarm firmware is not overwritten.
8. **Overlap safety:** Try starting a new timer during a watch alarm, and try writing a watch alarm while a timer is active. Both must be blocked without replacing existing operations. Verify Code Red cannot overwrite a manual timer already running; log must record the conflict.
9. **Audio optional:** Enable Code Red > MP3 checkbox > Select MP3. Verify the 0–120-second No-Snooze delay, URI persistence, playback at the intended phone alarm volume, and silence on confirmed Snooze or Stop. Backup should still start if no MP3 is chosen or playback fails.
10. **History:** Confirm one combined alarm+Code Red session. Watch snooze = gold/black-outline; phone snooze = gold/white-outline. Confirm the failed/absent handoff reports **backup NOT confirmed**, not successful completion. Copy All/Export must not erase or prematurely end the session; separate Connection log Clear must not erase History.

## Visual regression

- Connection, Alarms, Timer and History layout should match V2.0.49 except compact **full-width 39 px + New alarm**. Long hints/statuses may wrap but may not increase button height.
- Code Red `ⓘ Code Red 🔴 [Enable]` shows the MP3 checkbox only when enabled and the file button only when the MP3 checkbox is enabled; never show an expansion arrow.
- Connection Event Log collapsed shows **zero** rows; Expand scrolls to top of the log; Collapse restores previous scroll position.
- Verify at 320, 360, 380 and 412 px; dialogs, buttons, timer controls and alarm cards must not overflow horizontally.

**Release gate:** do not consider Code Red reliable until at least one actual successful T0+30:05 handoff and one full backup Snooze/Stop cycle are observed on a physical watch, including a disconnect/reconnect scenario.

## V3.0.2 notification checks

1. On a **clean uninstall/install**, check Settings > Notifications > Notification categories: *Timer connection warning* should initially be Off; *Watch connection* is requested Off at channel creation, but Android may turn the required foreground-service channel back On.
2. Confirm the app can maintain watch monitoring with the screen off and recover reconnects. If disabling the channel affects background monitoring on this device, restore the channel to On and prioritize alarm reliability.
3. Confirm alarm, timer countdown, timer alerts, and Code Red music notification options are unaffected. Because timer-disconnect warnings default Off, do not rely on them for critical alarms.
4. Because the GitHub Actions build uses a fresh debug keystore on each run, a prior APK may not be updatable by normal installation. Export any history you need before uninstalling.


## V3.0.2 targeted checks

1. On clean install with no sessions, History should say **Select** (disabled), **Delete All**, **Export All**; not Done.
2. Generate two or three sessions. Tap Select, check one: **Delete Selected** / **Export Selected**. Clear checkboxes: **Delete All** / **Export All**. Confirm exported file contains only checked sessions when selected, and every session otherwise.
3. With background watch monitoring connected, attempt to dismiss the **Watch connection** notification by swiping. If Android allows this, verify the service continues to observe alarms and Code Red; check whether the notification reappears on subsequent connection changes. The OS may still insist on a visible foreground-service notification. Do not disable the monitor as a workaround.

## V3.0.3 targeted regression checks

1. Save a watch alarm named `CRTest`, and use **Read from watch** to verify it. Confirm its firing session appears in History as `CRTest`, not `Alarm 1`; exported History should say `ALARM CRTest (watch #1)`. Preserve the native slot ID in the raw Connection event log.
2. Enable Code Red, trigger a watch alarm, snooze once and then **long-hold the watch middle button** after 2–3 minutes. Confirm `DISMISSED` and `Code Red CANCELED` appear in both Connection and saved session export. If the firmware also emits a long-button packet, status must be `WATCH_LONG_PRESS_CONFIRMED`; otherwise expect `WATCH_STOP_INFERRED`, not a fabricated long-press confirmation.
3. Stop an alarm using the **phone** Stop button. With a confirming watch dismissal, status should be `PHONE_STOP_CONFIRMED`; do not confuse a queued write with proof the watch actually stopped.
4. Let an alarm end naturally near 30:00, without manual Stop. Status should say `AUTO_CUTOFF_INFERRED`, **not** an inferred watch long press. Code Red handoff should still start at 30:05 once armed and exactly scheduled, subject to physical-device validation.
5. If a long-press packet arrives within 5 seconds *after* the watch dismissal, the saved session can contain the upgraded confirmed origin without extending elapsed time.
6. History: without selecting sessions, verify `Export All` and `Delete All`. After selecting one or two, verify `Export Selected` / `Delete Selected` and exported content only for the checked sessions. With Select open and no checked sessions, both actions must be disabled. With no saved sessions, selection/export/delete controls are disabled.
7. Inspect connection log while alarm runs and ensure the existing timer, Code Red arming, watch reading, phone notifications, and protected handoff semantics are unchanged.
