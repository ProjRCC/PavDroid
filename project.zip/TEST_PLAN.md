# PavDroid V1.0.15 — UI regression checklist

## Build and preservation
- [ ] GitHub Actions builds the APK with version 1.0.15 / versionCode 115 from root project.zip.
- [ ] Existing alarms, saved Settings defaults, Timer duration/options, Music library, and History preserved if an in-place install is possible with the same signing key.
- [ ] Physical watch: Alarm/Timer launched, Buzz/Beep/Zap, Watch Snooze/Stop, Bluetooth reconnect, Music ramp/restore, Smart Timeout, and overlap blocking behave as in V1.0.14.
- [ ] Android notification sounds, vibration, pop-up preferences unchanged (channel IDs preserved).

## Visual: Samsung Screen Zoom 3 primary; other zoom and font sizes
- [ ] Header shows PavDroid, battery, version and gear without the removed eyebrow, and never overlaps.
- [ ] Navigation reads **Watch / Alarms / Timer / History**, with equal-sized and readable tab text.
- [ ] Timer presets 5m, 10m, 20m, 25m have clearly readable type; wrap whole buttons to a new row if narrower.
- [ ] Alarm/Timer editors show `Tap middle button to snooze, hold to stop` directly beneath the Snooze time stepper; no clipped heading instruction.
- [ ] Alarm summary: line 1 schedule/stimulus counts; line 2 `Zaps Max ... Launch · Music ... Launch` only when enabled. No ellipsis or cut-off values.
- [ ] Music and Zap launch stepper reads ordinal above `Launch`; +/- buttons keep the original height, and next-door stepper remains equal height.
- [ ] In Settings, Alarm/Timer defaults retain the same number/value on changing device size; narrow views wrap rather than clipping the longer intensity explanation.
- [ ] Alarm action buttons, History actions, daily repeat presets, and count fields reflow when needed; taps remain correctly routed.
- [ ] Settings, alarm editor, and other dialogs scroll fully; Save/Cancel/Done remain accessible.
- [ ] Font size larger independently of Screen Zoom; landscape and very narrow viewports remain usable.

## Baseline safeguard
Only HTML/CSS and `pavdroid-ui.js` were modified for layout, plus version strings in `pavdroid-history.js`, build metadata, README and test plan. No native Java/BLE engines changed. The proposed full-screen alarm screen remains unimplemented.
