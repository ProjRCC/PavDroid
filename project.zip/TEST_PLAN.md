# PavDroid V1.0.0 — first hardware-test checklist

The new engine is unverified on hardware. These checks are required before relying on PavDroid to wake you.

1. Verify GitHub Actions compiles the APK with the workflow at `.github/workflows/build-apk.yml`; verify Android package `com.projrcc.pavdroid` and launcher name/icon.
2. Confirm PavDroid's Connection tab identifies the watch and reads battery; check watch BLE reconnect after background/lock.
3. Confirm the Timer screen retains Pavlok Control V3.0.3 layout: numeric `500` becomes `5:00`, original preset row, +/- pulse steppers, interval stepper, zap slider and Buzz on start.
4. Start a short timer. Verify it does **not** start a watch-firmware timer, but delivers the configured direct stimuli at Times Up. Test tapping the watch button to snooze and holding to Stop.
5. Create a once-only Android alarm. Confirm it saves and appears while disconnected. Grant exact-alarm permission; verify it fires at the set time with the phone locked, then disables the one-shot schedule.
6. Verify a short watch button tap snoozes, a hold stops, the 7-minute default, repeated snoozes, maximum snooze handling, and no overlapping timer/alarm sessions.
7. Verify Smart Timeout logic with safe accelerated development tests, including one-hour initial cutoff, two-hour snooze reset and never stopping mid-snooze.
8. Choose a local MP3; verify 20-second delay from first snooze and playback until Stop. Test with phone locked and service reopened.
9. Verify zap cap, BLE-disconnected notifications, notification controls, background lifecycle, app process recreation, reboot schedule re-arming and precise-alarm permissions.
10. Confirm legacy firmware-saved watch alarms remain separate; disable them through Pavlok Control to avoid duplicate alarms.

**A successful GitHub APK compile is not proof of reliable alarm delivery.** Keep a backup alarm.
