# PavDroid V1.0.3 — focused device test plan

1. **Upgrade:** In-place install GitHub APK from replaced root project.zip; confirm app header `V1.0.3 · ANDROID`, retained alarm settings and no History loss; icon uses approved blue watch/lightning artwork.
2. **Alarm notification:** With MP3 enabled, scheduled alarm triggers while phone locked. Native actions show STOP on left, Snooze / Mute on right. Snooze from notification silences music without ending alarm; STOP ends both. With music disabled label is Snooze. Confirm watch middle-button actions still work.
3. **Timer notification:** On Times Up, native STOP is on left; Snooze / Mute is on right when MP3 configured. Same behavior without music; countdown Pause/Resume still works and STOP is first.
4. **Notification settings:** The old `Alarm alerts` and `Alarm snooze` channels should disappear after upgrading, leaving active `PavDroid alarm firing` within the Alarm group if Android permits. The active firing channel retains the prior user setting. Ensure no duplicate legacy watch-alarm notifications. Category order cannot be forced by app (Samsung-controlled).
5. **Timer History:** Start a 5-second timer, let it alert, then snooze/stop. Colored timeline starts at Times Up and has no Timer running legend; summary retains `Times Up: 5s`; expanded events still record full countdown. Alarm History timeline unchanged.
6. **Battery:** While connected at 15% or higher both label/value white in Connection and header; below 15% both red; disconnected shows white Battery — and value —.
7. **No regressions:** Locked-phone GATT reconnect after leaving/returning to range, watch buzz/beep/zap on scheduled alarm, MP3 delay and silence on Snooze, History archive survive app process and screen changes.

Do not rely on this as an only overnight alarm until repeated unattended tests pass.
