/* PavDroid 2.0 / REfresh — Android-only application UI.
 * Fresh UI model; no browser-alarm, Code Red, firmware timer, or firmware
 * alarm-list source. Platform state is owned by the native service.
 * Native GATT button/Snooze/Stop and stimulation logic remain native.
 */
'use strict';
(function(){
const $=id=>document.getElementById(id);
const bt=window.PavDroidTransport;
const ui=window.AndroidUi||{};
const clamp=(n,min,max)=>Math.max(min,Math.min(max,Math.round(Number(n)||0)));
const load=(key,fallback)=>{try{const s=localStorage.getItem(key);return s===null?structuredClone(fallback):JSON.parse(s);}catch(_){return structuredClone(fallback);}};
const store=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));}catch(e){console.warn('Saving preferences',e);}};
const htmlSafe=value=>String(value??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const minInterval=(buzz,beep)=>Math.max(3,Math.max(Number(buzz)||0,Number(beep)||0)+1);
const ordinal=n=>{const v=Number(n),s=(v%100>=11&&v%100<=13)?'th':v%10===1?'st':v%10===2?'nd':v%10===3?'rd':'th';return v+s;};
const launch=n=>ordinal((Number(n)||0)+1)+' Launch';
const durationText=n=>{const sec=Math.max(0,Math.ceil(Number(n)||0));return Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0');};
const humanTime=t=>{const [h,m]=String(t||'07:00').split(':').map(Number);return (h%12||12)+':'+String(m||0).padStart(2,'0')+' '+(h>=12?'PM':'AM');};
const dayLabel=mask=>{const m=Number(mask)||0;if(!m)return'Once';if(m===127)return'Every day';if(m===62)return'Weekdays';if(m===65)return'Weekends';return [1,2,4,8,16,32,64].filter(b=>m&b).map(b=>({1:'Su',2:'Mo',4:'Tu',8:'We',16:'Th',32:'Fr',64:'Sa'}[b])).join(' · ');};
const defaults={alarm:{buzz:5,beep:5,zaps:1,interval:8,intensity:40,snooze:7,smart:true,safeMax:false,timeReadout:false,music:false,musicStartVolume:20,musicPreferredRisePercent:15,musicRiseSeconds:5,musicAfterSnoozes:0,zapsAfterSnoozes:1},timer:{buzz:3,beep:3,zaps:1,interval:6,intensity:40,snooze:1,smart:true,safeMax:false,timeReadout:false,music:false,musicStartVolume:20,musicPreferredRisePercent:15,musicRiseSeconds:5,musicAfterSnoozes:0,zapsAfterSnoozes:1}};
// A fresh install uses new keys; V1.0.20 data remains untouched. Future
// migration must be an explicit user-approved operation, not a silent overwrite.
const storedDefaults=load('pd2-defaults',{});
for(const type of ['alarm','timer'])defaults[type]={...defaults[type],...(storedDefaults[type]||{})};
const savedTimer=load('pd2-timer',{seconds:300});
const state={lastSessionKind:null,alarms:[],editorIndex:-1,editor:null,editorFromSettings:false,editorUnsaved:null,settingsFrom:null,timerSeconds:clamp(savedTimer.seconds||300,1,86399),timer:null,alarm:null,connected:false,busy:false,logExpanded:false,historySelected:new Set(),historySelecting:false,hiddenIds:new Set(load('pd2-history-hidden',[])),historyHideBefore:load('pd2-history-before',0),history:[],historySessions:[],music:load('pd2-music-library',{tracks:[],selectedUri:''}),tts:load('pd2-tts',{start:20,preferredIncrease:10}),previewVolume:load('pd2-preview-volume',70),previewPlaying:false,battery:'—',charging:false,lastBatteryAt:0};
if(!Array.isArray(state.music.tracks))state.music.tracks=[];
if(typeof state.music.selectedUri!=='string')state.music.selectedUri='';
const currentSong=()=>state.music.tracks.find(t=>t.uri===state.music.selectedUri)||null;
const songFor=p=>state.music.tracks.find(t=>t.uri===p?.musicUri)||currentSong();
const currentSession=()=>!!bt?.alarmState().active||!!bt?.timerState().active;
function haptic(){try{ui.hapticTap?.();}catch(_){}}
document.addEventListener('click',e=>{if(e.target.closest('button'))haptic();});
function warn(message){$('warningText').textContent=String(message||'Something went wrong.');if(!$('warningDialog').open)$('warningDialog').showModal();}
function ask(message,title='Confirm'){
 return new Promise(resolve=>{const d=$('confirmDialog');$('confirmText').textContent=message;$('confirmTitle').textContent=title;
  const done=val=>{d.close();resolve(val);};$('confirmNo').onclick=()=>done(false);$('confirmYes').onclick=()=>done(true);d.showModal();});
}
$('warningOk').onclick=()=>$('warningDialog').close();
function takeError(err){warn(err?.message||String(err));console.error(err);}
function assertIdle(){if(currentSession())throw Error('An alarm or timer is already in progress. Stop it before changing settings or starting another.');}
function configureToggleOptions(host,profile,change){
 host.replaceChildren();
 const defs=[{id:'safeMax',label:'Safe Max (50%)',info:'After reaching the selected maximum once, later zaps in this Launch use 50%. This is not a medically validated safe exposure level.'},
 {id:'timeReadout',label:'Time Readout',info:'On each Snooze, the MP3 stops and PavDroid announces the Snooze number and current time. Volume is configured under Settings → Advanced.'},
 {id:'smart',label:'Smart Timeout',info:'Stops after 1 hour of firing without Snooze. Each confirmed Snooze resets the deadline to 2 hours after that Snooze. Never interrupts Snooze.'}];
 for(const x of defs){const row=document.createElement('div');row.className='optionRow';row.id=host.id+'-'+x.id;
  row.innerHTML='<label class="check"><input type="checkbox"><span>'+x.label+'</span></label><button class="info" aria-label="About '+x.label+'" type="button">i</button>';
  const ck=row.querySelector('input');ck.checked=x.id==='safeMax'?!!profile.safeMax:!!profile[x.id];
  ck.addEventListener('change',()=>{profile[x.id]=ck.checked;if(x.id==='safeMax')profile.safeMaxTouched=true;change();});
  const help=document.createElement('div');help.className='optionHelp';help.textContent=x.info;help.hidden=true;
  row.querySelector('.info').onclick=()=>{help.hidden=!help.hidden;};
  host.append(row,help);if(x.id==='timeReadout'){const btn=document.createElement('button');btn.textContent='Go to Settings · Advanced';btn.type='button';btn.onclick=()=>openSettings('Advanced');help.append(btn);}
 }
 function refresh(){const visible=profile.intensity>=60;const row=$(host.id+'-safeMax');row.hidden=!visible;row.nextElementSibling.hidden=true;
  for(const x of defs){const checkbox=$(host.id+'-'+x.id).querySelector('input');checkbox.checked=!!profile[x.id];}
 }
 host.refresh=refresh;refresh();
}
function stepper(host,{min,max,step=1,value,format=String,onChange=()=>{}}){
 const node=typeof host==='string'?$(host):host;node.classList.add('stepBox');node.innerHTML='<button type="button" aria-label="Decrease">−</button><output></output><button type="button" aria-label="Increase">+</button>';
 const [minus,output,plus]=[...node.children];let val=clamp(value,min,max),lower=min,upper=max;
 const paint=()=>{output.innerHTML=format(val);minus.disabled=val<=lower;plus.disabled=val>=upper;};
 const set=(n,notify=false)=>{const next=clamp(n,lower,upper);if(val!==next){val=next;if(notify)onChange(val);}paint();};
 minus.onclick=()=>set(val-step,true);plus.onclick=()=>set(val+step,true);
 paint();return {get value(){return val;},set,maxValue(n){upper=n;set(val);},minValue(n){lower=n;set(val);}};
}
function makeNumberControl(type,kind,profile){
 const el=document.createElement('div');el.className='countField';el.innerHTML='<span>'+({buzz:'Buzzes',beep:'Beeps',zaps:'Zaps'}[kind])+'</span><div></div>';
 const ctr=stepper(el.lastElementChild,{min:0,max:5,value:profile[kind],onChange:v=>{
   if(!v&&!['buzz','beep','zaps'].some(k=>k!==kind&&profile[k]>0)){warn('Keep at least one stimulus.');ctr.set(1);return;}
   profile[kind]=v;profile.interval=Math.max(profile.interval,minInterval(profile.buzz,profile.beep));renderStimulus(type);
 }});el.controller=ctr;return el;
}
let currentlyRendering=false;
function renderStimulus(type){
 if(currentlyRendering)return;
 const p=type==='alarm'?state.editor:state.timer; if(!p)return;
 const host=$(type+'Stimulus');host.replaceChildren();
 const counts=document.createElement('div');counts.className='pulseCounts';for(const kind of ['buzz','beep','zaps'])counts.append(makeNumberControl(type,kind,p));host.append(counts);
 const interval=document.createElement('div');interval.className='stepRow';interval.innerHTML='<div><span>Stimulus interval</span><p class="intervalHint">Between repeating stimulus groups · 3–30s</p></div><div></div>';
 host.append(interval);p.interval=Math.max(minInterval(p.buzz,p.beep),clamp(p.interval,3,30));
 stepper(interval.lastElementChild,{min:minInterval(p.buzz,p.beep),max:30,value:p.interval,format:v=>v+'s',onChange:v=>{p.interval=v;renderPreview(type);}});
 const label=document.createElement('div');label.className='rangehead';label.innerHTML='<span>Maximum zap intensity</span><strong>'+p.intensity+'%</strong>';host.append(label);
 const slider=document.createElement('input');slider.type='range';slider.className='intensity';slider.min=10;slider.max=100;slider.step=10;slider.value=p.intensity;host.append(slider);
 // The existing 0.2-second deliberate touch is retained; scrolling the page
 // cannot accidentally select a stronger electrical-stimulus setting.
 let armed=false,touchTimer=null;
 const arm=()=>{touchTimer=setTimeout(()=>{armed=true;},200);};
 const clear=()=>{clearTimeout(touchTimer);armed=false;};
 slider.addEventListener('pointerdown',arm);slider.addEventListener('pointerup',clear);slider.addEventListener('pointercancel',clear);
 slider.addEventListener('input',()=>{
   if(!armed){slider.value=p.intensity;return;}
   p.intensity=Number(slider.value);label.querySelector('strong').textContent=p.intensity+'%';
   if(p.intensity>=60&&!p.safeMaxTouched)p.safeMax=true;
   $(type+'Options').refresh?.();paintSlider(slider);renderPreview(type);
 });paintSlider(slider);
 const zaps=document.createElement('div');zaps.className='stepRow';zaps.innerHTML='<span>Zaps start</span><div></div>';host.append(zaps);
 stepper(zaps.lastElementChild,{min:0,max:99,value:p.zapsAfterSnoozes,format:v=>launch(v),onChange:v=>{p.zapsAfterSnoozes=v;renderPreview(type);}});
 const hint=document.createElement('p');hint.className='zapHint';hint.textContent='10% first zap · +10% per zap, up to the maximum above.';host.append(hint);
 renderPreview(type);
}
function paintSlider(slider){const p=Number(slider.value);const tint=p<=30?'#42c987':p<=50?'#e9b959':'#f27880';const pct=(p-10)/90*100;slider.style.background='linear-gradient(to right,'+tint+' '+pct+'%,#43536b '+pct+'%)';slider.style.setProperty('--thumb-outline',p>=90?'#f7f9ff':'#c3cad3');slider.style.setProperty('--slider-fill',tint);slider.style.setProperty('--thumb-halo',p>=90?'4px':'1px');}
function renderPreview(type){const p=type==='alarm'?state.editor:state.timer;if(!p)return;
 const parts=[p.buzz?p.buzz+' buzz':null,p.beep?p.beep+' beep':null,p.zaps?p.zaps+' zap at '+p.intensity+'%':null].filter(Boolean);
 $(type+'Preview').textContent=(parts.length?parts.join(' → '):'No watch stimuli selected')+' · '+p.interval+'s between stimulus groups';
 if(type==='timer')saveTimerSetup();
}
function activeMusicSummary(p){const track=songFor(p)?.label||'Choose song in Settings';return `${track} · ${launch(p.musicAfterSnoozes)} · ${p.musicStartVolume}% +${p.musicRisePercent}% / ${p.musicRiseSeconds}s`;}
function musicCard(type,p,container){
 container.replaceChildren();const outer=document.createElement('div');outer.className='musicCard';container.append(outer);
 outer.innerHTML='<div class="musicHead"><label class="check"><input type="checkbox">Include Music</label><button type="button" class="musicFold" aria-label="Expand music settings">+</button></div><p class="smalltext musicSummary"></p><div class="musicDetails" hidden></div><div class="musicMissing" hidden><span class="smalltext">No song selected.</span><button type="button" class="ghost">Go to Settings · Music</button></div>';
 const enabled=outer.querySelector('input'),fold=outer.querySelector('.musicFold'),summary=outer.querySelector('.musicSummary'),details=outer.querySelector('.musicDetails'),missing=outer.querySelector('.musicMissing');enabled.checked=!!p.music;
 details.innerHTML='<p class="smalltext" style="margin-bottom:8px" id="songText-'+type+'"></p><div class="stepRow"><span>Music starts</span><div id="musicStart-'+type+'"></div></div><div class="musicVolumeGrid"><div><label>Start volume</label><div id="musicVolume-'+type+'"></div></div><div><label>Increase by</label><div id="musicRise-'+type+'"></div></div></div><div class="stepRow"><span>Increase every</span><div id="musicEvery-'+type+'"></div></div><p class="musicNote">Music starts 10s into each eligible launch; stops on Snooze or Stop.</p>';
 let collapsed=!p.music;const preferred=()=>clamp(p.musicPreferredRisePercent??15,0,50);
 const update=()=>{summary.textContent=activeMusicSummary(p);summary.hidden=!p.music||!collapsed;fold.textContent=collapsed?'+':'−';fold.disabled=!p.music;details.hidden=collapsed||!p.music;
   missing.hidden=!p.music||!!songFor(p);const name=$( 'songText-'+type);if(name)name.textContent=songFor(p)?.label||'Choose a song in Settings';
   if(type==='timer')saveTimerSetup();};
 const preferredIncrease=()=>Math.min(preferred(),100-p.musicStartVolume);
 let rise;
 stepper('musicStart-'+type,{min:0,max:99,value:p.musicAfterSnoozes,format:launch,onChange:v=>{p.musicAfterSnoozes=v;update();}});
 stepper('musicVolume-'+type,{min:10,max:100,step:10,value:p.musicStartVolume,format:v=>v+'%',onChange:v=>{p.musicStartVolume=v;p.musicRisePercent=preferredIncrease();rise.set(p.musicRisePercent);rise.maxValue(100-v);update();}});
 rise=stepper('musicRise-'+type,{min:0,max:50,step:5,value:Math.min(preferred(),100-p.musicStartVolume),format:v=>'+'+v+'%',onChange:v=>{p.musicRisePercent=v;p.musicPreferredRisePercent=v;update();}});
 stepper('musicEvery-'+type,{min:3,max:120,step:5,value:p.musicRiseSeconds,format:v=>v+'s',onChange:v=>{p.musicRiseSeconds=v;update();}});
 fold.onclick=()=>{collapsed=!collapsed;update();};enabled.onchange=()=>{p.music=enabled.checked;if(p.music){collapsed=false;if(!p.musicUri)p.musicUri=currentSong()?.uri||'';}else collapsed=true;update();};missing.querySelector('button').onclick=()=>openSettings('Music');
 update();return {update};
}
// All new profiles start from Settings defaults, not values accidentally
// inherited from a firmware-watch alarm object.
function profile(type,old=null){const p={...structuredClone(defaults[type]),...(old||{})};p.safeMaxTouched=!!old;
 // Native Android alarm templates persist 'max' and 'snoozeMinutes', while
 // the editor uses a single 'intensity' and 'snooze' model.
 if(type==='alarm' && old){
   p.intensity=old.intensity??old.max??p.intensity;
   p.snooze=old.snoozeMinutes??p.snooze;
   if(old.musicRisePercent!==undefined)p.musicPreferredRisePercent=old.musicRisePercent;
 }
 p.musicRisePercent=Math.min(p.musicPreferredRisePercent??15,100-p.musicStartVolume);p.intensity=clamp(p.intensity,10,100);p.interval=Math.max(minInterval(p.buzz,p.beep),p.interval);
 if(!old)p.safeMax=p.intensity>=60;return p;
}
function alarmEditorOpen(index=-1,copy=false){
 try{assertIdle();}catch(e){takeError(e);return;}
 const source=index>=0?state.alarms[index]:null;state.editorIndex=copy?-1:index;
 const p=profile('alarm',source);if(!source){p.name='ALARM '+(state.alarms.length+1);p.time='07:00';p.days=0;p.enabled=true;} else {p.name=copy?String(source.name+' copy').slice(0,20):source.name;}
 state.editor=p;$('editorTitle').textContent=source?(copy?'Copy alarm':'Edit alarm'):'New alarm';$('alarmName').value=p.name;$('alarmTime').value=p.time;
 renderDays();stepper('alarmSnoozeMinutes',{min:1,max:60,value:p.snooze,format:v=>v+' min',onChange:v=>{p.snooze=v;}});
 state.alarmMusicUi=musicCard('alarm',p,$('alarmMusicSlot'));
 configureToggleOptions($('alarmOptions'),p,()=>renderPreview('alarm'));renderStimulus('alarm');
 $('alarmEditor').scrollTop=0;$('alarmEditor').showModal();requestAnimationFrame(()=>$('alarmEditor').scrollTop=0);
}
function renderDays(){const mask=state.editor?.days||0;
 document.querySelectorAll('#dayButtons button').forEach(b=>{const selected=!!(mask&Number(b.dataset.day));b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
 document.querySelectorAll('.dayPresets button').forEach(b=>{const selected=Number(b.dataset.days)===0?mask===0:(mask&Number(b.dataset.days))===Number(b.dataset.days);b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
}
for(const b of document.querySelectorAll('#dayButtons button'))b.onclick=()=>{state.editor.days^=Number(b.dataset.day);renderDays();};
for(const b of document.querySelectorAll('.dayPresets button'))b.onclick=()=>{state.editor.days=Number(b.dataset.days);renderDays();};
function dismissEditor(){if($('alarmEditor').open)$('alarmEditor').close();$('alarmEditor').scrollTop=0;state.editor=null;state.editorIndex=-1;}
$('editorCancel').onclick=dismissEditor;$('editorClose').onclick=dismissEditor;
$('newAlarm').onclick=()=>alarmEditorOpen();
let saving=false;
$('editorSave').onclick=async()=>{if(saving)return;saving=true;$('editorSave').disabled=true;
 try{assertIdle();const p=state.editor;if(!p)throw Error('No alarm being edited');
  p.name=$('alarmName').value.trim();p.time=$('alarmTime').value;
  if(!p.name)throw Error('Enter an alarm name');if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(p.time))throw Error('Select a valid time');
  if(![p.buzz,p.beep,p.zaps].some(Boolean))throw Error('Choose at least one stimulus');
  if(p.interval<minInterval(p.buzz,p.beep)||p.interval>30)throw Error('Stimulus interval is too short');
  if(p.music&&!songFor(p)){openSettings('Music');return;}
  const data={...p,enabled:p.enabled??true,max:p.intensity,escalate:true,snoozeMinutes:p.snooze,
   smartTimeout:p.smart,safeMax:p.intensity>=60&&p.safeMax,timeReadout:p.timeReadout,
   music:!!p.music,musicUri:songFor(p)?.uri||'',musicLabel:songFor(p)?.label||'',
   musicDelay:10,musicRisePercent:p.musicRisePercent,musicStartVolume:p.musicStartVolume,musicRiseSeconds:p.musicRiseSeconds};
  delete data.safeMaxTouched;delete data.smart;delete data.snooze; // native reads intensity; max retained only as display alias
  const updated=state.alarms.map(x=>({...x}));if(state.editorIndex>=0)updated[state.editorIndex]=data;else updated.push(data);
  state.alarms=await bt.saveAlarms(updated);dismissEditor();renderAlarms();
 }catch(e){takeError(e);}finally{saving=false;$('editorSave').disabled=false;}
};
function renderAlarms(){
 state.alarms=bt.alarms();const host=$('alarmList');host.replaceChildren();$('alarmBadge').textContent=state.alarms.length+' on phone';
 if(!state.alarms.length){host.innerHTML='<p class="smalltext" style="margin-top:17px">No Android alarms yet. Tap + New alarm.</p>';return;}
 // Present enabled alarms first, then by time, without changing native storage order.
 // The original index is retained for Edit/Copy/Delete and the enable checkbox.
 const ordered=state.alarms.map((a,i)=>({a,i})).sort((x,y)=>
  Number(!!y.a.enabled)-Number(!!x.a.enabled)||
  String(x.a.time||'').localeCompare(String(y.a.time||''))||x.i-y.i);
 for(const {a,i} of ordered){
  const div=document.createElement('div');div.className='alarmItem'+(a.enabled?'':' is-disabled');
  const detail=(a.enabled?'':'Disabled · ')+dayLabel(a.days)+' · '+a.buzz+' buzz · '+a.beep+' beep · '+a.zaps+' zap';
  const musicBadge=a.music?' · <span class="alarmMusicGlyph" aria-label="Music enabled">♪</span>':'';
  const readoutBadge=a.timeReadout?' · <span class="alarmTtsGlyph" aria-label="Time Readout enabled">TTS</span>':'';
  div.innerHTML='<div class="row"><div><div class="alarmClock">'+htmlSafe(humanTime(a.time))+'</div><h3>'+htmlSafe(a.name)+'</h3></div><label class="check"><input type="checkbox" aria-label="Enable alarm" '+(a.enabled?'checked':'')+'></label></div><p class="alarmDetail">'+htmlSafe(detail)+musicBadge+readoutBadge+'</p><div class="alarmActions"><button data-action="edit">Edit</button><button data-action="copy">Copy</button><button data-action="delete" class="danger">Delete</button></div>';
  div.querySelector('input').onchange=async e=>{if(currentSession()){e.target.checked=a.enabled;warn('Stop the active alarm or timer before changing alarms.');return;}
   try{const updated=state.alarms.map(x=>({...x}));updated[i].enabled=e.target.checked;state.alarms=await bt.saveAlarms(updated);renderAlarms();}catch(err){takeError(err);renderAlarms();}};
  div.querySelectorAll('[data-action]').forEach(b=>b.onclick=async()=>{
   const act=b.dataset.action;
   if(act==='edit')return alarmEditorOpen(i);
   if(act==='copy')return alarmEditorOpen(i,true);
   if(await ask('Delete '+a.name+' · '+humanTime(a.time)+' from Android?','Delete alarm?')){
    try{assertIdle();const updated=state.alarms.filter((_,j)=>i!==j);state.alarms=await bt.saveAlarms(updated);renderAlarms();}catch(err){takeError(err);}
   }
  });host.append(div);
 }
}
function timerPrepare(fresh=false){state.timer=profile('timer',fresh?null:(Object.keys(savedTimer).length>1?savedTimer:null));
 const p=state.timer;p.seconds=state.timerSeconds;
 state.timerMusicUi=musicCard('timer',p,$('timerMusicSlot'));
 configureToggleOptions($('timerOptions'),p,()=>renderPreview('timer'));
 stepper('timerSnooze',{min:1,max:60,value:p.snooze,format:v=>v+' min',onChange:v=>{p.snooze=v;saveTimerSetup();}});
 renderStimulus('timer');renderTimerPreset();$('duration').value=durationText(p.seconds);
}
function saveTimerSetup(){if(bt.timerState().active)return;store('pd2-timer',{...state.timer,seconds:state.timerSeconds});}
function parseDuration(raw){
 const value=String(raw).trim();const mmss=value.match(/^(\d{1,4}):([0-5]?\d)$/);
 // A number without ':' is SECONDS, not an appended digit or minutes.
 // '5' means 0:05; '300' means 5:00; '5:00' is also 5 minutes.
 const sec=mmss?Number(mmss[1])*60+Number(mmss[2]):/^\d{1,5}$/.test(value)?Number(value):NaN;
 if(!Number.isFinite(sec)||sec<1||sec>86399)throw Error('Enter 1–86399 seconds or minutes:seconds (e.g. 5 or 5:00).');
 return sec;
}
function renderTimerPreset(){document.querySelectorAll('[data-seconds]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.seconds)===state.timerSeconds));}
for(const b of document.querySelectorAll('[data-seconds]'))b.onclick=()=>{if(bt.timerState().active)return warn('Stop the current timer first.');state.timerSeconds=Number(b.dataset.seconds);state.timer.seconds=state.timerSeconds;$('duration').value=durationText(state.timerSeconds);saveTimerSetup();renderTimerPreset();};
// Keep typing digits separate from the formatted MM:SS display. On Samsung's
// numeric IME, one digit shows 0:05 immediately; 5-0-0 becomes 5:00.
let timerKeypadDigits=null;
function timerSecondsFromDigits(digits){
 if(!/^\d{0,6}$/.test(digits))return NaN;
 if(!digits)return 0;
 const n=Number(digits),sec=(Math.floor(n/100)*60)+(n%100);
 return sec<=86399?sec:NaN;
}
$('duration').addEventListener('focus',e=>{
 if(bt.timerState().active)return;
 timerKeypadDigits='';
 e.target.select();requestAnimationFrame(()=>{if(document.activeElement===e.target)e.target.select();});
});
$('duration').oninput=e=>{
 if(bt.timerState().active)return;
 if(timerKeypadDigits===null)timerKeypadDigits='';
 const incoming=String(e.data||'').replace(/\D/g,'');
 if(String(e.inputType||'').startsWith('delete'))timerKeypadDigits=timerKeypadDigits.slice(0,-1);
 else if(incoming)timerKeypadDigits=(timerKeypadDigits+incoming).slice(0,6);
 else timerKeypadDigits=String(e.target.value).replace(/\D/g,'').slice(0,6);
 let seconds=timerSecondsFromDigits(timerKeypadDigits);
 if(!Number.isFinite(seconds)){timerKeypadDigits=timerKeypadDigits.slice(0,-1);seconds=timerSecondsFromDigits(timerKeypadDigits);}
 // '0:00' while empty is an edit state, not a runnable zero-second timer.
 e.target.value=durationText(seconds);
 if(document.activeElement===e.target)e.target.setSelectionRange(e.target.value.length,e.target.value.length);
 if(seconds>=1){state.timerSeconds=seconds;state.timer.seconds=seconds;renderTimerPreset();saveTimerSetup();}
};
$('duration').addEventListener('blur',e=>{
 if(bt.timerState().active)return;
 timerKeypadDigits=null;
 try{const seconds=parseDuration(e.target.value);state.timerSeconds=seconds;state.timer.seconds=seconds;saveTimerSetup();renderTimerPreset();}
 catch(_){}e.target.value=durationText(state.timerSeconds);
});
$('duration').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur();try{ui.hideKeyboard?.();}catch(_){}}};
async function timerAction(action){
 try{if(action==='start'){
   assertIdle();const p=state.timer;state.timerSeconds=parseDuration($('duration').value);
   if(!p.buzz&&!p.beep&&!p.zaps)throw Error('Choose at least one stimulus');
   if(p.music&&!songFor(p)){openSettings('Music');return;}
   const cfg={seconds:state.timerSeconds,buzz:p.buzz,beep:p.beep,zaps:p.zaps,intensity:p.intensity,interval:p.interval,snoozeSeconds:p.snooze*60,
    musicDelay:10,musicAfterSnoozes:p.musicAfterSnoozes,musicStartVolume:p.musicStartVolume,musicRisePercent:p.musicRisePercent,musicRiseSeconds:p.musicRiseSeconds,
    zapsAfterSnoozes:p.zapsAfterSnoozes,smartTimeout:p.smart,safeMax:p.intensity>=60&&p.safeMax,timeReadout:p.timeReadout,music:p.music,musicUri:songFor(p)?.uri||''};
   if(cfg.interval<minInterval(cfg.buzz,cfg.beep))throw Error('Stimulus interval is too short');
   saveTimerSetup();await bt.timerAction('start',cfg);

  }else await bt.timerAction(action);
  refreshSessions();if(action==='reset')tab('history');
 }catch(e){takeError(e);}
}
$('timerResetDefaults').onclick=async()=>{
 if(bt.timerState().active)return warn('Stop the timer before resetting its settings.');
 timerPrepare(true);saveTimerSetup();
};
$('timerStart').onclick=()=>{try{ui.hideKeyboard?.();}catch(_){}void timerAction('start');};
$('timerSnoozeBtn').onclick=()=>timerAction('snooze');$('timerPauseBtn').onclick=()=>timerAction('pause');$('timerResumeBtn').onclick=()=>timerAction('resume');$('timerStopBtn').onclick=()=>timerAction('reset');
$('alarmSnooze').onclick=()=>bt.alarmAction('snooze').then(refreshSessions,takeError);
$('alarmStop').onclick=()=>bt.alarmAction('stop').then(()=>{refreshSessions();tab('history');},takeError);
function refreshSessions(){const a=bt.alarmState(),t=bt.timerState();state.alarm=a;
 const currentKind=a.active?'alarms':t.active?'timer':null;
 if(state.lastSessionKind&&!currentKind)store('pd2-recent-stop',Date.now());
 state.lastSessionKind=currentKind;
 $('activeAlarmCard').hidden=!a.active;
 if(a.active){$('activeAlarmName').textContent=a.name||'Active alarm';$('activeAlarmStatus').textContent=a.phase==='snoozing'?'SNOOZING · '+durationText((a.snoozeUntil-Date.now())/1000)+' left':'ALARM ACTIVATED';$('alarmSnooze').disabled=a.phase!=='firing';}
 const active=!!t.active;$('timerSetup').hidden=active;$('timerEntry').hidden=active;$('timerActions').hidden=!active;$('timerFace').hidden=!active;
 $('timerBadge').textContent=active?({countdown:'Countdown',snoozing:'Snoozing',paused:'Paused',alerting:'Time Expired'}[t.phase]||t.phase):'Timer Enabled';
 $('timerBadge').hidden=!active;$('timerResetDefaults').hidden=active;
 if(active){$('timerFace').textContent=t.phase==='alerting'?'0:00':durationText(t.remaining);$('timerSnoozeBtn').hidden=t.phase!=='alerting';$('timerPauseBtn').hidden=t.phase!=='countdown';$('timerResumeBtn').hidden=t.phase!=='paused';}
 const blocked=!!a.active||active; // Popup-only interlock; never gray out the Start or New Alarm buttons.
 refreshPermissions(); // One owner for the notice avoids a visible permission flicker.
 $('timerStatus').textContent=active?t.phase==='alerting'?'Time Expired · tap watch middle button to Snooze, hold to Stop':t.phase==='snoozing'?'Snoozing · watch long hold to Stop':'' : '';
}
function tab(name,manual=false){
 if(manual)store('pd2-last-manual-tab',name);
 for(const b of document.querySelectorAll('[data-tab]'))b.classList.toggle('active',b.dataset.tab===name);
 for(const el of document.querySelectorAll('.page'))el.classList.toggle('active',el.id===name);
 if(name==='history')readHistory();if(name==='watch')refreshLog();if(name==='alarms'){renderAlarms();refreshSessions();}
 if(!document.querySelector('dialog[open]'))window.scrollTo({top:0,behavior:'instant'});
}
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>tab(b.dataset.tab,true);
// A recent physical watch Stop is discoverable from the native History journal.
// Missed scheduled alarms do not count as deliberately stopped sessions.
function latestNativeStop(){
 let latest=0;for(const event of bt.savedHistory()){
  const msg=String(event.msg||'');if(!msg.startsWith('PDH|'))continue;
  try{const rec=JSON.parse(msg.slice(4));if(rec.state==='stopped')latest=Math.max(latest,Number(event.millis)||0);}catch(_){}
 }return latest;
}
function openingTab(){
 if(bt.alarmState().active)return 'alarms';
 if(bt.timerState().active)return 'timer';
 const since=Math.max(Number(load('pd2-recent-stop',0)),latestNativeStop());
 if(since>0&&Date.now()-since<5*60*1000)return 'history';
 if(!load('pd2-has-opened',false))return 'watch';
 const preferred=load('pd2-last-manual-tab','watch');
 return ['watch','alarms','timer','history'].includes(preferred)?preferred:'watch';
}
function applyOpeningTab(){
 if(document.querySelector('dialog[open]'))return; // Don't steal focus from an existing editor.
 tab(openingTab());
}
function refreshConnection(){const info=bt.connection(),device=bt.device(),connected=bt.watchConnected();state.connected=connected;
 $('connectionBadge').textContent=connected?'Connected':info.state==='waiting'?'Waiting for watch':info.state==='connecting'?'Connecting':'Disconnected';
 $('connectionStatus').textContent=connected?'Connected to '+(device?.name||info.name||'Pavlok-3'):info.state==='waiting'?'Automatic Bluetooth reconnect armed':'Watch disconnected';
 $('watchName').textContent=device?.name||info.name||'—';$('disconnectBtn').disabled=!connected&&info.state!=='waiting';
 $('connectionHealth').textContent='Android schedules alarms; Bluetooth sends watch stimuli.';
 refreshSessions();
}
async function connect(){try{let device=bt.device();if(!device)device=await bt.scan();if(!device?.id)throw Error('No authorized watch found');await bt.connect(device.id);refreshConnection();refreshBattery(true);}catch(e){takeError(e);}}
$('connectBtn').onclick=connect;
$('disconnectBtn').onclick=()=>{bt.disconnect();refreshConnection();setBattery(null,false);};
$('refreshWatch').onclick=()=>{refreshConnection();refreshBattery(true);};
for(const id of ['batteryTapTop','batteryTapWatch'])$(id).onclick=()=>refreshBattery(true);
function setBattery(percent,charging){const pct=percent===null?'—':clamp(percent,0,100)+'%';state.battery=pct;state.charging=!!charging;
 for(const id of ['batteryValue','batteryTop'])$(id).textContent=pct;
 $('batteryBoltTop').hidden=!state.charging;$('batteryBoltWatch').hidden=!state.charging;$('watchBatteryLabel').textContent='Battery';
 $('batteryTop').style.color=percent!==null&&percent<15?'#ff8e96':'#eef5ff';$('batteryValue').style.color=percent!==null&&percent<15?'#ff8e96':'#eef5ff';}
let pollingBattery=false,chargeStatusUnsupported=false,chargeIssueRecorded=false;
async function refreshBattery(force=false){if(pollingBattery||!bt.watchConnected())return;
 if(!force&&(document.visibilityState==='hidden'||Date.now()-state.lastBatteryAt<30000||currentSession()))return;
 pollingBattery=true;try{const res=await bt.readBattery();const pct=Array.isArray(res)?res[0]:null;
  if(Number.isFinite(pct)){state.lastBatteryAt=Date.now();let charging=false;
   if(!chargeStatusUnsupported){
    try{const p=await bt.readCharge();
      if(Array.isArray(p)&&p.length){
       // GATT 0x2A1A: bits 5–4 = 11 means CHARGING. Bits 3–2 describe
       // discharging, and cannot be used to determine charging status.
       charging=((p[0]>>4)&3)===3;
      }else throw Error('empty charge-state value');
    }catch(e){
     const reason=String(e?.message||e);
     // A transient read timeout should not permanently disable future polls.
     chargeStatusUnsupported=/Characteristic not found|Characteristic unavailable/i.test(reason);
     if(!chargeIssueRecorded){chargeIssueRecorded=true;bt.note?.('Charging status not confirmed (GATT 2A1A): '+reason);}
    }
   }
   setBattery(pct,charging);
  }}catch(_){ /* BLE reads are deliberately secondary to watch stimuli. */ }finally{pollingBattery=false;}
}
bt.onConnection(()=>{chargeStatusUnsupported=false;chargeIssueRecorded=false;refreshConnection();setTimeout(()=>refreshBattery(true),1100);},()=>{refreshConnection();setBattery(null,false);});
window.addEventListener('focus',()=>{refreshConnection();refreshBattery(true);applyOpeningTab();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){refreshConnection();refreshBattery(true);applyOpeningTab();}});
// The same local Android Media volume is used for MP3 and spoken Snooze announcements.
function saveSpeech(){const t=state.tts;t.start=clamp(t.start,10,100);t.preferredIncrease=clamp(t.preferredIncrease,0,50);
 store('pd2-tts',t);try{ui.setTimeReadoutVolume?.(t.start,Math.min(t.preferredIncrease,100-t.start));}catch(_){}}
function refreshSpeechControls(){const p=state.tts;
 let rise;stepper('ttsStart',{min:10,max:100,step:10,value:p.start,format:v=>v+'%',onChange:v=>{p.start=v;rise.maxValue(100-v);rise.set(Math.min(p.preferredIncrease,100-v));saveSpeech();}});
 rise=stepper('ttsIncrease',{min:0,max:Math.min(50,100-p.start),step:10,value:Math.min(p.preferredIncrease,100-p.start),format:v=>'+'+v+'%',onChange:v=>{p.preferredIncrease=v;saveSpeech();}});
}
function resetSettingsLayout(section){
 for(const el of document.querySelectorAll('#settingsDialog details'))el.open=false;
 $('settingsDefaults').open=(!section||section==='Defaults');
 // The Defaults panel opens by default, but its two types are intentionally folded.
 if(section){const el=$('settings'+section);if(el)el.open=true;}
 $('settingsDialog').scrollTop=0;
}
function openSettings(section){
 if($('alarmEditor').open){state.editorFromSettings=true;$('alarmEditor').close();}else state.editorFromSettings=false;
 renderMusicLibrary();refreshSpeechControls();renderDefaults();resetSettingsLayout(section);
 $('settingsDialog').showModal();
 if(section&&section!=='Defaults')requestAnimationFrame(()=>$('settings'+section)?.scrollIntoView({block:'start',behavior:'instant'}));
 else requestAnimationFrame(()=>$('settingsDialog').scrollTop=0);
}
function closeSettings(){if(state.previewPlaying)stopPreview();$('settingsDialog').close();
 if(state.editorFromSettings&&state.editor){state.editorFromSettings=false;$('alarmEditor').showModal();state.alarmMusicUi?.update?.();}else state.timerMusicUi?.update?.();
}
$('settingsBtn').onclick=()=>openSettings();$('settingsDone').onclick=closeSettings;
function renderMusicLibrary(){const host=$('musicLibrary');host.replaceChildren();
 if(!state.music.tracks.length)host.innerHTML='<p class="smalltext" style="margin:13px 0">No music imported.</p>';
 for(const track of state.music.tracks){const row=document.createElement('div');row.className='trackRow';const l=document.createElement('label');const radio=document.createElement('input');radio.type='radio';radio.name='selectedTrack';radio.checked=track.uri===state.music.selectedUri;
 radio.onchange=()=>{state.music.selectedUri=track.uri;syncMusic();};l.append(radio,document.createTextNode(track.label));row.append(l);
 const remove=document.createElement('button');remove.className='ghost';remove.textContent='Remove';remove.onclick=async()=>{
  if(!await ask('Remove this song from the local library?'))return;
  state.music.tracks=state.music.tracks.filter(t=>t.uri!==track.uri);if(state.music.selectedUri===track.uri)state.music.selectedUri=state.music.tracks[0]?.uri||'';
  syncMusic();};row.append(remove);host.append(row);
 }
}
function syncMusic(){store('pd2-music-library',state.music);try{ui.setSelectedMusicUri?.(state.music.selectedUri);}catch(_){ }
 if(state.editor)state.editor.musicUri=state.music.selectedUri;
 if(state.timer && !$('alarmEditor').open)state.timer.musicUri=state.music.selectedUri;
 renderMusicLibrary();state.alarmMusicUi?.update?.();state.timerMusicUi?.update?.();}
$('addMp3').onclick=()=>{try{ui.pickMp3?.(state.music.selectedUri||'');}catch(e){takeError(e);}};
function mp3Picked(uri,label){if(!String(uri).startsWith('content://'))return;
 if(!state.music.tracks.some(t=>t.uri===uri))state.music.tracks.push({uri,label:label||'Selected MP3'});
 state.music.selectedUri=uri;syncMusic();}
function stopPreview(){try{ui.stopMusicPreview?.();}catch(_){ }state.previewPlaying=false;}
let previewVolume=clamp(state.previewVolume,10,100);
function renderPreviewVolume(){stepper('musicPreviewVolume',{min:10,max:100,step:10,value:previewVolume,format:v=>v+'%',onChange:v=>{previewVolume=v;store('pd2-preview-volume',v);ui.setMusicPreviewVolume?.(v);}});}
$('musicPreviewPlay').onclick=()=>{if(currentSession())return warn('Stop the alarm or timer before previewing music.');if(!currentSong())return warn('Select an MP3 first.');
 ui.previewMusic?.(currentSong().uri,previewVolume);state.previewPlaying=true;};$('musicPreviewStop').onclick=stopPreview;
$('exactSettings').onclick=()=>ui.openExactAlarmSettings?.();$('grantExactAlarm').onclick=()=>ui.openExactAlarmSettings?.();$('notificationSettings').onclick=()=>ui.openNotificationSettings?.('');
let testPower=30;
function setupTest(){const control=stepper('testIntensity',{min:10,max:100,step:10,value:testPower,format:v=>v+'%',onChange:v=>{testPower=v;paintIntensityBox($('testIntensity'),v);}});paintIntensityBox($('testIntensity'),control.value);}
for(const type of ['buzz','beep','zap'])$('test'+type[0].toUpperCase()+type.slice(1)).onclick=async()=>{
 if(currentSession())return warn('Stop the current alarm or timer before testing the watch.');if(!bt.watchConnected())return warn('Connect the watch first.');
 if(type==='zap'&&!await ask('Send a single '+testPower+'% test zap to your wrist?'))return;
 try{await bt.test(type,testPower);}catch(e){takeError(e);}
};
function renderDefaults(){const host=$('defaultsContent');host.replaceChildren();
 const groupSpecs=[['Stimuli',[
   ['buzz','Buzzes',0,5,1,v=>String(v)],['beep','Beeps',0,5,1,v=>String(v)],
   ['interval','Interval',3,30,1,v=>v+'s'],['snooze','Snooze time',1,60,1,v=>v+' min']]],
  ['Zaps',[
   ['zaps','Zaps',0,5,1,v=>String(v)],['intensity','Maximum intensity',10,100,10,v=>v+'%'],
   ['zapsAfterSnoozes','Zaps start',0,99,1,launch]]],
  ['Music',[
   ['musicAfterSnoozes','Music starts',0,99,1,launch],['musicStartVolume','Start volume',10,100,10,v=>v+'%'],
   ['musicPreferredRisePercent','Increase by',0,50,5,v=>'+'+v+'%'],
   ['musicRiseSeconds','Increase every',3,120,5,v=>v+'s']]]];
 for(const type of ['alarm','timer']){
  const p=defaults[type],section=document.createElement('details');section.className='defaultType';
  section.innerHTML='<summary><strong>New '+(type==='alarm'?'alarms':'timers')+'</strong><span class="foldIndicator" aria-hidden="true">+</span></summary>';
  host.append(section);
  const controls={};
  for(const [name,fields] of groupSpecs){
   const card=document.createElement('div');card.className='defaultsGroup';card.innerHTML='<h4>'+name+'</h4><div class="defaultsGrid"></div>';section.append(card);
   const grid=card.querySelector('.defaultsGrid');
   for(const [key,label,min,max,step,format] of fields){
    const field=document.createElement('div');field.className='defaultField';field.innerHTML='<label>'+label+'</label><div></div>';grid.append(field);
    const control=stepper(field.lastElementChild,{min:key==='interval'?minInterval(p.buzz,p.beep):min,max:key==='musicPreferredRisePercent'?Math.min(max,100-p.musicStartVolume):max,step,value:p[key],format,onChange:v=>{
     if(['buzz','beep','zaps'].includes(key)&&!v&&['buzz','beep','zaps'].every(k=>k===key||!p[k])){
      warn('Keep at least one buzz, beep, or zap.');control.set(1);return;}
     p[key]=v;
     if(key==='buzz'||key==='beep'){
      const limit=minInterval(p.buzz,p.beep);controls.interval?.minValue(limit);
      p.interval=Math.max(p.interval,limit);controls.interval?.set(p.interval);
     }
     if(key==='musicStartVolume'){
      controls.musicPreferredRisePercent?.maxValue(Math.min(50,100-v));
      // Retain preference internally, but don't let actual increase exceed 100%.
      p.musicRisePercent=Math.min(p.musicPreferredRisePercent??15,100-v);
     }
     if(key==='musicPreferredRisePercent')p.musicRisePercent=Math.min(v,100-p.musicStartVolume);
     if(key==='intensity'){
      paintIntensityBox(field.lastElementChild,v);
      const text=card.querySelector('.maxExplanation b');if(text)text.textContent=v+'%';
     }
     storeDefaults();
    }});
    controls[key]=control;
    if(key==='intensity')paintIntensityBox(field.lastElementChild,p.intensity);
   }
   if(name==='Zaps'){
    const d=document.createElement('div');d.className='maxExplanation';
    d.innerHTML='<strong>Escalation Setting</strong><span>Start at 10%.<br>Increase to Max <b>'+p.intensity+'%</b>.</span>';
    grid.append(d);
   }
  }
  const smart=document.createElement('label');smart.className='check defaultSmart';
  smart.innerHTML='<input type="checkbox" '+(p.smart?'checked':'')+'> Smart Timeout';
  smart.querySelector('input').onchange=e=>{p.smart=e.target.checked;storeDefaults();};section.append(smart);
 }
}
function paintIntensityBox(container,value){
 const box=container?.classList.contains('stepBox')?container:container?.querySelector('.stepBox');if(!box)return;
 const p=Number(value),color=p<=30?'#42c987':p<=50?'#e9b959':'#f27880';
 box.style.borderColor=color;box.style.borderWidth='2px';
 box.classList.toggle('extremeIntensity',p>=90);
}
function storeDefaults(){store('pd2-defaults',defaults);}
function refreshPermissions(){
 const allowed=bt.exactAllowed(),blocked=currentSession();
 $('alarmNotice').textContent=!allowed?'Exact alarm permission required. Enable it on the Watch tab.':blocked?'An alarm or timer is currently in progress.':'';
 $('exactAlarmGate').hidden=allowed;
 $('exactSettings').textContent=allowed?'Alarm permission ✓':'Allow exact alarms';
}
function keyboardDone(){try{ui.hideKeyboard?.();}catch(_){}document.activeElement?.blur?.();}
function disableAlarm(key){const alarms=bt.alarms();const i=alarms.findIndex(a=>String(a.name)+'|'+String(a.time)===key);if(i<0)return;
 if(currentSession())return warn('Stop the current alarm or timer first.');alarms[i].enabled=false;
 bt.saveAlarms(alarms).then(renderAlarms,takeError);
}
// Structured History: one session per actual PDH session ID, never a packet
// from a pre-existing watch-firmware alarm. No old Code Red sessions exist.
function readHistory(){state.history=bt.savedHistory().filter(e=>Number(e.millis)>0).sort((a,b)=>Number(a.millis)-Number(b.millis));
 const map=new Map();for(const e of state.history){if(!String(e.msg).startsWith('PDH|'))continue;
  let d;try{d=JSON.parse(e.msg.slice(4));}catch(_){continue;}if(!['timer','alarm'].includes(d.type)||!d.session||!d.state)continue;
  const id=d.type+':'+d.session;let s=map.get(id);if(!s){s={id,type:d.type,start:Number(e.millis),end:0,until:Number(e.millis),label:d.label||d.type,snoozes:0,events:[],states:[]};map.set(id,s);}
  s.until=Math.max(s.until,Number(e.millis));s.label=d.label||s.label;
  if(d.state==='snoozing')s.snoozes++;if(['stopped','missed'].includes(d.state)){s.end=Number(e.millis);s.reason=d.detail;s.missed=d.state==='missed';}
  s.states.push({at:Number(e.millis),kind:d.state,label:d.detail||''});
 }
 for(const s of map.values()){
  s.events=state.history.filter(e=>Number(e.millis)>=s.start&&Number(e.millis)<=s.until).map(e=>{
   let text=String(e.msg||'');if(text.startsWith('PDH|'))try{const d=JSON.parse(text.slice(4));text='PavDroid '+d.type.toUpperCase()+' · '+d.state.toUpperCase()+(d.detail?' · '+d.detail:'');}catch(_){ }
   return {at:Number(e.millis),text};
  });
 }
 state.historySessions=[...map.values()].filter(s=>s.start>state.historyHideBefore&&!state.hiddenIds.has(s.id)).sort((a,b)=>b.start-a.start);
 renderHistory();
}
function renderHistory(){const host=$('historyList');host.replaceChildren();$('historyCount').textContent=state.historySessions.length+' sessions';
 $('historySelect').textContent=state.historySelecting?'Done':'Select';$('historyDelete').textContent=state.historySelected.size?'Delete Selected':'Delete All';$('historyExport').textContent=state.historySelected.size?'Export Selected':'Export All';
 if(!state.historySessions.length){host.innerHTML='<p class="smalltext">No alarm or timer sessions recorded yet.</p>';return;}
 for(const s of state.historySessions){const item=document.createElement('div');item.className='historyItem';
  const fmt=new Date(s.start).toLocaleString();
  const header=document.createElement('div');header.className='row historyHeader';header.innerHTML='<div><h3>'+htmlSafe(s.label)+' · '+s.type.toUpperCase()+'</h3><p>'+htmlSafe(fmt)+'</p><p>Status: '+(s.missed?'MISSED':s.end?'Finished':'No stop recorded')+' · Snoozes: '+s.snoozes+'</p></div>';
  if(state.historySelecting){const box=document.createElement('input');box.type='checkbox';box.checked=state.historySelected.has(s.id);box.onchange=()=>{if(box.checked)state.historySelected.add(s.id);else state.historySelected.delete(s.id);renderHistory();};header.append(box);}
  item.append(header);const bar=document.createElement('div');bar.className='historyTimeline';
  const relevant=s.states.filter(x=>['firing','alerting','snoozing','countdown','paused','stopped','missed'].includes(x.kind));let prior=s.start,prevKind=s.type==='timer'?'countdown':'firing';
  for(const event of relevant.concat([{at:Math.max(s.until,s.start+1000),kind:'stopped'}])){
   if(event.at>prior){const span=document.createElement('span');span.style.flex=String(Math.max(1,event.at-prior));span.style.background=({firing:'#6f9fe5',alerting:'#f3a66d',countdown:'#55af91',snoozing:'#e8b75c',paused:'#61758d'}[prevKind]||'#66788e');bar.append(span);}prior=event.at;prevKind=event.kind;
  }item.append(bar);
  const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Expand session events ('+s.events.length+')';details.append(summary);
  for(const e of s.events){const div=document.createElement('div');div.className='historyEvent';div.textContent=new Date(e.at).toLocaleTimeString()+' | '+e.text;details.append(div);}item.append(details);host.append(item);
 }
}
$('historySelect').onclick=()=>{state.historySelecting=!state.historySelecting;if(!state.historySelecting)state.historySelected.clear();renderHistory();};
$('historyDelete').onclick=async()=>{
 const selected=state.historySelecting&&state.historySelected.size?[...state.historySelected]:state.historySessions.map(s=>s.id);
 if(!selected.length)return;if(!await ask('Delete '+selected.length+' selected History session(s)?'))return;
 if(selected.length===state.historySessions.length){bt.clearHistory();state.historyHideBefore=Date.now();state.hiddenIds.clear();store('pd2-history-before',state.historyHideBefore);}else {selected.forEach(id=>state.hiddenIds.add(id));store('pd2-history-hidden',[...state.hiddenIds]);}
 state.historySelected.clear();readHistory();};
function exportText(sessions){const lines=['PavDroid V2.0.4 | Alarm & Timer History','Exported '+new Date().toLocaleString(),''];
 for(const s of sessions){lines.push(s.type.toUpperCase()+' '+s.label+' | '+new Date(s.start).toLocaleString());lines.push('Status: '+(s.missed?'MISSED':s.end?'Finished':'No stop recorded')+' · Snoozes: '+s.snoozes+(s.reason?' · '+s.reason:''));
  for(const e of s.events)lines.push('  '+new Date(e.at).toLocaleTimeString()+' | '+e.text);lines.push('');}return lines.join('\n');}
$('historyExport').onclick=()=>{const selected=state.historySelecting&&state.historySelected.size?state.historySessions.filter(s=>state.historySelected.has(s.id)):state.historySessions;
 if(!selected.length)return warn('No History sessions to export.');try{ui.exportText?.('PavDroid-AlarmHistory.txt',exportText(selected));}catch(e){takeError(e);}};
function refreshLog(){const events=bt.eventHistory();const host=$('eventLog');host.replaceChildren();const recent=state.logExpanded?events:events.slice(-3);
 for(const e of recent.slice().reverse()){const li=document.createElement('li');const t=document.createElement('time');t.textContent=new Date(Number(e.millis)).toLocaleTimeString();const msg=document.createElement('span');msg.textContent=String(e.msg||'');li.append(t,msg);host.append(li);}host.hidden=!state.logExpanded;$('expandLog').textContent=state.logExpanded?'▲ Collapse event log':'▼ Expand event log';}
$('expandLog').onclick=()=>{state.logExpanded=!state.logExpanded;refreshLog();};
$('copyLog').onclick=()=>{const events=bt.eventHistory();const text='PavDroid V2.0.4 | Watch event log\n'+events.length+' recorded events\n\n'+events.map(e=>new Date(Number(e.millis)).toLocaleString()+' | '+e.msg).join('\n');
 try{ui.copyText?.(text);}catch(e){takeError(e);}};
$('clearLog').onclick=async()=>{if(!await ask('Clear the Connection event log? History will not be deleted.'))return;bt.clearEvents();refreshLog();};
function initialize(){
 state.timer=profile('timer',Object.keys(savedTimer).length>1?savedTimer:null);
 state.timerSeconds=clamp(savedTimer.seconds||300,1,86399);
 timerPrepare();renderPreviewVolume();setupTest();refreshSpeechControls();saveSpeech();
 renderAlarms();refreshSessions();refreshConnection();applyOpeningTab();store('pd2-has-opened',true);
 // Reapply the selected MP3 URI to the new test app's native audio store.
 syncMusic();
 setInterval(()=>{refreshSessions();if(document.querySelector('#history.page.active'))readHistory();if(document.querySelector('#watch.page.active'))refreshLog();refreshBattery();},1000);
 setTimeout(()=>refreshBattery(true),850);
}
window.PavDroidApp={tab,keyboardDone,mp3Picked,disableAlarm,refreshPermissions};
window.addEventListener('error',e=>{console.error('PavDroid UI',e.error||e.message);});
initialize();
})();
