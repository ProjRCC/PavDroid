/* PavDroid 2.0 / REfresh — Android-only application UI.
 * Fresh UI model; no browser-alarm, Code Red, firmware timer, or firmware
 * alarm-list source. Platform state is owned by the native service.
 * Native GATT button/Snooze/Stop and stimulation logic remain native.
 */
'use strict';
(function(){
const $=id=>document.getElementById(id);
const bt=window.PavDroidTransport;
const ui=window.AndroidUi||{};
const clamp=(n,min,max)=>Math.max(min,Math.min(max,Math.round(Number(n)||0)));
const load=(key,fallback)=>{try{const s=localStorage.getItem(key);return s===null?structuredClone(fallback):JSON.parse(s);}catch(_){return structuredClone(fallback);}};
const store=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));}catch(e){console.warn('Saving preferences',e);}};
const iconSvg=name=>{
 const paths={home:'<path d="M3 11 12 3l9 8v10h-6v-7H9v7H3z"/>',sliders:'<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="11" cy="17" r="2"/>',settings:'<path d="M12.00 5.25 L12.18 5.24 L12.36 5.19 L12.54 5.12 L12.73 5.03 L12.93 4.92 L13.14 4.78 L13.36 4.64 L13.60 4.49 L13.84 4.33 L14.10 4.18 L14.36 4.03 L14.63 3.90 L14.91 3.79 L15.19 3.70 L15.47 3.63 L15.74 3.60 L16.00 3.60 L16.26 3.64 L16.50 3.71 L16.72 3.82 L16.93 3.96 L17.11 4.13 L17.27 4.33 L17.40 4.56 L17.51 4.82 L17.60 5.09 L17.66 5.37 L17.70 5.67 L17.72 5.97 L17.73 6.27 L17.72 6.57 L17.71 6.86 L17.69 7.14 L17.68 7.40 L17.67 7.65 L17.67 7.88 L17.68 8.09 L17.72 8.29 L17.77 8.46 L17.85 8.62 L17.95 8.77 L18.07 8.91 L18.23 9.03 L18.40 9.15 L18.60 9.27 L18.82 9.38 L19.06 9.50 L19.31 9.63 L19.56 9.76 L19.82 9.90 L20.08 10.06 L20.33 10.23 L20.57 10.41 L20.78 10.61 L20.98 10.82 L21.14 11.04 L21.27 11.27 L21.37 11.51 L21.43 11.75 L21.45 12.00 L21.43 12.25 L21.37 12.49 L21.27 12.73 L21.14 12.96 L20.98 13.18 L20.78 13.39 L20.57 13.59 L20.33 13.77 L20.08 13.94 L19.82 14.10 L19.56 14.24 L19.31 14.37 L19.06 14.50 L18.82 14.62 L18.60 14.73 L18.40 14.85 L18.23 14.97 L18.07 15.09 L17.95 15.23 L17.85 15.37 L17.77 15.54 L17.72 15.71 L17.68 15.91 L17.67 16.12 L17.67 16.35 L17.68 16.60 L17.69 16.86 L17.71 17.14 L17.72 17.43 L17.73 17.73 L17.72 18.03 L17.70 18.33 L17.66 18.63 L17.60 18.91 L17.51 19.18 L17.40 19.44 L17.27 19.67 L17.11 19.87 L16.93 20.04 L16.72 20.18 L16.50 20.29 L16.26 20.36 L16.00 20.40 L15.74 20.40 L15.47 20.37 L15.19 20.30 L14.91 20.21 L14.63 20.10 L14.36 19.97 L14.10 19.82 L13.84 19.67 L13.60 19.51 L13.36 19.36 L13.14 19.22 L12.93 19.08 L12.73 18.97 L12.54 18.88 L12.36 18.81 L12.18 18.76 L12.00 18.75 L11.82 18.76 L11.64 18.81 L11.46 18.88 L11.27 18.97 L11.07 19.08 L10.86 19.22 L10.64 19.36 L10.40 19.51 L10.16 19.67 L9.90 19.82 L9.64 19.97 L9.37 20.10 L9.09 20.21 L8.81 20.30 L8.53 20.37 L8.26 20.40 L8.00 20.40 L7.74 20.36 L7.50 20.29 L7.28 20.18 L7.07 20.04 L6.89 19.87 L6.73 19.67 L6.60 19.44 L6.49 19.18 L6.40 18.91 L6.34 18.63 L6.30 18.33 L6.28 18.03 L6.27 17.73 L6.28 17.43 L6.29 17.14 L6.31 16.86 L6.32 16.60 L6.33 16.35 L6.33 16.12 L6.32 15.91 L6.28 15.71 L6.23 15.54 L6.15 15.38 L6.05 15.23 L5.93 15.09 L5.77 14.97 L5.60 14.85 L5.40 14.73 L5.18 14.62 L4.94 14.50 L4.69 14.37 L4.44 14.24 L4.18 14.10 L3.92 13.94 L3.67 13.77 L3.43 13.59 L3.22 13.39 L3.02 13.18 L2.86 12.96 L2.73 12.73 L2.63 12.49 L2.57 12.25 L2.55 12.00 L2.57 11.75 L2.63 11.51 L2.73 11.27 L2.86 11.04 L3.02 10.82 L3.22 10.61 L3.43 10.41 L3.67 10.23 L3.92 10.06 L4.18 9.90 L4.44 9.76 L4.69 9.63 L4.94 9.50 L5.18 9.38 L5.40 9.27 L5.60 9.15 L5.77 9.03 L5.93 8.91 L6.05 8.77 L6.15 8.62 L6.23 8.46 L6.28 8.29 L6.32 8.09 L6.33 7.88 L6.33 7.65 L6.32 7.40 L6.31 7.14 L6.29 6.86 L6.28 6.57 L6.27 6.27 L6.28 5.97 L6.30 5.67 L6.34 5.37 L6.40 5.09 L6.49 4.82 L6.60 4.56 L6.73 4.33 L6.89 4.13 L7.07 3.96 L7.28 3.82 L7.50 3.71 L7.74 3.64 L8.00 3.60 L8.26 3.60 L8.53 3.63 L8.81 3.70 L9.09 3.79 L9.37 3.90 L9.64 4.03 L9.90 4.18 L10.16 4.33 L10.40 4.49 L10.64 4.64 L10.86 4.78 L11.07 4.92 L11.27 5.03 L11.46 5.12 L11.64 5.19 L11.82 5.24 Z"/><circle cx="12" cy="12" r="3.0"/>',info:'<circle cx="12" cy="12" r="9.4"/><circle cx="12" cy="7.4" r="1.1" fill="currentColor" stroke="none"/><path d="M12 11v6" stroke-width="2.2"/>',watch:'<rect x="6" y="7" width="12" height="10" rx="3"/><path d="M9 7V3h6v4M9 17v4h6v-4"/><path d="M12 10v4"/>',alarms:'<circle cx="12" cy="13" r="8"/><path d="M12 9v5l3 2M5 2 2 5M19 2l3 3"/>',timer:'<circle cx="12" cy="13" r="8"/><path d="M12 13V8M9 2h6M19 6l2-2"/>',history:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2M3 4v4h4"/>',speech:'<path d="M5 6h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H8l-5 3V8a2 2 0 0 1 2-2z"/><path d="M8 11h8M8 14h5"/>',music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',arrow:'<path d="m15 18-6-6 6-6"/>',play:'<path d="m8 5 11 7-11 7z"/>',check:'<path d="m5 12 5 5L20 7"/>'};
 return '<svg class="appIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(paths[name]||paths.info)+'</svg>';
};
const RELEASES=[
 {version:'3.0.53',title:'Consistent controls and Home styling',items:['Home uses the shared page background and card borders.','Clock hands and selection circles match the selected time fields.','Primary buttons and the clock stepper use subtle outlines, including widget primary actions.']},
 {version:'3.0.52',title:'Cleaner alarm time selector',items:['Removed the separator between the hour and minute buttons and kept all three time fields evenly spaced.']},
 {version:'3.0.51',title:'Two-hand alarm clock',items:['Hour and minute hands stay visible with distinct lengths and emphasis.','Subtle minute markers, rounded hands and separate hour/minute number weights. Existing time selection behavior is unchanged.']},
 {version:'3.0.50',title:'Timer snooze extension',items:['The snoozing Timer page now offers +1 min, using the same native extension as widgets and notifications.']},
 {version:'3.0.49',title:'Consistent active session cards',items:['Timer sessions use centered headings and status text, matching the active Alarm card.','Timer has more vertical breathing room, no setup info control during sessions, and Stop on the left. Widget layout and session behavior unchanged.','Alarm notification and widget action labels consistently say Snooze.']},
 {version:'3.0.48',title:'Session color correction',items:['Restores the original Timer, Home and Alarm layouts. Only existing session titles, status labels and times receive status text colors.','Widget and History improvements retained.']},
 {version:'3.0.45',title:'Consistent session colors',items:['Blue borders for expired timers and activated alarms; gold for snoozing.','Running and paused timers use neutral colors, including all widgets.','Home and Timer session borders and status text match History.','Expired widgets omit the redundant zero; timeline endpoints use smaller seconds.']},
 {version:'3.0.44',title:'Quicker Timer return and navigation',items:['Scroll back to the top of Timer to restore Start Timer and navigation.','Back remains available when alarms are selected.','Explicit widget navigation takes priority over normal app opening.']},
 {version:'3.0.43',title:'Consistent help and compact controls',items:['Sounds and Stimulus terminology; contextual Settings help.','Bulk alarm selection, shorter timer presets and compact History times.','Upcoming Alarm widget heading and direct navigation.']},
 {version:'3.0.42',title:'Widget headings and simpler Music controls',items:['Larger adaptive Alarm and Timer widget headings.','Restored the Watch icon and shortened the Home heading.','Music help is behind the info icon; preview volume sits beside Active playlist.']},
 {version:'3.0.41',title:'Combined widget dividers',items:['Thinner centered dividers align with the outer navigation icons; widget spacing is unchanged.']},
 {version:'3.0.40',title:'Compact widget and Home refinements',items:['More clearance around the compact combined widget divider and edges.','Home alarm and timer detail text opens its editor without a surrounding button box.','Portrait-only activity.']},
 {version:'3.0.39',title:'Widget spacing refinements',items:['Larger individual 4×2 controls when space permits.','Balanced clearance around compact combined divider.','Thicker combined section and navigation dividers.']},
 {version:'3.0.38',title:'Consistent widget controls',items:['Alarm and Timer headings across all widgets.','Single five-minute adjustment pair, from one to sixty minutes.','Responsive control heights and restored expanded navigation.']},
 {version:'3.0.37',title:'Widget duration controls',items:['Expanded combined widgets add five-second adjustment buttons.','Larger timer adjustment buttons and a shorter navigation strip.']},
 {version:'3.0.36',title:'Combined widget borders',items:['Active blue or amber borders follow the outer edge of the combined widget.','Inactive sections remain gray and disabled.']},
 {version:'3.0.35',title:'Widget navigation and snoozing',items:['Equal-width snooze actions.','Expanded widget has Home, Alarm, Timer and History shortcuts with labels.','Widget launches resolve the requested destination before revealing the app.']},
 {version:'3.0.34',title:'Four widget choices',items:['Separate compact and expanded combined widgets.','Expanded widget includes a compact Home, Alarms and Timer navigation strip.']},
 {version:'3.0.33',title:'Comfortable widgets and active sections',items:['Larger matching controls in enlarged widgets and section-specific status borders.','Inactive alarm or timer controls are disabled during the other session.']} ,
 {version:'3.0.32',title:'Widget spacing and combined layout',items:['Refined 4×1 widget spacing, single-row alarm name and day/time, and corrected widget navigation.','Larger buttons at optional 4×2 and in the 4×3 combined Alarm & Timer widget.']},
 {version:'3.0.31',title:'Compact widgets and snooze extension',items:['Compact 4×1 Alarm and Timer widgets with bottom actions and optional larger layout.','Home icon shortcuts, +1 min snooze actions and simpler timer notifications.']},
 {version:'3.0.30',title:'Android Home widgets',items:['Upcoming Alarm, Quick Timer and combined widgets.','Shared settings and native session controls.']},
 {version:'3.0.29',title:'Compact Watch connection',items:['Removed temporary Home connection status indicators.','Watch details and actions sit side by side with less vertical space.','Automatic reconnection and all alarm and timer behavior are unchanged.']},
 {version:'3.0.28',title:'Minute selector and Disconnect styling',items:['Minute taps and held five-minute steps wrap within the selected hour.','Home Disconnect uses the regular button color.']},
 {version:'3.0.27',title:'Inactive zap settings',items:['When Zaps is zero, dependent zap settings are gray and inactive while the Zaps counter stays usable.','Previously selected zap settings are retained when zaps are re-enabled.']},
 {version:'3.0.26',title:'Countdown and History refinements',items:['Bold system-font notification countdown, with space reserved for the expansion arrow.','Elapsed duration centered between History timestamps; timeline markers stay fully visible.']},
 {version:'3.0.25',title:'Simpler timeout and music library',items:['Smart Timeout is now a global Advanced setting, on by default.','Remove sounds from the playlist directly in the Music Library.','Removed redundant Safe Max default text.']},
 {version:'3.0.24',title:'Original typography',items:['Restored V3.0.22 font sizes, colors and line spacing.','Retained shorter Settings wording, bullet points and notification improvements.']},
 {version:'3.0.23',title:'Readable settings and notification controls',items:['Single large countdown for Timer and Snooze.','Skip upcoming alarms; add one minute to running or paused timers.','Larger, shorter Settings explanations and bullet points.']},
 {version:'3.0.22',title:'Stable gear and contextual scrolling',items:['Settings gear stays at the same position when switching pages.','Settings only scrolls automatically when needed, aligning between cards.']},
 {version:'3.0.21',title:'Fixed Settings header',items:['Settings has a fixed opaque title bar and the gear remains at the far right.','Battery appears on the four main pages; version details remain in About.']},
 {version:'3.0.20',title:'Notification category cleanup',items:['Remove retired duplicate Alarm Activated, Time Expired and Timer countdown categories while keeping the current notification channels.']},
 {version:'3.0.19',title:'Settings page',items:['Settings is a normal page with the standard four-button navigation.','Opening a category retains up to two preceding collapsed categories in view.']},
 {version:'3.0.18',title:'Simpler Settings',items:['Alarm Default and Timer Default are independent sections.','Opening a Settings section closes the others, preserving the existing section highlight.']},
 {version:'3.0.17',title:'Smooth controls and alarm status colors',items:['Bottom bar buttons fade out and in over a permanent opaque surface, without a glow.','Alarm activated and snoozing borders match History. Stop is gray; Snooze is on the right.']},
 {version:'3.0.16',title:'Steady bottom bar',items:['The bottom bar stays opaque while its actions change. Action buttons briefly glow; returning to navigation does not flash.']},
 {version:'3.0.15',title:'Home spacing',items:['Reduced unused space in Watch connection and added breathing room between Quick Timer controls.']},
 {version:'3.0.14',title:'Full-screen alarm editor',items:['Alarm setup is a dedicated page with fixed header and footer.','The time picker is a standard popup slightly below center, with always-visible precision controls and one Set Time button.']},
 {version:'3.0.13',title:'More room for time adjustments',items:['The clock settles upward when digital adjustment controls appear, then returns smoothly when they close.','More separation between Set Time and the optional digital controls.']},
 {version:'3.0.12',title:'Refined alarm time picker',items:['The time picker fills the original alarm popup below its live header.','Tap the digital hour or minute for precise adjustments; hold minute controls for five-minute marks. Enter returns to the clock.']},
 {version:'3.0.11',title:'Focused Analog Clock',items:['The clock uses the normal app background, with the live alarm header visible and other controls hidden.','Subtle transitions preserve the editor position.']},
 {version:'3.0.10',title:'Compact alarm time editor',items:['Name and Time share a row with equal-sized fields. Tap the time to open the Analog Clock; the header updates live.','Timer duration controls are unchanged.']},
 {version:'3.0.9',title:'Consistent controls and analog hour rollover',items:['Ordinary buttons and stepper controls share a consistent blue fill and border.','AM/PM is a neutral pressable button. Drag the hour hand through 12 to change AM/PM; tapping an hour keeps the current period.']},
 {version:'3.0.8',title:'Home detail buttons and alarm time shortcut',items:['Home descriptions are compact buttons that open the specific alarm editor or Timer configuration.','Tap an alarm time on Alarms to edit it, with deliberate-touch scroll protection.']},
 {version:'3.0.7',title:'Refined Analog Clock',items:['Compact time and AM/PM controls below the clock face.','Minute dots replace tick marks.','Bottom navigation returns to its steady dark background.']},
 {version:'3.0.6',title:'Analog Clock and steadier navigation',items:['Custom analog alarm time picker with prominent AM/PM controls and live editor time.','Stable watch connection card while reconnecting.','Bottom navigation flashes when its available actions change.']},
 {version:'3.0.5',title:'Smoother Timer transition',items:['More space below the Timer heading.','Smooth transition from the compact Start Timer layout to the expanded duration controls, with presets remaining stationary.']},
 {version:'3.0.4',title:'Timer ready-to-start layout',items:['Timer opens with the compact duration and Start Timer controls from Home.','Interacting with Timer settings expands the duration and moves Start Timer to the bottom without shifting presets.']},
 {version:'3.0.3',title:'Compact Home layout',items:['Watch actions on the right and aligned battery information.','Consistent compact alarm and timer descriptions.','Home Start Timer matches duration box width; custom keypad remains available.']},
 {version:'3.0.2',title:'Compact Home and History',items:['Smaller Home Quick Timer with the same duration controls.','Compact History typography and single-line action buttons.','Removed the optional charging test from Settings; battery status and Event log remain available.']},
 {version:'3.0.1',title:'Home refinements',items:['More compact alarm and timer summaries, stacked watch and battery details, and a lighter Home background.','Open Alarms, Timer or History from the Home descriptions or timeline with a deliberate touch.','Alarm and Timer setup open at the top without activating the keyboard.']},
 {version:'3.0.0',title:'Home dashboard',items:['Home shows watch connection, next enabled alarm, Quick Timer and the last session timeline.','Shared compact settings summaries replace the old editor previews.','Music rotation uses a switch and dims tracks that will not play.']},
 {version:'2.0.30',title:'Timer layout and simpler time help',items:['Timer box aligns with preset grid and uses a lighter border with extra spacing.','Preset highlighting waits half a second after time adjustments stop.','Alarm and Timer time help uses short bullet points.']},
 {version:'2.0.29',title:'Time control help and Timer boundary',items:['Time info buttons explain tap and hold controls in both editors.','Timer controls stop at one minute when reducing; custom durations under one minute remain available through the keypad. A plus press from below one minute selects 1:00.']},
 {version:'2.0.28',title:'Alarm time editing and Timer rounding',items:['Larger live alarm header with a blue glow during time adjustment.','Holding alarm minute controls moves through five-minute marks; taps still move one minute.','Timer taps snap to the next whole minute, including custom durations with seconds.']},
 {version:'2.0.27',title:'Live alarm header and Timer refinements',items:['Alarm name and time update live in the fixed editor header.','The Timer custom-time hint has its own reserved space above the duration box.','A short plus press on a duration under one minute moves to 1:00.']},
 {version:'2.0.26',title:'Bolder Timer controls',items:['The Timer minus and plus symbols are heavier for better balance with the large duration display. Duration adjustment and custom keypad behavior are unchanged.']},
 {version:'2.0.25',title:'Timer minute controls',items:['Tap minus or plus to change the Timer by one minute. Hold to move rapidly through five-minute marks. Tap the time itself to enter a custom duration.']},
 {version:'2.0.24',title:'Boxed Timer duration',items:['Timer duration has a permanent outlined field with the same large time font and existing keypad entry.']},
 {version:'2.0.23',title:'Alarm time controls and steady editors',items:['Name editing uses Enter to dismiss the keyboard without saving; Timer custom entry keeps the same behavior.','Alarm time has separate hour, minute and AM/PM controls. Tap once or hold hour/minute buttons to move quickly.','Safe Max appearing or disappearing no longer changes the available scroll height while adjusting the slider.']},
 {version:'2.0.22',title:'Consistent editor typography and global Advanced settings',items:['Alarm Name and Time are easier to read, with a consistent font hierarchy across Alarm and Timer controls.','Safe Max and Time Readout info buttons open their shared Advanced settings. Numeric values apply to all saved alarms and the current timer; individual switches remain independent.','Corrected the History export version label. No change to playback or native alarm/timer behavior.']},
 {version:'2.0.21',title:'Continuous sound rotation and better library previews',items:['Rotate Sounds advances after each recording finishes, so songs can lead naturally into alarm clips.','All ten built-in sounds are standardized to ten seconds, with annoyance level and duration in their names.','Preview sounds before adding them from the Library, with Play/Pause and a compact volume control.','Custom Timer entry uses Enter instead of Start Timer, and the Settings highlight fades smoothly once.']},
 {version:'2.0.20',title:'New built-in alarm sounds',items:['Replaced the two previous built-in tones with ten supplied recordings, grouped by LOW, MED, HIGH, and EXTREME annoyance levels.','Added an info button explaining annoyance levels in the Music Library. Volume is still controlled independently.']},
 {version:'2.0.19',title:'Gentler Settings highlighting',items:['Expanded Settings sections now glow more gradually, with a single smooth blue pulse lasting about two seconds.','No change to alarms, timers, music, watch connection or saved settings.']},
 {version:'2.0.18',title:'Cleaner controls and reconnect on entry',items:['Aligned Snooze time controls on the right in both Alarm and Timer editors.','Music, Safe Max, Time Readout, and Smart Timeout now use clear on/off switches; History keeps selection checkboxes.','The What’s New button attempts to reconnect the watch as you enter PavDroid.']},
 {version:'2.0.17',title:'Music preview and Settings focus',items:['Global Music previews now use their own preview volume; individual Alarm and Timer previews still use starting volume.','Moved the compact Preview volume control directly under the playlist and simplified Stimulus interval labels.','Expanded Settings and Defaults sections briefly highlight in light blue to draw attention to the opened section.']},
 {version:'2.0.16',title:'Music preview and Settings polish',items:['Song previews play at the configured Music starting volume for the current Alarm, Timer, or app defaults.','Centered playlist remove icons and italic headings show which Settings sections are expanded.']},
 {version:'2.0.15',title:'Smoother navigation and alarm switches',items:['Alarm enable controls are now clear on/off switches instead of selection checkboxes.','Opening or closing sections scrolls toward the related heading, including nested Alarm and Timer defaults.','Custom Timer entry keeps the duration and surrounding layout stationary.']},
 {version:'2.0.14',title:'Quicker Settings and Timer entry',items:['Settings opens with all sections collapsed and Done fixed at the bottom. Expanded sections scroll toward the header.','Timer has a Tap for Custom Time hint that disappears while entering a duration, with a tighter layout.']},
 {version:'2.0.13',title:'Music previews and update history',items:['Tap a song in either Music playlist to preview it; tap again to stop or choose a different song.',"What's New appears once after an update and release notes remain in Settings → About → Changelog."]},
 {version:'2.0.12',title:'Customize music for each alarm or timer',items:['Compact Music checkbox and summary; sliders open individual playlist, rotation, and playback controls.','Reuse a custom Timer configuration, or save changes as app defaults after confirmation.','Updated rounded Settings gear and per-session music playback behavior.']},
 {version:'2.0.11',title:'Music Library and navigation refinements',items:['Separated the active playlist from the permanent Music Library, with Add from Files and Add from Library.','Improved Back, Done, and contextual footer behavior, including scrolling to the top.','Restored the expandable Music controls in the earlier editor layout.']},
 {version:'2.0.10',title:'Music, navigation, and alarm improvements',items:['Introduced Music Library, offline alarm tones, MP3 importing, and rotating tracks.','Added alarm countdowns and contextual navigation for Alarm and Timer editing.','Added adjustable Safe Max repeat limits and improved first-opening behavior.']}
];
function fillChangelog(){const host=$('aboutChangelog');host.replaceChildren();for(const release of RELEASES){const section=document.createElement('section');section.className='releaseEntry';const heading=document.createElement('h4');heading.textContent='V'+release.version+' · '+release.title;const list=document.createElement('ul');for(const line of release.items){const li=document.createElement('li');li.textContent=line;list.append(li);}section.append(heading,list);host.append(section);} }
function showWhatsNew(){if(currentSession()||state.activeTab==='settings'||ui.widgetRoutePending?.()||widgetNavigationInProgress||widgetExplicitVisit)return;if(document.querySelector('dialog[open],#alarmEditor:not([hidden])'))return;
 const last=load('pd2-whats-new-seen-version','');if(last==='3.0.53')return;
 const host=$('whatsNewContent');host.replaceChildren();const release=RELEASES[0];const heading=document.createElement('h3');heading.textContent=release.title;host.append(heading);const ul=document.createElement('ul');for(const line of release.items){const li=document.createElement('li');li.textContent=line;ul.append(li);}host.append(ul);
 const msg=document.createElement('p');msg.className='smalltext';msg.textContent='See earlier updates anytime in Settings → About → Changelog.';host.append(msg);
 $('whatsNewDialog').showModal();
}
function dismissWhatsNew(){store('pd2-whats-new-seen-version','3.0.53');if($('whatsNewDialog').open)$('whatsNewDialog').close();}
$('whatsNewContinue').onclick=()=>{
 // Dismiss first: reconnect/scan may require native Android interaction.
 dismissWhatsNew();
 if(!bt.watchConnected())connect();
};
$('whatsNewDialog').addEventListener('cancel',e=>{e.preventDefault();dismissWhatsNew();});
const htmlSafe=value=>String(value??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const minInterval=(buzz,beep)=>Math.max(3,Math.max(Number(buzz)||0,Number(beep)||0)+1);
const ordinal=n=>{const v=Number(n),s=(v%100>=11&&v%100<=13)?'th':v%10===1?'st':v%10===2?'nd':v%10===3?'rd':'th';return v+s;};
const launch=n=>ordinal((Number(n)||0)+1)+' Launch';
const durationText=n=>{const sec=Math.max(0,Math.ceil(Number(n)||0));return Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0');};
const humanTime=t=>{const [h,m]=String(t||'07:00').split(':').map(Number);return (h%12||12)+':'+String(m||0).padStart(2,'0')+' '+(h>=12?'PM':'AM');};
const dayLabel=mask=>{const m=Number(mask)||0;if(!m)return'Once';if(m===127)return'Every day';if(m===62)return'Weekdays';if(m===65)return'Weekends';return [1,2,4,8,16,32,64].filter(b=>m&b).map(b=>({1:'Su',2:'Mo',4:'Tu',8:'We',16:'Th',32:'Fr',64:'Sa'}[b])).join(' · ');};
const defaults={alarm:{buzz:5,beep:5,zaps:1,interval:8,intensity:40,snooze:7,safeMax:false,timeReadout:true,music:false,musicStartVolume:20,musicPreferredRisePercent:15,musicRiseSeconds:5,musicAfterSnoozes:0,zapsAfterSnoozes:1},timer:{buzz:3,beep:3,zaps:1,interval:6,intensity:40,snooze:1,safeMax:false,timeReadout:true,music:false,musicStartVolume:20,musicPreferredRisePercent:15,musicRiseSeconds:5,musicAfterSnoozes:0,zapsAfterSnoozes:1}};
// A fresh install uses new keys; V1.0.20 data remains untouched. Future
// migration must be an explicit user-approved operation, not a silent overwrite.
const storedDefaults=load('pd2-defaults',{});
for(const type of ['alarm','timer'])defaults[type]={...defaults[type],...(storedDefaults[type]||{})};
const savedTimer=load('pd2-timer',{seconds:300});
// Normal entry opens Home; active sessions and newly finished sessions take precedence.
const state={lastSessionKind:null,alarms:[],editorIndex:-1,editor:null,editorFromSettings:false,editorUnsaved:null,settingsFrom:null,timerSeconds:clamp(savedTimer.seconds||300,1,86399),timer:null,alarm:null,connected:false,busy:false,logExpanded:false,historySelected:new Set(),historySelecting:false,historyExpanded:new Set(),historySignature:"",hiddenIds:new Set(load('pd2-history-hidden',[])),historyHideBefore:load('pd2-history-before',0),history:[],historySessions:[],music:load('pd2-music-library',{tracks:[],selectedUri:''}),tts:load('pd2-tts',{start:40,preferredIncrease:10}),previewVolume:load('pd2-preview-volume',70),previewPlaying:false,timerEditing:false,activeTab:'home',battery:'—',charging:false,lastBatteryAt:0};
if(!Array.isArray(state.music.tracks))state.music.tracks=[];
if(typeof state.music.selectedUri!=='string')state.music.selectedUri='';
state.music.rotate=!!state.music.rotate;
for(const track of state.music.tracks){if(!track.source)track.source='user';if(typeof track.enabled!=='boolean')track.enabled=true;}
const musicList=()=>state.music.tracks.filter(t=>t.enabled!==false);
const selectedMusic=()=>musicList().find(t=>t.uri===state.music.selectedUri)||musicList()[0]||null;
const librarySummary=()=>!musicList().length?'Playlist empty · Add from Library':state.music.rotate&&musicList().length>1?'Cycling through '+musicList().length+' sounds continuously':(selectedMusic()?.label||'No sound selected');
const currentSong=()=>selectedMusic();
const songFor=p=>state.music.rotate?musicList()[0]||null:currentSong();
const currentSession=()=>!!bt?.alarmState().active||!!bt?.timerState().active;
function haptic(){try{ui.hapticTap?.();}catch(_){}}
document.addEventListener('click',e=>{if(e.target.closest('button'))haptic();});
function warn(message){$('warningText').textContent=String(message||'Something went wrong.');if(!$('warningDialog').open)$('warningDialog').showModal();}
function ask(message,title='Confirm'){
 return new Promise(resolve=>{const d=$('confirmDialog');$('confirmText').textContent=message;$('confirmTitle').textContent=title;
  const done=val=>{d.oncancel=null;d.close();resolve(val);};d.oncancel=e=>{e.preventDefault();done(false);};$('confirmNo').onclick=()=>done(false);$('confirmYes').onclick=()=>done(true);d.showModal();});
}
$('warningOk').onclick=()=>$('warningDialog').close();
const timeControlHelp={
 timer:{title:'Timer duration',items:['Tap + / −: next or previous whole minute.','Hold + / −: rapid 5-minute marks.','Minimum with −: 1:00.','Tap the time: custom minutes or seconds.','Below 1:00, + selects 1:00 first.']},
 music:{title:'Sounds',items:['Shared by Alarms and Timer unless individually customized.','Hold ⠿ to reorder.','× removes from the playlist only.','The percentage beside Active playlist controls preview volume only.','Rotate sounds continuously cycles through the playlist; otherwise the first active sound is used.','Playback settings control when sounds start, its starting volume and volume increases during actual sessions.','Imported MP3s remain in the app library. Built-in sounds are offline.']},
 alarmDefault:{title:'Alarm Default',items:['Changes are saved automatically and apply to new alarms only. Existing saved alarms keep their settings.','Buzzes, beeps, interval and snooze time set the alert pattern. Zaps and their maximum intensity are optional.','Time Readout announces the snooze count and current time when enabled.']},
 timerDefault:{title:'Timer Default',items:['Changes are saved automatically and apply to new timers or Reset to defaults. Existing custom timer settings remain until reset.','Buzzes, beeps, interval and snooze time set the alert pattern. Zaps and their maximum intensity are optional.','Time Readout announces the snooze count and current time when enabled.']},
 stimulus:{title:'Stimulus',items:['Test Buzz and Test Beep check the connected watch.','Test Zap requests the selected intensity; electrical stimulation can cause discomfort or injury. Avoid testing on irritated skin and stop if uncomfortable.','A queued Bluetooth command does not prove physical delivery.']},
 android:{title:'Android',items:['Exact alarm permission lets Android schedule alarms precisely.','Notification preferences are controlled by Android. Keep required permissions enabled for reliable operation.','Force-stopping the app or Android background restrictions may affect alarms.']},
 advanced:{title:'Advanced',items:['Safe Max controls repeat zap intensity when enabled in a profile; it does not guarantee safety.','Text-to-Speech controls the Time Readout volume.','Smart Timeout limits alert duration. Diagnostics shows watch connection events.']},
 about:{title:'About PavDroid',items:['PavDroid is an independent companion for Pavlok Shock Clock 3.','The current version and release history appear here.']},
 annoyance:{title:'Annoyance level',items:['LOW, MED, HIGH and EXTREME describe sound annoyance, not playback volume or zap intensity.']}
};
function bindInfoButton(button,action){button.classList.add('info');button.innerHTML=iconSvg('info');button.onclick=event=>{event.preventDefault();event.stopPropagation();action();};return button;}
function showInfo(kind){const help=timeControlHelp[kind];$('timeControlHelpTitle').textContent=help.title;const list=$('timeControlHelpText');list.replaceChildren(...help.items.map(text=>{const li=document.createElement('li');li.textContent=text;return li;}));$('timeControlHelpDialog').showModal();}
for(const [id,kind] of [['timerTimeInfo','timer'],['musicInfo','music'],['alarmDefaultInfo','alarmDefault'],['timerDefaultInfo','timerDefault'],['stimulusInfo','stimulus'],['androidInfo','android'],['advancedInfo','advanced'],['aboutInfo','about']])bindInfoButton($(id),()=>showInfo(kind));
$('timeControlHelpOk').onclick=()=>$('timeControlHelpDialog').close();

function takeError(err){warn(err?.message||String(err));console.error(err);}
function assertIdle(){if(currentSession())throw Error('An alarm or timer is already in progress. Stop it before changing settings or starting another.');}
function configureToggleOptions(host,profile,change){
 host.replaceChildren();
 // Preserve total editor height at the Safe Max threshold, without an empty row between switches.
 let reserve=host.nextElementSibling;
 if(!reserve?.classList.contains('safeMaxReserve')){reserve=document.createElement('div');reserve.className='safeMaxReserve';reserve.setAttribute('aria-hidden','true');host.after(reserve);}
 const defs=[{id:'safeMax',label:'Safe Max',advanced:'safeMaxSettingsHeading'},
 {id:'timeReadout',label:'Time Readout',advanced:'timeReadoutSettingsHeading'}];
 for(const x of defs){const row=document.createElement('div');row.className='optionRow';row.id=host.id+'-'+x.id;
  row.innerHTML='<label class="check featureSwitchLabel"><input type="checkbox" class="featureSwitch" role="switch"><span></span></label><button class="info" type="button">'+iconSvg('info')+'</button>';
  const ck=row.querySelector('input');ck.checked=!!profile[x.id];
  ck.addEventListener('change',()=>{profile[x.id]=ck.checked;if(x.id==='safeMax')profile.safeMaxTouched=true;change();});
  const help=document.createElement('div');help.className='optionHelp';if(x.info){const ul=document.createElement('ul');ul.className='helpBullets';for(const line of x.info){const li=document.createElement('li');li.textContent=line;ul.append(li);}help.append(ul);}help.hidden=true;
  bindInfoButton(row.querySelector('.info'),()=>{if(x.advanced)openSettings('Advanced',true,x.advanced);else help.hidden=!help.hidden;});
  host.append(row,help);
 }
 function refresh(){const visible=profile.intensity>=60;const row=$(host.id+'-safeMax');row.hidden=!visible;row.nextElementSibling.hidden=true;reserve.hidden=visible;
  for(const x of defs){const item=$(host.id+'-'+x.id),label=x.id==='safeMax'?'Safe Max ('+safeMaxRepeat()+'%)':x.label;
   item.querySelector('label span').textContent=label;const checkbox=item.querySelector('input');checkbox.checked=!!profile[x.id];checkbox.setAttribute('aria-label',label);
   const inactive=x.id==='safeMax'&&Number(profile.zaps)===0;
   item.classList.toggle('zapInactive',inactive);checkbox.disabled=inactive;item.querySelector('.info').disabled=inactive;
   item.querySelector('.info').setAttribute('aria-label',x.advanced?'Global settings for '+x.label:'About '+x.label);
  }
 }
 host.refresh=refresh;refresh();
}
function stepper(host,{min,max,step=1,value,format=String,onChange=()=>{}}){
 const node=typeof host==='string'?$(host):host;node.classList.add('stepBox');node.innerHTML='<button type="button" aria-label="Decrease">−</button><output></output><button type="button" aria-label="Increase">+</button>';
 const [minus,output,plus]=[...node.children];let val=clamp(value,min,max),lower=min,upper=max,disabled=false;
 const paint=()=>{output.innerHTML=format(val);minus.disabled=disabled||val<=lower;plus.disabled=disabled||val>=upper;};
 const set=(n,notify=false)=>{const next=clamp(n,lower,upper);if(val!==next){val=next;if(notify)onChange(val);}paint();};
 minus.onclick=()=>{if(!disabled)set(val-step,true);};plus.onclick=()=>{if(!disabled)set(val+step,true);};
 paint();return {get value(){return val;},set,setDisabled(v){disabled=!!v;paint();},maxValue(n){upper=n;set(val);},minValue(n){lower=n;set(val);}};
}
function makeNumberControl(type,kind,profile){
 const el=document.createElement('div');el.className='countField';el.innerHTML='<span>'+({buzz:'Buzzes',beep:'Beeps',zaps:'Zaps'}[kind])+'</span><div></div>';
 const ctr=stepper(el.lastElementChild,{min:0,max:5,value:profile[kind],onChange:v=>{
   if(!v&&!['buzz','beep','zaps'].some(k=>k!==kind&&profile[k]>0)){warn('Keep at least one stimulus.');ctr.set(1);return;}
   profile[kind]=v;profile.interval=Math.max(profile.interval,minInterval(profile.buzz,profile.beep));renderStimulus(type);
 }});el.controller=ctr;return el;
}
let currentlyRendering=false;
function renderStimulus(type){
 if(currentlyRendering)return;
 const p=type==='alarm'?state.editor:state.timer; if(!p)return;
 const host=$(type+'Stimulus');host.replaceChildren();
 const counts=document.createElement('div');counts.className='pulseCounts';for(const kind of ['buzz','beep','zaps'])counts.append(makeNumberControl(type,kind,p));host.append(counts);
 const interval=document.createElement('div');interval.className='stepRow';interval.innerHTML='<span>Stimulus interval</span><div></div>';
 host.append(interval);p.interval=Math.max(minInterval(p.buzz,p.beep),clamp(p.interval,3,30));
 stepper(interval.lastElementChild,{min:minInterval(p.buzz,p.beep),max:30,value:p.interval,format:v=>v+'s',onChange:v=>{p.interval=v;renderPreview(type);}});
 const label=document.createElement('div');label.className='rangehead';label.innerHTML='<span>Maximum zap intensity</span><strong>'+p.intensity+'%</strong>';host.append(label);
 const slider=document.createElement('input');slider.type='range';slider.className='intensity';slider.min=10;slider.max=100;slider.step=10;slider.value=p.intensity;host.append(slider);
 // The existing 0.2-second deliberate touch is retained; scrolling the page
 // cannot accidentally select a stronger electrical-stimulus setting.
 let armed=false,touchTimer=null;
 const arm=()=>{touchTimer=setTimeout(()=>{armed=true;},200);};
 const clear=()=>{clearTimeout(touchTimer);armed=false;};
 slider.addEventListener('pointerdown',arm);slider.addEventListener('pointerup',clear);slider.addEventListener('pointercancel',clear);
 slider.addEventListener('input',()=>{
   if(!armed){slider.value=p.intensity;return;}
   p.intensity=Number(slider.value);label.querySelector('strong').textContent=p.intensity+'%';
   if(p.intensity>=60&&!p.safeMaxTouched)p.safeMax=true;
   $(type+'Options').refresh?.();paintSlider(slider);renderPreview(type);
 });paintSlider(slider);
 const zaps=document.createElement('div');zaps.className='stepRow';zaps.innerHTML='<span>Zaps start</span><div></div>';host.append(zaps);
 const zapStartControl=stepper(zaps.lastElementChild,{min:0,max:99,value:p.zapsAfterSnoozes,format:v=>launch(v),onChange:v=>{p.zapsAfterSnoozes=v;renderPreview(type);}});
 const hint=document.createElement('p');hint.className='zapHint';hint.textContent='10% first zap · +10% per zap, up to the maximum above.';host.append(hint);
 const inactive=Number(p.zaps)===0;
 for(const el of [label,slider,zaps,hint])el.classList.toggle('zapInactive',inactive);
 slider.disabled=inactive;zapStartControl.setDisabled(inactive);
 $(type+'Options').refresh?.();
 renderPreview(type);
}
function paintSlider(slider){const p=Number(slider.value);const tint=p<=30?'#42c987':p<=50?'#e9b959':'#f27880';const pct=(p-10)/90*100;slider.style.background='linear-gradient(to right,'+tint+' '+pct+'%,#43536b '+pct+'%)';slider.style.setProperty('--thumb-outline',p>=90?'#f7f9ff':'#c3cad3');slider.style.setProperty('--slider-fill',tint);slider.style.setProperty('--thumb-halo',p>=90?'4px':'1px');}
function renderPreview(type){const p=type==='alarm'?state.editor:state.timer;if(!p)return;
 if(type==='timer')saveTimerSetup();
}
const MUSIC_KEYS=['musicAfterSnoozes','musicStartVolume','musicPreferredRisePercent','musicRiseSeconds'];
function appMusicDefault(){
 const playback=state.music.playback||defaults.alarm;
 return {musicPlaylist:musicList().map(t=>({uri:t.uri,label:t.label,source:t.source||'user'})),musicRotate:!!state.music.rotate,
  ...Object.fromEntries(MUSIC_KEYS.map(k=>[k,playback[k]??defaults.alarm[k]]))};
}
function ensureOwnMusic(p){
 const source=appMusicDefault();
 if(typeof p.musicPlaylist==='string'){try{const saved=JSON.parse(p.musicPlaylist);if(Array.isArray(saved))p.musicPlaylist=saved;}catch(_){}}
 if(!Array.isArray(p.musicPlaylist))p.musicPlaylist=source.musicPlaylist;
 if(typeof p.musicRotate!=='boolean')p.musicRotate=source.musicRotate;
 for(const k of MUSIC_KEYS)if(p[k]===undefined||p[k]===null)p[k]=source[k];
 p.musicRisePercent=Math.min(p.musicPreferredRisePercent??15,100-(p.musicStartVolume??20));
}
function ownMusicSummary(p){
 ensureOwnMusic(p);const n=p.musicPlaylist.length;
 const track=n===1?(p.musicPlaylist[0].label||'1 sound'):(n+' sounds');
 const behavior=p.musicRotate&&n>1?'rotating continuously':n>1?'playing first sound':'playing';
 return (n?track+' · '+behavior:'No sounds selected')+' · '+launch(p.musicAfterSnoozes)+' · '+p.musicStartVolume+'% → 100% (+'+p.musicRisePercent+'% every '+p.musicRiseSeconds+'s)';
}
function musicCard(type,p,container){
 ensureOwnMusic(p);container.replaceChildren();const outer=document.createElement('div');outer.className='musicCard musicCompactCard';container.append(outer);
 outer.innerHTML='<div class="musicCompactHead"><label class="check musicCompactCheck featureSwitchLabel"><input type="checkbox" class="featureSwitch" role="switch"><strong>Sounds</strong></label><button type="button" class="iconShortcut musicTune" aria-label="Customize this '+type+' sounds" title="Customize this '+type+' only">'+iconSvg('sliders')+'</button></div><div class="musicCompactSummary" hidden><p class="musicSummary"></p></div>';
 const enabled=outer.querySelector('input'),box=outer.querySelector('.musicCompactSummary'),summary=outer.querySelector('.musicSummary');
 enabled.setAttribute('aria-label','Sounds');enabled.onchange=()=>{p.music=enabled.checked;update();if(type==='timer'){state.timerEditing=true;paintFooter();}};
 outer.querySelector('.musicTune').onclick=()=>openOwnMusic(type);
 const update=()=>{enabled.checked=!!p.music;box.hidden=!p.music;summary.textContent=ownMusicSummary(p);if(type==='timer')saveTimerSetup();};update();
 return {update,expand:()=>{}};
}
function ownPlaylist(p){ensureOwnMusic(p);return p.musicPlaylist;}
function syncOwnMusic(type){const p=type==='alarm'?state.editor:state.timer;if(!p)return;
 ensureOwnMusic(p);p.musicRisePercent=Math.min(p.musicPreferredRisePercent,100-p.musicStartVolume);
 (type==='alarm'?state.alarmMusicUi:state.timerMusicUi)?.update?.();if(state.previewPlaying&&editingMusicType===type)ui.setMusicPreviewVolume?.(p.musicStartVolume);if(type==='timer'){saveTimerSetup();state.timerEditing=true;paintFooter();}
 renderOwnMusic(type);
}
function displayTrackLabel(track){const current=state.music.tracks.find(t=>t.uri===track.uri && t.source==='builtin');return current?current.label:(track.label||'MP3');}
function previewGlyph(playing){return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">'+(playing?'<rect x="5" y="3" width="5" height="18" rx="1"/><rect x="14" y="3" width="5" height="18" rx="1"/>':'<path d="M5 2.5 22 12 5 21.5Z"/>')+'</svg>';}
function makeTrackPreview(row,track){const old=row.querySelector('.trackName');if(!old)return;const button=document.createElement('button');button.type='button';button.className='trackName trackPreview';button.dataset.uri=track.uri;button.setAttribute('aria-label','Preview '+(track.label||'sound'));const label=document.createElement('span');label.textContent=displayTrackLabel(track);const status=document.createElement('span');status.className='previewIndicator';status.innerHTML=previewGlyph(state.previewPlaying&&previewTrackUri===track.uri&&!previewPaused);button.append(label,status);old.replaceWith(button);button.onclick=()=>toggleTrackPreview(track);markPreviewRows();}
function renderOwnMusic(type){const p=type==='alarm'?state.editor:state.timer;if(!p)return;
 const list=$('ownMusicPlaylist');list.replaceChildren();
 if(!p.musicPlaylist.length){const empty=document.createElement('p');empty.className='smalltext';empty.textContent='No sounds in this '+type+' playlist';list.append(empty);}
 for(const track of p.musicPlaylist){const row=document.createElement('div');row.className='trackRow playlistTrack';row.dataset.uri=track.uri;
  row.innerHTML='<span class="dragHandle" role="button" tabindex="0" aria-label="Hold to reorder">⠿</span><span class="trackName"></span><button type="button" class="ghost trackRemove" aria-label="Remove sound"><svg class="removeGlyph" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
  row.querySelector('.trackName').textContent=displayTrackLabel(track);makeTrackPreview(row,track);row.querySelector('.trackRemove').onclick=()=>{p.musicPlaylist=p.musicPlaylist.filter(t=>t.uri!==track.uri);syncOwnMusic(type);};
  row.classList.toggle('rotationInactive',!p.musicRotate&&track!==p.musicPlaylist[0]);list.append(row);bindHoldReorder(row,track,p.musicPlaylist,()=>syncOwnMusic(type));
 }
 $('ownMusicRotate').checked=!!p.musicRotate;
 $('ownMusicSummary').textContent=ownMusicSummary(p);
 const differ=JSON.stringify({musicPlaylist:p.musicPlaylist,musicRotate:p.musicRotate,...Object.fromEntries(MUSIC_KEYS.map(k=>[k,p[k]]))})!==JSON.stringify(appMusicDefault());
 $('ownMusicSaveDefault').hidden=!differ;
 const controls=$('ownMusicPlayback');controls.replaceChildren();
 for(const [key,label,min,max,step,format] of [
  ['musicAfterSnoozes','Sounds start',0,99,1,launch],
  ['musicStartVolume','Start volume',10,100,10,v=>v+'%'],
  ['musicPreferredRisePercent','Increase by',0,50,5,v=>'+'+v+'%'],
  ['musicRiseSeconds','Increase every',3,120,1,v=>v+'s']]){
  const item=document.createElement('div');item.className='defaultField';item.innerHTML='<label>'+label+'</label><div></div>';controls.append(item);
  stepper(item.lastElementChild,{min,max,step,value:p[key],format,onChange:value=>{p[key]=value;syncOwnMusic(type);}});
 }
}
let editingMusicType=null,importMusicScope='global';
function openOwnMusic(type){if(currentSession())return warn('Stop the active session before changing its sounds.');
 editingMusicType=type;renderOwnMusic(type);$('ownMusicDialog').showModal();}
function closeOwnMusic(){stopPreview();if($('ownMusicDialog').open)$('ownMusicDialog').close();editingMusicType=null;}
$('ownMusicDone').onclick=closeOwnMusic;
$('ownMusicDialog').addEventListener('cancel',e=>{e.preventDefault();closeOwnMusic();});
$('ownMusicRotate').onchange=e=>{if(!editingMusicType)return;const p=editingMusicType==='alarm'?state.editor:state.timer;p.musicRotate=e.target.checked;syncOwnMusic(editingMusicType);};
$('ownMusicAddFiles').onclick=()=>{if(!editingMusicType)return;importMusicScope='own';ui.pickMp3?.('');};
$('ownMusicAddLibrary').onclick=()=>{renderOwnLibrary();renderLibraryPickerVolume('ownLibraryPreviewVolume');$('ownMusicLibraryDialog').showModal();};
$('ownMusicLibraryClose').onclick=()=>{stopPreview();$('ownMusicLibraryDialog').close();};
$('ownMusicLibraryDialog').addEventListener('cancel',e=>{e.preventDefault();stopPreview();$('ownMusicLibraryDialog').close();});
function renderOwnLibrary(){const p=editingMusicType==='alarm'?state.editor:state.timer;if(!p)return;
 const host=$('ownMusicLibraryChoices');host.replaceChildren();
 for(const [title,tracks] of [['User Added',state.music.tracks.filter(t=>t.source!=='builtin')],['Built-in',state.music.tracks.filter(t=>t.source==='builtin')]]){
  librarySectionHeading(host,title);
  if(!tracks.length){const empty=document.createElement('p');empty.className='smalltext';empty.textContent='No sounds';host.append(empty);}
  for(const track of tracks){const row=document.createElement('div');row.className='trackRow libraryTrack';row.innerHTML='<span class="trackName"></span><button type="button" class="ghost libraryAdd">+ Add</button>';
   row.querySelector('.trackName').textContent=track.label;makeTrackPreview(row,track);
   const add=row.querySelector('.libraryAdd');const included=p.musicPlaylist.some(t=>t.uri===track.uri);paintLibraryMembership(add,track,included);
   add.onclick=()=>{if(included)p.musicPlaylist=p.musicPlaylist.filter(t=>t.uri!==track.uri);else p.musicPlaylist.push({uri:track.uri,label:track.label,source:track.source});syncOwnMusic(editingMusicType);renderOwnLibrary();};host.append(row);
  }
 }
}
$('ownMusicSaveDefault').onclick=async()=>{
 const type=editingMusicType,p=type==='alarm'?state.editor:state.timer;if(!p)return;
 if(!await ask('• Updates the default playlist and playback.\n• Applies to new alarms, new timers and Reset to Defaults.\n• Existing alarms stay unchanged.','Change App Defaults?'))return;
 const active=p.musicPlaylist.map(t=>({...t,enabled:true})),rest=state.music.tracks.filter(t=>!active.some(a=>a.uri===t.uri)).map(t=>({...t,enabled:false}));
 state.music.tracks=[...active,...rest];state.music.rotate=p.musicRotate;
 state.music.selectedUri=active[0]?.uri||'';
 state.music.playback=Object.fromEntries(MUSIC_KEYS.map(k=>[k,p[k]]));
 for(const t of ['alarm','timer']){Object.assign(defaults[t],state.music.playback);defaults[t].musicRisePercent=p.musicRisePercent;}
 storeDefaults();syncMusic();renderMusicPlayback();renderOwnMusic(type);
};
// All new profiles start from Settings defaults, not values accidentally
// inherited from a firmware-watch alarm object.
function profile(type,old=null){const p={...structuredClone(defaults[type]),...(old||{})};p.safeMaxTouched=!!old;
 // Native Android alarm templates persist 'max' and 'snoozeMinutes', while
 // the editor uses a single 'intensity' and 'snooze' model.
 if(type==='alarm' && old){
   p.intensity=old.intensity??old.max??p.intensity;
   p.snooze=old.snoozeMinutes??p.snooze;
   if(old.musicRisePercent!==undefined)p.musicPreferredRisePercent=old.musicRisePercent;
 }
 delete p.smart;delete p.smartTimeout;ensureOwnMusic(p);if(!old)Object.assign(p,Object.fromEntries(MUSIC_KEYS.map(k=>[k,appMusicDefault()[k]])));p.musicRisePercent=Math.min(p.musicPreferredRisePercent??15,100-p.musicStartVolume);p.intensity=clamp(p.intensity,10,100);p.interval=Math.max(minInterval(p.buzz,p.beep),p.interval);
 if(!old)p.safeMax=p.intensity>=60;return p;
}
// Canonical alarm time remains HH:mm (24-hour) for existing saved alarms/native scheduling.
function alarmClockMinutes(){const [h,m]=$('alarmTime').value.split(':').map(Number);return h*60+m;}
function paintAlarmHeader(){const minutes=alarmClockMinutes(),h=Math.floor(minutes/60),m=minutes%60;
 const name=$('alarmName').value.trim()||'New alarm';
 $('editorTitleName').textContent=name;
 $('editorTitleTime').textContent=(h%12||12)+':'+String(m).padStart(2,'0')+' '+(h<12?'AM':'PM');
}
function paintAlarmClock(){paintAlarmHeader();$('analogClockOpen').textContent=$('editorTitleTime').textContent;}
// Analog picker edits the same unsaved HH:mm value. Cancel restores the snapshot.
let analogOriginal=null,analogMode='hour',analogPointer=null,analogScroll=0,analogHold=null;
const analogDialog=$('analogClockDialog'),analogFace=$('analogFace');
const analogPoint=(value,total,r=106)=>[140+r*Math.sin(value*2*Math.PI/total),140-r*Math.cos(value*2*Math.PI/total)];
function analogSetMinutes(value){value=(value+1440)%1440;$('alarmTime').value=String(Math.floor(value/60)).padStart(2,'0')+':'+String(value%60).padStart(2,'0');paintAlarmClock();paintAnalog();}
function paintAnalog(){const value=alarmClockMinutes(),h=Math.floor(value/60),m=value%60,isHour=analogMode==='hour',selected=isHour?h%12:m,total=isHour?12:60;
 $('analogHour').textContent=h%12||12;$('analogMinute').textContent=String(m).padStart(2,'0');
 for(const [id,on] of [['analogHour',isHour],['analogMinute',!isHour]]){$(id).classList.toggle('selected',on);$(id).setAttribute('aria-pressed',String(on));}
 $('analogPeriod').textContent=h<12?'AM':'PM';$('analogPeriod').setAttribute('aria-label',h<12?'AM, tap to switch to PM':'PM, tap to switch to AM');
 $('analogDigitalValue').textContent=isHour?(h%12||12):String(m).padStart(2,'0');
 $('analogHint').textContent=isHour?'Select hour':'Select minute';analogFace.setAttribute('aria-label',isHour?'Hour':'Minute');analogFace.setAttribute('aria-valuemin',isHour?'1':'0');analogFace.setAttribute('aria-valuemax',isHour?'12':'59');analogFace.setAttribute('aria-valuenow',isHour?String(h%12||12):String(m));
 // Approved 280-unit geometry: minute tip reaches the inner circle edge (106-17).
 // Round caps are included in the visible length of both inactive hands.
 const minuteLength=106-17,hourLength=minuteLength*.8;
 const [x,y]=analogPoint(selected,total),[hx,hy]=analogPoint(h%12,12,hourLength-2.25),[mx,my]=analogPoint(m,60,minuteLength-(isHour?1.5:0));
 for(const [id,attrs] of [['analogHourHand',{x2:hx,y2:hy,opacity:isHour?1:.2}],['analogMinuteHand',{x2:mx,y2:my,opacity:isHour?.2:1}],['analogDot',{cx:x,cy:y}]])for(const [k,v] of Object.entries(attrs))$(id).setAttribute(k,v);
 // Draw the active hand on top even when the two hands share an angle.
 const hands=$('analogHands'),activeHand=$(isHour?'analogHourHand':'analogMinuteHand');if(hands.lastElementChild!==activeHand)hands.appendChild(activeHand);
 $('analogTicks').innerHTML=Array.from({length:60},(_,i)=>{const major=i%5===0,[tx,ty]=analogPoint(i,60,128);return `<circle cx="${tx}" cy="${ty}" r="${major?2.2:1.65}" opacity="${!isHour||major?.3:.1}"/>`;}).join('');
 $('analogNumbers').classList.toggle('hourMode',isHour);
 $('analogNumbers').innerHTML=Array.from({length:12},(_,i)=>{const n=isHour?i:i*5,[nx,ny]=analogPoint(i,12);return `<text x="${nx}" y="${ny}" class="${n===selected?'picked':''}">${isHour?(i||12):String(n).padStart(2,'0')}</text>`;}).join('');
}
function analogPick(value){const old=alarmClockMinutes(),h=Math.floor(old/60);analogSetMinutes(analogMode==='hour'?((h>=12?12:0)+value%12)*60+old%60:h*60+value%60);}
// A direct pick keeps AM/PM. Only successive samples within a continuous
// hour drag can cross the 12 boundary. Preserve minutes on hour changes.
function analogPickPointer(e,drag=false){
 const r=analogFace.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2;
 if(Math.hypot(dx,dy)<r.width*.08){if(analogPointer)analogPointer.lastHour=null;return;}
 const total=analogMode==='hour'?12:60,pick=(Math.round(Math.atan2(dx,-dy)*total/(2*Math.PI))+total)%total;
 if(analogMode==='hour'&&drag&&analogPointer.lastHour!==null){
  const prior=analogPointer.lastHour,raw=pick-prior,delta=((raw+18)%12)-6;
  // Signed shortest movement handles both clockwise and counterclockwise
  // crossing, including multiple revolutions within a single drag.
  analogSetMinutes(alarmClockMinutes()+delta*60);
 }else analogPick(pick);
 if(analogMode==='hour')analogPointer.lastHour=pick;
}
// Overlay exactly the existing popup interior below its real sticky header.
function stopAnalogHold(){if(!analogHold)return;clearTimeout(analogHold.timer);analogHold=null;}
function analogAdjust(direction,fast=false){
 const value=alarmClockMinutes();
 if(analogMode==='hour'){analogSetMinutes(value+direction*60);return;}
 // Minute edits wrap within the selected hour, including held five-minute steps.
 const minute=value%60,rem=minute%5,step=fast?(direction>0?5-rem:(rem||5)):1;
 analogSetMinutes(value-minute+((minute+direction*step+60)%60));
}
for(const [id,direction] of [['analogMinus',-1],['analogPlus',1]]){
 const button=$(id);let suppressClick=false;
 button.addEventListener('pointerdown',e=>{if(e.button!==0||!analogDialog.open)return;stopAnalogHold();suppressClick=false;button.setPointerCapture(e.pointerId);const hold={id:e.pointerId,button,timer:null};analogHold=hold;const repeat=()=>{if(analogHold!==hold)return;suppressClick=true;analogAdjust(direction,true);hold.timer=setTimeout(repeat,160);};hold.timer=setTimeout(repeat,380);});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,e=>{if(analogHold?.id===e.pointerId&&analogHold.button===button)stopAnalogHold();});
 button.addEventListener('click',e=>{if(!analogDialog.open)return;if(suppressClick&&e.detail!==0){suppressClick=false;return;}suppressClick=false;analogAdjust(direction);});
}
window.addEventListener('blur',stopAnalogHold);document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAnalogHold();});
$('analogClockOpen').onclick=()=>{if(!state.editor||analogDialog.open)return;keyboardDone();const editor=$('alarmEditor');analogScroll=editor.scrollTop;analogOriginal=alarmClockMinutes();analogMode='hour';paintAnalog();analogDialog.showModal();$('analogHint').focus({preventScroll:true});editor.scrollTop=analogScroll;};
function closeAnalog(commit){if(analogOriginal===null)return;const original=analogOriginal;analogOriginal=null;analogPointer=null;stopAnalogHold();if(!commit)analogSetMinutes(original);if(analogDialog.open)analogDialog.close();const editor=$('alarmEditor');if(!editor.hidden)editor.scrollTop=analogScroll;}
$('analogConfirm').onclick=()=>closeAnalog(true);
analogDialog.addEventListener('cancel',e=>{e.preventDefault();closeAnalog(false);});analogDialog.addEventListener('close',()=>{if(analogOriginal!==null&&!analogDialog.open)closeAnalog(false);});
for(const [id,mode] of [['analogHour','hour'],['analogMinute','minute']])$(id).onclick=()=>{stopAnalogHold();analogMode=mode;paintAnalog();};
$('analogPeriod').onclick=()=>analogSetMinutes(alarmClockMinutes()+720);
analogFace.addEventListener('pointerdown',e=>{if(e.button!==0||analogPointer!==null)return;e.preventDefault();stopAnalogHold();analogPointer={id:e.pointerId,lastHour:null,x:e.clientX,y:e.clientY,moved:false};analogFace.setPointerCapture(e.pointerId);analogPickPointer(e);});
function analogMove(e){if(e.pointerId!==analogPointer?.id)return;if(!analogPointer.moved&&Math.hypot(e.clientX-analogPointer.x,e.clientY-analogPointer.y)<4)return;analogPointer.moved=true;analogPickPointer(e,true);}
analogFace.addEventListener('pointermove',analogMove);
analogFace.addEventListener('pointerup',e=>{if(e.pointerId!==analogPointer?.id)return;analogMove(e);analogPointer=null;if(analogMode==='hour'){analogMode='minute';paintAnalog();}});
for(const event of ['pointercancel','lostpointercapture'])analogFace.addEventListener(event,e=>{if(e.pointerId===analogPointer?.id)analogPointer=null;});
analogFace.addEventListener('keydown',e=>{const delta={ArrowUp:1,ArrowRight:1,ArrowDown:-1,ArrowLeft:-1}[e.key];if(delta){e.preventDefault();const v=alarmClockMinutes(),total=analogMode==='hour'?12:60;analogPick(((analogMode==='hour'?Math.floor(v/60)%12:v%60)+delta+total)%total);}else if(e.key==='Enter'&&analogMode==='hour'){e.preventDefault();analogMode='minute';paintAnalog();}});
function alarmTextEditing(){return document.activeElement===$('alarmName');}
function paintAlarmFooter(){ $('editorSave').textContent=alarmTextEditing()?'Enter':'Save alarm'; }
function revealAlarmName(){if(!alarmTextEditing())return;const d=$('alarmEditor'),name=$('alarmName'),foot=d.querySelector('.editorfoot'),head=d.querySelector('.dialogheader');const r=name.getBoundingClientRect(),f=foot.getBoundingClientRect(),h=head.getBoundingClientRect();if(r.bottom>f.top-8)d.scrollTop+=r.bottom-f.top+8;else if(r.top<h.bottom+8)d.scrollTop-=h.bottom+8-r.top;}
$('alarmName').addEventListener('input',paintAlarmHeader);
$('alarmName').addEventListener('focus',()=>{paintAlarmFooter();requestAnimationFrame(revealAlarmName);});
$('alarmName').addEventListener('blur',()=>requestAnimationFrame(paintAlarmFooter));
$('alarmName').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();keyboardDone();paintAlarmFooter();}});
window.visualViewport?.addEventListener('resize',()=>requestAnimationFrame(revealAlarmName));
let alarmWasEnteringOnPress=false;
$('editorSave').addEventListener('pointerdown',e=>{alarmWasEnteringOnPress=alarmTextEditing();if(alarmWasEnteringOnPress)e.preventDefault();},true);
$('editorSave').addEventListener('pointercancel',()=>{alarmWasEnteringOnPress=false;});
function alarmEditorOpen(index=-1,copy=false){
 if(alarmSelecting){clearAlarmSelection();renderAlarms();}
 try{assertIdle();}catch(e){takeError(e);return;}
 const source=index>=0?state.alarms[index]:null;state.editorIndex=copy?-1:index;
 const p=profile('alarm',source);if(copy)delete p.skipDue;if(!source){p.name='ALARM '+(state.alarms.length+1);p.time='07:00';p.days=0;p.enabled=true;} else {p.name=copy?String(source.name+' copy').slice(0,20):source.name;}
 state.editor=p;state.editorOriginal=JSON.stringify(p);$('alarmName').value=p.name;$('alarmTime').value=p.time;paintAlarmClock();alarmWasEnteringOnPress=false;paintAlarmFooter();
 renderDays();stepper('alarmSnoozeMinutes',{min:1,max:60,value:p.snooze,format:v=>v+' min',onChange:v=>{p.snooze=v;}});
 state.alarmMusicUi=musicCard('alarm',p,$('alarmMusicSlot'));
 configureToggleOptions($('alarmOptions'),p,()=>renderPreview('alarm'));renderStimulus('alarm');
 openAlarmDialogAtTop();
}
function openAlarmDialogAtTop(){
 const dialog=$('alarmEditor');keyboardDone();dialog.scrollTop=0;dialog.hidden=false;document.documentElement.classList.add('alarmEditingPage');
 // Focus the non-editable heading instead of a field, then clear focus.
 $('editorTitle').focus({preventScroll:true});keyboardDone();dialog.scrollTop=0;paintAlarmFooter();
 requestAnimationFrame(()=>{if(!dialog.hidden&&!dialog.contains(document.activeElement))dialog.scrollTop=0;});
}
function renderDays(){const mask=state.editor?.days||0;
 document.querySelectorAll('#dayButtons button').forEach(b=>{const selected=!!(mask&Number(b.dataset.day));b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
 document.querySelectorAll('.dayPresets button').forEach(b=>{const selected=Number(b.dataset.days)===0?mask===0:(mask&Number(b.dataset.days))===Number(b.dataset.days);b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
}
for(const b of document.querySelectorAll('#dayButtons button'))b.onclick=()=>{state.editor.days^=Number(b.dataset.day);renderDays();};
for(const b of document.querySelectorAll('.dayPresets button'))b.onclick=()=>{state.editor.days=Number(b.dataset.days);renderDays();};
function scrollMainToTop(){
 timerScrollPrevious=0;timerReturnGesture=false;
 try{document.activeElement?.blur?.();}catch(_){}
 window.scrollTo({top:0,behavior:'instant'});
 document.documentElement.scrollTop=0;document.body.scrollTop=0;
}
function hideAlarmPage(){if(analogDialog.open)closeAnalog(false);$('alarmEditor').hidden=true;document.documentElement.classList.remove('alarmEditingPage');}
function dismissEditor(){if(!$('alarmEditor').hidden)hideAlarmPage();$('alarmEditor').scrollTop=0;state.editor=null;state.editorIndex=-1;}
$('editorCancel').onclick=async()=>{if(!state.editor)return;const dirty=$('alarmName').value!==state.editor.name||$('alarmTime').value!==state.editor.time||JSON.stringify(state.editor)!==state.editorOriginal;if(dirty&&!await ask('Discard changes to this alarm?','Leave alarm setup?'))return;dismissEditor();scrollMainToTop();};
$('newAlarm').onclick=()=>{if(alarmSelecting){clearAlarmSelection();renderAlarms();}alarmEditorOpen();};
let saving=false;
$('editorSave').onclick=async()=>{const entering=alarmWasEnteringOnPress||alarmTextEditing();alarmWasEnteringOnPress=false;if(entering){keyboardDone();paintAlarmFooter();return;}if(saving)return;saving=true;$('editorSave').disabled=true;
 try{assertIdle();const p=state.editor;if(!p)throw Error('No alarm being edited');
  p.name=$('alarmName').value.trim();p.time=$('alarmTime').value;
  if(!p.name)throw Error('Enter an alarm name');if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(p.time))throw Error('Select a valid time');
  if(![p.buzz,p.beep,p.zaps].some(Boolean))throw Error('Choose at least one stimulus');
  if(p.interval<minInterval(p.buzz,p.beep)||p.interval>30)throw Error('Stimulus interval is too short');
  if(p.music&&!ownPlaylist(p).length){openOwnMusic('alarm');return;}
  const data={...p,enabled:p.enabled??true,max:p.intensity,escalate:true,snoozeMinutes:p.snooze,
   safeMax:p.intensity>=60&&p.safeMax,timeReadout:p.timeReadout,
   music:!!p.music,musicUri:ownPlaylist(p)[0]?.uri||'',musicLabel:ownPlaylist(p)[0]?.label||'',musicPlaylist:JSON.stringify(ownPlaylist(p)),musicRotate:!!p.musicRotate,
   musicDelay:10,musicRisePercent:p.musicRisePercent,musicStartVolume:p.musicStartVolume,musicRiseSeconds:p.musicRiseSeconds};
  delete data.safeMaxTouched;delete data.snooze; // native reads intensity; max retained only as display alias
  const latest=bt.alarms();if(JSON.stringify(latest)!==JSON.stringify(state.alarms))throw Error('Alarm schedule changed. Reopen the alarm editor.');
  const updated=state.alarms.map(x=>({...x}));if(state.editorIndex>=0){const previous=updated[state.editorIndex];if(previous.time!==data.time||previous.days!==data.days||previous.enabled!==data.enabled)delete data.skipDue;updated[state.editorIndex]=data;}else updated.push(data);
  state.alarms=await bt.saveAlarms(updated,state.alarms);dismissEditor();renderAlarms();scrollMainToTop();
 }catch(e){takeError(e);}finally{saving=false;$('editorSave').disabled=false;}
};
function nextAlarmMs(a,now=Date.now()){
 const [hour,minute]=String(a.time||'07:00').split(':').map(Number),mask=Number(a.days)||0;
 for(let offset=0;offset<15;offset++){
  const d=new Date(now);d.setDate(d.getDate()+offset);d.setHours(hour,minute,0,0);
  const bit=1<<d.getDay();if(d.getTime()>now+900&&d.getTime()!==Number(a.skipDue||0)&&(mask===0||(mask&bit)))return d.getTime();
 }return Infinity;
}
function nextAlarmLabel(a){const ms=nextAlarmMs(a)-Date.now();if(!Number.isFinite(ms))return '';
 const mins=Math.max(0,Math.ceil(ms/60000)),d=Math.floor(mins/1440),h=Math.floor((mins%1440)/60),m=mins%60;
 return 'in '+(d?d+'d ':'')+(h?h+'h ':'')+m+'m';
}
function compactSummary(p,type,button=false){
 const field=(k,v)=>'<b>'+htmlSafe(k)+':</b> '+htmlSafe(v);
 let tracks=p.musicPlaylist; if(typeof tracks==='string'){try{tracks=JSON.parse(tracks);}catch(_){tracks=[];}}
 if(!Array.isArray(tracks))tracks=p.musicUri?[{uri:p.musicUri}]:[];
 const max=Number(p.intensity??p.max??40), snooze=Number(p.snoozeMinutes??p.snooze??1);
 const music=p.music?(tracks.length+' sound'+(tracks.length===1?'':'s')+(p.musicRotate&&tracks.length>1?' · Rotate':' · Loop')+' · '+(p.musicStartVolume??20)+'% +'+(p.musicRisePercent??0)+'%/'+(p.musicRiseSeconds??5)+'s'+(p.musicAfterSnoozes?' · '+launch(p.musicAfterSnoozes):'')):'Off';
 const days=type==='alarm'?htmlSafe((p.enabled?'':'Disabled · ')+dayLabel(p.days))+' · ':'';
 return [days+field('Snooze',snooze+'m'),field('Sounds',music),[field('Buzz',p.buzz??0),field('Beep',p.beep??0),field('Zap',(p.zaps??0)+' ('+max+'% max)')].join(' · ')].map(line=>button?'<span class="summaryLine">'+line+'</span>':'<div>'+line+'</div>').join('');
}
function deliberateTouch(el,action){let touch=null;
 el.addEventListener('pointerdown',e=>{if(e.button!==0||!e.isPrimary){touch=null;return;}touch={id:e.pointerId,x:e.clientX,y:e.clientY,at:performance.now(),scrollX:window.scrollX,scrollY:window.scrollY};});
 el.addEventListener('pointermove',e=>{if(touch&&e.pointerId===touch.id&&Math.hypot(e.clientX-touch.x,e.clientY-touch.y)>8)touch=null;});
 el.addEventListener('pointercancel',()=>touch=null);el.addEventListener('pointerleave',()=>touch=null);
 el.addEventListener('pointerup',e=>{const t=touch;touch=null;if(t&&t.id===e.pointerId&&Math.hypot(e.clientX-t.x,e.clientY-t.y)<=8&&performance.now()-t.at>=100&&t.scrollX===window.scrollX&&t.scrollY===window.scrollY)action();});
 el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();if(!e.repeat)action();}});
 el.addEventListener('click',e=>{if(e.detail===0)action();});
}
let alarmTogglePending=false,alarmSelecting=false,alarmSelected=new Set(),alarmSelectionSnapshot='',alarmBulkPending=false;
function paintAlarmSelect(){const b=$('alarmSelect');const deleting=alarmSelecting&&alarmSelected.size>0;b.textContent=deleting?'Delete':alarmSelecting?'Back':'Select';b.classList.toggle('danger',deleting);$('alarmSelectionBack').hidden=!deleting;$('alarmSelectionBack').disabled=alarmBulkPending;b.parentElement.classList.toggle('hasSelection',deleting);b.disabled=!state.alarms.length||alarmBulkPending;b.setAttribute('aria-label',deleting?'Delete '+alarmSelected.size+' selected alarms':alarmSelecting?'Exit selection':'Select alarms');}
$('alarmSelectionBack').onclick=()=>{if(!alarmBulkPending){clearAlarmSelection();renderAlarms();}};
function clearAlarmSelection(){alarmSelecting=false;alarmSelected.clear();alarmSelectionSnapshot='';paintAlarmSelect();}
$('alarmSelect').onclick=async()=>{if(alarmBulkPending)return;if(!alarmSelecting){if(currentSession())return warn('Stop the active alarm or timer before changing alarms.');alarmSelecting=true;alarmSelected.clear();alarmSelectionSnapshot=JSON.stringify(state.alarms);renderAlarms();return;}
 if(!alarmSelected.size){clearAlarmSelection();renderAlarms();return;}
 if(alarmTogglePending)return;const snapshot=alarmSelectionSnapshot,expected=JSON.parse(snapshot),selected=[...alarmSelected];alarmBulkPending=true;paintAlarmSelect();
 try{assertIdle();if(!await ask('Delete '+selected.length+' selected alarm'+(selected.length===1?'':'s')+' from Android?','Delete selected alarms?'))return;assertIdle();if(alarmSelectionSnapshot!==snapshot||JSON.stringify(bt.alarms())!==snapshot||selected.some(i=>!expected[i]))throw Error('Alarms changed. Select them again before deleting.');state.alarms=await bt.saveAlarms(expected.filter((_,i)=>!selected.includes(i)),expected);clearAlarmSelection();renderAlarms();}catch(e){clearAlarmSelection();renderAlarms();takeError(e);}finally{alarmBulkPending=false;paintAlarmSelect();}
};
function alarmCard(a,i,home=false){
 const div=document.createElement('div');div.className='alarmItem'+(a.enabled?'':' is-disabled');
 div.innerHTML='<div class="row"><div><div class="alarmClock">'+htmlSafe(humanTime(a.time))+(a.enabled?'<span class="alarmCountdown" data-alarm-index="'+i+'" title="'+htmlSafe(nextAlarmLabel(a))+'">'+htmlSafe(nextAlarmLabel(a))+'</span>':'')+'</div><h3>'+htmlSafe(a.name)+'</h3></div><label class="alarmSwitch" title="'+(a.enabled?'Turn alarm off':'Turn alarm on')+'"><input type="checkbox" role="switch" aria-label="'+(a.enabled?'Alarm enabled; turn off':'Alarm disabled; turn on')+'" '+(a.enabled?'checked':'')+'><span class="alarmSwitchTrack" aria-hidden="true"></span></label></div>'+(home?'<button type="button" class="compactSummary homeDetailButton homeShortcut" aria-label="Edit upcoming alarm settings">'+compactSummary(a,'alarm',true)+'</button>':'<div class="compactSummary">'+compactSummary(a,'alarm')+'</div>')+(home?'':'<div class="alarmActions"><button data-action="edit">Edit</button><button data-action="copy">Copy</button><button data-action="delete" class="danger">Delete</button></div>');
 div.querySelector('.alarmSwitch input').onchange=async e=>{if(currentSession()||alarmTogglePending||alarmBulkPending){e.target.checked=a.enabled;if(currentSession())warn('Stop the active alarm or timer before changing alarms.');return;}
  alarmTogglePending=true;try{const updated=state.alarms.map(x=>({...x}));updated[i].enabled=e.target.checked;delete updated[i].skipDue;state.alarms=await bt.saveAlarms(updated,state.alarms);renderAlarms();}catch(err){takeError(err);renderAlarms();}finally{alarmTogglePending=false;}};
 if(home){const summary=div.querySelector('.homeDetailButton');summary.onclick=()=>{tab('alarms');alarmEditorOpen(i);};}
 else{const clock=div.querySelector('.alarmClock');const main=clock.parentElement;main.classList.add('alarmCardMain');const line=document.createElement('div');line.className='alarmClockLine';clock.before(line);line.append(clock);const timeText=clock.firstChild;const timeSpan=document.createElement('span');timeSpan.className='alarmClockTime';timeSpan.textContent=timeText.textContent;timeText.replaceWith(timeSpan);if(alarmSelecting){const box=document.createElement('input');box.type='checkbox';box.className='historyCheckbox alarmSelectionCheckbox';box.checked=alarmSelected.has(i);box.setAttribute('aria-label','Select '+a.name+' '+humanTime(a.time));box.onchange=()=>{if(box.checked)alarmSelected.add(i);else alarmSelected.delete(i);paintAlarmSelect();};line.prepend(box);}clock.tabIndex=0;clock.setAttribute('role','button');clock.setAttribute('aria-label','Edit '+a.name+' alarm time');clock.classList.add('homeShortcut');deliberateTouch(clock,()=>alarmEditorOpen(i));}
 div.querySelectorAll('[data-action]').forEach(b=>b.onclick=async()=>{
  if(alarmBulkPending)return;const act=b.dataset.action;if(act==='edit')return alarmEditorOpen(i);if(act==='copy')return alarmEditorOpen(i,true);
  if(await ask('Delete '+a.name+' · '+humanTime(a.time)+' from Android?','Delete alarm?')){try{assertIdle();state.alarms=await bt.saveAlarms(state.alarms.filter((_,j)=>i!==j),state.alarms);renderAlarms();}catch(err){takeError(err);}}
 });return div;
}
function upcomingAlarm(alarms,now=Date.now()){return alarms.map((a,i)=>({a,i,at:nextAlarmMs(a,now)})).filter(x=>x.a.enabled&&Number.isFinite(x.at)).sort((x,y)=>x.at-y.at||x.i-y.i)[0];}
let homeAlarmSignature='';
function renderHomeAlarm(){const host=$('homeAlarm'),next=upcomingAlarm(state.alarms);const sig=next?JSON.stringify([next.i,next.a]):'none';
 if(sig!==homeAlarmSignature){homeAlarmSignature=sig;host.replaceChildren();if(next)host.append(alarmCard(next.a,next.i,true));else host.innerHTML='<p class="smalltext">No upcoming alarms</p>';}
 if(next){const clock=host.querySelector('.alarmCountdown');if(clock){clock.textContent=nextAlarmLabel(next.a);clock.title=clock.textContent;}}
}
function renderAlarms(){
 state.alarms=bt.alarms();if(alarmSelecting&&JSON.stringify(state.alarms)!==alarmSelectionSnapshot)clearAlarmSelection();paintAlarmSelect();const host=$('alarmList');host.replaceChildren();$('alarmBadge').textContent=state.alarms.length+' on phone';
 if(!state.alarms.length)host.innerHTML='<p class="smalltext" style="margin-top:17px">No Android alarms yet. Tap + New alarm.</p>';
 const ordered=state.alarms.map((a,i)=>({a,i})).sort((x,y)=>Number(!!y.a.enabled)-Number(!!x.a.enabled)||nextAlarmMs(x.a)-nextAlarmMs(y.a)||x.i-y.i);
 for(const {a,i} of ordered)host.append(alarmCard(a,i));renderHomeAlarm();
}
function renderHomeTimer(){if(state.timer)$('homeTimerSummary').innerHTML=compactSummary(state.timer,'timer',true);}
function timerPrepare(fresh=false){state.timer=profile('timer',fresh?null:(Object.keys(savedTimer).length>1?savedTimer:null));
 const p=state.timer;p.seconds=state.timerSeconds;
 state.timerMusicUi=musicCard('timer',p,$('timerMusicSlot'));
 configureToggleOptions($('timerOptions'),p,()=>renderPreview('timer'));
 stepper('timerSnooze',{min:1,max:60,value:p.snooze,format:v=>v+' min',onChange:v=>{p.snooze=v;saveTimerSetup();}});
 renderStimulus('timer');renderTimerPreset();$('duration').value=durationText(p.seconds);
}
let widgetTimerRevision=0;
function widgetTimerPull(){
 try{const n=JSON.parse(ui.widgetTimerSnapshot?.()||'{}');if(Number(n.revision||0)===widgetTimerRevision)return;
 widgetTimerRevision=Number(n.revision||0);if(n.seconds>0){state.timerSeconds=clamp(n.seconds,1,86399);if(state.timer)state.timer.seconds=state.timerSeconds;
 $('duration').value=durationText(state.timerSeconds);if(state.timer)store('pd2-timer',{...state.timer,seconds:state.timerSeconds});renderTimerPreset();}}
 catch(e){console.warn('Widget timer sync',e);}
}
function timerConfig(){const p=state.timer;return {seconds:state.timerSeconds,buzz:p.buzz,beep:p.beep,zaps:p.zaps,intensity:p.intensity,interval:p.interval,snoozeSeconds:p.snooze*60,
    musicDelay:10,musicAfterSnoozes:p.musicAfterSnoozes,musicStartVolume:p.musicStartVolume,musicRisePercent:p.musicRisePercent,musicRiseSeconds:p.musicRiseSeconds,
    zapsAfterSnoozes:p.zapsAfterSnoozes,safeMax:p.intensity>=60&&p.safeMax,timeReadout:p.timeReadout,music:p.music,musicUri:ownPlaylist(p)[0]?.uri||'',musicPlaylist:JSON.stringify(ownPlaylist(p)),musicRotate:!!p.musicRotate};}
function saveTimerSetup(){if(bt.timerState().active)return;store('pd2-timer',{...state.timer,seconds:state.timerSeconds});renderHomeTimer();
 try{if(ui.saveWidgetTimer&&!ui.saveWidgetTimer(JSON.stringify(timerConfig()),widgetTimerRevision))widgetTimerPull();}catch(e){console.warn('Widget timer mirror',e);}}

function parseDuration(raw){
 const value=String(raw).trim();const mmss=value.match(/^(\d{1,4}):([0-5]?\d)$/);
 // A number without ':' is SECONDS, not an appended digit or minutes.
 // '5' means 0:05; '300' means 5:00; '5:00' is also 5 minutes.
 const sec=mmss?Number(mmss[1])*60+Number(mmss[2]):/^\d{1,5}$/.test(value)?Number(value):NaN;
 if(!Number.isFinite(sec)||sec<1||sec>86399)throw Error('Enter 1–86399 seconds or minutes:seconds (e.g. 5 or 5:00).');
 return sec;
}
let presetHighlightTimer=null;
const timerAdjustingButtons=new Set();
function paintTimerPreset(show=true){document.querySelectorAll('[data-seconds]').forEach(b=>b.classList.toggle('selected',show&&Number(b.dataset.seconds)===state.timerSeconds));}
function renderTimerPreset(defer=false){
 clearTimeout(presetHighlightTimer);presetHighlightTimer=null;
 if(timerAdjustingButtons.size){paintTimerPreset(false);return;}
 if(!defer){paintTimerPreset();return;}
 paintTimerPreset(false);
 presetHighlightTimer=setTimeout(()=>{presetHighlightTimer=null;if(!timerAdjustingButtons.size)paintTimerPreset();},500);
}
for(const b of document.querySelectorAll('[data-seconds]'))b.onclick=()=>{if(bt.timerState().active)return warn('Stop the current timer first.');state.timerSeconds=Number(b.dataset.seconds);state.timer.seconds=state.timerSeconds;$('duration').value=durationText(state.timerSeconds);saveTimerSetup();renderTimerPreset();};
// Short taps snap to the next whole minute; held steps snap to five-minute marks.
function timerMinuteTarget(seconds,direction,held){
 // Sub-minute values are entered only through the custom keypad.
 if(seconds<60)return direction>0?60:seconds;
 const unit=held?300:60;
 const target=direction>0?(Math.floor(seconds/unit)+1)*unit:(Math.ceil(seconds/unit)-1)*unit;
 return direction>0?Math.min(86399,target):Math.max(60,target);
}
function adjustTimerMinutes(direction,held){
 if(bt.timerState().active)return false;
 if(document.activeElement===$('duration'))keyboardDone();
 const next=timerMinuteTarget(state.timerSeconds,direction,held);
 if(next===state.timerSeconds)return false;
 state.timerSeconds=next;state.timer.seconds=next;$('duration').value=durationText(next);
 saveTimerSetup();renderTimerPreset(true);return true;
}
function bindTimerMinuteButton(button,direction){
 let timer=null,pointer=null,held=false,start=0;
 const cancel=()=>{clearTimeout(timer);timer=null;pointer=null;if(timerAdjustingButtons.delete(button))renderTimerPreset(true);};
 button.addEventListener('pointerdown',e=>{
  if(e.button!==0||pointer!==null||bt.timerState().active)return;
  held=false;pointer=e.pointerId;start=performance.now();button.setPointerCapture(e.pointerId);timerAdjustingButtons.add(button);renderTimerPreset(true);
  const tick=()=>{
   if(pointer===null||bt.timerState().active||!['timer','home'].includes(state.activeTab)){cancel();return;}
   held=true;if(adjustTimerMinutes(direction,true))timer=setTimeout(tick,performance.now()-start>1500?75:150);
  };timer=setTimeout(tick,350);
 });
 button.addEventListener('pointerup',cancel);
 button.addEventListener('pointercancel',()=>{cancel();held=false;});
 button.addEventListener('lostpointercapture',cancel);
 button.addEventListener('contextmenu',e=>e.preventDefault());
 button.addEventListener('click',e=>{if(held&&e.detail!==0){held=false;return;}held=false;adjustTimerMinutes(direction,false);renderTimerPreset(true);});
 window.addEventListener('blur',()=>{cancel();held=false;});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancel();held=false;}});
}
bindTimerMinuteButton($('timerMinuteMinus'),-1);bindTimerMinuteButton($('timerMinutePlus'),1);
// Keep typing digits separate from the formatted MM:SS display. On Samsung's
// numeric IME, one digit shows 0:05 immediately; 5-0-0 becomes 5:00.
let timerKeypadDigits=null;
function timerSecondsFromDigits(digits){
 if(!/^\d{0,6}$/.test(digits))return NaN;
 if(!digits)return 0;
 const n=Number(digits),sec=(Math.floor(n/100)*60)+(n%100);
 return sec<=86399?sec:NaN;
}
// The duration field is a keypad, not a free-form text editor. One touch
// resets the *display* to 0:00, with the insertion caret at the RIGHT.
// Stored timer duration is not changed until a valid positive value is typed.
function caretAtTimerEnd(el){
 try{el.setSelectionRange(el.value.length,el.value.length);}catch(_){}
}
function timerResetEntry(el){
 if(bt.timerState().active)return;
 timerKeypadDigits='';el.value='0:00';
 caretAtTimerEnd(el);
 requestAnimationFrame(()=>{if(document.activeElement===el)caretAtTimerEnd(el);});
}
function timerApplyDigits(el,digits){
 const limited=String(digits).replace(/\D/g,'').slice(0,6);
 const value=timerSecondsFromDigits(limited);
 if(!Number.isFinite(value))return;
 timerKeypadDigits=limited;
 el.value=durationText(value);caretAtTimerEnd(el);
 if(value>0){state.timerSeconds=value;state.timer.seconds=value;renderTimerPreset();saveTimerSetup();}
}
$('duration').addEventListener('focus',e=>{timerResetEntry(e.target);$('timerCustomHint').hidden=true;paintFooter();});
// Android may move the selection after a touch; put it back after the click.
$('duration').addEventListener('click',e=>{
 if(bt.timerState().active)return;
 // A subsequent tap is another request to enter a completely new duration.
 if(timerKeypadDigits===null||timerKeypadDigits!=='')timerResetEntry(e.target);
 caretAtTimerEnd(e.target);
});
$('duration').addEventListener('beforeinput',e=>{
 if(bt.timerState().active)return;
 if(timerKeypadDigits===null)timerKeypadDigits='';
 const kind=String(e.inputType||'');
 if(kind.startsWith('delete')){
  e.preventDefault();timerApplyDigits(e.target,timerKeypadDigits.slice(0,-1));return;
 }
 if(kind==='insertText' && /^\d+$/.test(String(e.data||''))){
  e.preventDefault();timerApplyDigits(e.target,timerKeypadDigits+String(e.data));
 }
});
// Fallback for Samsung keyboard implementations that emit only an input event.
$('duration').addEventListener('input',e=>{
 if(bt.timerState().active)return;
 if(timerKeypadDigits===null)timerKeypadDigits='';
 const kind=String(e.inputType||''),text=String(e.data||'');
 if(kind.startsWith('delete'))timerApplyDigits(e.target,timerKeypadDigits.slice(0,-1));
 else if(/^\d+$/.test(text))timerApplyDigits(e.target,timerKeypadDigits+text);
 else {
  const visible=String(e.target.value||'');
  // If the IME replaced the visible value instead of appending, use its raw digits.
  const raw=visible.replace(/\D/g,'');
  timerApplyDigits(e.target,visible==='0:00'?'':raw);
 }
});
$('duration').addEventListener('blur',e=>{
 $('timerCustomHint').hidden=false;requestAnimationFrame(paintFooter);
 if(bt.timerState().active)return;
 timerKeypadDigits=null;
 // 0:00 is a blank edit; keep the last runnable duration if no digit was typed.
 if(e.target.value!=='0:00'){
  try{const seconds=parseDuration(e.target.value);state.timerSeconds=seconds;state.timer.seconds=seconds;saveTimerSetup();renderTimerPreset();}catch(_){}
 }
 e.target.value=durationText(state.timerSeconds);
});
$('duration').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.target.blur();try{ui.hideKeyboard?.();}catch(_){}}};
async function timerAction(action){
 try{if(action==='start'){
   assertIdle();widgetTimerPull();const p=state.timer;state.timerSeconds=parseDuration($('duration').value);
   if(!p.buzz&&!p.beep&&!p.zaps)throw Error('Choose at least one stimulus');
   if(p.music&&!ownPlaylist(p).length){openOwnMusic('timer');return;}
   const cfg=timerConfig();
   if(cfg.interval<minInterval(cfg.buzz,cfg.beep))throw Error('Stimulus interval is too short');
   saveTimerSetup();await bt.timerAction('start',cfg);

  }else await bt.timerAction(action);
  if(action==='start'||action==='reset'){state.timerEditing=false;paintFooter();}refreshSessions();if(action==='start'){if(state.activeTab==='home')tab('timer');scrollMainToTop();}if(action==='reset')tab('history');
 }catch(e){takeError(e);}
}
$('timerResetDefaults').onclick=async()=>{
 if(bt.timerState().active)return warn('Stop the timer before resetting its settings.');
 timerPrepare(true);saveTimerSetup();
};
let timerTopStarting=false;
$('timerStart').onclick=async()=>{if(timerTopStarting)return;timerTopStarting=true;try{keyboardDone();$('duration').value=durationText(state.timerSeconds);await timerAction('start');}finally{timerTopStarting=false;}};
$('timerSnoozeBtn').onclick=()=>{
 const button=$('timerSnoozeBtn'),t=bt.timerState();
 // Dispatch the action actually shown, not a different action after a phase transition.
 const action=button.dataset.action;
 if(!t.active||!((action==='snooze'&&t.phase==='alerting')||(action==='snooze_add_minute'&&t.phase==='snoozing'))){refreshSessions();return;}
 void timerAction(action);
};$('timerPauseBtn').onclick=()=>timerAction('pause');$('timerResumeBtn').onclick=()=>timerAction('resume');$('timerStopBtn').onclick=()=>timerAction('reset');
$('alarmSnooze').onclick=()=>bt.alarmAction('snooze').then(refreshSessions,takeError);
$('alarmStop').onclick=()=>bt.alarmAction('stop').then(()=>{refreshSessions();tab('history');},takeError);
function refreshSessions(){const a=bt.alarmState(),t=bt.timerState();state.alarm=a;
 const currentKind=a.active?'alarms':t.active?'timer':null;
 const finished=!!state.lastSessionKind&&!currentKind;if(finished)store('pd2-recent-stop',Date.now());
 state.lastSessionKind=currentKind;
 $('activeAlarmCard').hidden=!a.active;
 $('activeAlarmCard').dataset.phase=a.active?(a.phase==='snoozing'?'snoozing':'firing'):'';
 const timerPhase=t.active?(t.phase||''):'';
 for(const id of ['timerCard','homeTimerCard'])$(id).dataset.phase=timerPhase;
 if(a.active){$('activeAlarmName').textContent=a.name||'Active alarm';$('activeAlarmStatus').textContent=a.phase==='snoozing'?'SNOOZING · '+durationText((a.snoozeUntil-Date.now())/1000)+' left':'ALARM ACTIVATED';$('alarmSnooze').disabled=a.phase!=='firing';}
 const active=!!t.active;$('timerSetup').hidden=active;$('timerEntry').hidden=active;$('homeTimerRunning').hidden=!active;if(active)$('homeTimerRunning').textContent=t.phase==='alerting'?'Time expired':durationText(t.remaining)+' · '+(t.phase==='snoozing'?'Snoozing':t.phase==='paused'?'Paused':'Timer running');$('homeTimerStart').hidden=active;if(active)$('timerCustomHint').hidden=true;else if(document.activeElement!==$('duration'))$('timerCustomHint').hidden=false;$('timerActions').hidden=!active;$('timerFace').hidden=!active;
 $('timerCard').classList.toggle('timerSessionActive',active);
 $('timerTimeInfo').hidden=active;
 $('timerBadge').textContent=active?({countdown:'COUNTDOWN',snoozing:'SNOOZING',paused:'PAUSED',alerting:'TIME EXPIRED'}[t.phase]||String(t.phase||'Timer').toUpperCase()):'Timer Enabled';
 $('timerBadge').hidden=!active;$('timerResetDefaults').hidden=active;
 if(active){$('timerFace').textContent=t.phase==='alerting'?'0:00':durationText(t.remaining);$('timerFace').dataset.long=String($('timerFace').textContent.length>5);$('timerSnoozeBtn').hidden=!['alerting','snoozing'].includes(t.phase);const snoozing=t.phase==='snoozing';$('timerSnoozeBtn').textContent=snoozing?'+1 min':'Snooze';$('timerSnoozeBtn').dataset.action=snoozing?'snooze_add_minute':'snooze';$('timerSnoozeBtn').disabled=!['alerting','snoozing'].includes(t.phase);$('timerPauseBtn').hidden=t.phase!=='countdown';$('timerResumeBtn').hidden=t.phase!=='paused';}else{$('timerSnoozeBtn').disabled=false;$('timerSnoozeBtn').textContent='Snooze';delete $('timerSnoozeBtn').dataset.action;}
 const blocked=!!a.active||active; // Popup-only interlock; never gray out the Start or New Alarm buttons.
 refreshPermissions(); // One owner for the notice avoids a visible permission flicker.
 $('timerStatus').textContent=active?t.phase==='alerting'?'Time Expired · tap watch middle button to Snooze, hold to Stop':t.phase==='snoozing'?'Snoozing · watch long hold to Stop':'' : '';
 paintFooter();if(finished&&state.activeTab!=='settings'&&!document.querySelector('dialog[open],#alarmEditor:not([hidden])'))tab('history');
}
function tab(name,manual=false){
 if(state.activeTab==='settings'&&name!=='settings'){void leaveSettings(name,manual);return;}
 navigateTab(name,manual);
}
function navigateTab(name,manual=false){
 if(name==='watch')name='home';if(name!=='alarms'&&alarmSelecting)clearAlarmSelection();const entering=state.activeTab!==name||manual;if(entering)keyboardDone();
 const entry=$('timerEntry');if(name==='home'){if(entry.parentElement!==$('homeTimerSlot'))$('homeTimerSlot').append(entry);}else if(entry.parentElement===$('homeTimerSlot')){$('timerEntryAnchor').after(entry);}
 state.activeTab=name;document.documentElement.classList.toggle('homePage',name==='home');
 const settingsActive=name==='settings';document.documentElement.classList.toggle('settingsActive',settingsActive);$('appTitle').textContent=settingsActive?'Settings':'PavDroid';if(name!=='timer'||entering)state.timerEditing=false;paintFooter();
 if(manual&&name!=='settings')store('pd2-last-manual-tab',name);
 $('settingsBtn').classList.toggle('selected',name==='settings');$('settingsBtn').setAttribute('aria-pressed',String(name==='settings'));
 for(const b of document.querySelectorAll('[data-tab]'))b.classList.toggle('active',b.dataset.tab===name);
 for(const el of document.querySelectorAll('.page'))el.classList.toggle('active',el.id===name);
 if(name==='history'){acknowledgeHistory();readHistory();}if(name==='home'){renderAlarms();renderHomeTimer();readHistory();refreshSessions();}if(name==='alarms'){renderAlarms();refreshSessions();}
 if(!document.querySelector('dialog[open],#alarmEditor:not([hidden])'))scrollMainToTop();
}
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>tab(b.dataset.tab,true);
// Keep the real controls immediately usable; outgoing visuals are inert copies.
const footerFades=new WeakMap();
function fadeFooterButtons(group,onlyButton=null){
 const bar=$('bottomBar');
 if(window.matchMedia('(prefers-reduced-motion: reduce)').matches||!group.animate||!group.getClientRects().length)return false;
 bar.querySelectorAll('.footerOutgoing').forEach(el=>el.remove());
 const copy=group.cloneNode(true),r=group.getBoundingClientRect(),br=bar.getBoundingClientRect();
 copy.removeAttribute('id');copy.removeAttribute('role');copy.removeAttribute('aria-label');copy.classList.add('footerOutgoing');copy.inert=true;copy.setAttribute('aria-hidden','true');
 Object.assign(copy.style,{position:'absolute',left:(r.left-br.left)+'px',top:(r.top-br.top)+'px',right:'auto',bottom:'auto',width:r.width+'px',height:r.height+'px',background:'transparent',borderColor:'transparent',boxShadow:'none',pointerEvents:'none',margin:'0'});
 const originals=[...group.querySelectorAll('button')];
 [...copy.querySelectorAll('button')].forEach((b,i)=>{b.removeAttribute('id');b.removeAttribute('data-tab');b.tabIndex=-1;b.style.opacity=getComputedStyle(originals[i]).opacity;if(onlyButton&&originals[i]!==onlyButton)b.style.visibility='hidden';});
 bar.append(copy);
 copy.animate([{opacity:1},{opacity:0}],{duration:100,easing:'ease-in',fill:'forwards'}).onfinish=()=>copy.remove();
 return true;
}
function fadeFooterIn(button){
 footerFades.get(button)?.cancel();
 footerFades.set(button,button.animate([{opacity:0},{opacity:1}],{duration:180,delay:60,easing:'ease-out',fill:'backwards'}));
}
function paintFooter(){const idle=!bt.timerState().active,onTimer=state.activeTab==='timer',active=state.timerEditing&&onTimer&&idle,ready=onTimer&&idle&&!state.timerEditing;
 $('timer').classList.toggle('timerReady',ready);$('timerStart').hidden=!ready;$('timerStart').inert=!ready;
 const footer=$('contextFooter'),nav=$('mainTabs'),start=$('timerFooterStart'),wasActive=!footer.hidden,nextLabel=document.activeElement===$('duration')?'Enter':'Start Timer',labelChanged=start.textContent!==nextLabel;
 const switched=active!==wasActive;
 const fade=switched?fadeFooterButtons(wasActive?footer:nav):active&&labelChanged?fadeFooterButtons(footer,start):false;
 if(switched)for(const b of (wasActive?footer:nav).querySelectorAll('button'))footerFades.get(b)?.cancel();
 footer.hidden=!active;nav.hidden=active;start.textContent=nextLabel;$('homeTimerStart').textContent=nextLabel;
 if(fade){if(switched)for(const b of (active?footer:nav).querySelectorAll('button'))fadeFooterIn(b);else fadeFooterIn(start);}
}
let timerScrollPrevious=0,timerReturnGesture=false,timerTouch=null;
function timerCanReturn(){return state.activeTab==='timer'&&state.timerEditing&&!bt.timerState().active&&!document.querySelector('dialog[open],#alarmEditor:not([hidden])')&&!document.activeElement?.matches('input,textarea,[contenteditable=true]');}
function restoreTimerReady(){if(!timerCanReturn())return;state.timerEditing=false;timerReturnGesture=false;$('duration').value=durationText(state.timerSeconds);paintFooter();}
// Track user scroll gestures, including a pull down when the page is already at its top.
window.addEventListener('touchstart',e=>{const t=e.touches[0];timerTouch=state.activeTab==='timer'&&e.touches.length===1?{x:t.clientX,y:t.clientY,top:window.scrollY<=1,editing:state.timerEditing}:null;timerReturnGesture=false;},{passive:true});
window.addEventListener('touchmove',e=>{const t=e.touches[0];if(timerTouch&&e.touches.length===1&&t.clientY-timerTouch.y>12&&Math.abs(t.clientX-timerTouch.x)<t.clientY-timerTouch.y)timerReturnGesture=true;},{passive:true});
window.addEventListener('touchend',e=>{const t=e.changedTouches[0];if(timerTouch?.editing&&timerTouch.top&&timerReturnGesture&&t.clientY-timerTouch.y>36&&window.scrollY<=1)restoreTimerReady();timerTouch=null;},{passive:true});
window.addEventListener('touchcancel',()=>{timerTouch=null;},{passive:true});
window.addEventListener('wheel',e=>{if(state.activeTab==='timer'&&e.deltaY<0){timerReturnGesture=true;if(window.scrollY<=1)restoreTimerReady();}},{passive:true});
window.addEventListener('keydown',e=>{if(state.activeTab==='timer'&&['Home','PageUp','ArrowUp'].includes(e.key)&&timerCanReturn())timerReturnGesture=true;});
window.addEventListener('scroll',()=>{const y=Math.max(0,window.scrollY);if(timerReturnGesture&&timerScrollPrevious>1&&y<=1)restoreTimerReady();timerScrollPrevious=y;},{passive:true});
function enterTimerEditing(){if(state.activeTab!=='timer'||state.timerEditing||bt.timerState().active)return;state.timerEditing=true;paintFooter();}
// Settings and presets are stationary: enter editing on first touch there.
// For the compact duration controls, wait until the gesture finishes so resizing
// cannot move a +/- or input out from under the finger before it receives its click.
$('timer').addEventListener('pointerdown',e=>{
 if(e.target.closest('#timerStart,#timerEntry,#timerActions'))return;
 enterTimerEditing();
},true);
$('timer').addEventListener('click',e=>{if(!e.target.closest('#timerStart,#timerActions'))enterTimerEditing();});
$('timerEntry').addEventListener('pointercancel',e=>{if(!e.target.closest('#timerStart'))enterTimerEditing();});
// A held duration stepper can finish without a click on some touch devices.
$('timerEntry').addEventListener('pointerup',e=>{if(!e.target.closest('#timerStart')){setTimeout(()=>{if(state.activeTab==='timer'&&state.timerEditing===false)enterTimerEditing();},0);}});
$('timerEntry').addEventListener('keydown',e=>{if(!e.target.closest('#timerStart')&&e.key!=='Tab')enterTimerEditing();});
$('timerBack').onclick=()=>{state.timerEditing=false;keyboardDone();$('duration').value=durationText(state.timerSeconds);paintFooter();scrollMainToTop();};
let timerWasEnteringOnPress=false;
$('timerFooterStart').addEventListener('pointerdown',e=>{timerWasEnteringOnPress=document.activeElement===$('duration');if(timerWasEnteringOnPress)e.preventDefault();},true);
$('timerFooterStart').addEventListener('pointercancel',()=>{timerWasEnteringOnPress=false;});
$('timerFooterStart').onclick=()=>{const entering=timerWasEnteringOnPress||document.activeElement===$('duration');timerWasEnteringOnPress=false;keyboardDone();$('duration').value=durationText(state.timerSeconds);if(entering){paintFooter();return;}void timerAction('start');};
for(const b of document.querySelectorAll('[data-tab]')){
 const icons={home:'home',alarms:'alarms',timer:'timer',history:'history'};
 b.insertAdjacentHTML('afterbegin',iconSvg(icons[b.dataset.tab]));
}
$('settingsBtn').innerHTML=iconSvg('settings');
for(const b of document.querySelectorAll('[data-home-route]')){b.innerHTML=iconSvg(b.dataset.homeRoute);b.onclick=()=>tab(b.dataset.homeRoute);}

// A recent physical watch Stop is discoverable from the native History journal.
// Missed scheduled alarms do not count as deliberately stopped sessions.
function latestNativeStop(){
 let latest=0;for(const event of bt.savedHistory()){
  const msg=String(event.msg||'');if(!msg.startsWith('PDH|'))continue;
  try{const rec=JSON.parse(msg.slice(4));if(rec.state==='stopped')latest=Math.max(latest,Number(event.millis)||0);}catch(_){}
 }return latest;
}
// Each completed session gets exactly ONE automatic History opening. Older
// sessions are acknowledged permanently, rather than forcing History repeatedly
// during a five-minute window. Normal entry opens Home.
function latestRelevantStop(){return Math.max(Number(load('pd2-recent-stop',0)),latestNativeStop());}
function acknowledgeHistory(){const latest=latestRelevantStop();
 if(latest>Number(load('pd2-history-last-shown-stop',0)))store('pd2-history-last-shown-stop',latest);
}
function openingTab(){
 if(bt.alarmState().active)return 'alarms';
 if(bt.timerState().active)return 'timer';
 
 const latest=latestRelevantStop();
 if(latest>Number(load('pd2-history-last-shown-stop',0))){
  store('pd2-history-last-shown-stop',latest);return 'history';
 }
 return 'home';
}
function applyOpeningTab(){
 if(ui.widgetRoutePending?.()||widgetNavigationInProgress)return;
 widgetExplicitVisit=false;
 if(state.activeTab==='settings')return;
 if(document.querySelector('dialog[open],#alarmEditor:not([hidden])'))return;
 tab(openingTab());
}
function refreshConnection(){const info=bt.connection(),device=bt.device(),connected=bt.watchConnected();state.connected=connected;
 $('watchName').textContent=device?.name||info.name||'—';$('disconnectBtn').disabled=!connected&&info.state!=='waiting';$('disconnectBtn').hidden=!connected&&info.state!=='waiting';
 const reconnect=$('connectBtn');reconnect.textContent=device?.id?'Reconnect watch':'Connect to watch';
 reconnect.disabled=connected||info.state==='connecting';reconnect.hidden=connected||info.state==='connecting';reconnect.classList.toggle('primary',!connected);reconnect.classList.toggle('ghost',connected);
 $('refreshWatch').hidden=!connected&&info.state==='waiting';$('disconnectBtn').classList.toggle('waitingDisconnect',!connected&&info.state==='waiting');
 const disconnect=$('disconnectBtn');disconnect.classList.remove('danger');disconnect.classList.add('ghost');
 refreshSessions();
}
async function connect(){try{let device=bt.device();if(!device)device=await bt.scan();if(!device?.id)throw Error('No authorized watch found');await bt.connect(device.id);refreshConnection();refreshBattery(true);}catch(e){takeError(e);}}
$('connectBtn').onclick=connect;
$('disconnectBtn').onclick=async()=>{
  const info=bt.connection();if(!bt.watchConnected()&&info.state!=='waiting')return;
  const confirmed=await ask('Disconnect from the watch?\n\nAndroid will stop Bluetooth monitoring and direct watch stimuli until you reconnect. Any existing Android-owned alarm or timer remains scheduled or active, but watch buzzes, beeps, and zaps cannot be sent while disconnected.','Disconnect watch?');
  if(!confirmed)return;
  bt.disconnect();setBattery(null,false);setTimeout(refreshConnection,150);
 };
$('refreshWatch').onclick=()=>{refreshConnection();refreshBattery(true,true);};
for(const id of ['batteryTapTop','batteryTapWatch'])$(id).onclick=()=>refreshBattery(true,true);
function setBattery(percent,charging){
 const pct=percent===null?'—':clamp(percent,0,100)+'%';state.battery=pct;state.charging=!!charging;
 for(const id of ['batteryValue','batteryTop'])$(id).textContent=pct;
 $('batteryBoltTop').hidden=!state.charging;$('batteryBoltWatch').hidden=!state.charging;
 $('watchBatteryLabel').textContent='Battery';
 $('batteryTop').style.color=percent!==null&&percent<15?'#ff8e96':'#eef5ff';
 $('batteryValue').style.color=percent!==null&&percent<15?'#ff8e96':'#eef5ff';
}
const CHARGE_STATUS_UUID='00000001-0000-1000-8000-00805f9b34fb';
function nativeChargingStatus(){
 const info=bt.chargeState?.()||{};
 return {known:!!info.known,charging:!!info.known&&!!info.charging,source:'0001'};
}
function syncChargingIndicator(){
 const c=nativeChargingStatus();
 const pct=parseInt(state.battery,10);
 setBattery(Number.isFinite(pct)?pct:null,c.known&&c.charging);
}
let pollingBattery=false,chargeStatusUnsupported=false,chargeIssueRecorded=false;
let pendingManualBattery=false,batteryFeedbackTimer=null;
function batteryFeedback(mode){
 clearTimeout(batteryFeedbackTimer);
 for(const suffix of ['Top','Watch']){
  const node=$('batteryRefresh'+suffix);node.hidden=!mode;node.dataset.mode=mode||'';
  node.textContent=mode==='busy'?'↻':mode==='ok'?'✓':mode==='error'?'!':'';
  const btn=$(suffix==='Top'?'batteryTapTop':'batteryTapWatch');
  btn.title=mode==='busy'?'Refreshing battery…':mode==='ok'?'Battery refreshed just now':mode==='error'?'Battery refresh failed':'Tap to refresh battery from watch';
 }
 if(mode&&mode!=='busy')batteryFeedbackTimer=setTimeout(()=>batteryFeedback(''),2000);
}
const isMissingCharge=e=>/Characteristic not found|Characteristic unavailable/i.test(String(e?.message||e));
async function readChargingStatus(){
 // Only the proprietary notification byte was validated ON/OFF/ON/OFF in V2.0.8.
 // Unknown stays unknown: never infer from percentage, charger state of the phone,
 // or unsupported standard charging characteristics.
 return nativeChargingStatus();
}
async function refreshBattery(force=false,manual=false){
 if(manual){
  if(!bt.watchConnected()){
   batteryFeedback('error');warn('Connect to your watch to refresh its battery percentage.');return;
  }
  batteryFeedback('busy');
 }
 if(pollingBattery){if(manual)pendingManualBattery=true;return;}
 if(!bt.watchConnected())return;
 if(!force&&(document.visibilityState==='hidden'||Date.now()-state.lastBatteryAt<30000||currentSession()))return;
 pollingBattery=true;
 let success=false,pct=null,chargeInfo=null;
 try{
  const res=await bt.readBattery();pct=Array.isArray(res)?Number(res[0]):null;
  if(!Number.isFinite(pct)||pct<0||pct>100)throw Error('Watch returned invalid battery percentage');
  state.lastBatteryAt=Date.now();
  chargeInfo=await readChargingStatus();
  setBattery(pct,chargeInfo.charging);
  success=true;
  if(manual)bt.note?.('Battery tapped and refreshed: '+pct+'%; charge status '+(chargeInfo.known?(chargeInfo.charging?'charging':'not charging')+' via '+chargeInfo.source:'unavailable'));
 }catch(e){
  if(manual)bt.note?.('Battery manual refresh failed: '+String(e?.message||e));
 }finally{
  pollingBattery=false;
  if(pendingManualBattery){
   pendingManualBattery=false;
   // A tap during an existing poll still triggers its OWN new read.
   void refreshBattery(true,true);
  }else if(manual)batteryFeedback(success?'ok':'error');
 }
}
bt.onConnection(()=>{refreshConnection();syncChargingIndicator();setTimeout(()=>refreshBattery(true),1100);},()=>{refreshConnection();setBattery(null,false);});
let pageBackgrounded=false,widgetNavigationInProgress=false,widgetExplicitVisit=false;
window.addEventListener('focus',()=>{
 // An Android dialog or keyboard focus change is not a new app opening.
 if(!pageBackgrounded || document.visibilityState==='hidden')return;
 pageBackgrounded=false;widgetTimerPull();refreshConnection();refreshBattery(true);syncChargingIndicator();applyOpeningTab();
});
document.addEventListener('visibilitychange',()=>{
 if(document.visibilityState==='hidden'){pageBackgrounded=true;store('pd2-last-visited-version','3.0.53');return;}
 if(pageBackgrounded){pageBackgrounded=false;widgetTimerPull();refreshConnection();refreshBattery(true);syncChargingIndicator();applyOpeningTab();}
});
// The same local Android Media volume is used for MP3 and spoken Snooze announcements.
const safeMaxRepeat=()=>clamp(load('pd2-safe-max-repeat',50),10,70);
function saveSpeech(){const t=state.tts;t.start=clamp(t.start,10,100);t.preferredIncrease=clamp(t.preferredIncrease,0,50);
 store('pd2-tts',t);try{ui.setTimeReadoutVolume?.(t.start,Math.min(t.preferredIncrease,100-t.start));}catch(_){}}
function refreshGlobalSettingsNote(){
 const label=$('safeMaxGlobalNote');if(label)label.textContent='Applies immediately wherever Safe Max is enabled. Individual switches and maximums stay unchanged.';
 const tts=$('timeReadoutGlobalNote');if(tts)tts.textContent='Applies to subsequent announcements wherever Time Readout is enabled. Individual switches stay unchanged.';
}
function refreshSpeechControls(){refreshGlobalSettingsNote();const p=state.tts;
 stepper('safeMaxRepeatControl',{min:10,max:70,step:10,value:safeMaxRepeat(),format:v=>v+'%',onChange:v=>{store('pd2-safe-max-repeat',v);ui.setSafeMaxRepeat?.(v);for(const type of ['alarm','timer'])$(type+'Options')?.refresh?.();refreshGlobalSettingsNote();}});
 let rise;stepper('ttsStart',{min:10,max:100,step:10,value:p.start,format:v=>v+'%',onChange:v=>{p.start=v;rise.maxValue(100-v);rise.set(Math.min(p.preferredIncrease,100-v));saveSpeech();}});
 rise=stepper('ttsIncrease',{min:0,max:Math.min(50,100-p.start),step:10,value:Math.min(p.preferredIncrease,100-p.start),format:v=>'+'+v+'%',onChange:v=>{p.preferredIncrease=v;saveSpeech();}});
}
let settingsOrigin=null,settingsLeaving=false,settingsScrollToken=0;
function resetSettingsLayout(section){
 for(const el of $('settings').querySelectorAll('details'))el.open=false;
 if(section){const el=$('settings'+section);if(el)el.open=true;}
}
function openSettings(section,shortcut=false,focusId=null){
 if(state.activeTab==='settings'){if(!section)void leaveSettings();return;}
 settingsOrigin={tab:state.activeTab,timerEditing:state.timerEditing,scroll:window.scrollY,editorScroll:$('alarmEditor').scrollTop};
 state.editorFromSettings=!$('alarmEditor').hidden;
 state.settingsFrom=shortcut?(state.editorFromSettings?'Alarm':state.activeTab==='timer'?'Timer':null):null;
 if(state.editorFromSettings)hideAlarmPage();
 renderMusicLibrary();renderMusicPlayback();refreshSpeechControls();renderDefaults();resetSettingsLayout(section);refreshLog();
 navigateTab('settings');
 if(section)queueSettingsScroll($('settings'+section),focusId?$(focusId):null);
}
async function leaveSettings(name,manual=false){
 if(state.activeTab!=='settings'||settingsLeaving)return;
 const origin=settingsOrigin||{tab:'home'},from=state.settingsFrom;
 const destination=name||origin.tab;
 const draft=state.editorFromSettings&&state.editor;
 const resumeDraft=draft&&destination==='alarms'&&!currentSession();
 // A different tab must not silently throw away an unsaved alarm.
 if(draft&&!resumeDraft){
  const dirty=$('alarmName').value!==state.editor.name||$('alarmTime').value!==state.editor.time||JSON.stringify(state.editor)!==state.editorOriginal;
  if(dirty){settingsLeaving=true;let discard=false;try{discard=await ask('Discard changes to this alarm?','Leave alarm setup?');}finally{settingsLeaving=false;}if(!discard)return;}
  dismissEditor();
 }
 settingsScrollToken++;window.scrollTo({top:window.scrollY,behavior:'instant'});
 settingsOrigin=null;state.settingsFrom=null;state.editorFromSettings=false;
 for(const type of ['alarm','timer'])$(type+'Options')?.refresh?.();
 if(state.previewPlaying||previewPaused)stopPreview();
 navigateTab(destination,manual);
 if(resumeDraft){openAlarmDialogAtTop();requestAnimationFrame(()=>{$('alarmEditor').scrollTop=origin.editorScroll||0;});if(from==='Alarm')state.alarmMusicUi?.expand?.();state.alarmMusicUi?.update?.();}
 else if(destination==='timer'&&destination===origin.tab&&origin.timerEditing&&!bt.timerState().active){enterTimerEditing();if(from==='Timer')state.timerMusicUi?.expand?.();state.timerMusicUi?.update?.();}
 if(!name&&!resumeDraft)window.scrollTo({top:origin.scroll||0,behavior:'instant'});
}
$('settingsBtn').onclick=()=>openSettings();
// Expand/collapse scrolling uses one rule everywhere: open -> this heading;
// close -> the preceding section heading, or the parent heading for the first.
// Dialogs scroll internally; the underlying app never scrolls behind a modal.
function scrollSectionHeading(section, mayBeClosed=false){
 if(!section || (!section.open && !mayBeClosed))return;
 const dialog=section.closest('dialog,#alarmEditor');
 if(dialog && (dialog.id==='alarmEditor'?dialog.hidden:!dialog.open))return;
 const container=dialog || null;
 const head=container?.querySelector(':scope > .dialogheader');
 const topMargin=(head?.offsetHeight||0)+12;
 if(container){
  const target=container.scrollTop+section.getBoundingClientRect().top-container.getBoundingClientRect().top-topMargin;
  container.scrollTo({top:Math.max(0,target),behavior:'smooth'});
 }else{
  const headerInset=state.activeTab==='settings'?$('appHeader').offsetHeight:0;
  const target=window.scrollY+section.getBoundingClientRect().top-headerInset-12;
  window.scrollTo({top:Math.max(0,target),behavior:'smooth'});
 }
}
// Do not scroll a fully visible expanded section. Otherwise choose a real
// inter-card gap, preferring two preceding cards unless that hides the target.
function scrollSettingsHeading(section,focus=null){
 if(state.activeTab!=='settings'||!section)return;
 const cards=[...$('settings').querySelectorAll(':scope > .settingsSections > .settingsSection')];
 const index=cards.indexOf(section);if(index<0)return;
 const y=window.scrollY;
 const topEdge=$('appHeader').getBoundingClientRect().bottom;
 const bottomEdge=$('bottomBar').getBoundingClientRect().top;
 const height=bottomEdge-topEdge;
 const rect=section.getBoundingClientRect();
 const target=(focus||section.querySelector(':scope > summary')).getBoundingClientRect();
 const visible=r=>r.top>=topEdge-1&&r.bottom<=bottomEdge+1;
 if(visible(rect)&&(!focus||visible(target)))return;
 const max=Math.max(0,document.scrollingElement.scrollHeight-document.scrollingElement.clientHeight);
 const candidates=[];
 for(let i=Math.max(0,index-2);i<=index;i++){
  const r=cards[i].getBoundingClientRect();
  // Place the header's bottom edge at the exact midpoint of the card gap.
  const gap=i===0?0:y+(cards[i-1].getBoundingClientRect().bottom+r.top)/2-topEdge;
  if(gap>=-1&&gap<=max+1)candidates.push(Math.max(0,Math.min(max,gap)));
 }
 const shows=(r,pos)=>y+r.top-pos>=topEdge-1&&y+r.bottom-pos<=bottomEdge+1;
 let pos;
 if(rect.height<=height+1)pos=candidates.find(v=>shows(rect,v)&&(!focus||shows(target,v)));
 if(pos===undefined)pos=candidates.find(v=>shows(target,v));
 // At the end of the document or for a deep link, use minimum necessary
 // scrolling if no legal card-gap position can display the required target.
 if(pos===undefined){
  const r=rect.height<=height&&!focus?rect:target;
  pos=r.top<topEdge?y+r.top-topEdge-6:y+r.bottom-bottomEdge+6;
 }
 pos=Math.max(0,Math.min(max,pos));
 if(Math.abs(pos-y)<1)return;
 window.scrollTo({top:pos,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
}
function queueSettingsScroll(section,focus=null){const token=++settingsScrollToken;requestAnimationFrame(()=>requestAnimationFrame(()=>{if(token===settingsScrollToken)scrollSettingsHeading(section,focus);}));}
function precedingSection(section){
 let sibling=section.previousElementSibling;
 while(sibling){if(sibling.matches?.('details'))return sibling;sibling=sibling.previousElementSibling;}
 return section.parentElement?.closest('details') || section;
}
// Top-level Settings sections are exclusive. Close siblings synchronously so
// their deferred toggle events cannot race the newly opened section's scroll.
$('settings').addEventListener('click',event=>{
 const summary=event.target.closest('summary');
 const section=summary?.parentElement;
 if(!section?.matches('#settings > .settingsSections > .settingsSection'))return;
 event.preventDefault();
 const opening=!section.open;
 for(const sibling of $('settings').querySelectorAll(':scope > .settingsSections > .settingsSection')){
  if(sibling!==section){sibling.open=false;for(const child of sibling.querySelectorAll('details'))child.open=false;}
 }
 section.open=opening;
 if(!opening)for(const child of section.querySelectorAll('details'))child.open=false;
 queueSettingsScroll(section);
});
// Other accordions retain their original scroll behavior.
document.addEventListener('toggle',event=>{
 const section=event.target;
 if(!(section instanceof HTMLDetailsElement))return;
 if(section.matches('#settings > .settingsSections > .settingsSection'))return;
 if(section.closest('#settings .settingsSection:not([open])'))return;
 const dialog=section.closest('dialog,#alarmEditor');
 if(dialog && (dialog.id==='alarmEditor'?dialog.hidden:!dialog.open))return;
 if(!dialog && !section.closest('.page.active'))return;
 const target=section.open?section:precedingSection(section);
 requestAnimationFrame(()=>requestAnimationFrame(()=>scrollSectionHeading(target,true)));
},true);






// The persisted `tracks` array remains the native engine's playlist contract:
// enabled=true means active; disabled tracks remain available in the library.
function renderMusicLibrary(){
 const host=$('musicLibrary');host.replaceChildren();
 const list=musicList();
 if(!list.length){const empty=document.createElement('p');empty.className='smalltext';empty.textContent='No active sounds. Use Add from Library to build your playlist.';host.append(empty);}
 for(const track of list){const row=document.createElement('div');row.className='trackRow playlistTrack';row.dataset.uri=track.uri;
  row.innerHTML='<span class="dragHandle" role="button" aria-label="Hold to reorder" tabindex="0">⠿</span><span class="trackName"></span><button type="button" class="ghost trackRemove" aria-label="Remove from playlist"><svg class="removeGlyph" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
  row.querySelector('.trackName').textContent=track.label;makeTrackPreview(row,track);
  row.querySelector('.trackRemove').setAttribute('aria-label','Remove '+track.label+' from playlist');
  row.querySelector('.trackRemove').onclick=()=>{track.enabled=false;if(state.music.selectedUri===track.uri)state.music.selectedUri=musicList()[0]?.uri||'';syncMusic();};
  row.classList.toggle('rotationInactive',!state.music.rotate&&track!==list[0]);host.append(row);bindHoldReorder(row,track);
 }
 $('musicRotate').checked=!!state.music.rotate;
}
function paintLibraryMembership(button,track,included){
 button.classList.add('libraryMembership');button.replaceChildren();
 if(included){const status=document.createElement('span');status.className='libraryMembershipStatus';status.textContent='In playlist';const action=document.createElement('span');action.textContent='Remove';button.append(status,action);}else button.textContent='+ Add';
 button.setAttribute('aria-label',(included?'Remove ':'Add ')+track.label+(included?' from playlist':' to playlist'));
}
function renderLibraryPicker(){
 const host=$('musicLibraryChoices');host.replaceChildren();
 for(const [label,tracks] of [['User Added',state.music.tracks.filter(t=>t.source!=='builtin')],['Built-in',state.music.tracks.filter(t=>t.source==='builtin')]]){
  librarySectionHeading(host,label);
  if(!tracks.length){const p=document.createElement('p');p.className='smalltext';p.textContent='No sounds yet';host.append(p);}
  for(const track of tracks){const row=document.createElement('div');row.className='trackRow libraryTrack';
   row.innerHTML='<span class="trackName"></span><button type="button" class="ghost libraryAdd"></button>';
   row.querySelector('.trackName').textContent=track.label;makeTrackPreview(row,track);
   const add=row.querySelector('.libraryAdd');const included=track.enabled!==false;paintLibraryMembership(add,track,included);
   add.onclick=()=>{track.enabled=!included;if(included&&state.music.selectedUri===track.uri)state.music.selectedUri=musicList()[0]?.uri||'';else if(!included&&!state.music.selectedUri)state.music.selectedUri=track.uri;syncMusic();};
   if(track.source!=='builtin'){
    const del=document.createElement('button');del.className='ghost trackRemove';del.textContent='×';del.setAttribute('aria-label','Permanently delete '+track.label);
    del.onclick=async()=>{if(state.alarms.some(a=>Array.isArray(a.musicPlaylist)&&a.musicPlaylist.some(t=>t.uri===track.uri))||(Array.isArray(state.timer?.musicPlaylist)&&state.timer.musicPlaylist.some(t=>t.uri===track.uri))){warn('This MP3 is still used by an Alarm or Timer. Remove it from those playlists first so they do not lose their sound.');return;}if(!await ask('Permanently remove '+track.label+' from the Sound Library?'))return;state.music.tracks=state.music.tracks.filter(t=>t.uri!==track.uri);if(state.music.selectedUri===track.uri)state.music.selectedUri=musicList()[0]?.uri||'';syncMusic();try{ui.deleteImportedMp3?.(track.uri);}catch(e){console.warn('MP3 cleanup',e);}renderLibraryPicker();};
    row.append(del);
   }
   host.append(row);
  }
 }
}
function bindHoldReorder(row,track,list=state.music.tracks,onFinished=syncMusic){
 const handle=row.querySelector('.dragHandle');let held=false,startY=0,arm=null;
 const finish=()=>{clearTimeout(arm);if(held){held=false;row.classList.remove('dragging');onFinished();}};
 handle.addEventListener('contextmenu',e=>e.preventDefault());
 handle.addEventListener('pointerdown',e=>{startY=e.clientY;arm=setTimeout(()=>{held=true;row.classList.add('dragging');try{handle.setPointerCapture(e.pointerId);}catch(_){}},280);});
 handle.addEventListener('pointermove',e=>{
  if(!held){if(arm&&Math.abs(startY-e.clientY)>12){clearTimeout(arm);arm=null;}return;}
  e.preventDefault();const otherRow=document.elementFromPoint(e.clientX,e.clientY)?.closest('.playlistTrack');if(!otherRow||otherRow===row)return;
  const other=list.find(t=>t.uri===otherRow.dataset.uri);if(!other)return;
  const a=list.indexOf(track),b=list.indexOf(other);if(a<0||b<0)return;
  list.splice(a,1);list.splice(b,0,track);
  otherRow.parentNode.insertBefore(row,b>a?otherRow.nextSibling:otherRow);
 });
 handle.addEventListener('pointerup',finish);handle.addEventListener('pointercancel',finish);
}
function syncMusic(){
 store('pd2-music-library',state.music);
 try{ui.setMusicLibrary?.(JSON.stringify(state.music));ui.setSelectedMusicUri?.(state.music.selectedUri);}catch(e){console.warn('Music sync',e);}

 renderMusicLibrary();if($('musicLibraryDialog').open)renderLibraryPicker();state.alarmMusicUi?.update?.();state.timerMusicUi?.update?.();
}
$('musicRotate').onchange=e=>{state.music.rotate=e.target.checked;syncMusic();};
$('addMp3').onclick=()=>{importMusicScope='global';try{ui.pickMp3?.(state.music.selectedUri||'');}catch(e){takeError(e);}};
$('addFromLibrary').onclick=()=>{renderLibraryPicker();renderLibraryPickerVolume('libraryPreviewVolume');$('musicLibraryDialog').showModal();};
$('musicLibraryClose').onclick=()=>{stopPreview();$('musicLibraryDialog').close();};
$('musicLibraryDialog').addEventListener('cancel',e=>{e.preventDefault();stopPreview();$('musicLibraryDialog').close();});
function mp3Picked(uri,label){if(importMusicScope==='own'&&editingMusicType){const p=editingMusicType==='alarm'?state.editor:state.timer;if(p&&!p.musicPlaylist.some(t=>t.uri===uri)){p.musicPlaylist.push({uri,label:label||'Selected MP3',source:'session'});syncOwnMusic(editingMusicType);}importMusicScope='global';return;}importMusicScope='global';if(!String(uri).startsWith('file://')&&!String(uri).startsWith('content://'))return;
 if(!state.music.tracks.some(t=>t.uri===uri))state.music.tracks.unshift({uri,label:label||'Selected MP3',source:'user',enabled:false});
 syncMusic();renderLibraryPicker();if(!$('musicLibraryDialog').open)$('musicLibraryDialog').showModal();}
function registerBuiltins(){
 try {
  const builtins=JSON.parse(ui.builtInSounds?.()||'[]');
  if(!builtins.length)return;
  const oldBuiltins=new Set(['pavdroid_alarm_1.mp3','pavdroid_alarm_2.mp3']);
  let touched=false,retiredActive=false;
  state.music.tracks=state.music.tracks.filter(t=>{
   const retired=t.source==='builtin'&&[...oldBuiltins].some(name=>String(t.uri||'').endsWith('/'+name));
   if(retired){retiredActive ||=t.enabled!==false;touched=true;}
   return !retired;
  });
  // Imported files remain in place. New built-ins appear in LOW/MED/HIGH/EXTREME order.
  for(const b of builtins){
   const existing=state.music.tracks.find(t=>t.uri===b.uri);
   if(existing && existing.label!==b.label){existing.label=b.label;touched=true;}
   if(!existing){
    state.music.tracks.push({...b,source:'builtin',enabled:true});touched=true;
   }
  }
  if(!state.music.selectedUri||[...oldBuiltins].some(name=>String(state.music.selectedUri).endsWith('/'+name))){
   state.music.selectedUri=builtins[0].uri;touched=true;
  }
  if(touched)syncMusic();
 }catch(e){console.warn('Built-in music',e);}
}
function annoyanceInfoButton(){
 const btn=document.createElement('button');btn.type='button';btn.className='info';
 btn.setAttribute('aria-label','What do LOW, MED, HIGH and EXTREME mean?');
 btn.title='Annoyance level';return bindInfoButton(btn,()=>showInfo('annoyance'));
}
function librarySectionHeading(host,label){
 const h=document.createElement('h3');h.className='libraryGroupTitle';h.textContent=label;
 if(label==='Built-in'){h.append(document.createTextNode('  '),annoyanceInfoButton());}
 host.append(h);
}
function renderMusicPlayback(){
 const host=$('musicPlaybackControls');host.replaceChildren();
 const p=state.music.playback||defaults.alarm;
 for(const [key,label,min,max,step,format] of [
  ['musicAfterSnoozes','Sounds start',0,99,1,launch],
  ['musicStartVolume','Start volume',10,100,10,v=>v+'%'],
  ['musicPreferredRisePercent','Increase by',0,50,5,v=>'+'+v+'%'],
  ['musicRiseSeconds','Increase every',3,120,5,v=>v+'s']]){
  const item=document.createElement('div');item.className='defaultField';item.innerHTML='<label>'+label+'</label><div></div>';host.append(item);
  stepper(item.lastElementChild,{min,max,step,value:p[key],format,onChange:value=>{
   const playback={...(state.music.playback||{
    musicAfterSnoozes:defaults.alarm.musicAfterSnoozes,
    musicStartVolume:defaults.alarm.musicStartVolume,
    musicPreferredRisePercent:defaults.alarm.musicPreferredRisePercent,
    musicRiseSeconds:defaults.alarm.musicRiseSeconds})};
   playback[key]=value;playback.musicRisePercent=Math.min(playback.musicPreferredRisePercent,100-playback.musicStartVolume);
   state.music.playback=playback;
   for(const type of ['alarm','timer'])Object.assign(defaults[type],playback);
   storeDefaults();
   // Defaults never override a user's existing Alarm/Timer custom configuration.
   syncMusic();
  }});
 }
}
let previewTrackUri='';
function markPreviewRows(){document.querySelectorAll('.trackPreview').forEach(button=>{const active=state.previewPlaying&&button.dataset.uri===previewTrackUri;button.classList.toggle('playing',active);button.setAttribute('aria-pressed',String(active));button.title=active?(previewPaused?'Resume preview':'Pause preview'):'Preview sound';const status=button.querySelector('.previewIndicator');if(status)status.innerHTML=previewGlyph(active&&!previewPaused);});}
function stopPreview(){try{ui.stopMusicPreview?.();}catch(_){ }state.previewPlaying=false;previewPaused=false;previewTrackUri='';markPreviewRows();}
function currentTrackPreviewVolume(){
 // Local Alarm/Timer editor previews must use their configured start volume.
 // The global Settings Music library instead uses its separate Preview volume.
 if(editingMusicType){const p=editingMusicType==='alarm'?state.editor:state.timer;return clamp(Number(p?.musicStartVolume??20),10,100);}
 return clamp(previewVolume,10,100);
}
let previewPaused=false;
function toggleTrackPreview(track){if(currentSession())return warn('Stop the alarm or timer before previewing sounds.');if(state.previewPlaying&&previewTrackUri===track.uri){previewPaused=!previewPaused;if(previewPaused)ui.pauseMusicPreview?.();else ui.resumeMusicPreview?.();markPreviewRows();return;}stopPreview();previewPaused=false;previewTrackUri=track.uri;state.previewPlaying=true;ui.previewMusic?.(track.uri,currentTrackPreviewVolume());markPreviewRows();}
function renderLibraryPickerVolume(id){const host=$(id);if(!host)return;host.replaceChildren();const value=editingMusicType?currentTrackPreviewVolume():previewVolume;stepper(id,{min:10,max:100,step:10,value,format:v=>v+'%',onChange:v=>{if(editingMusicType){const p=editingMusicType==='alarm'?state.editor:state.timer;p.musicStartVolume=v;syncOwnMusic(editingMusicType);}else{previewVolume=v;state.previewVolume=v;store('pd2-preview-volume',v);previewVolumeControl?.set(v);}if(state.previewPlaying)ui.setMusicPreviewVolume?.(v);}});}
let previewVolume=clamp(state.previewVolume,10,100), previewVolumeControl;
function renderPreviewVolume(){previewVolumeControl=stepper('musicPreviewVolume',{min:10,max:100,step:10,value:previewVolume,format:v=>v+'%',onChange:v=>{previewVolume=v;state.previewVolume=v;store('pd2-preview-volume',v);if(state.previewPlaying&&!editingMusicType)ui.setMusicPreviewVolume?.(v);}});}

$('exactSettings').onclick=()=>ui.openExactAlarmSettings?.();$('grantExactAlarm').onclick=()=>ui.openExactAlarmSettings?.();$('notificationSettings').onclick=()=>ui.openNotificationSettings?.('');
let testPower=30;
function setupTest(){const control=stepper('testIntensity',{min:10,max:100,step:10,value:testPower,format:v=>v+'%',onChange:v=>{testPower=v;paintIntensityBox($('testIntensity'),v);}});paintIntensityBox($('testIntensity'),control.value);}
for(const type of ['buzz','beep','zap'])$('test'+type[0].toUpperCase()+type.slice(1)).onclick=async()=>{
 if(currentSession())return warn('Stop the current alarm or timer before testing the watch.');if(!bt.watchConnected())return warn('Connect the watch first.');
 if(type==='zap'&&!await ask('Send a single '+testPower+'% test zap to your wrist?'))return;
 try{await bt.test(type,testPower);}catch(e){takeError(e);}
};
function renderDefaults(){
 const groupSpecs=[['Stimuli',[
   ['buzz','Buzzes',0,5,1,v=>String(v)],['beep','Beeps',0,5,1,v=>String(v)],
   ['interval','Interval',3,30,1,v=>v+'s'],['snooze','Snooze time',1,60,1,v=>v+' min']]],
  ['Zaps',[
   ['zaps','Zaps',0,5,1,v=>String(v)],['intensity','Maximum intensity',10,100,10,v=>v+'%'],
   ['zapsAfterSnoozes','Zaps start',0,99,1,launch]]],
  ];
 for(const type of ['alarm','timer']){
  const p=defaults[type],section=$(type==='alarm'?'defaultsAlarmContent':'defaultsTimerContent');section.replaceChildren();
  const controls={},zapFields=[];
  function refreshZapDefaults(){const inactive=Number(p.zaps)===0;
   for(const el of zapFields)el.classList.toggle('zapInactive',inactive);
   for(const key of ['intensity','zapsAfterSnoozes'])controls[key]?.setDisabled(inactive);
  }
  for(const [name,fields] of groupSpecs){
   const card=document.createElement('div');card.className='defaultsGroup';card.innerHTML='<h4>'+name+'</h4><div class="defaultsGrid"></div>';section.append(card);
   const grid=card.querySelector('.defaultsGrid');
   for(const [key,label,min,max,step,format] of fields){
    const field=document.createElement('div');field.className='defaultField';field.innerHTML='<label>'+label+'</label><div></div>';grid.append(field);
    const control=stepper(field.lastElementChild,{min:key==='interval'?minInterval(p.buzz,p.beep):min,max:key==='musicPreferredRisePercent'?Math.min(max,100-p.musicStartVolume):max,step,value:p[key],format,onChange:v=>{
     if(['buzz','beep','zaps'].includes(key)&&!v&&['buzz','beep','zaps'].every(k=>k===key||!p[k])){
      warn('Keep at least one buzz, beep, or zap.');control.set(1);return;}
     p[key]=v;
     if(key==='buzz'||key==='beep'){
      const limit=minInterval(p.buzz,p.beep);controls.interval?.minValue(limit);
      p.interval=Math.max(p.interval,limit);controls.interval?.set(p.interval);
     }
     if(key==='musicStartVolume'){
      controls.musicPreferredRisePercent?.maxValue(Math.min(50,100-v));
      // Retain preference internally, but don't let actual increase exceed 100%.
      p.musicRisePercent=Math.min(p.musicPreferredRisePercent??15,100-v);
     }
     if(key==='musicPreferredRisePercent')p.musicRisePercent=Math.min(v,100-p.musicStartVolume);
     if(key==='intensity'){
      paintIntensityBox(field.lastElementChild,v);
      const text=card.querySelector('.maxExplanation b');if(text)text.textContent=v+'%';
     }
     if(key==='zaps')refreshZapDefaults();
     storeDefaults();
    }});
    controls[key]=control;
    if(['intensity','zapsAfterSnoozes'].includes(key))zapFields.push(field);
    if(key==='intensity')paintIntensityBox(field.lastElementChild,p.intensity);
   }
   if(name==='Zaps'){
    const d=document.createElement('div');d.className='maxExplanation';
    d.innerHTML='<strong>Escalation Setting</strong><span>Start at 10%.<br>Increase to Max <b>'+p.intensity+'%</b>.</span>';
    grid.append(d);zapFields.push(d);
   }
  }
  refreshZapDefaults();
  const readout=document.createElement('label');readout.className='check defaultSmart';
  readout.innerHTML='<input type="checkbox" '+(p.timeReadout?'checked':'')+'> Time Readout';
  readout.querySelector('input').onchange=e=>{p.timeReadout=e.target.checked;storeDefaults();};section.append(readout);
 }
}
function paintIntensityBox(container,value){
 const box=container?.classList.contains('stepBox')?container:container?.querySelector('.stepBox');if(!box)return;
 const p=Number(value),color=p<=30?'#42c987':p<=50?'#e9b959':'#f27880';
 box.style.borderColor=color;box.style.borderWidth='2px';
 box.classList.toggle('extremeIntensity',p>=90);
}
function storeDefaults(){store('pd2-defaults',defaults);}
function refreshPermissions(){
 const allowed=bt.exactAllowed(),blocked=currentSession();
 $('alarmNotice').textContent=!allowed?'Exact alarm permission required. Enable it on Home.':blocked?'An alarm or timer is currently in progress.':'';
 $('exactAlarmGate').hidden=allowed;
 $('exactSettings').textContent=allowed?'Alarm permission ✓':'Allow exact alarms';
}
function keyboardDone(){try{ui.hideKeyboard?.();}catch(_){}document.activeElement?.blur?.();}
function disableAlarm(key){const alarms=bt.alarms();const i=alarms.findIndex(a=>String(a.name)+'|'+String(a.time)===key);if(i<0)return;
 if(currentSession())return warn('Stop the current alarm or timer first.');const previous=structuredClone(alarms);alarms[i].enabled=false;delete alarms[i].skipDue;
 bt.saveAlarms(alarms,previous).then(renderAlarms,takeError);
}
// V1.0.20 History presentation, reimplemented against Android-owned PDH
// journal transitions. No old firmware alarm parsing / Code Red code is used.
const prettyElapsed=total=>{const sec=Math.max(0,Math.round(total));return sec>=3600?Math.floor(sec/3600)+'h '+Math.floor(sec%3600/60)+'m '+sec%60+'s':sec>=60?Math.floor(sec/60)+'m '+sec%60+'s':sec+'s';};
const historyClock=ms=>new Date(ms).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',second:'2-digit'});
const historyTickTime=(ms,span)=>{const d=new Date(ms);return (d.getHours()%12||12)+':'+String(d.getMinutes()).padStart(2,'0')+(span<600000?':'+String(d.getSeconds()).padStart(2,'0'):'');};
const historyReadable=txt=>String(txt||'').replace(/\bthis firing\b/gi,'this launch').replace(/\bRE-FIRING\b/g,'REACTIVATED').replace(/\bFIRING\b/g,'ACTIVATED').replace(/\bTimes Up\b/g,'Time Expired');
const historyStateName=(type,kind)=>kind==='firing'?'ACTIVATED':kind==='alerting'?'TIME EXPIRED':kind.toUpperCase();
function sessionSegments(s){
 const segs=[];let kind=s.skipped?'idle':s.type==='timer'?'countdown':'firing',since=s.start;
 const stateMap={countdown:'countdown',paused:'idle',firing:'firing',alerting:'alerting',snoozing:'snoozing',stopped:'idle',missed:'idle',skipped:'idle'};
 for(const event of s.states){const next=stateMap[event.kind];if(!next||next===kind)continue;
  if(event.at>since)segs.push({state:kind,start:since,end:event.at});
  kind=next;since=event.at;
 }
 if(s.until>since)segs.push({state:kind,start:since,end:s.until});
 return segs.length?segs:[{state:kind,start:s.start,end:s.start+1}];
}
function readHistory(){
 const fresh=bt.savedHistory().filter(e=>Number(e.millis)>0);
 const last=fresh[fresh.length-1];
 const fingerprint=fresh.length+'|'+(last?.millis||0)+'|'+String(last?.msg||'')+'|'+state.historyHideBefore+'|'+[...state.hiddenIds].sort().join(',');
 // The foreground polls every second. Leave expanded lists, scroll positions,
 // and selection controls intact when the archive has not changed.
 if(fingerprint===state.historySignature)return;
 state.historySignature=fingerprint;
 state.history=fresh.sort((a,b)=>Number(a.millis)-Number(b.millis));
 const map=new Map();
 for(const e of state.history){if(!String(e.msg||'').startsWith('PDH|'))continue;
  let d;try{d=JSON.parse(String(e.msg).slice(4));}catch(_){continue;}
  if(!['timer','alarm'].includes(d.type)||!Number.isFinite(Number(d.session))||Number(d.session)<=0||!d.state)continue;
  const at=Number(e.millis),id=d.type+':'+d.session;
  let s=map.get(id);if(!s){s={id,type:d.type,start:at,end:0,until:at,label:d.label||(d.type==='alarm'?'Alarm':'Timer'),
    snoozes:0,firstResponse:0,firstAlert:0,missed:false,skipped:false,reason:'',events:[],states:[]};map.set(id,s);}
  s.until=Math.max(s.until,at);if(d.label)s.label=d.label;
  if(d.state==='snoozing'){s.snoozes++;if(!s.firstResponse)s.firstResponse=at;}
  if(d.state==='alerting'&&!s.firstAlert)s.firstAlert=at;
  if(['stopped','missed','skipped'].includes(d.state)){s.end=at;s.reason=d.detail||'';if(d.state==='missed')s.missed=true;if(d.state==='skipped')s.skipped=true;}
  s.states.push({at,kind:d.state,label:d.detail||''});
 }
 for(const s of map.values()){
  s.states.sort((a,b)=>a.at-b.at);s.until=Math.max(s.until,s.start+1);
  s.events=state.history.filter(e=>Number(e.millis)>=s.start&&Number(e.millis)<=s.until).map(e=>{
   let msg=String(e.msg||'');if(msg.startsWith('PDH|'))try{const d=JSON.parse(msg.slice(4));msg='PavDroid '+String(d.type).toUpperCase()+' · '+historyStateName(d.type,d.state)+(d.detail?' · '+historyReadable(d.detail):'');}catch(_){}
   return {at:Number(e.millis),text:historyReadable(msg)};
  });
  s.segments=sessionSegments(s);
 }
 state.historySessions=[...map.values()].filter(s=>s.start>state.historyHideBefore&&!state.hiddenIds.has(s.id)).sort((a,b)=>b.start-a.start);
 const activeIds=new Set(state.historySessions.map(s=>s.id));for(const id of state.historySelected)if(!activeIds.has(id))state.historySelected.delete(id);
 for(const id of state.historyExpanded)if(!activeIds.has(id))state.historyExpanded.delete(id);
 renderHistory();renderHomeHistory();
}
function updateHistoryButtons(){
 const has=state.historySelecting&&state.historySelected.size>0;
 $('historySelect').textContent=state.historySelecting?'Done':'Select';
 $('historyDelete').textContent=has?'Delete Selected':'Delete All';
 $('historyExport').textContent=has?'Export Selected':'Export All';
 for(const id of ['historyDelete','historyExport'])$(id).dataset.selectedLabel=String(has);
 $('historySelect').disabled=!state.historySessions.length;
 $('historyDelete').disabled=!state.historySessions.length||(state.historySelecting&&!has);
 $('historyExport').disabled=!state.historySessions.length||(state.historySelecting&&!has);
}
function historyMarkers(s){
 const result=[];for(const event of s.states){
  if(event.kind==='snoozing'){
   const phone=/phone/i.test(event.label)||s.events.some(e=>Math.abs(e.at-event.at)<=5000&&/snooze requested from (?:app|phone|notification)|notification action: snooze|phone snooze/i.test(e.text));
   result.push({at:event.at,kind:phone?'historyDotPhoneSnooze':'historyDotWatchSnooze',name:phone?'Phone snooze':'Watch snooze'});
  }else if(event.kind==='stopped')result.push({at:event.at,kind:'historyDotStop',name:'STOP'});
 }
 return result;
}
function renderHistory(){
 const host=$('historyList');host.replaceChildren();
 $('historyCount').textContent=state.historySessions.length+' '+(state.historySessions.length===1?'session':'sessions');
 if(!state.historySessions.length){state.historySelecting=false;state.historySelected.clear();}
 updateHistoryButtons();
 if(!state.historySessions.length){host.innerHTML='<p class="smalltext">No saved alarm or timer sessions yet.</p>';return;}
 const names={firing:'Alarm Activated',alerting:'Time Expired',snoozing:'Snooze',countdown:'Timer running',idle:'Stopped / idle'};
 const colors={firing:'historyFiring',alerting:'historyAlerting',snoozing:'historySnoozing',countdown:'historyCountdown',idle:'historyIdle'};
 for(const s of state.historySessions){
  const item=document.createElement('div');item.className='historySession';
  const header=document.createElement('div');header.className='historyHeader';
  const title=document.createElement('strong');title.textContent=new Date(s.start).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})+' · '+(s.type==='alarm'?s.label:'Timer');
  if(state.historySelecting){const box=document.createElement('input');box.type='checkbox';box.className='historyCheckbox';box.setAttribute('aria-label','Select '+title.textContent);box.checked=state.historySelected.has(s.id);
   box.onchange=()=>{if(box.checked)state.historySelected.add(s.id);else state.historySelected.delete(s.id);updateHistoryButtons();};header.append(box);}
  header.append(title);item.append(header);
  const summary=document.createElement('div');summary.className='historySummary';
  if(s.type==='alarm')summary.textContent=s.skipped?'Skipped · '+s.reason:'First Snooze: '+(s.firstResponse?prettyElapsed((s.firstResponse-s.start)/1000):'None recorded')+' · Snoozes: '+s.snoozes+' · '+(s.skipped?'Skipped':s.missed?'Missed':s.end?'Ended':'End not confirmed');
  else summary.textContent='Time Expired: '+(s.firstAlert?prettyElapsed((s.firstAlert-s.start)/1000):'Not recorded')+' · Snoozes: '+s.snoozes+' · '+(s.end?'Stopped':'End not confirmed');
  item.append(summary);
  // The original timer History plots from expiration, not the pre-alert countdown.
  const chartStart=s.type==='timer'&&s.firstAlert>=s.start&&s.firstAlert<=s.until?s.firstAlert:s.start;
  const chartEnd=Math.max(s.until,chartStart+1),span=chartEnd-chartStart;
  const parts=s.segments.filter(p=>p.end>chartStart&&p.state!=='countdown');
  const times=document.createElement('div');times.className='historyTimeRow';
  for(const [key,clock] of [[s.type==='timer'&&s.firstAlert?'TIME EXPIRED':'START',chartStart],[s.end?'END':'LAST RECORDED',s.until]]){
   const part=document.createElement('span');const lab=document.createElement('b');lab.textContent=key;const formatted=historyClock(clock),match=formatted.match(/^(\d{1,2}:\d{2})(:\d{2})(.*)$/);part.append(lab);if(match){const seconds=document.createElement('span');seconds.className='historyEndpointSeconds';seconds.textContent=match[2];part.append(document.createTextNode(match[1]),seconds,document.createTextNode(match[3]));}else part.append(document.createTextNode(formatted));times.append(part);
  }
  const elapsed=document.createElement('div');elapsed.className='historyDuration';
  const elapsedValue=prettyElapsed((s.until-chartStart)/1000);
  const durationLabel=(s.type==='timer'&&s.firstAlert?'Alert elapsed: ':'Elapsed: ')+elapsedValue;
  elapsed.setAttribute('aria-label',durationLabel);elapsed.title=durationLabel;
  const elapsedText=document.createElement('span');elapsedText.textContent=elapsedValue;elapsed.append(elapsedText);
  times.insertBefore(elapsed,times.lastElementChild);item.append(times);
  const bar=document.createElement('div');bar.className='historyTimeline';bar.setAttribute('role','img');bar.setAttribute('aria-label','Timeline from '+historyClock(chartStart)+' to '+historyClock(s.until));
  for(const p of parts){const left=100*Math.max(0,Math.min(span,p.start-chartStart))/span,right=100*Math.max(0,Math.min(span,p.end-chartStart))/span;
   const block=document.createElement('span');block.className='historyPart '+(colors[p.state]||'historyIdle');block.style.left=left+'%';block.style.width=Math.max(0,right-left)+'%';
   block.title=(names[p.state]||p.state)+': '+historyClock(Math.max(chartStart,p.start))+' – '+historyClock(p.end)+' ('+prettyElapsed((p.end-Math.max(chartStart,p.start))/1000)+')';bar.append(block);
  }
  for(let i=1;i<4;i++){const line=document.createElement('i');line.className='historyGridline';line.style.left=i*25+'%';bar.append(line);}
  const markers=historyMarkers(s).filter(m=>m.at>=chartStart);
  for(const m of markers){const dot=document.createElement('i');dot.className='historyMarker '+m.kind;dot.style.left='clamp(8px, '+(100*Math.max(0,Math.min(span,m.at-chartStart))/span)+'%, calc(100% - 8px))';dot.title=m.name+' · '+historyClock(m.at);bar.append(dot);}
  item.append(bar);
  const ticks=document.createElement('div');ticks.className='historyTicks';ticks.setAttribute('aria-label','Actual clock times on the timeline');
  for(let i=0;i<=4;i++){const tick=document.createElement('span');tick.className='historyTick'+(i===0?' first':i===4?' last':'');tick.style.left=i*25+'%';const label=historyTickTime(chartStart+(s.until-chartStart)*i/4,s.until-chartStart);const parts=label.split(':');tick.textContent=parts.slice(0,2).join(':');if(parts.length===3){const seconds=document.createElement('span');seconds.className='historyTickSeconds';seconds.textContent=':'+parts[2];tick.append(seconds);}ticks.append(tick);}item.append(ticks);
  const legend=document.createElement('div');legend.className='historyLegend';legend.setAttribute('aria-label','Timeline color legend');
  const seen=new Set(parts.map(p=>p.state));
  const entries=[...['firing','alerting','snoozing','idle'].filter(x=>seen.has(x)).map(x=>[colors[x],names[x]]),
   ...[['historyDotPhoneSnooze','Phone snooze'],['historyDotWatchSnooze','Watch snooze'],['historyDotStop','STOP']].filter(([cls])=>markers.some(m=>m.kind===cls))];
  for(const [cls,name] of entries){const row=document.createElement('span');row.className='historyLegendItem';const icon=document.createElement('i');icon.className='historySwatch '+cls;row.append(icon,document.createTextNode(name));legend.append(row);}item.append(legend);
  const expanded=state.historyExpanded.has(s.id);
  const btn=document.createElement('button');btn.type='button';btn.className='historyExpandBtn';btn.textContent=(expanded?'▲ Collapse':'▼ Expand')+' session events · '+s.events.length;btn.setAttribute('aria-expanded',String(expanded));
  const extras=document.createElement('div');extras.className='historyExtra';extras.hidden=!expanded;
  const ul=document.createElement('ul');ul.className='historyEventList';
  for(const e of s.events){const row=document.createElement('li');const time=document.createElement('time');time.textContent=historyClock(e.at);const msg=document.createElement('span');msg.textContent=e.text;row.append(time,msg);ul.append(row);}extras.append(ul);
  btn.onclick=()=>{if(extras.hidden)state.historyExpanded.add(s.id);else state.historyExpanded.delete(s.id);extras.hidden=!extras.hidden;btn.textContent=(extras.hidden?'▼ Expand':'▲ Collapse')+' session events · '+s.events.length;btn.setAttribute('aria-expanded',String(!extras.hidden));};
  item.append(btn,extras);host.append(item);
 }
}
function renderHomeHistory(){const host=$('homeHistory');host.replaceChildren();const session=state.historySessions[0],card=$('historyList').querySelector('.historySession');if(!session||!card){host.innerHTML='<p class="smalltext">No saved sessions yet.</p>';return;}
 const title=document.createElement('div');title.className='homeHistoryTitle';title.textContent=(session.type==='alarm'?session.label:'Timer')+' · '+new Date(session.start).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});host.append(title);
 const summary=card.querySelector('.historySummary').cloneNode(true);host.append(summary);
 const graph=document.createElement('div');graph.className='homeHistoryGraph homeShortcut';graph.tabIndex=0;graph.setAttribute('role','button');graph.setAttribute('aria-label','Open History');for(const sel of ['.historyTimeRow','.historyTimeline']){const node=card.querySelector(sel);if(node)graph.append(node.cloneNode(true));}host.append(graph);deliberateTouch(graph,()=>tab('history'));
}
let homeEntering=false,homeStarting=false;
$('homeTimerStart').addEventListener('pointerdown',e=>{homeEntering=document.activeElement===$('duration');if(homeEntering)e.preventDefault();},true);
$('homeTimerStart').addEventListener('pointercancel',()=>homeEntering=false);
$('homeTimerStart').onclick=async()=>{const entering=homeEntering||document.activeElement===$('duration');homeEntering=false;keyboardDone();$('duration').value=durationText(state.timerSeconds);if(entering){paintFooter();return;}if(homeStarting)return;homeStarting=true;try{await timerAction('start');}finally{homeStarting=false;}};
$('homeTimerSummary').onclick=()=>{tab('timer');enterTimerEditing();};
$('historySelect').onclick=()=>{state.historySelecting=!state.historySelecting;state.historySelected.clear();renderHistory();};
$('historyDelete').onclick=async()=>{
 if(state.historySelecting&&!state.historySelected.size)return;
 const selected=state.historySelecting?[...state.historySelected]:state.historySessions.map(s=>s.id);
 if(!selected.length)return;if(!await ask('Delete '+selected.length+' History session(s)?'))return;
 if(selected.length===state.historySessions.length){bt.clearHistory();state.historyHideBefore=Date.now();state.hiddenIds.clear();store('pd2-history-before',state.historyHideBefore);store('pd2-history-hidden',[]);}
 else {selected.forEach(id=>state.hiddenIds.add(id));store('pd2-history-hidden',[...state.hiddenIds]);}
 state.historySelected.clear();state.historySelecting=false;readHistory();
};
function exportText(sessions){const lines=['PavDroid V3.0.53 | Alarm & Timer History','Exported '+new Date().toLocaleString(),''];
 for(const s of sessions){lines.push(s.type.toUpperCase()+' '+s.label+' | '+new Date(s.start).toLocaleString());
  lines.push('Status: '+(s.skipped?'SKIPPED':s.missed?'MISSED':s.end?'Finished':'No stop recorded')+' · Snoozes: '+s.snoozes+(s.reason?' · '+s.reason:''));
  for(const e of s.events)lines.push('  '+new Date(e.at).toLocaleTimeString()+' | '+e.text);lines.push('');}return lines.join('\n');}
$('historyExport').onclick=()=>{if(state.historySelecting&&!state.historySelected.size)return;
 const selected=state.historySelecting?state.historySessions.filter(s=>state.historySelected.has(s.id)):state.historySessions;
 if(!selected.length)return warn('No History sessions to export.');try{ui.exportText?.('PavDroid-AlarmHistory.txt',exportText(selected));}catch(e){takeError(e);}};
function refreshLog(){
 const events=bt.eventHistory(),host=$('eventLog');host.replaceChildren();
 for(const e of (state.logExpanded?events:[]).slice().reverse()){
  const li=document.createElement('li'),t=document.createElement('time'),msg=document.createElement('span');
  t.textContent=new Date(Number(e.millis)).toLocaleTimeString();msg.textContent=String(e.msg||'');li.append(t,msg);host.append(li);
 }
 host.hidden=!state.logExpanded;
 $('expandLog').textContent=(state.logExpanded?'▲ Collapse':'▼ Expand')+' event log · '+events.length+' '+(events.length===1?'event':'events');
 $('expandLog').setAttribute('aria-expanded',String(state.logExpanded));
}
$('expandLog').onclick=()=>{state.logExpanded=!state.logExpanded;refreshLog();};
// Keep the read-only native charging indicator notification; the optional test is removed.
bt.onDiagnostic((uuid)=>{if(uuid===CHARGE_STATUS_UUID)syncChargingIndicator();});
$('copyLog').onclick=()=>{const events=bt.eventHistory();const text='PavDroid V3.0.53 | Watch event log\n'+events.length+' recorded events\n\n'+events.map(e=>new Date(Number(e.millis)).toLocaleString()+' | '+e.msg).join('\n');
 try{ui.copyText?.(text);}catch(e){takeError(e);}};
$('clearLog').onclick=async()=>{if(!await ask('Clear the Connection event log? History will not be deleted.'))return;bt.clearEvents();refreshLog();};
function setupSmartTimeout(){
 const control=$('globalSmartTimeout');control.checked=ui.getSmartTimeout?.()??true;
 control.onchange=()=>{try{ui.setSmartTimeout(control.checked);control.checked=ui.getSmartTimeout();}catch(e){control.checked=ui.getSmartTimeout?.()??true;takeError(e);}};
}
function initialize(){
 setupSmartTimeout();
 fillChangelog();registerBuiltins();
 state.timer=profile('timer',Object.keys(savedTimer).length>1?savedTimer:null);
 state.timerSeconds=clamp(savedTimer.seconds||300,1,86399);
 widgetTimerPull();
 syncChargingIndicator();
 timerPrepare();renderPreviewVolume();setupTest();refreshSpeechControls();saveSpeech();ui.setSafeMaxRepeat?.(safeMaxRepeat());
 saveTimerSetup();renderAlarms();refreshSessions();refreshConnection();applyOpeningTab();store('pd2-has-opened',true);
 // Reapply the selected MP3 URI to the new test app's native audio store.
 syncMusic();
 setInterval(()=>{widgetTimerPull();refreshSessions();if(['history','home'].includes(state.activeTab))readHistory();if(state.activeTab==='settings'&&$('watchDiagnostics').open)refreshLog();if($('alarmEditor').hidden && !saving && !alarmTogglePending && JSON.stringify(bt.alarms())!==JSON.stringify(state.alarms))renderAlarms();if(state.activeTab==='home'){renderHomeAlarm();}refreshBattery();},1000);
 setInterval(()=>{if(state.activeTab==='alarms'&&$('alarmEditor').hidden){document.querySelectorAll('.alarmCountdown[data-alarm-index]').forEach(el=>{const a=state.alarms[Number(el.dataset.alarmIndex)];if(a){el.textContent=nextAlarmLabel(a);el.title=el.textContent;}});}},30000);
 setTimeout(()=>refreshBattery(true),850);
 setTimeout(showWhatsNew,1000);
 setInterval(()=>{if(load('pd2-whats-new-seen-version','')!=='3.0.53'&&!currentSession())showWhatsNew();},15000);
}
function handleBack(){
 if($('whatsNewDialog').open){dismissWhatsNew();return true;}
 if($('confirmDialog').open){$('confirmNo').click();return true;}
 if($('warningDialog').open){$('warningOk').click();return true;}
 if($('timeControlHelpDialog').open){$('timeControlHelpOk').click();return true;}
 if($('ownMusicLibraryDialog').open){$('ownMusicLibraryDialog').close();return true;}
 if($('ownMusicDialog').open){closeOwnMusic();return true;}
 if($('musicLibraryDialog').open){$('musicLibraryDialog').close();return true;}
 if(state.activeTab==='settings'){void leaveSettings();return true;}
 if(analogDialog.open){closeAnalog(false);return true;}
 if(!$('alarmEditor').hidden){$('editorCancel').click();return true;}
 if(state.activeTab==='alarms'&&alarmSelecting){clearAlarmSelection();renderAlarms();return true;}
 if(state.timerEditing){$('timerBack').click();return true;}
 return false;
}
function widgetOpen(route,index,expected){
 if(!['home','alarms','timer','history','new_alarm','edit_alarm'].includes(route))return false;
 if(widgetNavigationInProgress)return 'protected';
 // A widget tap is explicit navigation, not an ordinary app resume.
 pageBackgrounded=false;widgetExplicitVisit=true;
 if($('whatsNewDialog').open)dismissWhatsNew();
 // Never discard a pending destructive confirmation or a custom-sounds draft.
 if(document.querySelector('dialog[open]')){return 'protected';}
 widgetNavigationInProgress=true;
 const perform=async()=>{
  const destination=['new_alarm','edit_alarm'].includes(route)?'alarms':route;
  if(state.activeTab==='settings'){
   await leaveSettings(destination);
   if(state.activeTab==='settings')return; // User declined discard.
  }
  if(!$('alarmEditor').hidden){
   if(saving)return;
   const dirty=state.editor&&($('alarmName').value!==state.editor.name||$('alarmTime').value!==state.editor.time||JSON.stringify(state.editor)!==state.editorOriginal);
   if(dirty&&!await ask('Discard changes to this alarm?','Leave alarm setup?'))return;
   dismissEditor();
  }
  if(alarmSelecting){clearAlarmSelection();renderAlarms();}
  widgetTimerPull();
  if(['home','alarms','timer','history'].includes(route)){navigateTab(route,true);return;}
  if(currentSession()){navigateTab(bt.alarmState().active?'alarms':'timer',true);return;}
  navigateTab('alarms',true);renderAlarms();
  if(route==='new_alarm'){alarmEditorOpen();return;}
  let target;try{target=JSON.parse(expected);}catch(_){}
  const current=state.alarms[index];
  if(current&&target&&JSON.stringify(current)===JSON.stringify(target))alarmEditorOpen(index);
  else warn('Upcoming alarm changed. Select an alarm to edit.');
 };
 // Synchronous routes render before native reveal; confirmations can remain visible
 // while the user decides. Keep foreground auto-routing suppressed during that decision.
 void perform().catch(takeError).finally(()=>{pageBackgrounded=false;widgetNavigationInProgress=false;});
 return true;
}
window.PavDroidApp={widgetOpen,tab,keyboardDone,mp3Picked,disableAlarm,refreshPermissions,handleBack,musicPreviewEnded:()=>{state.previewPlaying=false;previewPaused=false;previewTrackUri='';markPreviewRows();}};
window.addEventListener('error',e=>{console.error('PavDroid UI',e.error||e.message);});
initialize();
})();
