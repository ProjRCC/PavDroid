/*
 * Pavlok Control native-Android Web Bluetooth compatibility layer.
 * This file runs ONLY inside the Android app's bundled WebView.
 * All device operations are delegated to android.bluetooth.BluetoothGatt, not Chrome.
 */
(function () {
  'use strict';
  if (!window.AndroidBle) return;
  let requestSequence = 1;
  const pending = new Map();
  const characteristicHandlers = new Map();
  const lastNotification = new Map();
  function resetCharacteristicListeners() {
    // Old NativeCharacteristic objects used to accumulate forever across BLE
    // reconnects, multiplying every received FIRING/SNOOZE/log event.
    characteristicHandlers.clear();
    lastNotification.clear();
  }
  const devices = new Map();
  const normalize = value => {
    const s = String(value).toLowerCase();
    if (s === 'battery_service') return '0000180f-0000-1000-8000-00805f9b34fb';
    if (s === 'battery_level') return '00002a19-0000-1000-8000-00805f9b34fb';
    return s;
  };
  function nativeCall(method, ...args) {
    return new Promise((resolve, reject) => {
      const id = requestSequence++;
      pending.set(id, {resolve, reject});
      try { window.AndroidBle[method](id, ...args); }
      catch (err) { pending.delete(id); reject(err); }
    });
  }
  function emitter(object) {
    const handlers = new Map();
    object.addEventListener = function (type, callback) {
      if (!handlers.has(type)) handlers.set(type, new Set());
      handlers.get(type).add(callback);
    };
    object.removeEventListener = function (type, callback) {
      handlers.get(type)?.delete(callback);
    };
    object._emit = function (type, event) {
      for (const callback of handlers.get(type) || []) {
        try { callback.call(object, event); } catch (e) { console.error(e); }
      }
    };
  }
  class NativeCharacteristic {
    constructor(uuid) {
      this.uuid = normalize(uuid);
      this.value = null;
      emitter(this);
      if (!characteristicHandlers.has(this.uuid)) characteristicHandlers.set(this.uuid, new Set());
      characteristicHandlers.get(this.uuid).add(this);
    }
    async startNotifications() {
      await nativeCall('subscribe', this.uuid);
      return this;
    }
    async readValue() {
      const bytes = await nativeCall('read', this.uuid);
      const view = new DataView(Uint8Array.from(bytes).buffer);
      this.value = view;
      return view;
    }
    async writeValueWithResponse(bytes) {
      await nativeCall('write', this.uuid, JSON.stringify(Array.from(new Uint8Array(bytes.buffer || bytes, bytes.byteOffset || 0, bytes.byteLength || bytes.length))));
    }
    async writeValue(bytes) { return this.writeValueWithResponse(bytes); }
    async writeValueWithoutResponse(bytes) { return this.writeValueWithResponse(bytes); }
  }
  class NativeService {
    constructor(uuid) { this.uuid = normalize(uuid); }
    async getCharacteristic(uuid) {
      const n = normalize(uuid);
      await nativeCall('characteristic', n);
      return new NativeCharacteristic(n);
    }
  }
  class NativeGattServer {
    constructor(device) { this.device = device; this.connected = false; }
    async connect() {
      resetCharacteristicListeners();
      await nativeCall('connect', this.device.id);
      this.connected = true;
      return this;
    }
    disconnect() {
      if (!this.connected) return;
      this.connected = false;
      this.device._emit('gattserverdisconnected', {target: this.device});
      window.AndroidBle.disconnect();
    }
    async getPrimaryService(uuid) {
      await nativeCall('service', normalize(uuid));
      return new NativeService(uuid);
    }
  }
  class NativeDevice {
    constructor(info) {
      this.id = info.id;
      this.name = info.name || 'Pavlok-3';
      this.gatt = new NativeGattServer(this);
      emitter(this);
    }
  }
  function device(info) {
    if (!devices.has(info.id)) devices.set(info.id, new NativeDevice(info));
    return devices.get(info.id);
  }
  window.PavlokNative = {
    _complete(id, success, message) {
      const p = pending.get(id);
      if (!p) return;
      pending.delete(id);
      if (!success) { p.reject(new Error(String(message))); return; }
      try { p.resolve(JSON.parse(message)); }
      catch (err) { p.reject(new Error('Invalid Android Bluetooth response: ' + err.message)); }
    },
    _notify(uuid, bytes) {
      const n = normalize(uuid);
      const signature = JSON.stringify(bytes);
      const previous = lastNotification.get(n);
      const now = Date.now();
      // Android versions can invoke the legacy and API-33 callbacks for one
      // indication. Do not suppress real 5–8 second firmware repeat events.
      if (previous && previous.signature === signature && now - previous.at < 200) return;
      lastNotification.set(n, {signature, at: now});
      for (const chr of characteristicHandlers.get(n) || []) {
        const array = Uint8Array.from(bytes);
        chr.value = new DataView(array.buffer);
        chr._emit('characteristicvaluechanged', {target: chr});
      }
    },
    _connected() {
      // Auto GATT connection may happen with WebView absent or hidden. When
      // visible, the page can rebuild read/notify characteristics safely.
      window.dispatchEvent(new Event('pavdroidnativeconnected'));
    },
    _disconnected() {
      resetCharacteristicListeners();
      for (const d of devices.values()) {
        if (!d.gatt.connected) continue;
        d.gatt.connected = false;
        d._emit('gattserverdisconnected', {target: d});
      }
    }
  };
  // Native foreground-service timer: the Activity may be destroyed and recreated.
  window.PavlokNativeTimer = {
    snapshot() {
      try { return JSON.parse(window.AndroidBle.timerSnapshot()); }
      catch (err) { return null; }
    },
    async action(name, config = {}) {
      return nativeCall('timerAction', String(name), JSON.stringify(config));
    }
  };
  window.PavDroidNative = {
    list() { try { return JSON.parse(window.AndroidBle.androidAlarms()); } catch (_) { return []; } },
    snapshot() { try { return JSON.parse(window.AndroidBle.androidAlarmSnapshot()); } catch (_) { return {}; } },
    save(alarms) { return nativeCall('saveAndroidAlarms', JSON.stringify(alarms)); },
    action(which) { return nativeCall('androidAlarmAction', String(which)); },
    exactAccess() { return !!window.AndroidBle.hasAndroidExactAlarmAccess(); }
  };
  const bluetooth = {
    async getDevices() {
      const raw = window.AndroidBle.savedDevice();
      const info = JSON.parse(raw);
      return info ? [device(info)] : [];
    },
    async requestDevice(options) {
      const prefix = options?.filters?.[0]?.namePrefix || 'Pavlok-3-';
      const info = await nativeCall('scan', prefix);
      return device(info);
    }
  };
  Object.defineProperty(navigator, 'bluetooth', { configurable: true, enumerable: true, value: bluetooth });
})();
