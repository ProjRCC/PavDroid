/* PavDroid History uses the original V3.0.3 History screen and native archive.
   Structured PDH transitions, never watch firmware alarm #ID, define sessions. */
'use strict';
(function () {
  // Presentation-only normalization for both new and archived entries. Native
  // PDH state keys (firing/alerting/snoozing) stay unchanged for diagnostics.
  const statusText=(type,state)=>type==='alarm'&&state==='firing'?'ACTIVATED':
    type==='timer'&&state==='alerting'?'TIME EXPIRED':state.toUpperCase();
  const readableEvent=raw=>String(raw||'')
    .replace(/\bthis firing\b/gi,'this launch')
    .replace(/\bTimes Up\b/g,'Time Expired')
    .replace(/\bRE-FIRING\b/g,'REACTIVATED')
    .replace(/\bFIRING\b/g,'ACTIVATED')
    .replace(/\bfiring\b/g,'activation');
  const oldHistorySessions=historySessions;
  function decode(event){
    const msg=String(event.msg||'');
    if(!msg.startsWith('PDH|'))return null;
    try{const data=JSON.parse(msg.slice(4));
      if(!['alarm','timer'].includes(data.type)||!Number.isFinite(Number(data.session))||!data.state)return null;
      return data;
    }catch(_){return null;}
  }
  function fromStructured(events){
    const map=new Map();
    for(const event of events){
      const d=decode(event);if(!d)continue;
      const at=Number(event.millis);if(!Number.isFinite(at)||at<=0)continue;
      const id='pd:'+d.type+':'+d.session;
      let s=map.get(id);
      if(!s){
        s={id,type:d.type,start:at,end:0,until:at,watchId:0,displayName:d.label||'Alarm',
           codeRedId:0,codeRedAlarm:false,linkedTimer:null,redStatus:null,
           snoozes:0,firstResponse:0,firstAlert:0,missed:false,stopOrigin:'',
           transitions:[]};map.set(id,s);
      }
      s.transitions.push({at,state:d.state,detail:d.detail||'',label:d.label||''});
      if(d.label)s.displayName=d.label;
      if(d.state==='snoozing'){s.snoozes++;if(!s.firstResponse)s.firstResponse=at;}
      if(d.state==='alerting'&&!s.firstAlert)s.firstAlert=at;
      if(d.state==='stopped'||d.state==='missed'){s.end=at;if(d.state==='missed')s.missed=true;
          s.stopOrigin=d.detail||'';}
      s.until=Math.max(s.until,at);
    }
    return [...map.values()];
  }
  function legacySessions(events,limit){
    const sessions=[];let timer=null,alarm=null;
    for(const e of events){
      const at=Number(e.millis),msg=String(e.msg||'');if(!Number.isFinite(at)||at<=0||at>=limit)continue;
      if(/^Timer status notification: countdown/.test(msg)&&(!timer||timer.end)){
        timer={id:'pd:legacy-timer:'+at,type:'timer',start:at,end:0,until:at,snoozes:0,
          firstAlert:0,firstResponse:0,displayName:'Timer',watchId:0,codeRedId:0,codeRedAlarm:false,linkedTimer:null,transitions:[{at,state:'countdown',detail:'Countdown'}]};sessions.push(timer);
      }else if(timer&&!timer.end){
        if(/Timer notification POSTED: (?:Times Up|Time Expired)/.test(msg)){timer.firstAlert=timer.firstAlert||at;timer.transitions.push({at,state:'alerting',detail:'Time Expired'});}
        if(msg.startsWith('Timer status notification: snoozing')){timer.snoozes++;timer.transitions.push({at,state:'snoozing',detail:'Snooze'});}
        if(msg.startsWith('PavDroid timer Stop from')){timer.end=at;timer.transitions.push({at,state:'stopped',detail:msg});}
        timer.until=at;
      }
      const started=msg.match(/^PavDroid alarm (?:FIRING|ACTIVATED): (.*)/);
      if(started){alarm={id:'pd:legacy-alarm:'+at,type:'alarm',start:at,end:0,until:at,snoozes:0,
        firstResponse:0,firstAlert:0,displayName:started[1],watchId:0,codeRedId:0,codeRedAlarm:false,linkedTimer:null,
        transitions:[{at,state:'firing',detail:msg}]};sessions.push(alarm);}
      else if(alarm&&!alarm.end){
        if(msg.startsWith('PavDroid alarm SNOOZED:')){alarm.snoozes++;alarm.firstResponse=alarm.firstResponse||at;alarm.transitions.push({at,state:'snoozing',detail:msg});}
        if(/^PavDroid alarm (?:RE-FIRING|ACTIVATED after snooze)/.test(msg))alarm.transitions.push({at,state:'firing',detail:msg});
        if(msg.startsWith('PavDroid alarm STOPPED')){alarm.end=at;alarm.transitions.push({at,state:'stopped',detail:msg});}
        alarm.until=at;
      }
    }
    return sessions;
  }
  historySessions=function(){
    const entries=(app.historyLog||[]).slice().sort((a,b)=>Number(a.millis)-Number(b.millis));
    let list=fromStructured(entries);
    const earliestStructured=list.length?Math.min(...list.map(s=>s.start)):Infinity;
    // The same start may have a legacy text status just milliseconds before PDH;
    // keep one real session, not an extra orphan at the same timestamp.
    const structured=list.slice();
    list=list.concat(legacySessions(entries,earliestStructured).filter(old=>
      !structured.some(s=>s.type===old.type && Math.abs(s.start-old.start)<5000)));

    for(const s of list){
      s.transitions.sort((a,b)=>a.at-b.at);
      s.until=Math.max(s.until,s.end||0,s.start+1);
      s.events=entries.filter(e=>Number(e.millis)>=s.start&&Number(e.millis)<=s.until).map(e=>{
        const d=decode(e);
        return d?{...e,structured:d,rawMsg:e.msg,msg:'PavDroid '+d.type.toUpperCase()+' · '+statusText(d.type,d.state)+(d.detail?' · '+readableEvent(d.detail):'')}:
          {...e,rawMsg:e.msg,msg:readableEvent(e.msg)};
      });
      s.startDay=new Date(s.start).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
      s.segments=historySegments(s);
    }
    return list.filter(s=>s.start>app.historyHideBefore&&!app.historyHiddenIds.has(s.id))
       .sort((a,b)=>b.start-a.start);
  };
  historySegments=function(s){
    const points=s.transitions||[];let state=s.type==='timer'?'countdown':'idle';
    const parts=[];let since=s.start;
    const mapped=x=>({waiting:'idle',late:null,music:null,link:null,missed:'idle',
      stopped:'idle',countdown:'countdown',paused:'idle',firing:'firing',alerting:'alerting',snoozing:'snoozing'})[x];
    for(const x of points){
      const next=mapped(x.state);if(!next||next===state)continue;
      if(x.at>since)parts.push({state,start:since,end:x.at});
      since=x.at;state=next;
    }
    if(s.until>since)parts.push({state,start:since,end:s.until});
    return parts.length?parts:[{state,start:s.start,end:s.start+1}];
  };
  historyEventMarkers=function(s){
    const result=[];
    for(const x of s.transitions||[]){
      if(x.state==='snoozing'){
        const phone=/phone/i.test(x.detail);
        result.push({kind:phone?'historyDotPhoneSnooze':'historyDotWatchSnooze',at:x.at,label:phone?'Phone snooze':'Watch snooze'});
      }else if(x.state==='stopped')result.push({kind:'historyDotStop',at:x.at,label:'STOP · '+x.detail});
      else if(x.state==='music')result.push({kind:'historyDotInput',at:x.at,label:'Music started'});
    }
    return result;
  };
  historyExportText=function(sessions){
    const lines=['PavDroid V1.0.14 | Alarm & Timer History','Exported '+new Date().toLocaleString(),''];
    for(const s of sessions){
      if(app.historySelecting&&app.historySelected.size&&!app.historySelected.has(s.id))continue;
      lines.push(s.type.toUpperCase()+' '+(s.displayName||'')+' | '+new Date(s.start).toLocaleString());
      lines.push('Status: '+(s.missed?'MISSED':s.end?'Finished':'No stop recorded')+' · Snoozes: '+s.snoozes+(s.stopOrigin?' · '+s.stopOrigin:''));
      for(const e of s.events)lines.push('  '+new Date(Number(e.millis)).toLocaleTimeString()+' | '+e.msg);
      lines.push('');
    }
    return lines.join('\n');
  };
  // The old page's controls, timeline, selection and styling are reused as-is.
  syncSavedHistory();
})();
