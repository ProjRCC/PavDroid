/* PavDroid adapter to ORIGINAL Pavlok Control V3.0.3 interface.
   This file does not recreate the timer, alarm cards, steppers, keypad,
   sliders, dialogs, navigation, or History layout. */
'use strict';
(function(){
 if(!window.PavDroidNative)throw Error('PavDroid native alarm bridge is missing');
 const $pd=id=>document.getElementById(id);
 const native=window.PavDroidNative;
 // Original watch-alarm and Code Red controls remain available in the source
 // for reference but are NEVER displayed or executed in PavDroid.
 const old=$pd('alarmEditor').querySelector('.codeRedSection');old.style.display='none';
 const extras=document.createElement('div');extras.className='pavdroidExtra';
 extras.innerHTML=`<div class="pdOption"><label class="check"><input type="checkbox" id="pdSmartTimeout" checked>Smart Timeout</label><p class="smalltext">Stops after 1 hour without snooze; every snooze resets shutoff to 2 hours after that snooze. Uncheck for no automatic timeout.</p></div>
 <div class="pdOption"><label class="check"><input type="checkbox" id="pdMusic">Include Music</label><div id="pdMusicChooseRow" class="mp3Selection" hidden><button class="small ghost" type="button" id="pdChooseMp3">Select MP3</button><span class="smalltext" id="pdMp3Name">No file selected</span><div class="pdMusicDelay">Start after <button type="button" id="pdMusicMinus" class="ghost" aria-label="Reduce music delay">−</button><b id="pdMusicDelayText">15s</b><button type="button" id="pdMusicPlus" class="ghost" aria-label="Increase music delay">+</button></div></div><p class="smalltext">MP3 starts after each firing delay. Music stops and phone volume is restored on Snooze or Stop.</p></div>`;
 old.after(extras);
 const foot=document.createElement('div');foot.className='pdSnoozeBottom';
 foot.innerHTML=`<div class="alarmEditorFields"><label class="field">Snooze duration (minutes)<input id="pdSnoozeMinutes" type="number" inputmode="numeric" min="1" max="60" value="7"></label></div>`;
 const existingEnabled=$pd('editEnabled');existingEnabled.closest('label').hidden=true;
 existingEnabled.closest('label').after(foot);
 const editorText=$pd('alarmEditor').querySelector('.quiet');if(editorText)editorText.textContent='Schedules are saved on your phone. The watch receives direct stimuli only.';
 $pd('saveEditorBtn').textContent='Save alarm';
 $pd('deleteTitle').textContent='Delete alarm?';
 $pd('alarmSyncLabel').removeAttribute('title');$pd('alarmSyncLabel').removeAttribute('aria-label');
 $pd('alarmOpStatus').textContent='Alarms are stored on Android, independent of watch connection.';
 const exactNotice=document.createElement('p');exactNotice.className='quiet';exactNotice.id='pdExactNotice';
 exactNotice.innerHTML='Precise alarm scheduling is not authorized. <button type="button" class="small ghost" id="pdExactSettings">Allow Alarms & reminders</button>';
 $pd('alarmOpStatus').after(exactNotice);
 $pd('pdExactSettings').onclick=()=>AndroidUi.openExactAlarmSettings();
 const refreshExactAccess=()=>{exactNotice.hidden=native.exactAccess();};
 refreshExactAccess();document.addEventListener('visibilitychange',refreshExactAccess);
 window.addEventListener('focus',refreshExactAccess);
 $pd('alarmList').textContent='No alarms saved on Android.';
 $pd('emptyConfirmWrap').hidden=true;
 const settings=document.createElement('div');settings.className='pavdroidExtra';
 settings.innerHTML=`<div class="pdOption"><label class="check"><input id="pdTimerSmart" type="checkbox" checked>Smart Timeout</label><p class="smalltext">1 hour initially; resets to 2 hours after each snooze.</p></div>
 <div class="pdOption"><label class="check"><input id="pdTimerMusic" type="checkbox">Include Music</label><div id="pdTimerMusicRow" class="mp3Selection" hidden><button type="button" id="pdTimerChooseMp3" class="small ghost">Select MP3</button><span id="pdTimerMp3Name" class="smalltext">No file selected</span><div class="pdMusicDelay">Start after <button type="button" class="ghost" id="pdTimerMusicMinus" aria-label="Reduce timer music delay">−</button><b id="pdTimerMusicDelayText">15s</b><button type="button" class="ghost" id="pdTimerMusicPlus" aria-label="Increase timer music delay">+</button></div></div></div>
 <div class="alarmEditorFields"><label class="field">Snooze duration (minutes)<input id="pdTimerSnoozeMinutes" inputmode="numeric" type="number" min="1" max="60" value="7"></label></div>`;
 $pd('timerSetup').append(settings);
 const style=document.createElement('style');style.textContent=`.pavdroidExtra{padding:0;margin:13px 0}.pdOption{border:1px solid #364c65;border-radius:12px;padding:12px 13px;margin-bottom:10px;background:#172334}.pdOption p.smalltext{font-size:11px;line-height:1.45;margin:6px 0 0;color:#b1c2d6}.pdSnoozeBottom{margin-top:13px}.pdSnoozeBottom .alarmEditorFields{margin-top:0}.pdSnoozeBottom input{font-size:16px}#pdMusicChooseRow,#pdTimerMusicRow{margin-top:9px}.pavdroidExtra .check{min-height:22px}.pdMusicDelay{width:100%;display:flex;gap:10px;align-items:center;margin-top:9px;font-size:13px}.pdMusicDelay button{min-width:38px;min-height:38px;padding:5px;font-size:20px}.pdMusicDelay b{min-width:34px;text-align:center}`;document.head.append(style);
 let alarmMusicDelay=15;
 let timerMusicDelay=Number(readLocal('pavdroid-timer-music',{})?.delay??15);
 if(!Number.isFinite(timerMusicDelay))timerMusicDelay=15;
 const clampMusic=x=>Math.max(0,Math.min(120,Math.round(x)));
 const setAlarmDelay=v=>{$pd('pdMusicDelayText').textContent=(alarmMusicDelay=clampMusic(v))+'s';};
 const setTimerDelay=v=>{
  timerMusicDelay=clampMusic(v);$pd('pdTimerMusicDelayText').textContent=timerMusicDelay+'s';
  storeLocal('pavdroid-timer-music',{...readLocal('pavdroid-timer-music',{}),delay:timerMusicDelay});
 };
 $pd('pdMusicMinus').onclick=()=>setAlarmDelay(alarmMusicDelay-5);
 $pd('pdMusicPlus').onclick=()=>setAlarmDelay(alarmMusicDelay+5);
 $pd('pdTimerMusicMinus').onclick=()=>setTimerDelay(timerMusicDelay-5);
 $pd('pdTimerMusicPlus').onclick=()=>setTimerDelay(timerMusicDelay+5);
 setTimerDelay(timerMusicDelay);
 const musicToggle=(checked,row)=>{row.hidden=!checked;};
 $pd('pdMusic').addEventListener('change',()=>musicToggle($pd('pdMusic').checked,$pd('pdMusicChooseRow')));
 $pd('pdTimerMusic').addEventListener('change',()=>musicToggle($pd('pdTimerMusic').checked,$pd('pdTimerMusicRow')));
 $pd('pdChooseMp3').onclick=()=>{window.__pdMp3Destination='alarm';AndroidUi.pickMp3(app.mp3Uri||'');};
 $pd('pdTimerChooseMp3').onclick=()=>{window.__pdMp3Destination='timer';AndroidUi.pickMp3(readLocal('pavdroid-timer-music',{}).uri||'');};
 const oldMp3Handler=onMp3Picked;
 onMp3Picked=function(uri,label){oldMp3Handler(uri,label);
  if(window.__pdMp3Destination==='timer'){storeLocal('pavdroid-timer-music',{uri,label,delay:timerMusicDelay});$pd('pdTimerMp3Name').textContent=label;}
  else{$pd('pdMp3Name').textContent=label;}
 };
 const musicSaved=readLocal('pavdroid-timer-music',{});
 if(musicSaved.label)$pd('pdTimerMp3Name').textContent=musicSaved.label;
 // Alarm editor and scheduled card visuals are literally the V3.0.3 elements.
 const originalShowEditor=showEditor;
 showEditor=function(i=-1,copy=false,plus30=false){
  originalShowEditor(i,copy,plus30);
  const selected=i>=0?app.alarms?.[i]:null;
  $pd('pdSmartTimeout').checked=selected?.smartTimeout!==false;
  $pd('pdMusic').checked=!!selected?.music;
  $pd('pdMusicChooseRow').hidden=!$pd('pdMusic').checked;
  $pd('pdSnoozeMinutes').value=selected?.snoozeMinutes??7;
  setAlarmDelay(selected?.musicDelay??15);
  const remembered=readLocal(lastMp3Key,{})||{};
  app.mp3Uri=selected?.musicUri||remembered.uri||'';
  app.mp3Label=selected?.musicLabel||remembered.label||'';
  $pd('pdMp3Name').textContent=app.mp3Label||'No file selected';
 };
 alarmChangeIsUnsafe=function(){return native.snapshot()?.active===true;};
 const originalRefreshConnection=refreshConnection;
 refreshConnection=function(){originalRefreshConnection();const disabled=alarmChangeIsUnsafeIncludingTimer()||app.busy;
  $pd('newAlarmBtn').disabled=disabled;
  $pd('readAlarmsBtn').disabled=false;
  for(const b of document.querySelectorAll('[data-alarm-action]'))b.disabled=disabled;
  const s=native.snapshot(),active=!!s?.active;
  $pd('snoozeAlarmBtn').disabled=!active||s.phase!=='firing';
  $pd('stopAlarmBtn').disabled=!active;
  // Timer is phone-controlled, but direct watch output still requires BLE.
  $pd('timerStartBtn').disabled=app.busy||!isOn()||nativeTimerPhase()!=='ready'||active;
 };
 readAlarms=async function(skipListRender=false){
  app.alarms=native.list();app.alarmsTrusted=true;
  $pd('alarmSyncLabel').textContent=app.alarms.length+' on phone';
  $pd('emptyConfirmWrap').hidden=true;
  if(!skipListRender)renderAlarms();refreshConnection();return app.alarms;
 };
 writeAlarms=async function(next,reason,revealIndex=null){
  if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is currently in progress.');
  const saved=await native.save(next);
  app.alarms=saved;app.alarmsTrusted=true;
  renderAlarms(revealIndex);refreshConnection();
  $pd('alarmOpStatus').textContent=reason+(native.exactAccess()?' · saved on Android.':' · saved, but precise alarm permission is required.');
  refreshExactAccess();
  return true;
 };
 alarmAction=async function(i,act){
  if(blockAlarmChangeWhileActive())return;
  if(act==='edit')return showEditor(i);
  if(act==='copy'||act==='copy30')return showEditor(i,true,act==='copy30');
  const next=app.alarms.map(a=>({...a}));if(!next[i])return;
  if(act==='toggle')next[i].enabled=!next[i].enabled;
  else if(act==='delete'){
   if(!await askConfirmation('Delete '+next[i].name+' · '+humanTime(next[i].time)+' from Android?'))return;
   next.splice(i,1);
  }
  try{await writeAlarms(next,act==='delete'?'Alarm deleted':'Alarm updated');}
  catch(e){showWarning(e.message);}
 };
 saveEditor=async function(){
  if(blockAlarmChangeWhileActive())return;
  try{
   const a=editData();
   a.smartTimeout=$pd('pdSmartTimeout').checked;
   a.music=$pd('pdMusic').checked;
   a.musicUri=app.mp3Uri||'';a.musicLabel=app.mp3Label||'';
   a.snoozeMinutes=Number($pd('pdSnoozeMinutes').value);
   a.musicDelay=alarmMusicDelay;
   if(!Number.isInteger(a.snoozeMinutes)||a.snoozeMinutes<1||a.snoozeMinutes>60)throw Error('Snooze duration must be 1–60 minutes.');
   if(a.music&&!a.musicUri)throw Error('Choose an MP3 before enabling music.');
   const next=app.alarms.map(x=>({...x}));
   if(app.editorIndex>=0){if(!next[app.editorIndex])throw Error('Alarm list changed');next[app.editorIndex]=a;}
   else {a.enabled=true;next.push(a);}
   await writeAlarms(next,'Alarm saved',app.editorIndex<0?next.length-1:null);
   $pd('alarmEditor').close();
  }catch(e){showWarning(e.message);}
 };
 // Replace only the button handlers which formerly sent firmware packets.
 $pd('saveEditorBtn').onclick=()=>saveEditor();
 $pd('newAlarmBtn').onclick=()=>showEditor();
 $pd('readAlarmsBtn').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();readAlarms();}};
 $pd('confirmEmptyBtn').onclick=()=>{};
 $pd('snoozeAlarmBtn').onclick=async()=>{try{await native.action('snooze');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 $pd('stopAlarmBtn').onclick=async()=>{try{await native.action('stop');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 alarmButton=async(which)=>{try{await native.action(which);refreshAlarmSession();}catch(e){showWarning(e.message);}};
 // Preserve V3.0.3 duration keypad, preset row, count +/- controls, slider,
 // countdown face and all timer status/snooze/stop buttons. Only routing changes.
 timerCommand=async function(action){
  try{
   if(action==='start'){
    if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is already in progress.');
    const cfg={seconds:duration(),buzz:count('timerBuzzCount',5),beep:count('timerBeepCount',5),
      zaps:count('timerZapCount',5),intensity:Number($pd('timerZapMax').value),
      interval:pref.timerInterval,snoozeSeconds:withinUi($pd('pdTimerSnoozeMinutes').value,1,60)*60,
      musicDelay:timerMusicDelay,
      smartTimeout:$pd('pdTimerSmart').checked,music:$pd('pdTimerMusic').checked,
      musicUri:readLocal('pavdroid-timer-music',{}).uri||''};
    if(cfg.buzz+cfg.beep+cfg.zaps===0)throw Error('Select at least one stimulus.');
    if(cfg.music&&!cfg.musicUri)throw Error('Select a timer MP3 first.');
    await nativeTimerAction('start',cfg);
    if($pd('timerConfirmBuzz').checked&&isOn())try{await immediate({type:'buzz'},30);}catch(_){}
   }else if(action==='snooze')await nativeTimerAction('snooze');
   else await nativeTimerAction(action);
   syncNativeTimer(false);refreshConnection();
  }catch(e){message('timerWriteStatus',e.message,true);}
 };
 function withinUi(value,lo,hi){const n=Number(value);if(!Number.isInteger(n)||n<lo||n>hi)throw Error('Choose a value between '+lo+' and '+hi);return n;}
 $pd('timerStartBtn').onclick=()=>{dismissSoftKeyboard($pd('duration'));void timerCommand('start');};
 $pd('timerSnoozeBtn').onclick=()=>timerCommand('snooze');
 $pd('timerPauseBtn').onclick=()=>timerCommand('pause');
 $pd('timerResumeBtn').onclick=()=>timerCommand('resume');
 $pd('timerStopBtn').onclick=()=>timerCommand('reset');
 // Watch-reported firmware timer/status notifications cannot alter PavDroid UI.
 onAlarmNotify=function(){};
 onTimerConfig=function(){};
 function refreshAlarmSession(){
  const s=native.snapshot();if(!s?.active){app.activeAlarm=null;app.snoozeUntil=null;
    alarmState('STATUS UNKNOWN','No Android alarm currently active','unknown');refreshConnection();return;}
  app.activeAlarm={id:s.id+1,firing:s.phase==='firing'};
  app.snoozes=s.snoozes||0;app.snoozeUntil=s.snoozeUntil||null;
  $pd('snoozeCount').textContent=String(s.snoozes||0);
  $pd('snoozeRemaining').textContent=s.snoozeUntil&&s.phase==='snoozing'?fmt((s.snoozeUntil-Date.now())/1000):'—';
  alarmState(s.phase==='firing'?'ALARM FIRING':'SNOOZING',s.name,s.phase==='firing'?'active-state':'snooze-state');
  $pd('activeName').textContent=s.name||'Active alarm';refreshConnection();
 }
 const originalDrop=onDrop;
 onDrop=function(){originalDrop();setPavDroidBattery(null);};
 const baseTab=tab;
 tab=function(name){baseTab(name);if(name==='alarms')readAlarms();};
 readAlarms();refreshAlarmSession();
 setInterval(refreshAlarmSession,1000);
 // The connection page is unchanged in layout, but its labels are accurate.
 $pd('connectionHealth').textContent='Android schedules the alarms; BLE sends direct stimuli only.';
})();
