/* PavDroid adapter to ORIGINAL Pavlok Control V3.0.3 interface.
   This file does not recreate the timer, alarm cards, steppers, keypad,
   sliders, dialogs, navigation, or History layout. */
'use strict';
(function(){
 if(!window.PavDroidNative)throw Error('PavDroid native alarm bridge is missing');
 const $pd=id=>document.getElementById(id);
 const native=window.PavDroidNative;
 // Original watch-alarm and Code Red controls remain available in the source
 // for reference but are NEVER displayed or executed in PavDroid.
 const old=$pd('alarmEditor').querySelector('.codeRedSection');old.style.display='none';
 const defaultKey='pavdroid-defaults-v104';
 const defaultValues={alarm:{buzz:5,beep:5,zaps:1,interval:8,intensity:40,snooze:7,smart:true,safeMax:false,musicStartVolume:20,musicRisePercent:15,musicRiseSeconds:5,musicPreferredRisePercent:15,musicAfterSnoozes:0,zapsAfterSnoozes:1},
                      timer:{buzz:3,beep:3,zaps:1,interval:6,intensity:40,snooze:1,smart:true,safeMax:false,
                             musicStartVolume:20,musicRisePercent:15,musicRiseSeconds:5,musicPreferredRisePercent:15,musicAfterSnoozes:0,zapsAfterSnoozes:1}};
 const settingDefaults=Object.assign({},defaultValues,readLocal(defaultKey,{}));
 for(const type of ['alarm','timer'])settingDefaults[type]={...defaultValues[type],...(settingDefaults[type]||{})};
 const within=(x,min,max)=>Math.max(min,Math.min(max,Math.round(Number(x)||0)));
 // One second longer than the larger Buzz/Beep group, never below 3s.
 const minimumStimulusSeconds=(buzz,beep)=>Math.max(3,Math.max(Number(buzz)||0,Number(beep)||0)+1);
 for(const type of ['alarm','timer']){
  const d=settingDefaults[type];d.musicStartVolume=within(d.musicStartVolume,10,100);
  // V1.0.8 at 100% stored a forced +0. Retain the user's preferred +20
  // separately so lowering Start makes the increase available again.
  d.musicPreferredRisePercent=within(d.musicPreferredRisePercent??d.musicPreferredStepVolume??20,0,50);
  d.musicRisePercent=Math.min(d.musicPreferredRisePercent,50,100-d.musicStartVolume);
  d.interval=within(d.interval??8,minimumStimulusSeconds(d.buzz,d.beep),30);
  d.musicRiseSeconds=within(d.musicRiseSeconds??15,3,120);
  d.zapsAfterSnoozes=within(d.zapsAfterSnoozes??0,0,99);
  d.musicAfterSnoozes=within(d.musicAfterSnoozes??0,0,99);
 }
 const libraryKey='pavdroid-music-library-v104';
 let library=readLocal(libraryKey,{tracks:[],selectedUri:''})||{tracks:[],selectedUri:''};
 if(!Array.isArray(library.tracks))library.tracks=[];
 // One-time migration of the last selected MP3 and timer MP3; no files are moved.
 if(!library.tracks.length){
  for(const item of [readLocal(lastMp3Key,{}),readLocal('pavdroid-timer-music',{})]){
   if(item?.uri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===item.uri))
    library.tracks.push({uri:item.uri,label:item.label||'Selected MP3'});
  }
  if(!library.selectedUri)library.selectedUri=library.tracks[0]?.uri||'';
 }
 const selectedSong=()=>library.tracks.find(t=>t.uri===library.selectedUri);
 const librarySave=()=>{
  try{AndroidUi.stopMusicPreview();previewActive=false;}catch(_){ }
  storeLocal(libraryKey,library);
  try{AndroidUi.setSelectedMusicUri(library.selectedUri||'');}catch(e){console.warn('Music sync:',e)}
  refreshMusicLabels();renderLibrary();
 };
 const extras=document.createElement('div');extras.className='pavdroidExtra';
 extras.innerHTML=`<div class="pdOption"><label class="check"><input type="checkbox" id="pdSmartTimeout" checked>Smart Timeout</label></div>
  <div class="pdOption pdMusicCard" id="pdAlarmMusicCard"><div class="pdMusicHead"><label class="check"><input type="checkbox" id="pdMusic">Include Music</label><button type="button" class="pdMusicFold" id="pdAlarmMusicFold" aria-label="Expand music options" aria-expanded="false">+</button></div>
   <p class="smalltext pdMusicSummary" id="pdAlarmMusicSummary" hidden></p>
   <div id="pdMusicChooseRow" hidden><p class="smalltext" id="pdMp3Name">Choose a song in Settings</p>
    <div id="pdMusicAfterRow" class="pdMiniStepper"><span>Music starts</span><div class="pdStepBox"><button type="button" id="pdMusicMinus" aria-label="Earlier music launch">−</button><output id="pdMusicDelayText">1st Launch</output><button type="button" id="pdMusicPlus" aria-label="Later music launch">+</button></div></div>
    <div class="pdDefaultRow pdMusicVolumeRow"><div><label class="field">Start volume</label><div id="pdStartVolume"></div></div><div><label class="field">Increase by</label><div id="pdStepVolume"></div></div></div>
    <div class="pdMiniStepper pdMusicRiseEvery"><span>Increase every</span><div id="pdRiseEvery"></div></div>
    <p class="smalltext">Music starts 10s into each eligible launch. Stops on Snooze or Stop.</p></div></div>`;
 old.after(extras);
 // Smart Timeout belongs AFTER Preview as the final editor setting.
 const alarmSmart=extras.querySelector('#pdSmartTimeout').closest('.pdOption');
 const foot=document.createElement('div');foot.className='pdSnoozeBottom';
 foot.innerHTML=`<div class="pdMiniStepper"><span>Snooze time</span><div id="pdAlarmSnoozeStep"></div><input id="pdSnoozeMinutes" type="hidden" value="7"></div><p class="pdSnoozeHint">Tap middle button to snooze, hold to stop</p>`;
 const existingEnabled=$pd('editEnabled');existingEnabled.closest('label').hidden=true;
 existingEnabled.closest('label').after(foot);
 foot.after(alarmSmart);
 // Put Snooze and Music immediately below Name / Time, before the stimulus editor.
 // Moving existing nodes retains all original event listeners and stored settings.
 const alarmFields=$pd('editName').closest('.alarmEditorFields');
 const alarmMusic=$pd('pdAlarmMusicCard');
 alarmFields.after(foot,alarmMusic);
 extras.remove(); // all active controls were moved from this now-empty wrapper
 // Preview comes immediately before Smart Timeout in both editors.
 const alarmPreview=$pd('editSeqPreview').closest('.calc');
 alarmPreview.classList.add('pdBottomPreview');
 alarmPreview.after(alarmSmart);
 function addSmartInfo(option,kind){
  option.classList.add('pdSmartOption');
  const label=option.querySelector('label.check');
  const info=document.createElement('button');info.type='button';info.className='pdInfoBtn';
  info.setAttribute('aria-label','About '+kind+' Smart Timeout');info.setAttribute('aria-expanded','false');info.textContent='i';
  const help=document.createElement('p');help.className='pdSmartHelp';help.hidden=true;
  help.textContent='When on: stops after 1 hour without a snooze. Each snooze resets the cutoff to 2 hours after that snooze. Never stops mid-snooze.';
  label.after(info,help);info.onclick=()=>{help.hidden=!help.hidden;info.setAttribute('aria-expanded',String(!help.hidden));};
 }
 addSmartInfo(alarmSmart,'alarm');
 const editorText=$pd('alarmEditor').querySelector('.quiet');if(editorText)editorText.textContent='';
 $pd('saveEditorBtn').textContent='Save alarm';
 const editorTopSave=document.createElement('button');editorTopSave.type='button';
 editorTopSave.id='pdSaveEditorTop';editorTopSave.className='primary pdTopSaveBtn';editorTopSave.textContent='Save alarm';
 const editorHeaderActions=document.createElement('div');editorHeaderActions.className='pdEditorTopActions';
 const editorClose=$pd('closeEditorBtn');editorClose.replaceWith(editorHeaderActions);
 editorHeaderActions.append(editorTopSave,editorClose);
 // PavDroid directly ramps zap power from 10% to its chosen maximum.
 // The inherited firmware Full/Escalate picker is not applicable here.
 const escalateSelect=$pd('editEscalate');
 escalateSelect.value='1';escalateSelect.closest('label').hidden=true;
 const updateSegment=()=>{escalateSelect.value='1';};
 const alarmZapOptions=document.createElement('div');alarmZapOptions.className='pdZapDelay';
 alarmZapOptions.innerHTML='<div class="pdMiniStepper"><span>Zaps start</span><div class="pdStepBox"><button type="button" id="pdAlarmZapMinus">−</button><output id="pdAlarmZapAfterText">1st Launch</output><button type="button" id="pdAlarmZapPlus">+</button></div></div><p class="smalltext">10% first zap · +10% per zap, up to the maximum above.</p>';
 escalateSelect.closest('label').after(alarmZapOptions);
 const makeSafeMax=(kind)=>{
  const div=document.createElement('div');div.className='pdSafeMaxOption';
  div.innerHTML='<label class="check"><input type="checkbox" id="pd'+kind+'SafeMax"> Safe Max (50%)</label><button type="button" class="pdInfoBtn pdSafeMaxInfo" aria-label="Safe Max explanation">i</button><p class="pdSmartHelp" hidden>After the selected peak (60% or higher), later zaps are limited to 50%. The initial peak stays unchanged. This limit is not a medical safety guarantee. Use Smart Timeout for extended sessions.</p>';
  const info=div.querySelector('button');const desc=div.querySelector('p');
  info.onclick=()=>{desc.hidden=!desc.hidden;};return div;
 };
 const alarmSafeMax=makeSafeMax('Alarm'),timerSafeMax=makeSafeMax('Timer');
 // The hidden original slider hint still anchors the next control, but takes no space.
 $pd('editZapMaxHoldHint').after(alarmSafeMax,alarmZapOptions);
 const timerZapOptions=document.createElement('div');timerZapOptions.className='pdZapDelay';
 timerZapOptions.innerHTML='<div class="pdMiniStepper"><span>Zaps start</span><div class="pdStepBox"><button type="button" id="pdTimerZapMinus">−</button><output id="pdTimerZapAfterText">1st Launch</output><button type="button" id="pdTimerZapPlus">+</button></div></div><p class="smalltext">10% first zap · +10% per zap, up to the maximum above.</p>';
 $pd('timerZapMax').after(timerZapOptions);
 $pd('timerZapMaxHoldHint').after(timerSafeMax,timerZapOptions);
 $pd('deleteTitle').textContent='Delete alarm?';
 $pd('alarmSyncLabel').removeAttribute('title');$pd('alarmSyncLabel').removeAttribute('aria-label');
 $pd('alarmOpStatus').textContent='';
 const exactNotice=document.createElement('p');exactNotice.className='quiet';exactNotice.id='pdExactNotice';
 exactNotice.innerHTML='Precise alarms permission needed. <button type="button" class="small ghost" id="pdExactSettings">Allow</button>';
 $pd('alarmOpStatus').after(exactNotice);
 $pd('pdExactSettings').onclick=()=>AndroidUi.openExactAlarmSettings();
 const refreshExactAccess=()=>{exactNotice.hidden=native.exactAccess();};
 refreshExactAccess();document.addEventListener('visibilitychange',refreshExactAccess);
 window.addEventListener('focus',refreshExactAccess);
 $pd('alarmList').textContent='No alarms saved.';$pd('emptyConfirmWrap').hidden=true;
 const settings=document.createElement('div');settings.className='pavdroidExtra';
 settings.innerHTML=`<div class="pdOption"><label class="check"><input id="pdTimerSmart" type="checkbox" checked>Smart Timeout</label></div>
  <div class="pdOption pdMusicCard" id="pdTimerMusicCard"><div class="pdMusicHead"><label class="check"><input id="pdTimerMusic" type="checkbox">Include Music</label><button type="button" class="pdMusicFold" id="pdTimerMusicFold" aria-label="Expand music options" aria-expanded="false">+</button></div>
   <p class="smalltext pdMusicSummary" id="pdTimerMusicSummary" hidden></p>
   <div id="pdTimerMusicRow" hidden><p id="pdTimerMp3Name" class="smalltext">Choose a song in Settings</p>
    <div class="pdMiniStepper"><span>Music starts</span><div class="pdStepBox"><button type="button" id="pdTimerMusicMinus" aria-label="Earlier music launch">−</button><output id="pdTimerMusicDelayText">1st Launch</output><button type="button" id="pdTimerMusicPlus" aria-label="Later music launch">+</button></div></div>
    <div class="pdDefaultRow pdMusicVolumeRow"><div><label class="field">Start volume</label><div id="pdTimerStartVolume"></div></div><div><label class="field">Increase by</label><div id="pdTimerStepVolume"></div></div></div>
    <div class="pdMiniStepper pdMusicRiseEvery"><span>Increase every</span><div id="pdTimerRiseEvery"></div></div>
    <p class="smalltext">Music starts 10s into each eligible launch. Stops on Snooze or Stop.</p></div></div>
  <div class="pdSnoozeBottom"><div class="pdMiniStepper"><span>Snooze time</span><div id="pdTimerSnoozeStep"></div><input id="pdTimerSnoozeMinutes" type="hidden" value="7"></div><p class="pdSnoozeHint">Tap middle button to snooze, hold to stop</p></div>`;
  $pd('timerSetup').append(settings);
 // Timer follows the exact same configuration order as Alarm.
 const timerPresets=$pd('timerSetup').querySelector('.presetgrid');
 const timerSnoozeRow=settings.querySelector('.pdSnoozeBottom');
 const timerMusic=$pd('pdTimerMusicCard');
 timerPresets.after(timerSnoozeRow,timerMusic);
 // The hold-to-adjust slider wraps the native range input in a flex container.
 // In V1.0.10, Zaps after was accidentally inserted INSIDE that flex wrapper,
 // shrinking the slider. Place it after the slider's hint, full-width.
 const timerZapHint=$pd('timerZapMaxHoldHint');
 timerZapHint.after(timerZapOptions);
 const confirmBuzzOption=$pd('timerConfirmBuzz').closest('label');
 confirmBuzzOption.remove();
 const timerSmart=$pd('pdTimerSmart').closest('.pdOption');
 $pd('timerSetup').append(timerSmart);addSmartInfo(timerSmart,'timer');
 const timerPreview=$pd('timerSequencePreview').closest('.calc');
 timerPreview.classList.add('pdBottomPreview');
 timerPreview.after(timerSmart);
 settings.remove(); // no active controls remain in this temporary wrapper
 const style=document.createElement('style');style.textContent=`.pavdroidExtra{padding:0;margin:13px 0}.pdOption{border:1px solid #364c65;border-radius:12px;padding:12px 13px;margin-bottom:10px;background:#172334}.pdOption p.smalltext{font-size:11px;margin:7px 0 0;color:#b1c2d6}.pdSnoozeBottom{margin-top:13px}.pavdroidExtra .check{min-height:22px}.pdOption .pdDefaultRow{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .pdSafeMaxOption{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;margin:7px 0 10px;min-height:27px}.pdSafeMaxOption[hidden]{display:none!important}.pdSafeMaxOption .pdSmartHelp{flex:0 0 100%;margin:0!important}.pdSafeMaxInfo{width:24px;height:24px;min-height:24px!important;min-width:24px}.pdExtremeIntensity .pdStepBox{background:#a92331!important;border:2px solid white!important;color:white!important}.pdExtremeIntensity .pdStepBox button,.pdExtremeIntensity .pdStepBox output{color:white!important}.pdExtremeIntensity .pdStepBox button:disabled{opacity:.6}.pdSafeMaxOption label.check{margin:0}.pdIntensityRange{appearance:none;-webkit-appearance:none;height:5px;border-radius:99px;outline:0;min-height:5px;cursor:pointer}
 input[type=range].pdIntensityRange::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:22px;height:22px;border-radius:50%;border:2px solid var(--pd-thumb-ring,#cbdcf1);background:var(--pd-intensity,#e9b959);box-shadow:0 0 0 var(--pd-thumb-outline,1px) rgba(255,255,255,.8)}
 input[type=range].pdIntensityRange::-moz-range-thumb{width:20px;height:20px;border:2px solid var(--pd-thumb-ring,#cbdcf1);border-radius:50%;background:var(--pd-intensity,#e9b959)}
 .pdMusicCard{min-width:0}
 .pdMusicHead{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:28px}
 .pdMusicHead label.check{min-width:0;flex:1}
 .pdMusicFold{width:32px;min-width:32px!important;height:32px;min-height:32px!important;padding:0!important;border-radius:9px!important;border:1px solid #5b7695;background:#243a54;color:#e7f2ff;font-size:20px!important;font-weight:550;line-height:1}
 .pdMusicFold:active{background:#41668f;transform:scale(.96)}
 .pdMusicFold:disabled{opacity:.36}
 .pdMusicSummary{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:4px 0 0!important}
 .pdMusicVolumeRow{margin-top:16px;margin-bottom:7px;align-items:end}
 .pdMusicRiseEvery{margin-top:12px}
 .pdZapDelay{margin:12px 0 18px}
 .pdZapDelay p.smalltext{margin:5px 0 0;font-size:11px;color:#b1c2d6}
 .pdDefaultsGroup{border:1px solid #34475e;border-radius:11px;background:#111f30;padding:11px 10px;margin:12px 0}
 .pdDefaultsGroup h4{margin:0 0 10px;font-size:13px;font-weight:700;color:#dceafd}
 .pdAndroidLinks{gap:8px;display:flex;flex-wrap:wrap}
 .pdAndroidLinks button{flex:1;min-width:125px}
 .pdMusicVolumeRow label.field{display:block;margin:0 0 8px;font-size:12px;font-weight:650}
 .pdSmartOption{display:grid;grid-template-columns:minmax(0,1fr) 30px;align-items:center;gap:8px}
 .pdInfoBtn{width:29px;height:29px;min-height:29px!important;min-width:29px;padding:0!important;border-radius:100%;border:1px solid #5b7695;background:#263c57;color:#d3e5fd;font-size:15px;font-style:italic;font-weight:700}
 .pdSmartHelp{grid-column:1/-1;margin:3px 0 0!important;color:#b1c2d6;font-size:12px;line-height:1.45}
 .pdSmartHelp[hidden]{display:none}
 .pdTestZapBtn{margin-top:12px;width:100%}
 .pdZapBehavior{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:9px}
 .pdZapBehavior button{min-height:40px;border-radius:10px;border:1px solid #4f6884;background:#1c2b3f;color:#d4e3f6}
 .pdZapBehavior button.selected{background:#3c6594;border-color:#8fb8fc;color:#fff;font-weight:700}
 .pdSnoozeBottom{margin:20px 0 20px!important;min-height:44px}
 .pdSmartOption{margin:0 0 14px!important}
 .pdBottomPreview{margin:18px 0 10px!important}
 /* Editors: same order and consistent gaps, with max Zap slider on its own full-width row. */
 #alarmEditor .pdSnoozeBottom{margin:18px 0 14px!important}
 #timerSetup .pdSnoozeBottom{margin:16px 0 14px!important}
 #alarmEditor .pdMusicCard,#timerSetup .pdMusicCard{margin:0 0 19px!important}
 #alarmEditor .holdZapSlider,#timerSetup .holdZapSlider{display:flex!important;width:100%!important;max-width:100%!important;box-sizing:border-box;clear:both}
 #alarmEditor .holdZapSlider input[type=range],#timerSetup .holdZapSlider input[type=range]{width:100%!important;min-width:0;flex:1}
 #alarmEditor .pdZapDelay,#timerSetup .pdZapDelay{width:100%;box-sizing:border-box;clear:both;margin:17px 0 20px!important}
 #alarmEditor .pdSmartOption,#timerSetup .pdSmartOption{margin:20px 0 16px!important}
 /* Compact raised ordinal suffix; stepper dimensions and hit targets unchanged. */
 .pdLaunchOrdinal{display:flex;flex-direction:column;justify-content:center;align-items:center;gap:0;white-space:nowrap;font-weight:650;line-height:1.04}
 .pdLaunchNumber{font-size:13px;line-height:1.08}
 .pdLaunchOrdinal sup{font-size:.62em;vertical-align:super;line-height:0;margin-right:1px}
 .pdLaunchWord{font-size:11px;line-height:1.12}
 .pdDefaultTitle{font-size:18px!important;font-weight:780!important;margin:19px 0 12px!important}
 .pdZapEscalationInfo{font-size:12px;color:#bfd0e5;line-height:1.45;align-self:center;min-width:0;padding:4px 0}
 .pdZapEscalationInfo strong{display:block;font-weight:750;color:#e6effe;margin:0 0 5px}
 .pdZapEscalationInfo span{display:block}
 /* Snooze label and value stay together rather than stretching to both sides. */
 #alarmEditor .pdSnoozeBottom .pdMiniStepper,#timerSetup .pdSnoozeBottom .pdMiniStepper{justify-content:flex-start!important;gap:14px!important}
 #alarmEditor .pdSnoozeBottom .pdMiniStepper>span,#timerSetup .pdSnoozeBottom .pdMiniStepper>span{flex:0 0 auto!important;white-space:nowrap}
 .pdSnoozeHint{font-size:12px;color:#b7c9df;line-height:1.4;margin:5px 0 0}
 .pdSnoozeBottom>.pdMiniStepper{margin:0}
 #alarmEditor .pdSnoozeBottom .pdStepBox,#timerSetup .pdSnoozeBottom .pdStepBox{width:157px!important;flex:0 0 157px!important}
 /* Settings headings: page > section > new alarm/timer > subsection > field. */
 .pdSettingsDialog .dialogheader h2{font-size:22px!important}
 .pdSettingsDialog section .pdFoldHead.pdFoldMain h3{font-size:19px!important;font-weight:780!important;margin:0!important}
 .pdSettingsDialog .pdFoldHead.pdFoldType h3{font-size:16px!important;font-weight:750!important;margin:0!important}
 .pdSettingsDialog .pdFoldHead.pdFoldGroup h4{font-size:14px!important;font-weight:720!important;margin:0!important}
 .pdFoldHead{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:32px}
 .pdFoldHead>h3,.pdFoldHead>h4{min-width:0;flex:1;line-height:1.3}
 .pdSettingsMainIcon{display:inline-flex;align-items:center;justify-content:center;width:21px;height:21px;margin-right:9px;vertical-align:-3px;color:#a9c8eb}
 .pdSettingsMainIcon svg{width:20px;height:20px;display:block}
 .pdFoldButton{display:grid;place-items:center;flex:0 0 31px;width:31px;min-width:31px!important;height:31px;min-height:31px!important;padding:0!important;border:1px solid #58718f!important;border-radius:9px!important;background:#253b56!important;color:#e2eeff;font-size:19px!important;font-weight:700;line-height:1}
 .pdFoldButton:active{background:#43658a!important}
 .pdFoldBody[hidden]{display:none!important}
 .pdFoldMain+.pdFoldBody{margin-top:12px}
 .pdFoldType+.pdFoldBody{margin-top:9px}
 .pdFoldGroup+.pdFoldBody{margin-top:10px}
 .pdDefaultBlock{margin:15px 0 10px}
 .pdDefaultsGroup{margin:10px 0 12px}
 .pdDefaultsGroup .pdDefaultSmart{display:flex;align-items:center;margin:15px 0 1px;min-height:26px}
 .pdTimerReset{appearance:none;cursor:pointer;background:#29415e;color:#e2edfe;border:1px solid #6481a4;font-size:11px;font-weight:750;padding:8px 11px;border-radius:28px;white-space:nowrap;min-height:34px}
 .pdTimerReset[hidden],#timerBadge[hidden]{display:none!important}
 #timer .timerHeading{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:start;gap:8px}
 #timer .timerHeading>div:first-child{min-width:0}
 #timer .timerHeading .watchButtonHint{max-width:none}
 @media(max-width:360px){#alarmEditor .pdSnoozeBottom .pdStepBox,#timerSetup .pdSnoozeBottom .pdStepBox{width:145px!important;flex-basis:145px!important}}
 .pdEditorTopActions{display:flex;align-items:center;gap:8px;flex-shrink:0}
 #alarmEditor .dialogheader h2{min-width:0;flex:1}
 #alarmEditor .pdTopSaveBtn{white-space:nowrap;font-size:12px;padding:9px 12px;min-height:38px;border-radius:10px}
 @media(max-width:380px){#alarmEditor .dialogheader{padding:12px 13px;gap:7px}#alarmEditor .pdEditorTopActions{gap:5px}#alarmEditor .pdTopSaveBtn{font-size:11px;padding:8px 9px}}
 /* Zoom and font-size responsive editor controls: wrap complete steppers, never their +/- halves. */
 .pdStepBox{min-width:0}
 .pdStepBox output{white-space:normal}
 .pdDefaultsGrid{grid-template-columns:repeat(auto-fit,minmax(min(100%,132px),1fr));align-items:stretch}
 .pdDefaultsField{min-width:0}
 .pdDefaultsField .pdStepBox{min-height:42px}
 .pdDefaultsField .pdStepBox button{min-height:40px!important}
 .pdDefaultsField .pdStepBox output{min-width:0}
 .pdDefaultsGroup .pdZapEscalationInfo{overflow-wrap:anywhere}
 .pdMusicVolumeRow{grid-template-columns:repeat(auto-fit,minmax(min(100%,120px),1fr))}
 .pdSettingsDialog section{min-width:0}
 .pdMiniStepper>span{overflow-wrap:break-word}
 @media(max-width:390px){
  .pdSettingsDialog section{padding:11px}
  .pdDefaultsGroup{padding:10px 8px}
  .pdDefaultsGroup .pdZapEscalationInfo{grid-column:1/-1}
  #alarmEditor .pdMusicVolumeRow,#timerSetup .pdMusicVolumeRow{grid-template-columns:repeat(auto-fit,minmax(min(100%,115px),1fr))}
 }
 @media(max-width:300px){
  .pdMiniStepper{flex-wrap:wrap;align-items:center}
  .pdMiniStepper>span,#alarmEditor .pdSnoozeBottom .pdMiniStepper>span,#timerSetup .pdSnoozeBottom .pdMiniStepper>span{flex:1 0 100%!important;white-space:normal!important}
  .pdMiniStepper>.pdStepBox,.pdSettingsDialog .pdMiniStepper>.pdStepBox{flex:1 1 100%;width:100%;max-width:100%}
  .pdDefaultsGrid{grid-template-columns:1fr}
  #alarmEditor .pdSnoozeBottom .pdMiniStepper,#timerSetup .pdSnoozeBottom .pdMiniStepper{flex-wrap:wrap}
  #alarmEditor .pdSnoozeBottom .pdStepBox,#timerSetup .pdSnoozeBottom .pdStepBox{flex:1 1 100%!important;width:100%!important;max-width:100%}
 }
 /* Oversized font accessibility: grow vertically, never collide horizontally. */
 /* V1.0.18: 3+1 adaptive day presets. Only use one row when all labels fit. */
 .dayPresets{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:7px!important;align-items:stretch!important}
 .dayPresets button{min-width:0!important;width:100%!important;max-width:none!important;font-size:inherit!important;white-space:normal!important;overflow-wrap:normal;padding:9px 4px!important;min-height:42px}
 .dayPresets button[data-days="127"]{grid-column:1/-1;min-height:30px!important;padding:5px 6px!important}
 .dayPresets.pdDayPresetsWide{grid-template-columns:repeat(4,minmax(0,1fr))!important}
 .dayPresets.pdDayPresetsWide button[data-days="127"]{grid-column:auto;min-height:42px!important;padding:9px 4px!important}
 .dayPresetsDivider{display:none!important}
 #alarmEditor .dialogheader{display:flex;flex-wrap:wrap!important;gap:8px}
 #alarmEditor .dialogheader h2{flex:1 1 145px!important;overflow-wrap:anywhere}
 #alarmEditor .pdEditorTopActions{flex:0 1 auto;flex-wrap:wrap;justify-content:end}
 .pdSettingsDialog .pdStepBox,.pdMusicCard .pdStepBox{min-height:44px}
 .pdSettingsDialog .pdStepBox button,.pdMusicCard .pdStepBox button{min-height:42px!important}
 .pdSettingsDialog .pdDefaultsField{min-width:0}
 /* Keep a 3+1 row balanced, and allow 2+2 / 1+1 at larger fonts. */
 .presetgrid,.alarmbuttons{display:flex!important;flex-wrap:wrap!important;justify-content:center!important;align-items:stretch;gap:7px}
 .presetgrid button,.alarmbuttons button{flex:1 1 72px!important;min-width:min(100%,72px)!important;max-width:94px;white-space:normal!important;overflow-wrap:break-word;min-height:44px}
 /* Timer durations always display in 3 columns, 2 equal-height rows. */
 #timerSetup .presetgrid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:7px!important}
 #timerSetup .presetgrid button{min-width:0!important;width:100%!important;max-width:none!important;min-height:44px;flex:none!important;white-space:nowrap!important}
 header{flex-wrap:wrap!important;gap:8px}
 .headerMain{flex:1 1 145px;min-width:min(100%,145px)!important}
 .headerMain h1{overflow-wrap:anywhere}
 .pdHeaderRight{flex:0 0 auto;margin-left:auto}
 .tabs button{white-space:normal!important;overflow-wrap:break-word;min-height:45px}
`;document.head.append(style);
 // Use actual rendered text widths to avoid squeezing four day presets on
 // smaller screens or when Android text size / display zoom is increased.
 const dayPresetGroup=$pd('alarmEditor').querySelector('.dayPresets');
 const updateDayPresetLayout=()=>{
  if(!dayPresetGroup)return;
  const width=dayPresetGroup.clientWidth;
  if(width<=0)return;
  const buttons=[...dayPresetGroup.querySelectorAll('button[data-days]')];
  const context=document.createElement('canvas').getContext('2d');
  const cellWidths=buttons.map(button=>{
   const css=getComputedStyle(button);
   context.font=css.font;
   return context.measureText(button.textContent.trim()).width + 24;
  });
  const widest=Math.max(...cellWidths);
  dayPresetGroup.classList.toggle('pdDayPresetsWide',width>=4*widest+3*7);
 };
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(updateDayPresetLayout).observe(dayPresetGroup);
 window.addEventListener('resize',updateDayPresetLayout);
 document.fonts?.ready?.then(updateDayPresetLayout);
 requestAnimationFrame(updateDayPresetLayout);
 // One control for every new numeric setting: minus, value WITH unit, plus.
 const makeStepper=(holder,min,max,step,initial,format,onChange)=>{
  let lowerBound=min,upperBound=max;
  const allowsThreeSecondOption=min===3&&step===5;
  const normalize=requested=>{
   const raw=Number(requested);
   const numeric=Number.isFinite(raw)?raw:min;
   const rounded=allowsThreeSecondOption?(numeric<=3?3:Math.max(5,Math.round(numeric/5)*5)):
    Math.round(numeric/step)*step;
   return Math.max(lowerBound,Math.min(upperBound,rounded));
  };
  let value=normalize(initial);
  const box=document.createElement('div');box.className='pdStepBox';
  const minus=document.createElement('button');minus.type='button';minus.textContent='−';minus.setAttribute('aria-label','Decrease');
  const display=document.createElement('output');display.setAttribute('aria-live','off');
  const plus=document.createElement('button');plus.type='button';plus.textContent='+';plus.setAttribute('aria-label','Increase');
  box.append(minus,display,plus);holder.replaceChildren(box);
  const set=(requested,notify=false)=>{
   const next=normalize(requested);
   if(notify&&onChange&&onChange(next)===false)return;
   value=next;if(format===displayAfter)display.innerHTML=launchMarkup(value);else display.textContent=format(value);minus.disabled=value<=lowerBound;plus.disabled=value>=upperBound;
  };
  minus.onclick=()=>set(allowsThreeSecondOption&&value===5?3:value-step,true);
  plus.onclick=()=>set(allowsThreeSecondOption&&value===3?5:value+step,true);
  set(value);return {get value(){return value},set,
   setMin(limit){lowerBound=Math.max(min,Math.min(max,Number(limit)));set(value);},
   setMax(limit){upperBound=Math.max(lowerBound,Math.min(max,Number(limit)));set(value);}};
 };
 const miniStep=(id,min,max,step,initial,format)=>makeStepper($pd(id),min,max,step,initial,format);
 // Keep the initial rise within 100%; later within-firing rises stop at 100%.
 // When Start rises, clamp Increase and disable its + button at the new limit.
 // A user-selected preferred step remains even when the current start-volume cap
 // forces a smaller actual increment (e.g. 100% +0 -> 90% +10 -> 80% +20).
 let alarmPreferredStep=20,timerPreferredStep=20;
 const setVolumePair=(start,increase,startPercent,increasePercent,preferredPercent,kind)=>{
  if(kind==='alarm')alarmPreferredStep=within(preferredPercent??increasePercent,0,50);
  else timerPreferredStep=within(preferredPercent??increasePercent,0,50);
  start.set(startPercent);
  increase.setMax(Math.min(50,100-start.value));
  increase.set(Math.min(100-start.value,kind==='alarm'?alarmPreferredStep:timerPreferredStep));
 };
 let stepVolume,timerStepVolume;
 const startVolume=makeStepper($pd('pdStartVolume'),10,100,10,settingDefaults.alarm.musicStartVolume,v=>v+'%',
  v=>{if(stepVolume){stepVolume.setMax(Math.min(50,100-v));stepVolume.set(Math.min(alarmPreferredStep,100-v));}});
 stepVolume=makeStepper($pd('pdStepVolume'),0,50,5,settingDefaults.alarm.musicRisePercent,v=>'+'+v+'%',v=>{alarmPreferredStep=v;});
 const timerStartVolume=makeStepper($pd('pdTimerStartVolume'),10,100,10,settingDefaults.timer.musicStartVolume,v=>v+'%',
  v=>{if(timerStepVolume){timerStepVolume.setMax(Math.min(50,100-v));timerStepVolume.set(Math.min(timerPreferredStep,100-v));}});
 timerStepVolume=makeStepper($pd('pdTimerStepVolume'),0,50,5,settingDefaults.timer.musicRisePercent,v=>'+'+v+'%',v=>{
  timerPreferredStep=v;storeLocal('pavdroid-timer-preferred-rise-v110',v);
 });
 setVolumePair(startVolume,stepVolume,settingDefaults.alarm.musicStartVolume,settingDefaults.alarm.musicRisePercent,
  settingDefaults.alarm.musicPreferredRisePercent,'alarm');
 setVolumePair(timerStartVolume,timerStepVolume,settingDefaults.timer.musicStartVolume,settingDefaults.timer.musicRisePercent,
  readLocal('pavdroid-timer-preferred-rise-v110',settingDefaults.timer.musicPreferredRisePercent),'timer');
 const alarmRiseEvery=miniStep('pdRiseEvery',3,120,5,settingDefaults.alarm.musicRiseSeconds,v=>v+'s');
 const timerRiseEvery=miniStep('pdTimerRiseEvery',3,120,5,settingDefaults.timer.musicRiseSeconds,v=>v+'s');
 const alarmSnooze=miniStep('pdAlarmSnoozeStep',1,60,1,7,v=>v+' min');
 const timerSnooze=miniStep('pdTimerSnoozeStep',1,60,1,7,v=>v+' min');
 // The hidden values maintain the existing save/start data contract.
 const bindSnooze=(id,holder,initial)=>{
  const box=holder.querySelector('.pdStepBox');
  const btns=box.querySelectorAll('button');
  const original=[btns[0].onclick,btns[1].onclick];
  btns.forEach((btn,i)=>btn.onclick=()=>{original[i]();$pd(id).value=holder===($pd('pdAlarmSnoozeStep'))?alarmSnooze.value:timerSnooze.value;});
  $pd(id).value=initial;
 };
 bindSnooze('pdSnoozeMinutes',$pd('pdAlarmSnoozeStep'),7);
 bindSnooze('pdTimerSnoozeMinutes',$pd('pdTimerSnoozeStep'),7);
 let alarmMusicAfter=0,timerMusicAfter=0;
 // Persisted values remain zero-based snoozes; only their DISPLAY becomes
 // one-based Launch numbers. E.g. 0 snoozes = 1st Launch.
 function launchOrdinal(n){const v=within(n,0,99)+1;const suffix=(v%100>=11&&v%100<=13)?'th':v%10===1?'st':v%10===2?'nd':v%10===3?'rd':'th';return [v,suffix];};
 function displayAfter(n){const [number,suffix]=launchOrdinal(n);return number+suffix+' Launch';};
 function launchMarkup(n){const [number,suffix]=launchOrdinal(n);return '<span class="pdLaunchOrdinal"><span class="pdLaunchNumber">'+number+'<sup>'+suffix+'</sup></span><span class="pdLaunchWord">Launch</span></span>';};
 const setAlarmAfter=v=>{alarmMusicAfter=within(v,0,99);$pd('pdMusicDelayText').innerHTML=launchMarkup(alarmMusicAfter);$pd('pdMusicMinus').disabled=alarmMusicAfter===0;$pd('pdMusicPlus').disabled=alarmMusicAfter===99;};
 const setTimerAfter=v=>{timerMusicAfter=within(v,0,99);$pd('pdTimerMusicDelayText').innerHTML=launchMarkup(timerMusicAfter);$pd('pdTimerMusicMinus').disabled=timerMusicAfter===0;$pd('pdTimerMusicPlus').disabled=timerMusicAfter===99;
  storeLocal('pavdroid-timer-music',{...readLocal('pavdroid-timer-music',{}),after:timerMusicAfter});};
 $pd('pdMusicMinus').onclick=()=>setAlarmAfter(alarmMusicAfter-1);
 $pd('pdMusicPlus').onclick=()=>setAlarmAfter(alarmMusicAfter+1);
 $pd('pdTimerMusicMinus').onclick=()=>setTimerAfter(timerMusicAfter-1);
 $pd('pdTimerMusicPlus').onclick=()=>setTimerAfter(timerMusicAfter+1);
 setTimerAfter(readLocal('pavdroid-timer-music',{})?.after??settingDefaults.timer.musicAfterSnoozes);
 let alarmZapAfter=0,timerZapAfter=0;
 const setAlarmZapAfter=v=>{alarmZapAfter=within(v,0,99);
  $pd('pdAlarmZapAfterText').innerHTML=launchMarkup(alarmZapAfter);
  $pd('pdAlarmZapMinus').disabled=alarmZapAfter===0;$pd('pdAlarmZapPlus').disabled=alarmZapAfter===99;};
 const setTimerZapAfter=v=>{timerZapAfter=within(v,0,99);
  $pd('pdTimerZapAfterText').innerHTML=launchMarkup(timerZapAfter);
  $pd('pdTimerZapMinus').disabled=timerZapAfter===0;$pd('pdTimerZapPlus').disabled=timerZapAfter===99;
  storeLocal('pavdroid-timer-zap-delay-v110',timerZapAfter);};
 $pd('pdAlarmZapMinus').onclick=()=>setAlarmZapAfter(alarmZapAfter-1);
 $pd('pdAlarmZapPlus').onclick=()=>setAlarmZapAfter(alarmZapAfter+1);
 $pd('pdTimerZapMinus').onclick=()=>setTimerZapAfter(timerZapAfter-1);
 $pd('pdTimerZapPlus').onclick=()=>setTimerZapAfter(timerZapAfter+1);
 setTimerZapAfter(readLocal('pavdroid-timer-zap-delay-v110',settingDefaults.timer.zapsAfterSnoozes));
 // Keep legacy read-only preview labels truthful about the Android ramp.
 const oldEditPreview=renderEditSeq;
 renderEditSeq=function(){oldEditPreview();
  $pd('editZapIntensityLabel').textContent='Maximum zap intensity';
  const b=Number($pd('editBuzzCount').value)||0,be=Number($pd('editBeepCount').value)||0,z=Number($pd('editZapCount').value)||0;
  $pd('editSeqPreview').textContent=[b?b+' buzz':null,be?be+' beep':null,z?z+' zap · 10% → '+$pd('editZapMax').value+'% · '+displayAfter(alarmZapAfter):null].filter(Boolean).join(' → ')||'No watch stimuli selected';
 };
 const oldTimerPreview=renderTimerSeq;
 renderTimerSeq=function(){oldTimerPreview();
  const b=Number($pd('timerBuzzCount').value)||0,be=Number($pd('timerBeepCount').value)||0,z=Number($pd('timerZapCount').value)||0;
  $pd('timerSequencePreview').textContent=([b?b+' buzz':null,be?be+' beep':null,z?z+' zap · 10% → '+$pd('timerZapMax').value+'% · '+displayAfter(timerZapAfter):null].filter(Boolean).join(' → ')||'No watch stimuli selected')+' · '+pref.timerInterval+'s interval';
 };
 for(const id of ['pdAlarmZapMinus','pdAlarmZapPlus'])$pd(id).addEventListener('click',()=>queueMicrotask(renderEditSeq));
 for(const id of ['pdTimerZapMinus','pdTimerZapPlus'])$pd(id).addEventListener('click',()=>queueMicrotask(renderTimerSeq));
 // Compact music cards on BOTH editors; folding never changes music enablement,
 // configured levels, snooze count, timer state, or the saved alarm.
 let alarmMusicCollapsed=false, timerMusicCollapsed=false;
 const musicSummary=(after,vol,step,interval)=>{
  const song=selectedSong()?.label||'Choose song in Settings';
  return `${song} · ${displayAfter(after)} · ${vol}% +${step}% / ${interval}s`;
 };
 const refreshMusicFold=()=>{
  for(const spec of [
   {checkbox:'pdMusic',row:'pdMusicChooseRow',summary:'pdAlarmMusicSummary',button:'pdAlarmMusicFold',collapsed:alarmMusicCollapsed,after:alarmMusicAfter,start:startVolume,step:stepVolume,every:alarmRiseEvery},
   {checkbox:'pdTimerMusic',row:'pdTimerMusicRow',summary:'pdTimerMusicSummary',button:'pdTimerMusicFold',collapsed:timerMusicCollapsed,after:timerMusicAfter,start:timerStartVolume,step:timerStepVolume,every:timerRiseEvery}
  ]){
   const enabled=$pd(spec.checkbox).checked;
   $pd(spec.row).hidden=spec.collapsed||!enabled;
   const summary=$pd(spec.summary);summary.hidden=!enabled||!spec.collapsed;
   summary.textContent=musicSummary(spec.after,spec.start.value,spec.step.value,spec.every.value);
   const toggle=$pd(spec.button);toggle.disabled=!enabled;
   toggle.textContent=spec.collapsed?'+':'−';toggle.setAttribute('aria-expanded',String(!spec.collapsed));
   toggle.setAttribute('aria-label',(spec.collapsed?'Expand':'Collapse')+' music options');
  }
 };
 $pd('pdAlarmMusicFold').onclick=()=>{alarmMusicCollapsed=!alarmMusicCollapsed;refreshMusicFold();};
 $pd('pdTimerMusicFold').onclick=()=>{timerMusicCollapsed=!timerMusicCollapsed;refreshMusicFold();};
 $pd('pdMusic').addEventListener('change',refreshMusicFold);
 $pd('pdTimerMusic').addEventListener('change',refreshMusicFold);
 const refreshMusicLabels=()=>{
  const label=selectedSong()?.label||'No song selected · Settings ⚙';
  $pd('pdMp3Name').textContent=label;$pd('pdTimerMp3Name').textContent=label;
  refreshMusicFold();
 };
 // Keep compact summary accurate after numeric +/- adjustments, without
 // triggering any alarm/session save or change to the native clock.
 for(const id of ['pdMusicMinus','pdMusicPlus','pdTimerMusicMinus','pdTimerMusicPlus',
   'pdStartVolume','pdStepVolume','pdTimerStartVolume','pdTimerStepVolume','pdRiseEvery','pdTimerRiseEvery']){
  $pd(id).addEventListener('click',()=>queueMicrotask(refreshMusicFold));
 }
 // Settings is a modal, not a fifth tab. The existing four-tab layout stays intact.
 let previewActive=false, timerDefaultsChanged=false;
 const dialog=document.createElement('dialog');dialog.className='pdSettingsDialog';dialog.id='pdSettingsDialog';
 dialog.innerHTML=`<div class="dialogheader"><h2>Settings</h2><button class="small ghost" id="pdSettingsClose">Done</button></div>
 <div class="dialoginner">
 <section><h3>♫ Music</h3><div id="pdMusicLibrary"></div><button class="small" id="pdAddMusic">+ Add Music</button><div class="pdMiniStepper"><span>Preview volume</span><div class="pdStepBox"><button type="button" id="pdPreviewMinus">−</button><output id="pdPreviewValue">100%</output><button type="button" id="pdPreviewPlus">+</button></div></div><div class="actions"><button id="pdPreviewPlay">Preview selected</button><button id="pdPreviewStop" class="ghost">Stop</button></div></section>
 <section><h3>Watch</h3><div class="actions"><button class="small" id="pdTestBuzz">Test Buzz</button><button class="small" id="pdTestBeep">Test Beep</button></div><div class="pdMiniStepper"><span>Test zap intensity</span><div id="pdTestZapIntensity"></div></div><button class="small ghost pdTestZapBtn" id="pdTestZap">Test Zap</button></section>
 <section><h3>Defaults</h3><p class="smalltext">Auto-saved · New alarms and timers only</p><div id="pdDefaultControls"></div></section>
 <section><h3>Android</h3><div class="actions pdAndroidLinks"><button type="button" class="small ghost" id="pdOpenAppInfo">App info</button><button type="button" class="small ghost" id="pdOpenNotifications">Notifications</button></div></section>
 <section><h3>About</h3><p class="smalltext">PavDroid V1.0.18 · Android · Project RCC</p><p class="smalltext">Independent companion for Pavlok Shock Clock 3. Not affiliated with or endorsed by Pavlok.</p></section>
 </div>`;
 document.body.append(dialog);

 // Folding is presentation-only. Always open Settings with the user's preferred
 // initial layout; do not persist section state across Settings openings.
 const openingFoldStates={
  'main-defaults':false,'main-music':true,'main-watch':true,
  'main-android':true,'main-about':true,
  'defaults-alarm':true,'defaults-timer':true
 };
 const foldStates={...openingFoldStates};
 const foldUpdates=new Map();
 const sectionIcons={
  defaults:'<path d="M4 7h9m4 0h3M4 17h3m4 0h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
  music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  watch:'<rect x="6" y="7" width="12" height="10" rx="3"/><path d="M9 7V3h6v4M9 17v4h6v-4"/><path d="M12 10v4l2 1"/>',
  android:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  about:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/>'
 };
 const mainSections=[...dialog.querySelectorAll('.dialoginner > section')];
 const settingsBody=dialog.querySelector('.dialoginner');
 const mainOrder=[['defaults',2],['music',0],['watch',1],['android',3],['about',4]];
 for(const [,index] of mainOrder)settingsBody.append(mainSections[index]);
 const foldSection=(container,heading,key,level)=>{
  const header=document.createElement('div');header.className='pdFoldHead pdFold'+level;
  const button=document.createElement('button');button.type='button';button.className='pdFoldButton';
  const content=document.createElement('div');content.className='pdFoldBody';
  content.id='pdSettingsFold-'+key;
  for(const node of [...container.childNodes])if(node!==heading)content.append(node);
  if(level==='Main'){
   const keyName=key.slice(5);
   const icon=document.createElement('span');icon.className='pdSettingsMainIcon';icon.setAttribute('aria-hidden','true');
   icon.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+sectionIcons[keyName]+'</svg>';
   if(keyName==='music')heading.textContent=heading.textContent.replace(/^[♫♪]\s*/, '');
   heading.prepend(icon);
  }
  heading.remove();header.append(heading,button);container.append(header,content);
  button.setAttribute('aria-controls',content.id);
  const update=()=>{const closed=!!foldStates[key];content.hidden=closed;button.textContent=closed?'+':'−';
   button.setAttribute('aria-expanded',String(!closed));button.setAttribute('aria-label',(closed?'Expand ':'Collapse ')+heading.textContent);};
  button.onclick=()=>{foldStates[key]=!foldStates[key];update();};
  foldUpdates.set(key,update);update();return content;
 };
 for(const [key,index] of mainOrder)
  foldSection(mainSections[index],mainSections[index].querySelector('h3'),'main-'+key,'Main');
 $pd('pdSettingsBtn').onclick=()=>{
  Object.assign(foldStates,openingFoldStates);
  renderLibrary();renderDefaultControls();timerDefaultsChanged=false;
  for(const update of foldUpdates.values())update();
  dialog.showModal();
 };
 $pd('pdOpenAppInfo').onclick=()=>AndroidUi.openAppInfoSettings();
 $pd('pdOpenNotifications').onclick=()=>AndroidUi.openNotificationSettings('');
 $pd('pdSettingsClose').onclick=()=>{AndroidUi.stopMusicPreview();previewActive=false;dialog.close();};
 dialog.addEventListener('close',()=>{AndroidUi.stopMusicPreview();previewActive=false;});
 let previewVolume=within(readLocal('pavdroid-preview-volume-v107',readLocal('pavdroid-timer-volume-v104',100)),10,100);
 const renderPreview=()=>{$pd('pdPreviewValue').textContent=previewVolume+'%';$pd('pdPreviewMinus').disabled=previewVolume<=10;$pd('pdPreviewPlus').disabled=previewVolume>=100;
  storeLocal('pavdroid-preview-volume-v107',previewVolume);AndroidUi.setMusicPreviewVolume(previewVolume);};
 $pd('pdPreviewMinus').onclick=()=>{previewVolume=Math.max(10,previewVolume-10);renderPreview();};
 $pd('pdPreviewPlus').onclick=()=>{previewVolume=Math.min(100,previewVolume+10);renderPreview();};
 $pd('pdPreviewPlay').onclick=()=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before previewing music.');return;}
  if(!selectedSong()){showWarning('Add and select a song first.');return;}
  previewActive=true;AndroidUi.previewMusic(selectedSong().uri,previewVolume);
 };
 $pd('pdPreviewStop').onclick=()=>{previewActive=false;AndroidUi.stopMusicPreview();};renderPreview();
 $pd('pdAddMusic').onclick=()=>{window.__pdMp3Destination='library';AndroidUi.pickMp3(library.selectedUri||'');};
 function renderLibrary(){
  const host=$pd('pdMusicLibrary');host.replaceChildren();
  if(!library.tracks.length){const p=document.createElement('p');p.className='smalltext';p.textContent='No music imported.';host.append(p);}
  for(const song of library.tracks){
   const item=document.createElement('div');item.className='pdTrackRow';
   const label=document.createElement('label');const radio=document.createElement('input');radio.type='radio';radio.name='pdSong';radio.checked=song.uri===library.selectedUri;
   radio.onchange=()=>{library.selectedUri=song.uri;librarySave();};
   const name=document.createElement('span');name.textContent=song.label;label.append(radio,name);item.append(label);
   const remove=document.createElement('button');remove.type='button';remove.textContent='Remove';remove.className='small ghost';
   remove.onclick=()=>{library.tracks=library.tracks.filter(t=>t.uri!==song.uri);if(library.selectedUri===song.uri)library.selectedUri=library.tracks[0]?.uri||'';librarySave();};
   item.append(remove);host.append(item);
  }
 }
 const oldMp3Handler=onMp3Picked;
 onMp3Picked=function(uri,label){
  if(!uri?.startsWith('content://'))return;
  if(!library.tracks.some(t=>t.uri===uri))library.tracks.push({uri,label:label||'Selected MP3'});
  library.selectedUri=uri;librarySave();
 };
 // The established below-15% battery color behavior remains in the base UI.
 const testWatch=async(type,pct)=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before testing the watch.');return;}
  if(!isOn()){showWarning('Connect the watch first.');return;}
  if(type==='zap'&&!await askConfirmation('Send one '+pct+'% test zap to the watch?'))return;
  try{await immediate({type},pct);}catch(e){showWarning(e.message);}
 };
 $pd('pdTestBuzz').onclick=()=>testWatch('buzz',30);
 $pd('pdTestBeep').onclick=()=>testWatch('beep',30);
 const intensityColor=pct=>Number(pct)<=30?'#42c987':Number(pct)<=50?'#e9b959':'#f27880';
 const paintIntensityBox=(element,pct)=>{
  const box=element?.querySelector('.pdStepBox');if(!box)return;
  box.style.borderColor=intensityColor(pct);box.style.borderWidth='2px';element.classList.toggle('pdExtremeIntensity',Number(pct)>=90);
 };
 const paintIntensityRanges=()=>{
  for(const id of ['editZapMax','timerZapMax']){
   const input=$pd(id);if(!input)continue;
   const pct=within(input.value,10,100);
   const fraction=(pct-10)/90*100;
   const tint=intensityColor(pct);
   input.classList.add('pdIntensityRange');
   input.style.setProperty('--pd-intensity',tint);
   input.style.setProperty('--pd-thumb-ring',pct>=90?'#fff':'#cbdcf1');
   input.style.setProperty('--pd-thumb-outline',pct>=90?'4px':'1px');
   input.style.background='linear-gradient(to right,'+tint+' '+fraction+'%,#485364 '+fraction+'%)';
   const safe=id==='editZapMax'?alarmSafeMax:timerSafeMax;safe.hidden=pct<60;
  }
 };
 const testZap=makeStepper($pd('pdTestZapIntensity'),10,100,10,
  readLocal('pavdroid-test-zap-pct-v107',10),v=>v+'%',v=>{
   storeLocal('pavdroid-test-zap-pct-v107',v);
  });
 paintIntensityBox($pd('pdTestZapIntensity'),testZap.value);
 $pd('pdTestZapIntensity').addEventListener('click',()=>queueMicrotask(()=>paintIntensityBox($pd('pdTestZapIntensity'),testZap.value)));
 for(const id of ['editZapMax','timerZapMax'])$pd(id).addEventListener('input',paintIntensityRanges);
 paintIntensityRanges();
 $pd('pdTestZap').onclick=()=>testWatch('zap',testZap.value);
 // Defaults update immediately, with units and the same +/- control style.
 const persistDefaults=()=>storeLocal(defaultKey,settingDefaults);
 function renderDefaultControls(){
  const root=$pd('pdDefaultControls');root.replaceChildren();
  const sections=[
   ['Stimuli',[
     ['buzz','Buzzes',0,5,1,v=>String(v)],['beep','Beeps',0,5,1,v=>String(v)],
     ['interval','Interval',3,30,1,v=>v+'s'],['snooze','Snooze time',1,60,1,v=>v+' min']]],
   ['Zaps',[
     ['zaps','Zaps',0,5,1,v=>String(v)],['intensity','Maximum intensity',10,100,10,v=>v+'%'],
     ['zapsAfterSnoozes','Zaps start',0,99,1,displayAfter]]],
   ['Music',[
     ['musicAfterSnoozes','Music starts',0,99,1,displayAfter],
     ['musicStartVolume','Start volume',10,100,10,v=>v+'%'],
     ['musicRisePercent','Increase by',0,50,5,v=>'+'+v+'%'],
     ['musicRiseSeconds','Increase every',3,120,5,v=>v+'s']]]
  ];
  for(const type of ['alarm','timer']){
   const block=document.createElement('div');block.className='pdDefaultBlock';root.append(block);
   const title=document.createElement('h3');title.textContent=type==='alarm'?'New alarms':'New timers';title.className='pdDefaultTitle';block.append(title);
   const controls={};
   for(const [groupName,fields] of sections){
    const card=document.createElement('div');card.className='pdDefaultsGroup';
    const heading=document.createElement('h4');heading.textContent=groupName;card.append(heading);
    const grid=document.createElement('div');grid.className='pdDefaultsGrid';card.append(grid);block.append(card);
    for(const [key,label,min,max,step,format] of fields){
     const field=document.createElement('div');field.className='pdDefaultsField';
     const caption=document.createElement('label');caption.textContent=label;
     const holder=document.createElement('div');holder.id='pdDefault-'+type+'-'+key;
     field.append(caption,holder);grid.append(field);
     const effectiveMax=key==='musicRisePercent'?Math.min(max,100-settingDefaults[type].musicStartVolume):max;
     controls[key]=makeStepper(holder,min,max,step,settingDefaults[type][key],format,v=>{
      if(['buzz','beep','zaps'].includes(key)){
       const candidate={...settingDefaults[type],[key]:v};
       if(candidate.buzz+candidate.beep+candidate.zaps===0){showWarning('Keep at least one buzz, beep, or zap.');return false;}
      }
      settingDefaults[type][key]=v;
      if(key==='buzz'||key==='beep'){
       const required=minimumStimulusSeconds(settingDefaults[type].buzz,settingDefaults[type].beep);
       if(controls.interval){controls.interval.setMin(required);
        settingDefaults[type].interval=controls.interval.value;}
       else settingDefaults[type].interval=Math.max(required,settingDefaults[type].interval);
      }
      if(key==='musicRisePercent')settingDefaults[type].musicPreferredRisePercent=v;
      if(key==='musicStartVolume'){
       const allowed=Math.min(50,100-v);
       settingDefaults[type].musicRisePercent=Math.min(settingDefaults[type].musicPreferredRisePercent??20,allowed);
       controls.musicRisePercent?.setMax(allowed);
       controls.musicRisePercent?.set(settingDefaults[type].musicRisePercent);
      }
      persistDefaults();if(type==='timer')timerDefaultsChanged=true;return true;
     });
     if(key==='musicRisePercent')controls[key].setMax(effectiveMax);
     if(key==='interval')controls[key].setMin(minimumStimulusSeconds(settingDefaults[type].buzz,settingDefaults[type].beep));
     if(key==='intensity'){
      paintIntensityBox(holder,controls[key].value);
      holder.addEventListener('click',()=>queueMicrotask(()=>paintIntensityBox(holder,controls[key].value)));
      holder.addEventListener('change',()=>queueMicrotask(()=>paintIntensityBox(holder,controls[key].value)));
     }
    }
    if(groupName==='Zaps'){
      const explanation=document.createElement('div');explanation.className='pdZapEscalationInfo';
      explanation.innerHTML='<strong>Escalation Setting</strong><span>Start at 10%.<br>Increase to Max <b></b>.</span>';
      const maxText=explanation.querySelector('b');
      const updateExplanation=()=>{maxText.textContent=settingDefaults[type].intensity+'%';};
      const intensityHolder=card.querySelector('#pdDefault-'+type+'-intensity');
      intensityHolder.addEventListener('click',()=>queueMicrotask(updateExplanation));
      updateExplanation();grid.append(explanation);
    }
    // All three groups appear immediately when New alarms/timers expands.
    // They are intentionally not individually collapsible.
   }
   const smart=document.createElement('label');smart.className='check pdDefaultSmart';
   smart.innerHTML='<input type="checkbox"> Smart Timeout';
   const toggle=smart.querySelector('input');toggle.checked=settingDefaults[type].smart!==false;
   toggle.onchange=()=>{settingDefaults[type].smart=toggle.checked;persistDefaults();if(type==='timer')timerDefaultsChanged=true;};
   block.append(smart);
   foldSection(block,title,'defaults-'+type,'Type');
  }
 }
 if(library.migrated||library.tracks.length)librarySave();
 else {renderLibrary();refreshMusicLabels();}
 // Timer is a reusable setup: keep manual timer options across idle sessions.
 // The Reset button explicitly reapplies the currently saved new-timer defaults.
 const timerCurrentKey='pavdroid-timer-current-v112';
 function applyTimerDefaultsIfReady(d=settingDefaults.timer){
 if(nativeTimerPhase()==='ready'){
  for(const [key,id] of [['buzz','timerBuzzCount'],['beep','timerBeepCount'],['zaps','timerZapCount'],['intensity','timerZapMax']])
   $pd(id).value=d[key];
  pref.timerInterval=Math.max(minimumStimulusSeconds(d.buzz,d.beep),d.interval);
  renderTimerInterval();renderTimerSeq();
  timerSnooze.set(d.snooze);$pd('pdTimerSnoozeMinutes').value=timerSnooze.value;$pd('pdTimerSmart').checked=d.smart!==false;
  setVolumePair(timerStartVolume,timerStepVolume,d.musicStartVolume,d.musicRisePercent,d.musicPreferredRisePercent,'timer');
  timerRiseEvery.set(d.musicRiseSeconds);setTimerZapAfter(d.zapsAfterSnoozes);
  setTimerAfter(d.musicAfterSnoozes);
  if(typeof d.music==='boolean')$pd('pdTimerMusic').checked=d.music;
  $pd('pdTimerSafeMax').checked=!!d.safeMax;
  refreshMusicFold();paintIntensityRanges();renderTimerSeq();
 }
 }
 applyTimerDefaultsIfReady({...settingDefaults.timer,...(readLocal(timerCurrentKey,{})||{})});
 const rememberTimerSetup=()=>{
  if(nativeTimerPhase()!=='ready'||native.snapshot()?.active)return;
  storeLocal(timerCurrentKey,{
   buzz:Number($pd('timerBuzzCount').value),beep:Number($pd('timerBeepCount').value),
   zaps:Number($pd('timerZapCount').value),interval:pref.timerInterval,
   intensity:Number($pd('timerZapMax').value),snooze:timerSnooze.value,
   smart:$pd('pdTimerSmart').checked,music:$pd('pdTimerMusic').checked,safeMax:$pd('pdTimerSafeMax').checked,
   musicStartVolume:timerStartVolume.value,musicRisePercent:timerStepVolume.value,
   musicPreferredRisePercent:timerPreferredStep,musicRiseSeconds:timerRiseEvery.value,
   musicAfterSnoozes:timerMusicAfter,zapsAfterSnoozes:timerZapAfter
  });
 };
 for(const eventName of ['input','change','click']){
  $pd('timerSetup').addEventListener(eventName,()=>queueMicrotask(rememberTimerSetup));
 }

 // Timer reuses its editor between runs. Explicit Reset to defaults applies
 // the current saved Timer defaults while retaining the chosen MM:SS duration.
 const timerBadge=$pd('timerBadge');
 const timerReset=document.createElement('button');timerReset.type='button';
 timerReset.id='pdTimerResetDefaults';timerReset.className='pdTimerReset';timerReset.textContent='Reset to defaults';
 timerBadge.after(timerReset);
 const updateTimerResetVisibility=()=>{
  const idle=nativeTimerPhase()==='ready'&&!native.snapshot()?.active;
  timerReset.hidden=!idle;timerBadge.hidden=idle;
 };
 const baseRenderClock=renderClock;
 renderClock=function(...args){const result=baseRenderClock(...args);updateTimerResetVisibility();return result;};
 timerReset.onclick=()=>{
  if(nativeTimerPhase()!=='ready'||native.snapshot()?.active){showWarning('Stop the current alarm or timer first.');return;}
  const selectedDuration=$pd('duration').value;
  applyTimerDefaultsIfReady();
  // Resetting configuration must never change selected timer time/preset.
  $pd('duration').value=selectedDuration;
  rememberTimerSetup();
  timerMusicCollapsed=false;refreshMusicFold();
  paintIntensityRanges();renderTimerSeq();
  message('timerWriteStatus','');updateTimerResetVisibility();
 };
 updateTimerResetVisibility();
 // Alarm editor and scheduled card visuals are literally the V3.0.3 elements.
 const originalShowEditor=showEditor;
 showEditor=function(i=-1,copy=false,plus30=false){
  originalShowEditor(i,copy,plus30);updateSegment();
  const selected=i>=0?app.alarms?.[i]:null;
  $pd('pdSmartTimeout').checked=selected?.smartTimeout??settingDefaults.alarm.smart;
  $pd('pdAlarmSafeMax').checked=!!selected?.safeMax;
  $pd('pdMusic').checked=!!selected?.music;
  alarmMusicCollapsed=false;refreshMusicFold();
  alarmSnooze.set(selected?.snoozeMinutes??settingDefaults.alarm.snooze);
  $pd('pdSnoozeMinutes').value=alarmSnooze.value;
  setAlarmAfter(selected?.musicAfterSnoozes??settingDefaults.alarm.musicAfterSnoozes);
  setAlarmZapAfter(selected?.zapsAfterSnoozes??settingDefaults.alarm.zapsAfterSnoozes);
  alarmRiseEvery.set(selected?.musicRiseSeconds??settingDefaults.alarm.musicRiseSeconds);
  setVolumePair(startVolume,stepVolume,
   selected?.musicStartVolume??(selected?100:settingDefaults.alarm.musicStartVolume),
   selected?.musicRisePercent??(selected?0:settingDefaults.alarm.musicRisePercent),
   selected?.musicPreferredRisePercent??(selected?(selected.musicRisePercent||20):settingDefaults.alarm.musicPreferredRisePercent),'alarm');
  if(!selected){
   for(const [key,id] of [['buzz','editBuzzCount'],['beep','editBeepCount'],['zaps','editZapCount'],['intensity','editZapMax']]){
    $pd(id).value=settingDefaults.alarm[key];$pd(id).dispatchEvent(new Event('input',{bubbles:true}));
   }
   app.editorInterval=settingDefaults.alarm.interval;renderIntervalStepper();renderEditSeq();
  }
  // Keep a saved alarm's longer interval; auto-raise only if its counts require it.
  app.editorInterval=Math.max(app.editorInterval,minimumStimulusSeconds($pd('editBuzzCount').value,$pd('editBeepCount').value));
  renderIntervalStepper();refreshMusicLabels();paintIntensityRanges();renderEditSeq();
 };
 alarmChangeIsUnsafe=function(){return native.snapshot()?.active===true;};
 const originalRefreshConnection=refreshConnection;
 refreshConnection=function(){originalRefreshConnection();const disabled=alarmChangeIsUnsafeIncludingTimer()||app.busy;
  $pd('newAlarmBtn').disabled=disabled;
  $pd('readAlarmsBtn').disabled=false;
  for(const b of document.querySelectorAll('[data-alarm-action]'))b.disabled=disabled;
  const s=native.snapshot(),active=!!s?.active;
  $pd('snoozeAlarmBtn').disabled=!active||s.phase!=='firing';
  $pd('stopAlarmBtn').disabled=!active;
  // Timer is phone-controlled, but direct watch output still requires BLE.
  $pd('timerStartBtn').disabled=app.busy||!isOn()||nativeTimerPhase()!=='ready'||active;
 };
 readAlarms=async function(skipListRender=false){
  app.alarms=native.list();app.alarmsTrusted=true;
  if(!library.migrated){
   for(const alarm of app.alarms){
    if(alarm.musicUri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===alarm.musicUri))
     library.tracks.push({uri:alarm.musicUri,label:alarm.musicLabel||'Saved alarm MP3'});
   }
   if(!library.selectedUri&&library.tracks.length)library.selectedUri=library.tracks[0].uri;
   library.migrated=true;librarySave();
  }
  $pd('alarmSyncLabel').textContent=app.alarms.length+' on phone';
  $pd('emptyConfirmWrap').hidden=true;
  if(!skipListRender)renderAlarms();refreshConnection();return app.alarms;
 };
 writeAlarms=async function(next,reason,revealIndex=null){
  if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is currently in progress.');
  const saved=await native.save(next);
  app.alarms=saved;app.alarmsTrusted=true;
  renderAlarms(revealIndex);refreshConnection();
  $pd('alarmOpStatus').textContent=reason+(native.exactAccess()?' · saved on Android.':' · saved, but precise alarm permission is required.');
  refreshExactAccess();
  return true;
 };
 alarmAction=async function(i,act){
  if(blockAlarmChangeWhileActive())return;
  if(act==='edit')return showEditor(i);
  if(act==='copy'||act==='copy30')return showEditor(i,true,act==='copy30');
  const next=app.alarms.map(a=>({...a}));if(!next[i])return;
  if(act==='toggle')next[i].enabled=!next[i].enabled;
  else if(act==='delete'){
   if(!await askConfirmation('Delete '+next[i].name+' · '+humanTime(next[i].time)+' from Android?'))return;
   next.splice(i,1);
  }
  try{await writeAlarms(next,act==='delete'?'Alarm deleted':'Alarm updated');}
  catch(e){showWarning(e.message);}
 };
 saveEditor=async function(){
  if(blockAlarmChangeWhileActive())return;
  try{
   const a=editData();
   if(a.interval<minimumStimulusSeconds(a.buzz,a.beep))throw Error('Interval must be at least 1s longer than the largest Buzz/Beep count.');
   a.smartTimeout=$pd('pdSmartTimeout').checked;
   a.safeMax=Number($pd('editZapMax').value)>=60&&$pd('pdAlarmSafeMax').checked;
   a.music=$pd('pdMusic').checked;
   a.musicUri=selectedSong()?.uri||'';a.musicLabel=selectedSong()?.label||'';
   a.snoozeMinutes=Number($pd('pdSnoozeMinutes').value);
   a.musicDelay=10;a.musicAfterSnoozes=alarmMusicAfter;
   a.musicStartVolume=startVolume.value;a.musicRisePercent=stepVolume.value;
   a.musicRiseSeconds=alarmRiseEvery.value;a.zapsAfterSnoozes=alarmZapAfter;a.escalate=true;
   a.musicPreferredRisePercent=alarmPreferredStep;
   if(a.musicStartVolume+a.musicRisePercent>100)throw Error('Music start and increase cannot total over 100%.');
   if(!Number.isInteger(a.snoozeMinutes)||a.snoozeMinutes<1||a.snoozeMinutes>60)throw Error('Snooze duration must be 1–60 minutes.');
   if(a.music&&!a.musicUri)throw Error('Choose a song in Settings first.');
   const next=app.alarms.map(x=>({...x}));
   if(app.editorIndex>=0){if(!next[app.editorIndex])throw Error('Alarm list changed');next[app.editorIndex]=a;}
   else {a.enabled=true;next.push(a);}
   await writeAlarms(next,'Alarm saved',app.editorIndex<0?next.length-1:null);
   $pd('alarmEditor').close();
  }catch(e){showWarning(e.message);}
 };
 // Replace only the button handlers which formerly sent firmware packets.
 // Both Save buttons invoke the same validated editor save; block accidental double taps.
 let savePending=false;
 const saveFromEitherButton=async()=>{
  if(savePending)return;savePending=true;
  $pd('saveEditorBtn').disabled=true;editorTopSave.disabled=true;
  try{await saveEditor();}finally{savePending=false;
   $pd('saveEditorBtn').disabled=false;editorTopSave.disabled=false;}
 };
 $pd('saveEditorBtn').onclick=saveFromEitherButton;editorTopSave.onclick=saveFromEitherButton;
 $pd('newAlarmBtn').onclick=()=>showEditor();
 $pd('readAlarmsBtn').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();readAlarms();}};
 $pd('confirmEmptyBtn').onclick=()=>{};
 $pd('snoozeAlarmBtn').onclick=async()=>{try{await native.action('snooze');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 $pd('stopAlarmBtn').onclick=async()=>{try{await native.action('stop');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 alarmButton=async(which)=>{try{await native.action(which);refreshAlarmSession();}catch(e){showWarning(e.message);}};
 // Preserve V3.0.3 duration keypad, preset row, count +/- controls, slider,
 // countdown face and all timer status/snooze/stop buttons. Only routing changes.
 timerCommand=async function(action){
  try{
   if(action==='start'){
    if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is already in progress.');
    const cfg={seconds:duration(),buzz:count('timerBuzzCount',5),beep:count('timerBeepCount',5),
      zaps:count('timerZapCount',5),intensity:Number($pd('timerZapMax').value),
      interval:pref.timerInterval,snoozeSeconds:withinUi($pd('pdTimerSnoozeMinutes').value,1,60)*60,
      musicDelay:10,musicAfterSnoozes:timerMusicAfter,
      musicStartVolume:timerStartVolume.value,musicRisePercent:timerStepVolume.value,
      musicRiseSeconds:timerRiseEvery.value,zapsAfterSnoozes:timerZapAfter,
      smartTimeout:$pd('pdTimerSmart').checked,music:$pd('pdTimerMusic').checked,
      safeMax:Number($pd('timerZapMax').value)>=60&&$pd('pdTimerSafeMax').checked,
      musicUri:selectedSong()?.uri||''};
    if(cfg.interval<minimumStimulusSeconds(cfg.buzz,cfg.beep))
     throw Error('Interval must be at least 1s longer than the largest Buzz/Beep count.');
    if(cfg.musicStartVolume+cfg.musicRisePercent>100)throw Error('Music start and increase cannot total over 100%.');
    if(cfg.buzz+cfg.beep+cfg.zaps===0)throw Error('Select at least one stimulus.');
    if(cfg.music&&!cfg.musicUri)throw Error('Choose a song in Settings first.');
    await nativeTimerAction('start',cfg);
    // The timer's brief 30% start acknowledgement is always on (no editor toggle).
    if(isOn())try{await immediate({type:'buzz'},30);}catch(_){}
   }else if(action==='snooze')await nativeTimerAction('snooze');
   else await nativeTimerAction(action);
   syncNativeTimer(false);refreshConnection();
  }catch(e){message('timerWriteStatus',e.message,true);}
 };
 function withinUi(value,lo,hi){const n=Number(value);if(!Number.isInteger(n)||n<lo||n>hi)throw Error('Choose a value between '+lo+' and '+hi);return n;}
 $pd('timerStartBtn').onclick=()=>{dismissSoftKeyboard($pd('duration'));void timerCommand('start');};
 $pd('timerSnoozeBtn').onclick=()=>timerCommand('snooze');
 $pd('timerPauseBtn').onclick=()=>timerCommand('pause');
 $pd('timerResumeBtn').onclick=()=>timerCommand('resume');
 $pd('timerStopBtn').onclick=()=>timerCommand('reset');
 // Watch-reported firmware timer/status notifications cannot alter PavDroid UI.
 onAlarmNotify=function(){};
 onTimerConfig=function(){};
 function refreshAlarmSession(){
  const s=native.snapshot();if(previewActive&&(s?.active||nativeTimerPhase()!=='ready')){AndroidUi.stopMusicPreview();previewActive=false;}
  if(!s?.active){app.activeAlarm=null;app.snoozeUntil=null;
    alarmState('STATUS UNKNOWN','No Android alarm currently active','unknown');refreshConnection();return;}
  app.activeAlarm={id:s.id+1,firing:s.phase==='firing'};
  app.snoozes=s.snoozes||0;app.snoozeUntil=s.snoozeUntil||null;
  $pd('snoozeCount').textContent=String(s.snoozes||0);
  $pd('snoozeRemaining').textContent=s.snoozeUntil&&s.phase==='snoozing'?fmt((s.snoozeUntil-Date.now())/1000):'—';
  alarmState(s.phase==='firing'?'ALARM ACTIVATED':'SNOOZING',s.name,s.phase==='firing'?'active-state':'snooze-state');
  $pd('activeName').textContent=s.name||'Alarm Enabled';
  $pd('alarmState').textContent=s.phase==='firing'?'ALARM ACTIVATED':
   `SNOOZING (${s.snoozes||0}) · ${fmt((s.snoozeUntil-Date.now())/1000)} left`;
  refreshConnection();
 }
 const originalDrop=onDrop;
 onDrop=function(){originalDrop();setPavDroidBattery(null);};
 const baseTab=tab;
 tab=function(name){baseTab(name);if(name==='alarms')readAlarms();};
 readAlarms();refreshAlarmSession();
 setInterval(refreshAlarmSession,1000);
 // The connection page is unchanged in layout, but its labels are accurate.
 $pd('connectionHealth').textContent='Android schedules alarms. Bluetooth sends watch stimuli.';
})();
