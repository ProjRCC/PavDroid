/* PavDroid adapter to ORIGINAL Pavlok Control V3.0.3 interface.
   This file does not recreate the timer, alarm cards, steppers, keypad,
   sliders, dialogs, navigation, or History layout. */
'use strict';
(function(){
 if(!window.PavDroidNative)throw Error('PavDroid native alarm bridge is missing');
 const $pd=id=>document.getElementById(id);
 const native=window.PavDroidNative;
 // Original watch-alarm and Code Red controls remain available in the source
 // for reference but are NEVER displayed or executed in PavDroid.
 const old=$pd('alarmEditor').querySelector('.codeRedSection');old.style.display='none';
 const defaultKey='pavdroid-defaults-v104';
 const defaultValues={alarm:{buzz:5,beep:5,zaps:1,interval:8,intensity:40,snooze:7,smart:true,musicStartVolume:30,musicStepVolume:20},
                      timer:{buzz:3,beep:3,zaps:1,interval:8,intensity:40,snooze:7,smart:true,
                             musicStartVolume:Number(readLocal('pavdroid-timer-volume-v104',100))||100,musicStepVolume:0}};
 const settingDefaults=Object.assign({},defaultValues,readLocal(defaultKey,{}));
 for(const type of ['alarm','timer'])settingDefaults[type]={...defaultValues[type],...(settingDefaults[type]||{})};
 const within=(x,min,max)=>Math.max(min,Math.min(max,Math.round(Number(x)||0)));
 const libraryKey='pavdroid-music-library-v104';
 let library=readLocal(libraryKey,{tracks:[],selectedUri:''})||{tracks:[],selectedUri:''};
 if(!Array.isArray(library.tracks))library.tracks=[];
 // One-time migration of the last selected MP3 and timer MP3; no files are moved.
 if(!library.tracks.length){
  for(const item of [readLocal(lastMp3Key,{}),readLocal('pavdroid-timer-music',{})]){
   if(item?.uri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===item.uri))
    library.tracks.push({uri:item.uri,label:item.label||'Selected MP3'});
  }
  if(!library.selectedUri)library.selectedUri=library.tracks[0]?.uri||'';
 }
 const selectedSong=()=>library.tracks.find(t=>t.uri===library.selectedUri);
 const librarySave=()=>{
  try{AndroidUi.stopMusicPreview();previewActive=false;}catch(_){ }
  storeLocal(libraryKey,library);
  try{AndroidUi.setSelectedMusicUri(library.selectedUri||'');}catch(e){console.warn('Music sync:',e)}
  refreshMusicLabels();renderLibrary();
 };
 const extras=document.createElement('div');extras.className='pavdroidExtra';
 extras.innerHTML=`<div class="pdOption"><label class="check"><input type="checkbox" id="pdSmartTimeout" checked>Smart Timeout</label></div>
  <div class="pdOption"><label class="check"><input type="checkbox" id="pdMusic">Include Music</label>
   <div id="pdMusicChooseRow" hidden><p class="smalltext" id="pdMp3Name">Choose a song in Settings</p>
    <div id="pdMusicAfterRow" class="pdMiniStepper"><span>Play after</span><div class="pdStepBox"><button type="button" id="pdMusicMinus" aria-label="Fewer snoozes">−</button><output id="pdMusicDelayText">0 snoozes</output><button type="button" id="pdMusicPlus" aria-label="More snoozes">+</button></div></div>
    <div class="pdDefaultRow pdMusicVolumeRow"><div><label class="field">Start volume</label><div id="pdStartVolume"></div></div><div><label class="field">Increase per snooze</label><div id="pdStepVolume"></div></div></div>
    <p class="smalltext">Music starts 10s into firing.</p></div></div>`;
 old.after(extras);
 // Smart Timeout belongs at the bottom, after the alarm Snooze control.
 const alarmSmart=extras.querySelector('#pdSmartTimeout').closest('.pdOption');
 const foot=document.createElement('div');foot.className='pdSnoozeBottom';
 foot.innerHTML=`<div class="pdMiniStepper"><span>Snooze</span><div id="pdAlarmSnoozeStep"></div><input id="pdSnoozeMinutes" type="hidden" value="7"></div>`;
 const existingEnabled=$pd('editEnabled');existingEnabled.closest('label').hidden=true;
 existingEnabled.closest('label').after(foot);
 foot.after(alarmSmart);
 function addSmartInfo(option,kind){
  option.classList.add('pdSmartOption');
  const label=option.querySelector('label.check');
  const info=document.createElement('button');info.type='button';info.className='pdInfoBtn';
  info.setAttribute('aria-label','About '+kind+' Smart Timeout');info.setAttribute('aria-expanded','false');info.textContent='i';
  const help=document.createElement('p');help.className='pdSmartHelp';help.hidden=true;
  help.textContent='When on: stops after 1 hour without a snooze. Each snooze resets the cutoff to 2 hours after that snooze. Never stops mid-snooze.';
  label.after(info,help);info.onclick=()=>{help.hidden=!help.hidden;info.setAttribute('aria-expanded',String(!help.hidden));};
 }
 addSmartInfo(alarmSmart,'alarm');
 const editorText=$pd('alarmEditor').querySelector('.quiet');if(editorText)editorText.textContent='';
 $pd('saveEditorBtn').textContent='Save alarm';
 // Replace Android's oversized native dropdown with inline, tap-friendly choices.
 const escalateSelect=$pd('editEscalate');
 escalateSelect.style.display='none';escalateSelect.tabIndex=-1;escalateSelect.setAttribute('aria-hidden','true');
 const segment=document.createElement('div');segment.className='pdZapBehavior';segment.setAttribute('role','group');
 segment.setAttribute('aria-label','Zap behavior');
 const choices=[['1','Escalate'],['0','Full']];
 const updateSegment=()=>{for(const button of segment.querySelectorAll('button')){
   const selected=button.dataset.value===escalateSelect.value;button.classList.toggle('selected',selected);
   button.setAttribute('aria-pressed',String(selected));}};
 for(const [value,label] of choices){const button=document.createElement('button');button.type='button';
  button.dataset.value=value;button.textContent=label;button.onclick=()=>{
    escalateSelect.value=value;escalateSelect.dispatchEvent(new Event('change',{bubbles:true}));
    updateSegment();renderEditSeq();};segment.append(button);}
 escalateSelect.after(segment);updateSegment();
 $pd('deleteTitle').textContent='Delete alarm?';
 $pd('alarmSyncLabel').removeAttribute('title');$pd('alarmSyncLabel').removeAttribute('aria-label');
 $pd('alarmOpStatus').textContent='';
 const exactNotice=document.createElement('p');exactNotice.className='quiet';exactNotice.id='pdExactNotice';
 exactNotice.innerHTML='Precise alarms permission needed. <button type="button" class="small ghost" id="pdExactSettings">Allow</button>';
 $pd('alarmOpStatus').after(exactNotice);
 $pd('pdExactSettings').onclick=()=>AndroidUi.openExactAlarmSettings();
 const refreshExactAccess=()=>{exactNotice.hidden=native.exactAccess();};
 refreshExactAccess();document.addEventListener('visibilitychange',refreshExactAccess);
 window.addEventListener('focus',refreshExactAccess);
 $pd('alarmList').textContent='No alarms saved.';$pd('emptyConfirmWrap').hidden=true;
 const settings=document.createElement('div');settings.className='pavdroidExtra';
 settings.innerHTML=`<div class="pdOption"><label class="check"><input id="pdTimerSmart" type="checkbox" checked>Smart Timeout</label></div>
  <div class="pdOption"><label class="check"><input id="pdTimerMusic" type="checkbox">Include Music</label>
   <div id="pdTimerMusicRow" hidden><p id="pdTimerMp3Name" class="smalltext">Choose a song in Settings</p>
    <div class="pdMiniStepper"><span>Play after</span><div class="pdStepBox"><button type="button" id="pdTimerMusicMinus" aria-label="Fewer snoozes">−</button><output id="pdTimerMusicDelayText">0 snoozes</output><button type="button" id="pdTimerMusicPlus" aria-label="More snoozes">+</button></div></div>
    <div class="pdDefaultRow pdMusicVolumeRow"><div><label class="field">Start volume</label><div id="pdTimerStartVolume"></div></div><div><label class="field">Increase per snooze</label><div id="pdTimerStepVolume"></div></div></div>
    <p class="smalltext">Music starts 10s into firing.</p></div></div>
  <div class="pdMiniStepper pdSnoozeBottom"><span>Snooze</span><div id="pdTimerSnoozeStep"></div><input id="pdTimerSnoozeMinutes" type="hidden" value="7"></div>`;
  $pd('timerSetup').append(settings);
 const timerSmart=$pd('pdTimerSmart').closest('.pdOption');
 settings.append(timerSmart);addSmartInfo(timerSmart,'timer');
 const style=document.createElement('style');style.textContent=`.pavdroidExtra{padding:0;margin:13px 0}.pdOption{border:1px solid #364c65;border-radius:12px;padding:12px 13px;margin-bottom:10px;background:#172334}.pdOption p.smalltext{font-size:11px;margin:7px 0 0;color:#b1c2d6}.pdSnoozeBottom{margin-top:13px}.pavdroidExtra .check{min-height:22px}.pdOption .pdDefaultRow{display:grid;grid-template-columns:1fr 1fr;gap:12px}
 .pdMusicVolumeRow{margin-top:16px;margin-bottom:7px;align-items:end}
 .pdMusicVolumeRow label.field{display:block;margin:0 0 8px;font-size:12px;font-weight:650}
 .pdSmartOption{display:grid;grid-template-columns:minmax(0,1fr) 30px;align-items:center;gap:8px}
 .pdInfoBtn{width:29px;height:29px;min-height:29px!important;min-width:29px;padding:0!important;border-radius:100%;border:1px solid #5b7695;background:#263c57;color:#d3e5fd;font-size:15px;font-style:italic;font-weight:700}
 .pdSmartHelp{grid-column:1/-1;margin:3px 0 0!important;color:#b1c2d6;font-size:12px;line-height:1.45}
 .pdSmartHelp[hidden]{display:none}
 .pdTestZapBtn{margin-top:12px;width:100%}
 .pdZapBehavior{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:9px}
 .pdZapBehavior button{min-height:40px;border-radius:10px;border:1px solid #4f6884;background:#1c2b3f;color:#d4e3f6}
 .pdZapBehavior button.selected{background:#3c6594;border-color:#8fb8fc;color:#fff;font-weight:700}
`;document.head.append(style);
 // One control for every new numeric setting: minus, value WITH unit, plus.
 const makeStepper=(holder,min,max,step,initial,format,onChange)=>{
  let value=within(initial,min,max);
  const box=document.createElement('div');box.className='pdStepBox';
  const minus=document.createElement('button');minus.type='button';minus.textContent='−';minus.setAttribute('aria-label','Decrease');
  const display=document.createElement('output');display.setAttribute('aria-live','off');
  const plus=document.createElement('button');plus.type='button';plus.textContent='+';plus.setAttribute('aria-label','Increase');
  box.append(minus,display,plus);holder.replaceChildren(box);
  const set=(requested,notify=false)=>{
   const next=Math.max(min,Math.min(max,Math.round(Number(requested)/step)*step));
   if(notify&&onChange&&onChange(next)===false)return;
   value=next;display.textContent=format(value);minus.disabled=value<=min;plus.disabled=value>=max;
  };
  minus.onclick=()=>set(value-step,true);plus.onclick=()=>set(value+step,true);
  set(value);return {get value(){return value},set};
 };
 const miniStep=(id,min,max,step,initial,format)=>makeStepper($pd(id),min,max,step,initial,format);
 const startVolume=miniStep('pdStartVolume',10,100,10,settingDefaults.alarm.musicStartVolume,v=>v+'%');
 const stepVolume=miniStep('pdStepVolume',0,50,5,settingDefaults.alarm.musicStepVolume,v=>'+'+v+'%');
 const timerStartVolume=miniStep('pdTimerStartVolume',10,100,10,settingDefaults.timer.musicStartVolume,v=>v+'%');
 const timerStepVolume=miniStep('pdTimerStepVolume',0,50,5,settingDefaults.timer.musicStepVolume,v=>'+'+v+'%');
 const alarmSnooze=miniStep('pdAlarmSnoozeStep',1,60,1,7,v=>v+' min');
 const timerSnooze=miniStep('pdTimerSnoozeStep',1,60,1,7,v=>v+' min');
 // The hidden values maintain the existing save/start data contract.
 const bindSnooze=(id,holder,initial)=>{
  const box=holder.querySelector('.pdStepBox');
  const btns=box.querySelectorAll('button');
  const original=[btns[0].onclick,btns[1].onclick];
  btns.forEach((btn,i)=>btn.onclick=()=>{original[i]();$pd(id).value=holder===($pd('pdAlarmSnoozeStep'))?alarmSnooze.value:timerSnooze.value;});
  $pd(id).value=initial;
 };
 bindSnooze('pdSnoozeMinutes',$pd('pdAlarmSnoozeStep'),7);
 bindSnooze('pdTimerSnoozeMinutes',$pd('pdTimerSnoozeStep'),7);
 let alarmMusicAfter=0,timerMusicAfter=0;
 const displayAfter=(n)=>n+' '+(n===1?'snooze':'snoozes');
 const setAlarmAfter=v=>{alarmMusicAfter=within(v,0,99);$pd('pdMusicDelayText').textContent=displayAfter(alarmMusicAfter);$pd('pdMusicMinus').disabled=alarmMusicAfter===0;$pd('pdMusicPlus').disabled=alarmMusicAfter===99;};
 const setTimerAfter=v=>{timerMusicAfter=within(v,0,99);$pd('pdTimerMusicDelayText').textContent=displayAfter(timerMusicAfter);$pd('pdTimerMusicMinus').disabled=timerMusicAfter===0;$pd('pdTimerMusicPlus').disabled=timerMusicAfter===99;
  storeLocal('pavdroid-timer-music',{...readLocal('pavdroid-timer-music',{}),after:timerMusicAfter});};
 $pd('pdMusicMinus').onclick=()=>setAlarmAfter(alarmMusicAfter-1);
 $pd('pdMusicPlus').onclick=()=>setAlarmAfter(alarmMusicAfter+1);
 $pd('pdTimerMusicMinus').onclick=()=>setTimerAfter(timerMusicAfter-1);
 $pd('pdTimerMusicPlus').onclick=()=>setTimerAfter(timerMusicAfter+1);
 setTimerAfter(readLocal('pavdroid-timer-music',{})?.after??0);
 $pd('pdMusic').addEventListener('change',()=>{$pd('pdMusicChooseRow').hidden=!$pd('pdMusic').checked;});
 $pd('pdTimerMusic').addEventListener('change',()=>{$pd('pdTimerMusicRow').hidden=!$pd('pdTimerMusic').checked;});
 const refreshMusicLabels=()=>{
  const label=selectedSong()?.label||'No song selected · Settings ⚙';
  $pd('pdMp3Name').textContent=label;$pd('pdTimerMp3Name').textContent=label;
 };
 // Settings is a modal, not a fifth tab. The existing four-tab layout stays intact.
 let previewActive=false, timerDefaultsChanged=false;
 const dialog=document.createElement('dialog');dialog.className='pdSettingsDialog';dialog.id='pdSettingsDialog';
 dialog.innerHTML=`<div class="dialogheader"><h2>Settings</h2><button class="small ghost" id="pdSettingsClose">Done</button></div>
 <div class="dialoginner">
 <section><h3>♫ Music</h3><div id="pdMusicLibrary"></div><button class="small" id="pdAddMusic">+ Add Music</button><div class="pdMiniStepper"><span>Preview volume</span><div class="pdStepBox"><button type="button" id="pdPreviewMinus">−</button><output id="pdPreviewValue">100%</output><button type="button" id="pdPreviewPlus">+</button></div></div><div class="actions"><button id="pdPreviewPlay">Preview selected</button><button id="pdPreviewStop" class="ghost">Stop</button></div></section>
 <section><h3>Watch</h3><div class="actions"><button class="small" id="pdTestBuzz">Test Buzz</button><button class="small" id="pdTestBeep">Test Beep</button></div><div class="pdMiniStepper"><span>Test zap intensity</span><div id="pdTestZapIntensity"></div></div><button class="small ghost pdTestZapBtn" id="pdTestZap">Test Zap</button></section>
 <section><h3>Defaults</h3><p class="smalltext">Auto-saved · New alarms and timers only</p><div id="pdDefaultControls"></div></section>
 <section><h3>About</h3><p class="smalltext">PavDroid V1.0.7 · Android · Project RCC</p><p class="smalltext">Independent companion for Pavlok Shock Clock 3. Not affiliated with or endorsed by Pavlok.</p></section>
 </div>`;
 document.body.append(dialog);
 $pd('pdSettingsBtn').onclick=()=>{renderLibrary();renderDefaultControls();timerDefaultsChanged=false;dialog.showModal();};
 $pd('pdSettingsClose').onclick=()=>{AndroidUi.stopMusicPreview();previewActive=false;if(timerDefaultsChanged)applyTimerDefaultsIfReady();dialog.close();};
 dialog.addEventListener('close',()=>{AndroidUi.stopMusicPreview();previewActive=false;if(timerDefaultsChanged)applyTimerDefaultsIfReady();});
 let previewVolume=within(readLocal('pavdroid-preview-volume-v107',readLocal('pavdroid-timer-volume-v104',100)),10,100);
 const renderPreview=()=>{$pd('pdPreviewValue').textContent=previewVolume+'%';$pd('pdPreviewMinus').disabled=previewVolume<=10;$pd('pdPreviewPlus').disabled=previewVolume>=100;
  storeLocal('pavdroid-preview-volume-v107',previewVolume);AndroidUi.setMusicPreviewVolume(previewVolume);};
 $pd('pdPreviewMinus').onclick=()=>{previewVolume=Math.max(10,previewVolume-10);renderPreview();};
 $pd('pdPreviewPlus').onclick=()=>{previewVolume=Math.min(100,previewVolume+10);renderPreview();};
 $pd('pdPreviewPlay').onclick=()=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before previewing music.');return;}
  if(!selectedSong()){showWarning('Add and select a song first.');return;}
  previewActive=true;AndroidUi.previewMusic(selectedSong().uri,previewVolume);
 };
 $pd('pdPreviewStop').onclick=()=>{previewActive=false;AndroidUi.stopMusicPreview();};renderPreview();
 $pd('pdAddMusic').onclick=()=>{window.__pdMp3Destination='library';AndroidUi.pickMp3(library.selectedUri||'');};
 function renderLibrary(){
  const host=$pd('pdMusicLibrary');host.replaceChildren();
  if(!library.tracks.length){const p=document.createElement('p');p.className='smalltext';p.textContent='No music imported.';host.append(p);}
  for(const song of library.tracks){
   const item=document.createElement('div');item.className='pdTrackRow';
   const label=document.createElement('label');const radio=document.createElement('input');radio.type='radio';radio.name='pdSong';radio.checked=song.uri===library.selectedUri;
   radio.onchange=()=>{library.selectedUri=song.uri;librarySave();};
   const name=document.createElement('span');name.textContent=song.label;label.append(radio,name);item.append(label);
   const remove=document.createElement('button');remove.type='button';remove.textContent='Remove';remove.className='small ghost';
   remove.onclick=()=>{library.tracks=library.tracks.filter(t=>t.uri!==song.uri);if(library.selectedUri===song.uri)library.selectedUri=library.tracks[0]?.uri||'';librarySave();};
   item.append(remove);host.append(item);
  }
 }
 const oldMp3Handler=onMp3Picked;
 onMp3Picked=function(uri,label){
  if(!uri?.startsWith('content://'))return;
  if(!library.tracks.some(t=>t.uri===uri))library.tracks.push({uri,label:label||'Selected MP3'});
  library.selectedUri=uri;librarySave();
 };
 // The established below-15% battery color behavior remains in the base UI.
 const testWatch=async(type,pct)=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before testing the watch.');return;}
  if(!isOn()){showWarning('Connect the watch first.');return;}
  if(type==='zap'&&!await askConfirmation('Send one '+pct+'% test zap to the watch?'))return;
  try{await immediate({type},pct);}catch(e){showWarning(e.message);}
 };
 $pd('pdTestBuzz').onclick=()=>testWatch('buzz',30);
 $pd('pdTestBeep').onclick=()=>testWatch('beep',30);
 const testZap=makeStepper($pd('pdTestZapIntensity'),10,100,10,
  readLocal('pavdroid-test-zap-pct-v107',10),v=>v+'%',v=>{storeLocal('pavdroid-test-zap-pct-v107',v);});
 $pd('pdTestZap').onclick=()=>testWatch('zap',testZap.value);
 // Defaults update immediately, with units and the same +/- control style.
 const persistDefaults=()=>storeLocal(defaultKey,settingDefaults);
 function renderDefaultControls(){
  const root=$pd('pdDefaultControls');root.replaceChildren();
  const fields=[['buzz','Buzzes',0,5,1,v=>String(v)],['beep','Beeps',0,5,1,v=>String(v)],
   ['zaps','Zaps',0,5,1,v=>String(v)],['interval','Interval',5,30,1,v=>v+'s'],
   ['intensity','Zap intensity',10,100,10,v=>v+'%'],['snooze','Snooze',1,60,1,v=>v+' min'],
   ['musicStartVolume','Music start',10,100,10,v=>v+'%'],['musicStepVolume','Music / snooze',0,50,5,v=>'+'+v+'%']];
  for(const type of ['alarm','timer']){
   const title=document.createElement('h3');title.textContent=type==='alarm'?'New alarms':'New timers';title.className='pdDefaultTitle';root.append(title);
   const grid=document.createElement('div');grid.className='pdDefaultsGrid';root.append(grid);
   for(const [key,label,min,max,step,format] of fields){
    const field=document.createElement('div');field.className='pdDefaultsField';
    const caption=document.createElement('label');caption.textContent=label;
    const holder=document.createElement('div');holder.id='pdDefault-'+type+'-'+key;
    field.append(caption,holder);grid.append(field);
    makeStepper(holder,min,max,step,settingDefaults[type][key],format,v=>{
     if(['buzz','beep','zaps'].includes(key)){
      const candidate={...settingDefaults[type],[key]:v};
      if(candidate.buzz+candidate.beep+candidate.zaps===0){showWarning('Keep at least one buzz, beep, or zap.');return false;}
     }
     settingDefaults[type][key]=v;persistDefaults();if(type==='timer')timerDefaultsChanged=true;return true;
    });
   }
   const smart=document.createElement('label');smart.className='check pdDefaultSmart';
   smart.innerHTML='<input type="checkbox"> Smart Timeout';
   const toggle=smart.querySelector('input');toggle.checked=settingDefaults[type].smart!==false;
   toggle.onchange=()=>{settingDefaults[type].smart=toggle.checked;persistDefaults();if(type==='timer')timerDefaultsChanged=true;};
   root.append(smart);
  }
 }
 if(library.migrated||library.tracks.length)librarySave();
 else {renderLibrary();refreshMusicLabels();}
 // Initialize timer setup from saved defaults, without changing an active timer.
 function applyTimerDefaultsIfReady(){
 if(nativeTimerPhase()==='ready'){
  const d=settingDefaults.timer;
  for(const [key,id] of [['buzz','timerBuzzCount'],['beep','timerBeepCount'],['zaps','timerZapCount'],['intensity','timerZapMax']])
   $pd(id).value=d[key];
  pref.timerInterval=d.interval;renderTimerInterval();renderTimerSeq();
  timerSnooze.set(d.snooze);$pd('pdTimerSnoozeMinutes').value=timerSnooze.value;$pd('pdTimerSmart').checked=d.smart!==false;
  timerStartVolume.set(d.musicStartVolume);timerStepVolume.set(d.musicStepVolume);
 }timerDefaultsChanged=false;
 }
 applyTimerDefaultsIfReady();
 // Alarm editor and scheduled card visuals are literally the V3.0.3 elements.
 const originalShowEditor=showEditor;
 showEditor=function(i=-1,copy=false,plus30=false){
  originalShowEditor(i,copy,plus30);updateSegment();
  const selected=i>=0?app.alarms?.[i]:null;
  $pd('pdSmartTimeout').checked=selected?.smartTimeout??settingDefaults.alarm.smart;
  $pd('pdMusic').checked=!!selected?.music;
  $pd('pdMusicChooseRow').hidden=!$pd('pdMusic').checked;
  alarmSnooze.set(selected?.snoozeMinutes??settingDefaults.alarm.snooze);
  $pd('pdSnoozeMinutes').value=alarmSnooze.value;
  setAlarmAfter(selected?.musicAfterSnoozes??0);
  startVolume.set(selected?.musicStartVolume??(selected?100:settingDefaults.alarm.musicStartVolume));
  stepVolume.set(selected?.musicStepVolume??(selected?0:settingDefaults.alarm.musicStepVolume));
  if(!selected){
   for(const [key,id] of [['buzz','editBuzzCount'],['beep','editBeepCount'],['zaps','editZapCount'],['intensity','editZapMax']]){
    $pd(id).value=settingDefaults.alarm[key];$pd(id).dispatchEvent(new Event('input',{bubbles:true}));
   }
   app.editorInterval=settingDefaults.alarm.interval;renderIntervalStepper();renderEditSeq();
  }
  refreshMusicLabels();
 };
 alarmChangeIsUnsafe=function(){return native.snapshot()?.active===true;};
 const originalRefreshConnection=refreshConnection;
 refreshConnection=function(){originalRefreshConnection();const disabled=alarmChangeIsUnsafeIncludingTimer()||app.busy;
  $pd('newAlarmBtn').disabled=disabled;
  $pd('readAlarmsBtn').disabled=false;
  for(const b of document.querySelectorAll('[data-alarm-action]'))b.disabled=disabled;
  const s=native.snapshot(),active=!!s?.active;
  $pd('snoozeAlarmBtn').disabled=!active||s.phase!=='firing';
  $pd('stopAlarmBtn').disabled=!active;
  // Timer is phone-controlled, but direct watch output still requires BLE.
  $pd('timerStartBtn').disabled=app.busy||!isOn()||nativeTimerPhase()!=='ready'||active;
 };
 readAlarms=async function(skipListRender=false){
  app.alarms=native.list();app.alarmsTrusted=true;
  if(!library.migrated){
   for(const alarm of app.alarms){
    if(alarm.musicUri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===alarm.musicUri))
     library.tracks.push({uri:alarm.musicUri,label:alarm.musicLabel||'Saved alarm MP3'});
   }
   if(!library.selectedUri&&library.tracks.length)library.selectedUri=library.tracks[0].uri;
   library.migrated=true;librarySave();
  }
  $pd('alarmSyncLabel').textContent=app.alarms.length+' on phone';
  $pd('emptyConfirmWrap').hidden=true;
  if(!skipListRender)renderAlarms();refreshConnection();return app.alarms;
 };
 writeAlarms=async function(next,reason,revealIndex=null){
  if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is currently in progress.');
  const saved=await native.save(next);
  app.alarms=saved;app.alarmsTrusted=true;
  renderAlarms(revealIndex);refreshConnection();
  $pd('alarmOpStatus').textContent=reason+(native.exactAccess()?' · saved on Android.':' · saved, but precise alarm permission is required.');
  refreshExactAccess();
  return true;
 };
 alarmAction=async function(i,act){
  if(blockAlarmChangeWhileActive())return;
  if(act==='edit')return showEditor(i);
  if(act==='copy'||act==='copy30')return showEditor(i,true,act==='copy30');
  const next=app.alarms.map(a=>({...a}));if(!next[i])return;
  if(act==='toggle')next[i].enabled=!next[i].enabled;
  else if(act==='delete'){
   if(!await askConfirmation('Delete '+next[i].name+' · '+humanTime(next[i].time)+' from Android?'))return;
   next.splice(i,1);
  }
  try{await writeAlarms(next,act==='delete'?'Alarm deleted':'Alarm updated');}
  catch(e){showWarning(e.message);}
 };
 saveEditor=async function(){
  if(blockAlarmChangeWhileActive())return;
  try{
   const a=editData();
   a.smartTimeout=$pd('pdSmartTimeout').checked;
   a.music=$pd('pdMusic').checked;
   a.musicUri=selectedSong()?.uri||'';a.musicLabel=selectedSong()?.label||'';
   a.snoozeMinutes=Number($pd('pdSnoozeMinutes').value);
   a.musicDelay=10;a.musicAfterSnoozes=alarmMusicAfter;
   a.musicStartVolume=startVolume.value;a.musicStepVolume=stepVolume.value;
   if(!Number.isInteger(a.snoozeMinutes)||a.snoozeMinutes<1||a.snoozeMinutes>60)throw Error('Snooze duration must be 1–60 minutes.');
   if(a.music&&!a.musicUri)throw Error('Choose a song in Settings first.');
   const next=app.alarms.map(x=>({...x}));
   if(app.editorIndex>=0){if(!next[app.editorIndex])throw Error('Alarm list changed');next[app.editorIndex]=a;}
   else {a.enabled=true;next.push(a);}
   await writeAlarms(next,'Alarm saved',app.editorIndex<0?next.length-1:null);
   $pd('alarmEditor').close();
  }catch(e){showWarning(e.message);}
 };
 // Replace only the button handlers which formerly sent firmware packets.
 $pd('saveEditorBtn').onclick=()=>saveEditor();
 $pd('newAlarmBtn').onclick=()=>showEditor();
 $pd('readAlarmsBtn').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();readAlarms();}};
 $pd('confirmEmptyBtn').onclick=()=>{};
 $pd('snoozeAlarmBtn').onclick=async()=>{try{await native.action('snooze');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 $pd('stopAlarmBtn').onclick=async()=>{try{await native.action('stop');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 alarmButton=async(which)=>{try{await native.action(which);refreshAlarmSession();}catch(e){showWarning(e.message);}};
 // Preserve V3.0.3 duration keypad, preset row, count +/- controls, slider,
 // countdown face and all timer status/snooze/stop buttons. Only routing changes.
 timerCommand=async function(action){
  try{
   if(action==='start'){
    if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is already in progress.');
    const cfg={seconds:duration(),buzz:count('timerBuzzCount',5),beep:count('timerBeepCount',5),
      zaps:count('timerZapCount',5),intensity:Number($pd('timerZapMax').value),
      interval:pref.timerInterval,snoozeSeconds:withinUi($pd('pdTimerSnoozeMinutes').value,1,60)*60,
      musicDelay:10,musicAfterSnoozes:timerMusicAfter,
      musicStartVolume:timerStartVolume.value,musicStepVolume:timerStepVolume.value,
      smartTimeout:$pd('pdTimerSmart').checked,music:$pd('pdTimerMusic').checked,
      musicUri:selectedSong()?.uri||''};
    if(cfg.buzz+cfg.beep+cfg.zaps===0)throw Error('Select at least one stimulus.');
    if(cfg.music&&!cfg.musicUri)throw Error('Choose a song in Settings first.');
    await nativeTimerAction('start',cfg);
    if($pd('timerConfirmBuzz').checked&&isOn())try{await immediate({type:'buzz'},30);}catch(_){}
   }else if(action==='snooze')await nativeTimerAction('snooze');
   else await nativeTimerAction(action);
   syncNativeTimer(false);refreshConnection();
  }catch(e){message('timerWriteStatus',e.message,true);}
 };
 function withinUi(value,lo,hi){const n=Number(value);if(!Number.isInteger(n)||n<lo||n>hi)throw Error('Choose a value between '+lo+' and '+hi);return n;}
 $pd('timerStartBtn').onclick=()=>{dismissSoftKeyboard($pd('duration'));void timerCommand('start');};
 $pd('timerSnoozeBtn').onclick=()=>timerCommand('snooze');
 $pd('timerPauseBtn').onclick=()=>timerCommand('pause');
 $pd('timerResumeBtn').onclick=()=>timerCommand('resume');
 $pd('timerStopBtn').onclick=()=>timerCommand('reset');
 // Watch-reported firmware timer/status notifications cannot alter PavDroid UI.
 onAlarmNotify=function(){};
 onTimerConfig=function(){};
 function refreshAlarmSession(){
  const s=native.snapshot();if(previewActive&&(s?.active||nativeTimerPhase()!=='ready')){AndroidUi.stopMusicPreview();previewActive=false;}
  if(!s?.active){app.activeAlarm=null;app.snoozeUntil=null;
    alarmState('STATUS UNKNOWN','No Android alarm currently active','unknown');refreshConnection();return;}
  app.activeAlarm={id:s.id+1,firing:s.phase==='firing'};
  app.snoozes=s.snoozes||0;app.snoozeUntil=s.snoozeUntil||null;
  $pd('snoozeCount').textContent=String(s.snoozes||0);
  $pd('snoozeRemaining').textContent=s.snoozeUntil&&s.phase==='snoozing'?fmt((s.snoozeUntil-Date.now())/1000):'—';
  alarmState(s.phase==='firing'?'ALARM FIRING':'SNOOZING',s.name,s.phase==='firing'?'active-state':'snooze-state');
  $pd('activeName').textContent=s.name||'Active alarm';
  $pd('alarmState').textContent=s.phase==='firing'?'ALARM FIRING':
   `SNOOZING (${s.snoozes||0}) · ${fmt((s.snoozeUntil-Date.now())/1000)} left`;
  refreshConnection();
 }
 const originalDrop=onDrop;
 onDrop=function(){originalDrop();setPavDroidBattery(null);};
 const baseTab=tab;
 tab=function(name){baseTab(name);if(name==='alarms')readAlarms();};
 readAlarms();refreshAlarmSession();
 setInterval(refreshAlarmSession,1000);
 // The connection page is unchanged in layout, but its labels are accurate.
 $pd('connectionHealth').textContent='Android schedules alarms. Bluetooth sends watch stimuli.';
})();
