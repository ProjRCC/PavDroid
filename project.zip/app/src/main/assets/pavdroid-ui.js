/* PavDroid adapter to ORIGINAL Pavlok Control V3.0.3 interface.
   This file does not recreate the timer, alarm cards, steppers, keypad,
   sliders, dialogs, navigation, or History layout. */
'use strict';
(function(){
 if(!window.PavDroidNative)throw Error('PavDroid native alarm bridge is missing');
 const $pd=id=>document.getElementById(id);
 const native=window.PavDroidNative;
 // Original watch-alarm and Code Red controls remain available in the source
 // for reference but are NEVER displayed or executed in PavDroid.
 const old=$pd('alarmEditor').querySelector('.codeRedSection');old.style.display='none';
 const defaultKey='pavdroid-defaults-v104';
 const defaultValues={alarm:{buzz:5,beep:5,zaps:1,interval:8,intensity:40,snooze:7,smart:true},
                      timer:{buzz:3,beep:3,zaps:1,interval:8,intensity:40,snooze:7,smart:true}};
 const settingDefaults=Object.assign({},defaultValues,readLocal(defaultKey,{}));
 for(const type of ['alarm','timer'])settingDefaults[type]={...defaultValues[type],...(settingDefaults[type]||{})};
 const within=(x,min,max)=>Math.max(min,Math.min(max,Math.round(Number(x)||0)));
 const libraryKey='pavdroid-music-library-v104';
 let library=readLocal(libraryKey,{tracks:[],selectedUri:''})||{tracks:[],selectedUri:''};
 if(!Array.isArray(library.tracks))library.tracks=[];
 // One-time migration of the last selected MP3 and timer MP3; no files are moved.
 if(!library.tracks.length){
  for(const item of [readLocal(lastMp3Key,{}),readLocal('pavdroid-timer-music',{})]){
   if(item?.uri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===item.uri))
    library.tracks.push({uri:item.uri,label:item.label||'Selected MP3'});
  }
  if(!library.selectedUri)library.selectedUri=library.tracks[0]?.uri||'';
 }
 const selectedSong=()=>library.tracks.find(t=>t.uri===library.selectedUri);
 const librarySave=()=>{
  storeLocal(libraryKey,library);
  try{AndroidUi.setSelectedMusicUri(library.selectedUri||'');}catch(e){console.warn('Music sync:',e)}
  refreshMusicLabels();renderLibrary();
 };
 const extras=document.createElement('div');extras.className='pavdroidExtra';
 extras.innerHTML=`<div class="pdOption"><label class="check"><input type="checkbox" id="pdSmartTimeout" checked>Smart Timeout</label></div>
  <div class="pdOption"><label class="check"><input type="checkbox" id="pdMusic">Include Music</label>
   <div id="pdMusicChooseRow" hidden><p class="smalltext" id="pdMp3Name">Choose a song in Settings</p>
    <div id="pdMusicAfterRow" class="pdMiniStepper"><span>Play after</span><button type="button" id="pdMusicMinus" aria-label="Fewer snoozes">−</button><b id="pdMusicDelayText">0 snoozes</b><button type="button" id="pdMusicPlus" aria-label="More snoozes">+</button></div>
    <div class="pdDefaultRow" style="margin-top:12px;grid-template-columns:1fr 1fr"><div><label class="field">Start volume</label><div id="pdStartVolume"></div></div><div><label class="field">Increase per snooze</label><div id="pdStepVolume"></div></div></div>
    <p class="smalltext">Music starts 10s into eligible firings.</p></div></div>`;
 old.after(extras);
 const foot=document.createElement('div');foot.className='pdSnoozeBottom';
 foot.innerHTML=`<div class="alarmEditorFields"><label class="field">Snooze (minutes)<input id="pdSnoozeMinutes" type="number" inputmode="numeric" min="1" max="60" value="7"></label></div>`;
 const existingEnabled=$pd('editEnabled');existingEnabled.closest('label').hidden=true;
 existingEnabled.closest('label').after(foot);
 const editorText=$pd('alarmEditor').querySelector('.quiet');if(editorText)editorText.textContent='';
 $pd('saveEditorBtn').textContent='Save alarm';
 $pd('deleteTitle').textContent='Delete alarm?';
 $pd('alarmSyncLabel').removeAttribute('title');$pd('alarmSyncLabel').removeAttribute('aria-label');
 $pd('alarmOpStatus').textContent='';
 const exactNotice=document.createElement('p');exactNotice.className='quiet';exactNotice.id='pdExactNotice';
 exactNotice.innerHTML='Precise alarms permission needed. <button type="button" class="small ghost" id="pdExactSettings">Allow</button>';
 $pd('alarmOpStatus').after(exactNotice);
 $pd('pdExactSettings').onclick=()=>AndroidUi.openExactAlarmSettings();
 const refreshExactAccess=()=>{exactNotice.hidden=native.exactAccess();};
 refreshExactAccess();document.addEventListener('visibilitychange',refreshExactAccess);
 window.addEventListener('focus',refreshExactAccess);
 $pd('alarmList').textContent='No alarms saved.';$pd('emptyConfirmWrap').hidden=true;
 const settings=document.createElement('div');settings.className='pavdroidExtra';
 settings.innerHTML=`<div class="pdOption"><label class="check"><input id="pdTimerSmart" type="checkbox" checked>Smart Timeout</label></div>
  <div class="pdOption"><label class="check"><input id="pdTimerMusic" type="checkbox">Include Music</label>
   <div id="pdTimerMusicRow" hidden><p id="pdTimerMp3Name" class="smalltext">Choose a song in Settings</p>
    <div class="pdMiniStepper"><span>Play after</span><button type="button" id="pdTimerMusicMinus" aria-label="Fewer snoozes">−</button><b id="pdTimerMusicDelayText">0 snoozes</b><button type="button" id="pdTimerMusicPlus" aria-label="More snoozes">+</button></div>
    <p class="smalltext">Starts 10s into eligible alerts.</p></div></div>
  <div class="alarmEditorFields"><label class="field">Snooze (minutes)<input id="pdTimerSnoozeMinutes" inputmode="numeric" type="number" min="1" max="60" value="7"></label></div>`;
 $pd('timerSetup').append(settings);
 const style=document.createElement('style');style.textContent=`.pavdroidExtra{padding:0;margin:13px 0}.pdOption{border:1px solid #364c65;border-radius:12px;padding:12px 13px;margin-bottom:10px;background:#172334}.pdOption p.smalltext{font-size:11px;margin:7px 0 0;color:#b1c2d6}.pdSnoozeBottom{margin-top:13px}.pdSnoozeBottom .alarmEditorFields{margin-top:0}.pdSnoozeBottom input{font-size:16px}#pdMusicChooseRow,#pdTimerMusicRow{margin-top:9px}.pavdroidExtra .check{min-height:22px}.pdOption .pdDefaultRow{display:grid;grid-template-columns:1fr 1fr}`;document.head.append(style);
 const miniStep=(id,min,max,step,initial,format)=>{
  const holder=$pd(id);let value=within(initial,min,max);
  const row=document.createElement('div');row.className='pdMiniStepper';
  const minus=document.createElement('button');minus.type='button';minus.textContent='−';
  const display=document.createElement('b');display.textContent=format(value);
  const plus=document.createElement('button');plus.type='button';plus.textContent='+';
  holder.replaceChildren(row);row.append(minus,display,plus);
  const set=v=>{value=Math.max(min,Math.min(max,Math.round(v/step)*step));display.textContent=format(value);
                  minus.disabled=value===min;plus.disabled=value===max;};
  minus.onclick=()=>set(value-step);plus.onclick=()=>set(value+step);set(value);
  return {get value(){return value},set};
 };
 const startVolume=miniStep('pdStartVolume',10,100,10,30,v=>v+'%');
 const stepVolume=miniStep('pdStepVolume',0,50,5,20,v=>'+'+v+'%');
 let alarmMusicAfter=0,timerMusicAfter=0;
 const displayAfter=(n)=>n+' '+(n===1?'snooze':'snoozes');
 const setAlarmAfter=v=>{$pd('pdMusicDelayText').textContent=displayAfter(alarmMusicAfter=within(v,0,99));};
 const setTimerAfter=v=>{$pd('pdTimerMusicDelayText').textContent=displayAfter(timerMusicAfter=within(v,0,99));
  storeLocal('pavdroid-timer-music',{...readLocal('pavdroid-timer-music',{}),after:timerMusicAfter});};
 $pd('pdMusicMinus').onclick=()=>setAlarmAfter(alarmMusicAfter-1);
 $pd('pdMusicPlus').onclick=()=>setAlarmAfter(alarmMusicAfter+1);
 $pd('pdTimerMusicMinus').onclick=()=>setTimerAfter(timerMusicAfter-1);
 $pd('pdTimerMusicPlus').onclick=()=>setTimerAfter(timerMusicAfter+1);
 setTimerAfter(readLocal('pavdroid-timer-music',{})?.after??0);
 $pd('pdMusic').addEventListener('change',()=>{$pd('pdMusicChooseRow').hidden=!$pd('pdMusic').checked;});
 $pd('pdTimerMusic').addEventListener('change',()=>{$pd('pdTimerMusicRow').hidden=!$pd('pdTimerMusic').checked;});
 const refreshMusicLabels=()=>{
  const label=selectedSong()?.label||'No song selected · Settings ⚙';
  $pd('pdMp3Name').textContent=label;$pd('pdTimerMp3Name').textContent=label;
 };
 // Settings is a modal, not a fifth tab. The existing four-tab layout stays intact.
 const dialog=document.createElement('dialog');dialog.className='pdSettingsDialog';dialog.id='pdSettingsDialog';
 dialog.innerHTML=`<div class="dialogheader"><h2>Settings</h2><button class="small ghost" id="pdSettingsClose">Done</button></div>
 <div class="dialoginner">
 <section><h3>♫ Music</h3><div id="pdMusicLibrary"></div><button class="small" id="pdAddMusic">+ Add Music</button><div class="pdMiniStepper"><span>Timer / Preview volume</span><button id="pdPreviewMinus">−</button><b id="pdPreviewValue">50%</b><button id="pdPreviewPlus">+</button></div><div class="actions"><button id="pdPreviewPlay">Play selected</button><button id="pdPreviewStop" class="ghost">Stop</button></div></section>
 <section><h3>Watch</h3><label class="field">Low battery warning in app (%)<input type="number" id="pdBatteryWarning" min="5" max="50" step="5" value="15"></label><p class="smalltext">Battery text stays red below 15%.</p><div class="actions"><button class="small" id="pdTestBuzz">Test Buzz</button><button class="small" id="pdTestBeep">Test Beep</button><button class="small ghost" id="pdTestZap">Test Zap 10%</button></div><p class="smalltext">Bluetooth status and logs: Connection tab.</p></section>
 <section><h3>Notifications</h3><div class="actions"><button class="small" id="pdNotifAlarm">Alarm</button><button class="small" id="pdNotifTimer">Timer</button><button class="small" id="pdNotifWatch">Connection</button><button class="small ghost" id="pdNotifAll">All</button></div><p class="smalltext">Android controls sounds and appearance.</p></section>
 <section><h3>Defaults</h3><p class="smalltext">Used for new alarms and new timers only.</p><div id="pdDefaultControls"></div><div class="actions"><button id="pdSaveDefaults" class="primary">Save defaults</button></div><p class="smalltext" id="pdDefaultsStatus" role="status"></p></section>
 <section><h3>About</h3><p class="smalltext">PavDroid V1.0.4 · Android · Project RCC</p><p class="smalltext">Independent companion for Pavlok Shock Clock 3. Not affiliated with or endorsed by Pavlok.</p></section>
 </div>`;
 document.body.append(dialog);
 $pd('pdSettingsBtn').onclick=()=>{renderLibrary();renderDefaultControls();dialog.showModal();};
 $pd('pdSettingsClose').onclick=()=>{AndroidUi.stopMusicPreview();dialog.close();};
 dialog.addEventListener('close',()=>AndroidUi.stopMusicPreview());
 let previewVolume=within(readLocal('pavdroid-timer-volume-v104',100),10,100);
 const renderPreview=()=>{$pd('pdPreviewValue').textContent=previewVolume+'%';storeLocal('pavdroid-timer-volume-v104',previewVolume);AndroidUi.setTimerMusicVolume(previewVolume);};
 $pd('pdPreviewMinus').onclick=()=>{previewVolume=Math.max(10,previewVolume-10);renderPreview();};
 $pd('pdPreviewPlus').onclick=()=>{previewVolume=Math.min(100,previewVolume+10);renderPreview();};
 $pd('pdPreviewPlay').onclick=()=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before previewing music.');return;}
  if(!selectedSong()){showWarning('Add and select a song first.');return;}
  AndroidUi.previewMusic(selectedSong().uri,previewVolume);
 };
 $pd('pdPreviewStop').onclick=()=>AndroidUi.stopMusicPreview();renderPreview();
 $pd('pdAddMusic').onclick=()=>{window.__pdMp3Destination='library';AndroidUi.pickMp3(library.selectedUri||'');};
 function renderLibrary(){
  const host=$pd('pdMusicLibrary');host.replaceChildren();
  if(!library.tracks.length){const p=document.createElement('p');p.className='smalltext';p.textContent='No music imported.';host.append(p);}
  for(const song of library.tracks){
   const item=document.createElement('div');item.className='pdTrackRow';
   const label=document.createElement('label');const radio=document.createElement('input');radio.type='radio';radio.name='pdSong';radio.checked=song.uri===library.selectedUri;
   radio.onchange=()=>{library.selectedUri=song.uri;librarySave();};
   const name=document.createElement('span');name.textContent=song.label;label.append(radio,name);item.append(label);
   const remove=document.createElement('button');remove.type='button';remove.textContent='Remove';remove.className='small ghost';
   remove.onclick=()=>{library.tracks=library.tracks.filter(t=>t.uri!==song.uri);if(library.selectedUri===song.uri)library.selectedUri=library.tracks[0]?.uri||'';librarySave();};
   item.append(remove);host.append(item);
  }
 }
 const oldMp3Handler=onMp3Picked;
 onMp3Picked=function(uri,label){
  if(!uri?.startsWith('content://'))return;
  if(!library.tracks.some(t=>t.uri===uri))library.tracks.push({uri,label:label||'Selected MP3'});
  library.selectedUri=uri;librarySave();
 };
 const batteryStored=readLocal('pavdroid-watch-settings-v104',{});
 $pd('pdBatteryWarning').value=batteryStored.warning??15;
 $pd('pdBatteryWarning').onchange=()=>{const value=within($pd('pdBatteryWarning').value,5,50);$pd('pdBatteryWarning').value=value;
  storeLocal('pavdroid-watch-settings-v104',{warning:value});};
 // Warning text is connection-only. Existing hardcoded red-below-15% battery styling stays unchanged.
 const batteryAlert=document.createElement('p');batteryAlert.className='smalltext caution';batteryAlert.id='pdBatteryAlert';
 $pd('connectionHealth').after(batteryAlert);
 let lastBattery=null;
 const previousBattery=setPavDroidBattery;
 setPavDroidBattery=function(value){
  previousBattery(value);lastBattery=value;
  const n=Number(value),limit=within($pd('pdBatteryWarning').value,5,50);
  batteryAlert.textContent=value!==null && value!==undefined && Number.isInteger(n)&&n>=0&&n<limit?
   'Low watch battery · '+n+'% (warning at '+limit+'%)':'';
  batteryAlert.hidden=!batteryAlert.textContent;
 };
 $pd('pdBatteryWarning').addEventListener('change',()=>setPavDroidBattery(lastBattery));
 setPavDroidBattery(null);
 const testWatch=async(type,pct)=>{
  if(alarmChangeIsUnsafeIncludingTimer()){showWarning('Stop the current alarm or timer before testing the watch.');return;}
  if(!isOn()){showWarning('Connect the watch first.');return;}
  if(type==='zap'&&!await askConfirmation('Send one 10% test zap to the watch?'))return;
  try{await immediate({type},pct);}catch(e){showWarning(e.message);}
 };
 $pd('pdTestBuzz').onclick=()=>testWatch('buzz',30);
 $pd('pdTestBeep').onclick=()=>testWatch('beep',30);
 $pd('pdTestZap').onclick=()=>testWatch('zap',10);
 $pd('pdNotifAlarm').onclick=()=>AndroidUi.openNotificationSettings('pavdroid_active_alarm');
 $pd('pdNotifTimer').onclick=()=>AndroidUi.openNotificationSettings('pavlok_timer_finished_v218');
 $pd('pdNotifWatch').onclick=()=>AndroidUi.openNotificationSettings('pavlok_ble_monitor_v208');
 $pd('pdNotifAll').onclick=()=>AndroidUi.openNotificationSettings('');
 function renderDefaultControls(){
  const root=$pd('pdDefaultControls');root.replaceChildren();
  for(const type of ['alarm','timer']){
   const title=document.createElement('h3');title.textContent=type==='alarm'?'New alarms':'New timers';title.style.marginTop='14px';root.append(title);
   const grid=document.createElement('div');grid.className='pdDefaultRow';grid.style.gridTemplateColumns='repeat(3,1fr)';
   for(const [key,label] of [['buzz','Buzzes'],['beep','Beeps'],['zaps','Zaps'],['interval','Interval (s)'],['intensity','Zap (%)'],['snooze','Snooze (m)']]){
    const field=document.createElement('label');field.textContent=label;
    const input=document.createElement('input');input.type='number';input.inputMode='numeric';input.id='pdDefault-'+type+'-'+key;
    const min=key==='intensity'?10:key==='interval'?5:key==='snooze'?1:0;
    const max=key==='intensity'?100:key==='interval'?30:key==='snooze'?60:5;
    input.min=min;input.max=max;input.step=key==='intensity'?10:1;input.value=settingDefaults[type][key];
    field.append(input);grid.append(field);
   }
   root.append(grid);
   const smart=document.createElement('label');smart.className='check';
   smart.innerHTML='<input type="checkbox" id="pdDefault-'+type+'-smart"> Smart Timeout';
   root.append(smart);smart.querySelector('input').checked=settingDefaults[type].smart!==false;
  }
 }
 $pd('pdSaveDefaults').onclick=()=>{
  for(const type of ['alarm','timer']){
   const next={};
   for(const key of ['buzz','beep','zaps','interval','intensity','snooze']){
    const element=$pd('pdDefault-'+type+'-'+key);const n=Number(element.value);
    if(!Number.isInteger(n)||n<Number(element.min)||n>Number(element.max)||(key==='intensity'&&n%10!==0)){
     showWarning('Check '+type+' '+key+' default.');return;
    }
    next[key]=n;
   }
   if(next.buzz+next.beep+next.zaps===0){showWarning('At least one stimulus is needed for '+type+'.');return;}
   next.smart=$pd('pdDefault-'+type+'-smart').checked;
   settingDefaults[type]=next;
  }
  storeLocal(defaultKey,settingDefaults);
  $pd('pdDefaultsStatus').textContent='Saved · existing alarms unchanged.';
 };
 if(library.migrated||library.tracks.length)librarySave();
 else {renderLibrary();refreshMusicLabels();}
 // Initialize timer setup from saved defaults, without changing an active timer.
 if(nativeTimerPhase()==='ready'){
  const d=settingDefaults.timer;
  for(const [key,id] of [['buzz','timerBuzzCount'],['beep','timerBeepCount'],['zaps','timerZapCount'],['intensity','timerZapMax']])
   $pd(id).value=d[key];
  pref.timerInterval=d.interval;renderTimerInterval();renderTimerSeq();
  $pd('pdTimerSnoozeMinutes').value=d.snooze;$pd('pdTimerSmart').checked=d.smart!==false;
 }
 // Alarm editor and scheduled card visuals are literally the V3.0.3 elements.
 const originalShowEditor=showEditor;
 showEditor=function(i=-1,copy=false,plus30=false){
  originalShowEditor(i,copy,plus30);
  const selected=i>=0?app.alarms?.[i]:null;
  $pd('pdSmartTimeout').checked=selected?.smartTimeout??settingDefaults.alarm.smart;
  $pd('pdMusic').checked=!!selected?.music;
  $pd('pdMusicChooseRow').hidden=!$pd('pdMusic').checked;
  $pd('pdSnoozeMinutes').value=selected?.snoozeMinutes??settingDefaults.alarm.snooze;
  setAlarmAfter(selected?.musicAfterSnoozes??0);
  startVolume.set(selected?.musicStartVolume??(selected?100:30));stepVolume.set(selected?.musicStepVolume??(selected?0:20));
  if(!selected){
   for(const [key,id] of [['buzz','editBuzzCount'],['beep','editBeepCount'],['zaps','editZapCount'],['intensity','editZapMax']]){
    $pd(id).value=settingDefaults.alarm[key];$pd(id).dispatchEvent(new Event('input',{bubbles:true}));
   }
   app.editorInterval=settingDefaults.alarm.interval;renderIntervalStepper();renderEditSeq();
  }
  refreshMusicLabels();
 };
 alarmChangeIsUnsafe=function(){return native.snapshot()?.active===true;};
 const originalRefreshConnection=refreshConnection;
 refreshConnection=function(){originalRefreshConnection();const disabled=alarmChangeIsUnsafeIncludingTimer()||app.busy;
  $pd('newAlarmBtn').disabled=disabled;
  $pd('readAlarmsBtn').disabled=false;
  for(const b of document.querySelectorAll('[data-alarm-action]'))b.disabled=disabled;
  const s=native.snapshot(),active=!!s?.active;
  $pd('snoozeAlarmBtn').disabled=!active||s.phase!=='firing';
  $pd('stopAlarmBtn').disabled=!active;
  // Timer is phone-controlled, but direct watch output still requires BLE.
  $pd('timerStartBtn').disabled=app.busy||!isOn()||nativeTimerPhase()!=='ready'||active;
 };
 readAlarms=async function(skipListRender=false){
  app.alarms=native.list();app.alarmsTrusted=true;
  if(!library.migrated){
   for(const alarm of app.alarms){
    if(alarm.musicUri?.startsWith('content://')&&!library.tracks.some(t=>t.uri===alarm.musicUri))
     library.tracks.push({uri:alarm.musicUri,label:alarm.musicLabel||'Saved alarm MP3'});
   }
   if(!library.selectedUri&&library.tracks.length)library.selectedUri=library.tracks[0].uri;
   library.migrated=true;librarySave();
  }
  $pd('alarmSyncLabel').textContent=app.alarms.length+' on phone';
  $pd('emptyConfirmWrap').hidden=true;
  if(!skipListRender)renderAlarms();refreshConnection();return app.alarms;
 };
 writeAlarms=async function(next,reason,revealIndex=null){
  if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is currently in progress.');
  const saved=await native.save(next);
  app.alarms=saved;app.alarmsTrusted=true;
  renderAlarms(revealIndex);refreshConnection();
  $pd('alarmOpStatus').textContent=reason+(native.exactAccess()?' · saved on Android.':' · saved, but precise alarm permission is required.');
  refreshExactAccess();
  return true;
 };
 alarmAction=async function(i,act){
  if(blockAlarmChangeWhileActive())return;
  if(act==='edit')return showEditor(i);
  if(act==='copy'||act==='copy30')return showEditor(i,true,act==='copy30');
  const next=app.alarms.map(a=>({...a}));if(!next[i])return;
  if(act==='toggle')next[i].enabled=!next[i].enabled;
  else if(act==='delete'){
   if(!await askConfirmation('Delete '+next[i].name+' · '+humanTime(next[i].time)+' from Android?'))return;
   next.splice(i,1);
  }
  try{await writeAlarms(next,act==='delete'?'Alarm deleted':'Alarm updated');}
  catch(e){showWarning(e.message);}
 };
 saveEditor=async function(){
  if(blockAlarmChangeWhileActive())return;
  try{
   const a=editData();
   a.smartTimeout=$pd('pdSmartTimeout').checked;
   a.music=$pd('pdMusic').checked;
   a.musicUri=selectedSong()?.uri||'';a.musicLabel=selectedSong()?.label||'';
   a.snoozeMinutes=Number($pd('pdSnoozeMinutes').value);
   a.musicDelay=10;a.musicAfterSnoozes=alarmMusicAfter;
   a.musicStartVolume=startVolume.value;a.musicStepVolume=stepVolume.value;
   if(!Number.isInteger(a.snoozeMinutes)||a.snoozeMinutes<1||a.snoozeMinutes>60)throw Error('Snooze duration must be 1–60 minutes.');
   if(a.music&&!a.musicUri)throw Error('Choose a song in Settings first.');
   const next=app.alarms.map(x=>({...x}));
   if(app.editorIndex>=0){if(!next[app.editorIndex])throw Error('Alarm list changed');next[app.editorIndex]=a;}
   else {a.enabled=true;next.push(a);}
   await writeAlarms(next,'Alarm saved',app.editorIndex<0?next.length-1:null);
   $pd('alarmEditor').close();
  }catch(e){showWarning(e.message);}
 };
 // Replace only the button handlers which formerly sent firmware packets.
 $pd('saveEditorBtn').onclick=()=>saveEditor();
 $pd('newAlarmBtn').onclick=()=>showEditor();
 $pd('readAlarmsBtn').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onclick=()=>readAlarms();
 $pd('alarmSyncLabel').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();readAlarms();}};
 $pd('confirmEmptyBtn').onclick=()=>{};
 $pd('snoozeAlarmBtn').onclick=async()=>{try{await native.action('snooze');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 $pd('stopAlarmBtn').onclick=async()=>{try{await native.action('stop');refreshAlarmSession();}catch(e){showWarning(e.message);}};
 alarmButton=async(which)=>{try{await native.action(which);refreshAlarmSession();}catch(e){showWarning(e.message);}};
 // Preserve V3.0.3 duration keypad, preset row, count +/- controls, slider,
 // countdown face and all timer status/snooze/stop buttons. Only routing changes.
 timerCommand=async function(action){
  try{
   if(action==='start'){
    if(alarmChangeIsUnsafeIncludingTimer())throw Error('An alarm or timer is already in progress.');
    const cfg={seconds:duration(),buzz:count('timerBuzzCount',5),beep:count('timerBeepCount',5),
      zaps:count('timerZapCount',5),intensity:Number($pd('timerZapMax').value),
      interval:pref.timerInterval,snoozeSeconds:withinUi($pd('pdTimerSnoozeMinutes').value,1,60)*60,
      musicDelay:10,musicAfterSnoozes:timerMusicAfter,
      smartTimeout:$pd('pdTimerSmart').checked,music:$pd('pdTimerMusic').checked,
      musicUri:selectedSong()?.uri||''};
    if(cfg.buzz+cfg.beep+cfg.zaps===0)throw Error('Select at least one stimulus.');
    if(cfg.music&&!cfg.musicUri)throw Error('Choose a song in Settings first.');
    await nativeTimerAction('start',cfg);
    if($pd('timerConfirmBuzz').checked&&isOn())try{await immediate({type:'buzz'},30);}catch(_){}
   }else if(action==='snooze')await nativeTimerAction('snooze');
   else await nativeTimerAction(action);
   syncNativeTimer(false);refreshConnection();
  }catch(e){message('timerWriteStatus',e.message,true);}
 };
 function withinUi(value,lo,hi){const n=Number(value);if(!Number.isInteger(n)||n<lo||n>hi)throw Error('Choose a value between '+lo+' and '+hi);return n;}
 $pd('timerStartBtn').onclick=()=>{dismissSoftKeyboard($pd('duration'));void timerCommand('start');};
 $pd('timerSnoozeBtn').onclick=()=>timerCommand('snooze');
 $pd('timerPauseBtn').onclick=()=>timerCommand('pause');
 $pd('timerResumeBtn').onclick=()=>timerCommand('resume');
 $pd('timerStopBtn').onclick=()=>timerCommand('reset');
 // Watch-reported firmware timer/status notifications cannot alter PavDroid UI.
 onAlarmNotify=function(){};
 onTimerConfig=function(){};
 function refreshAlarmSession(){
  const s=native.snapshot();if(!s?.active){app.activeAlarm=null;app.snoozeUntil=null;
    alarmState('STATUS UNKNOWN','No Android alarm currently active','unknown');refreshConnection();return;}
  app.activeAlarm={id:s.id+1,firing:s.phase==='firing'};
  app.snoozes=s.snoozes||0;app.snoozeUntil=s.snoozeUntil||null;
  $pd('snoozeCount').textContent=String(s.snoozes||0);
  $pd('snoozeRemaining').textContent=s.snoozeUntil&&s.phase==='snoozing'?fmt((s.snoozeUntil-Date.now())/1000):'—';
  alarmState(s.phase==='firing'?'ALARM FIRING':'SNOOZING',s.name,s.phase==='firing'?'active-state':'snooze-state');
  $pd('activeName').textContent=s.name||'Active alarm';
  $pd('alarmState').textContent=s.phase==='firing'?'ALARM FIRING':
   `SNOOZING (${s.snoozes||0}) · ${fmt((s.snoozeUntil-Date.now())/1000)} left`;
  refreshConnection();
 }
 const originalDrop=onDrop;
 onDrop=function(){originalDrop();setPavDroidBattery(null);};
 const baseTab=tab;
 tab=function(name){baseTab(name);if(name==='alarms')readAlarms();};
 readAlarms();refreshAlarmSession();
 setInterval(refreshAlarmSession,1000);
 // The connection page is unchanged in layout, but its labels are accurate.
 $pd('connectionHealth').textContent='Android schedules alarms. Bluetooth sends watch stimuli.';
})();
