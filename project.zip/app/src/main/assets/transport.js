/* PavDroid 2.0: minimal Android bridge. No browser Bluetooth shim, firmware
 * alarm-list transport, timer configuration, or watch-firmware writes. */
'use strict';
(function(global){
  let sequence=1;
  const pending=new Map();
  const api=global.AndroidBle;
  function nativeCall(method,...args){
    if(!api||typeof api[method]!=='function')return Promise.reject(Error('PavDroid requires the Android APK'));
    return new Promise((resolve,reject)=>{
      const id=sequence++;const timeout=setTimeout(()=>{
        if(pending.has(id)){pending.delete(id);reject(Error('Android '+method+' timed out'));}
      },21000);
      pending.set(id,{resolve,reject,timeout});
      try{api[method](id,...args);}catch(e){clearTimeout(timeout);pending.delete(id);reject(e);}
    });
  }
  const parse=(text,fallback)=>{try{return JSON.parse(text);}catch(_){return fallback;}};
  const BATTERY_LEVEL='00002a19-0000-1000-8000-00805f9b34fb';
  const BATTERY_POWER='00002a1a-0000-1000-8000-00805f9b34fb';
  const BATTERY_LEVEL_STATUS='00002bed-0000-1000-8000-00805f9b34fb';
  const EFFECT={buzz:'00001001-0000-1000-8000-00805f9b34fb',beep:'00001002-0000-1000-8000-00805f9b34fb',zap:'00001003-0000-1000-8000-00805f9b34fb'};
  let connectedListener=()=>{},disconnectedListener=()=>{},diagnosticListener=()=>{};
  global.PavDroidTransport={
    onConnection(fn,disconnected){connectedListener=fn||(()=>{});disconnectedListener=disconnected||(()=>{});},
    onDiagnostic(fn){diagnosticListener=fn||(()=>{});},
    _complete(id,ok,payload){
      const p=pending.get(id);if(!p)return;
      pending.delete(id);clearTimeout(p.timeout);
      if(!ok){p.reject(Error(String(payload||'Bluetooth operation failed')));return;}
      p.resolve(parse(payload,payload));
    },
    _connected(){connectedListener();},
    _disconnected(){disconnectedListener();},
    _notify(uuid,bytes){diagnosticListener(uuid,bytes);/* Physical watch buttons remain native-owned. */},
    watchConnected(){try{return !!api?.isWatchConnected();}catch(_){return false;}},
    connection(){try{return parse(api.connectionSnapshot(),{});}catch(_){return {}; }},
    device(){try{return parse(api.savedDevice(),null);}catch(_){return null;}},
    scan:()=>nativeCall('scan','Pavlok-3-'),
    connect:address=>nativeCall('connect',address),
    disconnect(){api?.disconnect();},
    readBattery:()=>nativeCall('read',BATTERY_LEVEL),
    chargeState(){try{return parse(api?.chargingSnapshot?.()||'{}',{known:false,charging:false});}catch(_){return {known:false,charging:false};}},
    readCharge:()=>nativeCall('read',BATTERY_POWER),
    readChargeStatus:()=>nativeCall('read',BATTERY_LEVEL_STATUS),
    chargeInventory(){try{return parse(api?.chargingDiagnosticInventory?.(),{connected:false,readable:[],notifiable:[],characteristics:[]});}catch(_){return {connected:false,readable:[],notifiable:[],characteristics:[]};}},
    readDiagnostic:(uuid)=>nativeCall('diagnosticRead',uuid),
    diagnosticSubscribe:(uuid)=>nativeCall('diagnosticSubscribe',uuid),
    diagnosticUnsubscribe:(uuid)=>nativeCall('diagnosticUnsubscribe',uuid),
    test(type,percent){
      const uuid=EFFECT[type];if(!uuid) return Promise.reject(Error('Unknown watch test'));
      const pct=Math.max(10,Math.min(100,Math.round(percent/10)*10));
      const bytes=type==='zap'?[0x81,pct]:[0x81,1,pct,0x16,0x16];
      return nativeCall('write',uuid,JSON.stringify(bytes));
    },
    alarms(){try{return parse(api?.androidAlarms(),[]);}catch(_){return [];}},
    alarmState(){try{return parse(api?.androidAlarmSnapshot(),{});}catch(_){return {};}},
    saveAlarms:(list,expected)=>nativeCall('saveAndroidAlarms',JSON.stringify(list),JSON.stringify(expected)),
    alarmAction:action=>nativeCall('androidAlarmAction',action),
    exactAllowed(){try{return !!api?.hasAndroidExactAlarmAccess();}catch(_){return false;}},
    timerState(){try{return parse(api?.timerSnapshot(),{});}catch(_){return {};}},
    timerAction:(action,config={})=>nativeCall('timerAction',action,JSON.stringify(config)),
    eventHistory(){try{return parse(api?.eventHistory(),[]);}catch(_){return [];}},
    savedHistory(){try{return parse(api?.savedSessionEvents(),[]);}catch(_){return [];}},
    note(message){try{api?.appendEvent?.(String(message));}catch(_){}},
    clearEvents(){api?.clearEvents();},
    clearHistory(){api?.clearSavedSessionEvents();}
  };
})(window);
