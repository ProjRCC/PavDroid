package com.projectrcc.pavlokcontrol;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

/** Urgent watch-confirmed alert, once per firing / again after each snooze. */
final class AlarmNotifications {
    // New channel: Android never retroactively upgrades an older channel's importance.
    private static final String CHANNEL = "pavlok_watch_alarm_alerts_v208";
    private static final int ID = 20506;
    private static final int SAFETY_ID = 20507;
    private static final int ACTION_WARNING_ID = 20508;
    private static final int SNOOZE_ID = 21840;
    private static final String SNOOZE_CHANNEL = "pavlok_alarm_snooze_v218";
    private static final Set<Integer> notifiedRounds = new HashSet<>();
    private static final Handler snoozeHandler = new Handler(Looper.getMainLooper());
    private static Runnable snoozeTicker;
    private AlarmNotifications() { }

    private static void stopSnoozeTicker() {
        if (snoozeTicker != null) snoozeHandler.removeCallbacks(snoozeTicker);
        snoozeTicker = null;
    }

    static void createChannel(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationGroups.ensure(context, manager);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Alarm alerts", NotificationManager.IMPORTANCE_HIGH);
        channel.setGroup(NotificationGroups.ALARM);
        channel.setDescription("Prominent alert whenever the Pavlok watch reports an alarm firing");
        channel.enableVibration(true);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(channel);
        NotificationChannel snooze = new NotificationChannel(SNOOZE_CHANNEL, "Alarm snooze", NotificationManager.IMPORTANCE_LOW);
        snooze.setGroup(NotificationGroups.ALARM);
        snooze.setDescription("Countdown while the watch alarm is snoozed");
        snooze.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(snooze);
    }

    /** Actions are queued only; a watch-reported state event confirms Snooze/Stop. */
    private static PendingIntent watchAction(Context context, int alarmId, long eventUpdated, String command) {
        Intent intent = new Intent(context, WatchMonitorService.class)
                .setAction(WatchMonitorService.ACTION_WATCH_ALARM)
                .setData(Uri.parse("pavlok://alarm-action/" + alarmId + "/" + eventUpdated + "/" + command))
                .putExtra(WatchMonitorService.EXTRA_WATCH_ALARM_ID, alarmId)
                .putExtra(WatchMonitorService.EXTRA_WATCH_ALARM_UPDATED, eventUpdated)
                .putExtra(WatchMonitorService.EXTRA_WATCH_ALARM_COMMAND, command);
        return PendingIntent.getForegroundService(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static long watchActionToken(Context context) {
        try {
            JSONObject snapshot = new JSONObject(SnoozeGuard.snapshot(context));
            return "firing".equals(snapshot.optString("state"))
                    ? snapshot.optLong("roundStarted", 0L) : snapshot.optLong("updated", 0L);
        } catch (Exception ignored) { return 0L; }
    }

    /** A failed or unconfirmed notification action must not dismiss the actual alarm. */
    static void actionWarning(Context context, int alarmId, String detail) {
        EventJournal.append(context, "Watch alarm notification action WARNING: " + detail);
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null || !manager.areNotificationsEnabled()) return;
        Intent open = new Intent(context, MainActivity.class).putExtra("show_alarms", true);
        PendingIntent pending = PendingIntent.getActivity(context, 20508, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            manager.notify(ACTION_WARNING_ID, new Notification.Builder(context, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("ALARM - " + UpcomingAlarmReminders.nameForWatchAlarm(context, alarmId) + " - Action not confirmed")
                    .setContentText(detail)
                    .setStyle(new Notification.BigTextStyle().bigText(detail))
                    .setContentIntent(pending).setCategory(Notification.CATEGORY_ALARM)
                    .setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setAutoCancel(true).setOnlyAlertOnce(false).build());
        } catch (RuntimeException ex) { EventJournal.append(context, "Alarm action warning notification FAILED: " + ex.getMessage()); }
    }

    static void firing(Context context, int watchAlarmId) {
        stopSnoozeTicker();
        NotificationManager current = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (current != null) { current.cancel(SNOOZE_ID); current.cancel(ACTION_WARNING_ID); }
        if (notifiedRounds.contains(watchAlarmId)) return;
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            EventJournal.append(context, "Alarm notification BLOCKED: notification permission missing");
            return;
        }
        createChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null || !manager.areNotificationsEnabled()) {
            EventJournal.append(context, "Alarm notification BLOCKED: notifications disabled");
            return;
        }
        NotificationChannel channel = manager.getNotificationChannel(CHANNEL);
        if (channel == null || channel.getImportance() < NotificationManager.IMPORTANCE_HIGH) {
            EventJournal.append(context, "Alarm notification BLOCKED: Alarm alerts channel is not high-priority");
            return;
        }

        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("show_alarms", true);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long eventUpdated = watchActionToken(context);
        Notification.Builder builder = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ALARM - " + UpcomingAlarmReminders.nameForWatchAlarm(context, watchAlarmId) + " - Firing")
                .setContentText("Pavlok alarm is firing")
                .setContentIntent(pending)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                // Leave it in the notification drawer until the watch reports snooze/stop
                // or the user dismisses it. Android still controls heads-up banner time.
                .setAutoCancel(false)
                .setOnlyAlertOnce(false);
        if (eventUpdated > 0L) {
            builder.addAction(new Notification.Action.Builder(null, "Snooze",
                    watchAction(context, watchAlarmId, eventUpdated, "snooze")).build());
            builder.addAction(new Notification.Action.Builder(null, "Stop",
                    watchAction(context, watchAlarmId, eventUpdated, "stop")).build());
        }
        // When Android allows alarm full-screen alerts, display over the lock screen.
        // Otherwise Android still decides if the HIGH-importance notification heads-up.
        boolean canFullScreen = Build.VERSION.SDK_INT < 34 || manager.canUseFullScreenIntent();
        if (canFullScreen) builder.setFullScreenIntent(pending, true);
        manager.cancel(SAFETY_ID);
        try {
            manager.notify(ID, builder.build());
            notifiedRounds.add(watchAlarmId);
            EventJournal.append(context, "Alarm notification POSTED for watch alarm #" + watchAlarmId
                    + (canFullScreen ? " (full-screen permission available)" : " (heads-up only; full-screen permission unavailable)"));
        } catch (RuntimeException ex) {
            EventJournal.append(context, "Alarm notification FAILED: " + ex.getClass().getSimpleName()
                    + " " + ex.getMessage());
        }
    }

    static void snoozed(Context context, int watchAlarmId) {
        cancelVisible(context);
        if (watchAlarmId != 0) notifiedRounds.remove(watchAlarmId);
        else notifiedRounds.clear();
        beginSnoozeTicker(context, watchAlarmId);
    }

    /** Restore only a watch-confirmed, unexpired snooze after service restart. */
    static void restoreSnoozeIfActive(Context context) {
        try {
            JSONObject snap = new JSONObject(SnoozeGuard.snapshot(context));
            if ("snoozed".equals(snap.optString("state")) && snap.optInt("id") > 0
                    && snap.optLong("until") > System.currentTimeMillis())
                beginSnoozeTicker(context, snap.optInt("id"));
        } catch (Exception ignored) { }
    }

    private static void beginSnoozeTicker(Context context, int watchAlarmId) {
        stopSnoozeTicker();
        if (watchAlarmId <= 0) return;
        Context appContext = context.getApplicationContext();
        createChannel(appContext);
        Runnable tick = new Runnable() {
            @Override public void run() {
                try {
                    JSONObject snap = new JSONObject(SnoozeGuard.snapshot(appContext));
                    if (!"snoozed".equals(snap.optString("state")) || snap.optInt("id") != watchAlarmId) {
                        stopSnoozeTicker();
                        return;
                    }
                    long until = snap.optLong("until", 0L);
                    long updated = snap.optLong("updated", 0L);
                    long seconds = Math.max(0L, (until - System.currentTimeMillis() + 999L) / 1000L);
                    postSnooze(appContext, watchAlarmId, updated, seconds);
                    // The countdown is phone-estimated from a watch-confirmed event.
                    // Do not assert a watch re-fire or issue watch commands when it expires.
                    if (seconds > 0L) snoozeHandler.postDelayed(this, 1000L);
                    else snoozeTicker = null;
                } catch (Exception ex) {
                    stopSnoozeTicker();
                    EventJournal.append(appContext, "Alarm snooze countdown refresh failed: " + ex.getMessage());
                }
            }
        };
        snoozeTicker = tick;
        snoozeHandler.post(tick);
    }

    private static void postSnooze(Context context, int watchAlarmId, long updated, long seconds) {
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null || !manager.areNotificationsEnabled()) return;
        NotificationChannel channel = manager.getNotificationChannel(SNOOZE_CHANNEL);
        if (channel == null || channel.getImportance() == NotificationManager.IMPORTANCE_NONE) return;
        Intent open = new Intent(context, MainActivity.class).putExtra("show_alarms", true);
        PendingIntent pending = PendingIntent.getActivity(context, 21840, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(context, SNOOZE_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ALARM - " + UpcomingAlarmReminders.nameForWatchAlarm(context, watchAlarmId) + " - Snoozing")
                .setContentText(String.format(Locale.US, "Snooze for %d:%02d", seconds / 60L, seconds % 60L))
                .setContentIntent(pending).setCategory(Notification.CATEGORY_STATUS)
                .setShowWhen(false).setUsesChronometer(false)
                .setOngoing(true).setOnlyAlertOnce(true);
        if (updated > 0L) b.addAction(new Notification.Action.Builder(null, "Stop",
                watchAction(context, watchAlarmId, updated, "stop")).build());
        try { manager.notify(SNOOZE_ID, b.build()); }
        catch (RuntimeException ex) {
            EventJournal.append(context, "Alarm snooze notification FAILED: " + ex.getMessage());
        }
    }

    static void dismissed(Context context, int watchAlarmId) {
        cancelVisible(context);
        if (watchAlarmId != 0) notifiedRounds.remove(watchAlarmId);
        else notifiedRounds.clear();
    }

    /** Safety warning, not a claim that the watch is firing. */
    static void safetyWarning(Context context, int watchAlarmId) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        createChannel(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null || !manager.areNotificationsEnabled()) return;
        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("show_alarms", true);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 20507, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        manager.notify(SAFETY_ID, new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ALARM - " + UpcomingAlarmReminders.nameForWatchAlarm(context, watchAlarmId) + " - Check Snooze")
                .setContentText("Watch has NOT confirmed alarm " + watchAlarmId + " resumed. Check your watch.")
                .setContentIntent(pending)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .setAutoCancel(true)
                .setOnlyAlertOnce(false)
                .build());
    }

    private static void cancelVisible(Context context) {
        stopSnoozeTicker();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) { manager.cancel(ID); manager.cancel(SAFETY_ID); manager.cancel(SNOOZE_ID); manager.cancel(ACTION_WARNING_ID); }
    }
}
