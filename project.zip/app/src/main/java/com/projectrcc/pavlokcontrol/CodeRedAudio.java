package com.projectrcc.pavlokcontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;

/** Optional local phone MP3 for Code Red. Never changes the watch alarm packet.
 *  Backed by Android's persistable Storage Access Framework file permissions.
 *  Code Red backup-timer alerts own their countdown; MP3-only mode owns its own
 *  five-minute snooze and can be stopped via middle hold or notification.
 */
final class CodeRedAudio {
    static final String ACTION_AUDIO = "com.projectrcc.pavlokcontrol.CODE_RED_AUDIO";
    static final String EXTRA_COMMAND = "command";
    // Dedicated opt-out Android notification channel, independent of all alarm,
    // timer and connection channels. Disabling it never disables MP3 playback.
    private static final String CHANNEL = "pavlok_code_red_music_controls_v2044";
    private static final String LEGACY_CHANNEL = "pavlok_code_red_audio_v2040";
    private static final int NOTIFICATION_ID = 32040;
    private static final String PREFS = "pavlok_code_red_audio_v2040";
    private final WatchMonitorService owner;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private String uri = "";
    private boolean audioOnly;
    private boolean noSnoozeAudio;
    // The same notification controls phone music for all three paths:
    // alarm No-Snooze MP3, 30:05 MP3-only, and Code Red timer Times Up.
    private boolean timerAudioActive;
    private boolean timerRoundSilenced;
    private boolean audioPaused;
    private boolean playerPrepared;
    private int priorAlarmVolume = -1;
    private long snoozeUntil;
    private final Runnable resume = this::resumeIfDue;

    CodeRedAudio(WatchMonitorService owner) {
        this.owner = owner;
        prefs = owner.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        NotificationManager nm = (NotificationManager) owner.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            NotificationGroups.ensure(owner, nm);
            NotificationChannel channel = new NotificationChannel(CHANNEL,
                    "Music controls (optional)", NotificationManager.IMPORTANCE_LOW);
            channel.setGroup(NotificationGroups.CODE_RED);
            channel.setDescription("Optional Pause/Resume/Stop Music notification. " +
                    "Turning this off does not stop Code Red MP3 playback; " +
                    "watch Snooze still silences the music.");
            channel.setSound(null, null); // silent controls; never make an extra alarm noise
            channel.enableVibration(false);
            channel.setShowBadge(false);
            nm.createNotificationChannel(channel);
            // The old high-importance audio channel belonged to the prior
            // notification implementation. Avoid showing two confusing choices.
            nm.deleteNotificationChannel(LEGACY_CHANNEL);
        }
        // Restore persisted pause/silence choices before reconstructing playback.
        // Never automatically blast a paused track after Android restarts us.
        audioPaused = prefs.getBoolean("music_paused", false);
        timerRoundSilenced = prefs.getBoolean("timer_music_silenced", false);
        // Restore only an existing audio-only session. Timer-owned MP3 playback
        // is reconstructed when the native timer returns to Times Up.
        if (prefs.getBoolean("no_snooze_active", false)) {
            noSnoozeAudio = true;
            uri = prefs.getString("uri", "");
            priorAlarmVolume = prefs.getInt("prior_alarm_volume", -1);
            if (!uri.isEmpty()) {
                // Pause Music should not leave the user's alarm volume pegged.
                if (!audioPaused) forceMaxAlarmVolume();
                play();
            }
        } else if (prefs.getBoolean("audio_only", false)) {
            audioOnly = true;
            uri = prefs.getString("uri", "");
            snoozeUntil = prefs.getLong("snooze_until", 0L);
            if (snoozeUntil > System.currentTimeMillis()) {
                handler.postDelayed(resume, snoozeUntil - System.currentTimeMillis());
                showNotice(true);
            } else if (!uri.isEmpty()) play();
        } else if (owner.codeRedGuard() != null && owner.codeRedGuard().ownsTimer()) {
            try {
                String phase = new JSONObject(owner.timerEngine().snapshot()).optString("phase", "ready");
                if ("alerting".equals(phase)) onTimerAlerting(owner.codeRedGuard().activeTimerMp3Uri());
            } catch (Exception ignored) { }
        }
    }

    void onTimerAlerting(String mp3Uri) {
        if (audioOnly || noSnoozeAudio || timerRoundSilenced ||
                mp3Uri == null || mp3Uri.isEmpty()) return;
        timerAudioActive = true;
        uri = mp3Uri;
        play();
    }

    void startBeforeFirstSnooze(String mp3Uri) {
        if (mp3Uri == null || !mp3Uri.startsWith("content://")) {
            EventJournal.append(owner, "Code Red No Snooze MP3 refused: no local file selected");return;
        }
        stop();
        noSnoozeAudio = true;
        uri = mp3Uri;
        forceMaxAlarmVolume();
        persist();
        play();
    }
    void stopBeforeFirstSnooze() {
        if (noSnoozeAudio) {
            EventJournal.append(owner, "Code Red No Snooze MP3 silenced by watch Snooze/Stop");
            stop();
        }
    }
    private void forceMaxAlarmVolume() {
        try {
            AudioManager manager = (AudioManager) owner.getSystemService(Context.AUDIO_SERVICE);
            if (manager == null) return;
            int maximum = manager.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            if (priorAlarmVolume < 0) priorAlarmVolume = manager.getStreamVolume(AudioManager.STREAM_ALARM);
            manager.setStreamVolume(AudioManager.STREAM_ALARM, maximum, 0);
            int observed = manager.getStreamVolume(AudioManager.STREAM_ALARM);
            EventJournal.append(owner, "Code Red No Snooze MP3 requested 100% alarm volume; Android reports " + observed + "/" + maximum);
        } catch (Exception e) {
            EventJournal.append(owner, "Code Red No Snooze max volume could not be set: " + e.getMessage());
        }
    }
    private void restoreAlarmVolume() {
        if (priorAlarmVolume < 0) return;
        try {
            AudioManager manager = (AudioManager) owner.getSystemService(Context.AUDIO_SERVICE);
            if (manager != null && manager.getStreamVolume(AudioManager.STREAM_ALARM) ==
                    manager.getStreamMaxVolume(AudioManager.STREAM_ALARM)) {
                manager.setStreamVolume(AudioManager.STREAM_ALARM, priorAlarmVolume, 0);
                EventJournal.append(owner, "Code Red No Snooze restored prior phone alarm volume");
            }
        } catch (Exception e) {
            EventJournal.append(owner, "Code Red alarm volume restore unavailable: " + e.getMessage());
        }
        priorAlarmVolume = -1;
    }

    void startAudioOnly(String mp3Uri) {
        if (mp3Uri == null || !mp3Uri.startsWith("content://")) {
            EventJournal.append(owner, "Code Red MP3 refused: select a local Android document");
            return;
        }
        stop();
        audioOnly = true;
        uri = mp3Uri;
        snoozeUntil = 0L;
        persist();
        play();
    }

    private void persist() {
        prefs.edit().putBoolean("audio_only", audioOnly)
             .putBoolean("no_snooze_active", noSnoozeAudio)
             .putInt("prior_alarm_volume", noSnoozeAudio ? priorAlarmVolume : -1)
             .putString("uri", (audioOnly || noSnoozeAudio) ? uri : "")
             .putLong("snooze_until", audioOnly ? snoozeUntil : 0L)
             .putBoolean("music_paused", audioPaused)
             .putBoolean("timer_music_silenced", timerRoundSilenced).apply();
    }

    private void play() {
        releasePlayer();
        if (uri.isEmpty() || !uri.startsWith("content://")) return;
        try {
            MediaPlayer p = new MediaPlayer();
            p.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            p.setDataSource(owner, Uri.parse(uri));
            p.setLooping(true);
            p.setVolume(1.0f, 1.0f);
            player = p;
            playerPrepared = false;
            p.setOnPreparedListener(ready -> {
                if (player != ready) return; // canceled while preparing
                playerPrepared = true;
                if (audioPaused) {
                    showNotice(false);
                    return; // pause action arrived while MediaPlayer was preparing
                }
                try {
                    ready.start();
                    showNotice(false);
                    EventJournal.append(owner, "Code Red local MP3 playback started (looping)");
                } catch (Exception ex) {
                    EventJournal.append(owner, "Code Red MP3 start FAILED: " + ex.getMessage());
                    if (noSnoozeAudio) stop(); else releasePlayer();
                }
            });
            p.setOnErrorListener((failed, what, extra) -> {
                EventJournal.append(owner, "Code Red MP3 player error: " + what + "/" + extra);
                if (noSnoozeAudio) stop();
                else {
                    releasePlayer();
                    if (timerAudioActive) { timerAudioActive = false; hideNotice(); }
                }
                return true;
            });
            p.prepareAsync(); // never block the alarm monitor's main looper
            showNotice(false);
        } catch (Exception ex) {
            EventJournal.append(owner, "Code Red MP3 playback FAILED: " + ex.getMessage());
            if (noSnoozeAudio) stop();
            else { releasePlayer(); if (audioOnly) showNotice(false); else { timerAudioActive = false; hideNotice(); } }
        }
    }

    /** Any timer Snooze silences the phone MP3; the next Times Up can play anew. */
    void onTimerSnoozed() {
        if (audioOnly) return; // MP3-only owns its independent 5-minute snooze
        if (noSnoozeAudio) stopBeforeFirstSnooze();
        if (timerAudioActive) EventJournal.append(owner, "Code Red phone MP3 silenced by timer Snooze");
        releasePlayer();
        timerAudioActive = false;
        timerRoundSilenced = false;
        audioPaused = false;
        uri = "";
        persist();
        hideNotice();
    }
    void onTimerStopped() {
        if (audioOnly) return;
        if (noSnoozeAudio) stop();
        releasePlayer();
        timerAudioActive = false;
        timerRoundSilenced = false;
        audioPaused = false;
        uri = "";
        persist();
        hideNotice();
    }
    boolean onAudioOnlyButton(int press) {
        if (!audioOnly && !noSnoozeAudio) return false;
        try {
            String alarmState = new JSONObject(SnoozeGuard.snapshot(owner)).optString("state", "");
            if ("firing".equals(alarmState) || "snoozed".equals(alarmState)) return false;
        } catch (Exception ignored) { }
        if (press == 3) { command("stop"); return true; }
        if (press == 1) {
            if (noSnoozeAudio) { command("stop"); return true; }
            if (snoozeUntil > System.currentTimeMillis()) return true;
            command("snooze");return true;
        }
        return false;
    }
    void command(String action) {
        if ("pause_music".equals(action)) { pauseMusic(); return; }
        if ("resume_music".equals(action)) { resumeMusic(); return; }
        if ("stop_music".equals(action)) { stopMusicOnly(); return; }
        if ("stop".equals(action)) {
            if (audioOnly) EventJournal.append(owner, "Code Red audio-only stopped");
            if (noSnoozeAudio) EventJournal.append(owner, "Code Red No Snooze MP3 manually silenced");
            stop();
        } else if ("snooze".equals(action) && audioOnly) {
            releasePlayer();
            audioPaused = false;
            snoozeUntil = System.currentTimeMillis() + 300000L;
            persist();
            handler.removeCallbacks(resume);
            handler.postDelayed(resume,300000L);
            showNotice(true);
            EventJournal.append(owner, "Code Red MP3-only snoozed for five minutes");
        } else if ("resume".equals(action)) resumeIfDue();
    }

    /** Only changes phone playback. Neither command snoozes nor stops the watch alarm. */
    private void pauseMusic() {
        if (!(audioOnly || noSnoozeAudio || timerAudioActive) || audioPaused ||
                (audioOnly && snoozeUntil > System.currentTimeMillis())) return;
        audioPaused = true;
        if (noSnoozeAudio) restoreAlarmVolume();
        persist();
        if (player != null && playerPrepared) {
            try { if (player.isPlaying()) player.pause(); }
            catch (Exception ex) { EventJournal.append(owner, "Code Red MP3 pause failed: " + ex.getMessage()); }
        }
        showNotice(false);
        EventJournal.append(owner, "Code Red phone MP3 PAUSED from music notification");
    }
    private void resumeMusic() {
        if (!(audioOnly || noSnoozeAudio || timerAudioActive) || !audioPaused ||
                (audioOnly && snoozeUntil > System.currentTimeMillis())) return;
        audioPaused = false;
        if (noSnoozeAudio) forceMaxAlarmVolume();
        persist();
        try {
            if (player != null && playerPrepared) player.start();
            else if (player == null && !uri.isEmpty()) play();
            // If prepareAsync is in progress its prepared listener handles resume.
            showNotice(false);
            EventJournal.append(owner, "Code Red phone MP3 RESUMED from music notification");
        } catch (Exception ex) {
            EventJournal.append(owner, "Code Red MP3 resume failed: " + ex.getMessage());
            stopMusicOnly();
        }
    }
    private void stopMusicOnly() {
        if (!(audioOnly || noSnoozeAudio || timerAudioActive)) return;
        if (timerAudioActive) {
            // Stop only the song for THIS Times Up; do not cancel the Code Red
            // timer or block MP3 playback on the next Times Up after Snooze.
            releasePlayer();
            timerAudioActive = false;
            timerRoundSilenced = true;
            audioPaused = false;
            uri = "";
            persist();
            hideNotice();
        } else {
            // A new watch FIRING round will re-arm the No-Snooze deadline;
            // stopping the current song never stops the watch's alarm.
            stop();
        }
        EventJournal.append(owner, "Code Red phone MP3 STOPPED from music notification (watch alarm/timer unchanged)");
    }

    private void resumeIfDue() {
        if (!audioOnly) return;
        long remaining = snoozeUntil - System.currentTimeMillis();
        if (remaining > 0) { handler.postDelayed(resume,remaining);return; }
        snoozeUntil = 0L;persist();play();
    }
    private PendingIntent commandIntent(String command, int id) {
        Intent intent = new Intent(owner, WatchMonitorService.class).setAction(ACTION_AUDIO)
                .putExtra(EXTRA_COMMAND,command);
        return PendingIntent.getService(owner,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void showNotice(boolean snoozing) {
        if (!audioOnly && !noSnoozeAudio && !timerAudioActive) return;
        NotificationManager nm = (NotificationManager) owner.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(owner, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(owner, 32041, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean asleep = audioOnly && snoozing;
        String title = asleep ? "Code Red · Music snoozing" :
                (audioPaused ? "Code Red · Music paused" : "Code Red · Music playing");
        String description = asleep ? "Phone music returns in five minutes" :
                (noSnoozeAudio ? "100% alarm volume requested · watch Snooze silences music" :
                    "Phone MP3 · Snooze silences music");
        Notification.Builder builder = new Notification.Builder(owner, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title).setContentText(description)
                // The watch alarm already has its own high-priority ALARM notification.
                // This separate quiet notification is only optional media controls.
                .setContentIntent(content).setCategory(Notification.CATEGORY_TRANSPORT)
                .setOngoing(true).setOnlyAlertOnce(true);
        // Separate from Alarm firing and Timer notifications: these buttons
        // affect ONLY MediaPlayer/phone audio, never the BLE alarm or timer.
        if (!asleep) {
            builder.addAction(new Notification.Action.Builder(null,
                    audioPaused ? "Resume Music" : "Pause Music",
                    commandIntent(audioPaused ? "resume_music" : "pause_music", 32042)).build());
        }
        builder.addAction(new Notification.Action.Builder(null, "Stop Music",
                commandIntent("stop_music", 32043)).build());
        if (audioOnly && !asleep) {
            builder.addAction(new Notification.Action.Builder(null, "Snooze MP3",
                    commandIntent("snooze", 32044)).build());
        }
        nm.notify(NOTIFICATION_ID, builder.build());
    }
    private void hideNotice() {
        NotificationManager nm = (NotificationManager) owner.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
    }
    private void releasePlayer() {
        MediaPlayer old = player;
        player = null;
        playerPrepared = false;
        if (old != null) { try { old.stop(); } catch(Exception ignored) {} try { old.release(); } catch(Exception ignored) {} }
    }
    private void stop() {
        handler.removeCallbacks(resume);
        releasePlayer();
        if (noSnoozeAudio || priorAlarmVolume >= 0) restoreAlarmVolume();
        audioOnly = false;
        noSnoozeAudio = false;
        timerAudioActive = false;
        audioPaused = false;
        timerRoundSilenced = false;
        uri = "";
        snoozeUntil = 0L;
        persist();
        hideNotice();
    }
    void close() {
        handler.removeCallbacks(resume);
        releasePlayer();
        // Restore the user's volume even if Android destroys the service; the
        // persisted pre-boost value lets a recreated service reapply max safely.
        if (noSnoozeAudio) restoreAlarmVolume();
        // Preserve playback intent across temporary service recreation.
    }
}
