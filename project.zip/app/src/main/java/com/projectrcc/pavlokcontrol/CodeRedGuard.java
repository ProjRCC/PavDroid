package com.projectrcc.pavlokcontrol;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * V3.0 INDEPENDENT TIMED HANDOFF: Code Red is PHONE-ONLY metadata, never a modification of
 * the Shock Clock 3 alarm packet. It uses confirmed watch FIRING/SNOOZED/STOP
 * events and starts a separate Android-managed timer.
 *
 * Every CODE_RED_* constant deliberately belongs to Code Red. These constants
 * are independent of the regular Timer profile (including Code Red's 60%
 * zap setting); Timer tab preferences must NEVER alter the Code Red timer.
 *
 * Watch firmware owns the first 30 minutes; this timer starts afterward only following verified Snooze.
 */
final class CodeRedGuard {
    // === Code Red handoff timing, anchored to FIRST watch-confirmed FIRING ===
    // 30 minutes 5 seconds gives native watch firmware time to end its 30-minute alarm.
    static final long CODE_RED_HANDOFF_AFTER_FIRST_FIRING_MS = 30L * 60_000L + 5_000L;
    // Allow recovery from an Android scheduling delay, but never resurrect an old
    // episode hours later. V2.0.31 failed because a 46s delay exceeded 15s.
    static final long CODE_RED_MAX_LATE_START_MS = 10L * 60_000L;
    private static final int CODE_RED_HANDOFF_REQUEST = 32005;
    static final String ACTION_CODE_RED_DUE = "com.projectrcc.pavlokcontrol.CODE_RED_DUE";
    static final String ACTION_CODE_RED_NO_SNOOZE = "com.projectrcc.pavlokcontrol.CODE_RED_NO_SNOOZE";
    private static final int CODE_RED_NO_SNOOZE_REQUEST = 32006;
    private static final long NO_SNOOZE_MAX_LATE_MS = 2L * 60_000L;
    // Treat only dismissals close to the 30-minute firmware cutoff as automatic;
    // earlier DISMISSED events are intentional Stop and cancel the protection.
    // There is no definitive watch-provided reason code for DISMISSED.
    static final long CODE_RED_AUTO_DISMISS_WINDOW_MS = 29L * 60_000L + 55_000L;

    // === Independent Code Red TIMER CONFIGURATION (not normal timer defaults) ===
    static final int CODE_RED_TIMER_DURATION_SECONDS = 300; // 5 minutes
    static final int CODE_RED_TIMER_BUZZ_COUNT = 3;
    static final int CODE_RED_TIMER_BEEP_COUNT = 3;
    static final int CODE_RED_TIMER_ZAP_COUNT = 1;
    static final int CODE_RED_TIMER_ZAP_INTENSITY_PERCENT = 60;
    static final int CODE_RED_TIMER_STIMULUS_INTERVAL_SECONDS = 8;
    static final boolean CODE_RED_TIMER_USE_FIRMWARE_FIRST_STIMULUS = false;
    static final boolean CODE_RED_TIMER_START_CONFIRMATION_BUZZ = true;
    static final int CODE_RED_TIMER_START_CONFIRMATION_INTENSITY_PERCENT = 30;

    private static final String PREFS = "pavlok_code_red_v2029";
    private final WatchMonitorService owner;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable trigger = this::tryStartTimer;
    private final Runnable noSnoozeTrigger = this::tryStartNoSnoozeAudio;
    // The MP3 escalation is scoped to EACH distinct watch FIRING round, not to
    // the 30-minute alarm episode. Subsequent firmware FIRING notifications
    // every ~8 seconds are stimulus updates, not a fresh round.
    private long currentNoSnoozeRoundStart() {
        if (prefs.getBoolean("no_snooze_waiting_refire", false)) return 0L;
        long round = prefs.getLong("no_snooze_round_started_ms", 0L);
        if (round > 0L) return round;
        // Existing persisted episodes from V2.0.42 may lack the new key.
        // Only recover the initial round when no Snooze has happened yet.
        return prefs.getBoolean("snoozed", false) ? 0L : startedAt();
    }
    private PendingIntent noSnoozeIntent() {
        Intent intent = new Intent(owner, CodeRedReceiver.class).setAction(ACTION_CODE_RED_NO_SNOOZE);
        return PendingIntent.getBroadcast(owner, CODE_RED_NO_SNOOZE_REQUEST, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private void cancelNoSnooze() {
        handler.removeCallbacks(noSnoozeTrigger);
        AlarmManager manager = (AlarmManager) owner.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(noSnoozeIntent());
    }
    private void scheduleNoSnoozeIfEligible() {
        handler.removeCallbacks(noSnoozeTrigger);
        long roundStart = currentNoSnoozeRoundStart();
        if (sessionId() <= 0 || roundStart <= 0 || canceled() ||
                prefs.getBoolean("no_snooze_triggered", false)) return;
        JSONObject config = configForId(sessionId());
        if (config == null || !config.optBoolean("playMp3", false) ||
                !config.optBoolean("noSnoozeMp3", false) ||
                config.optString("mp3Uri", "").isEmpty()) return;
        long due = roundStart + Math.max(0, Math.min(120, config.optInt("noSnoozeSeconds", 10))) * 1000L;
        long now = System.currentTimeMillis();
        if (now > due + NO_SNOOZE_MAX_LATE_MS) {
            prefs.edit().putBoolean("no_snooze_triggered", true).apply();
            EventJournal.append(owner, "Code Red No Snooze MP3 missed recovery window; stale playback suppressed");
            return;
        }
        if (now >= due) handler.post(noSnoozeTrigger);
        else {
            AlarmManager manager = (AlarmManager) owner.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) {
                try {
                    if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms())
                        manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, noSnoozeIntent());
                    else manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, noSnoozeIntent());
                } catch (SecurityException e) {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, noSnoozeIntent());
                } catch (Exception e) {
                    EventJournal.append(owner, "Code Red No Snooze wake-up scheduling failed: " + e.getMessage());
                }
            }
            handler.postDelayed(noSnoozeTrigger, due - now);
            EventJournal.append(owner, "Code Red No Snooze MP3 scheduled " + ((due-roundStart)/1000L) + "s after FIRING round for alarm #" + sessionId());
        }
    }
    void onNoSnoozeDeadline() { tryStartNoSnoozeAudio(); }
    private void tryStartNoSnoozeAudio() {
        long roundStart = currentNoSnoozeRoundStart();
        if (sessionId() <= 0 || roundStart <= 0 || canceled() ||
                prefs.getBoolean("no_snooze_triggered", false)) return;
        JSONObject config = configForId(sessionId());
        if (config == null || !config.optBoolean("playMp3", false) ||
                !config.optBoolean("noSnoozeMp3", false)) return;
        long now = System.currentTimeMillis();
        long due = roundStart + Math.max(0, Math.min(120, config.optInt("noSnoozeSeconds", 10))) * 1000L;
        if (now < due) { scheduleNoSnoozeIfEligible(); return; }
        prefs.edit().putBoolean("no_snooze_triggered", true).commit();
        cancelNoSnooze();
        if (now > due + NO_SNOOZE_MAX_LATE_MS) {
            EventJournal.append(owner, "Code Red No Snooze MP3 skipped stale alarm");return;
        }
        String mp3 = config.optString("mp3Uri", "");
        if (mp3.isEmpty() || owner.codeRedAudio() == null) return;
        EventJournal.append(owner, "Code Red No Snooze MP3 starting " + ((due-roundStart)/1000L) + "s after this FIRING round: requesting max phone alarm volume");
        owner.codeRedAudio().startBeforeFirstSnooze(mp3);
    }

    private PendingIntent handoffIntent() {
        Intent intent = new Intent(owner, CodeRedReceiver.class).setAction(ACTION_CODE_RED_DUE);
        return PendingIntent.getBroadcast(owner, CODE_RED_HANDOFF_REQUEST, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private void cancelHandoff() {
        handler.removeCallbacks(trigger);
        AlarmManager alarm = (AlarmManager)owner.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(handoffIntent());
    }
    private void setHandoffAlarm(long due) {
        AlarmManager alarm = (AlarmManager)owner.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) { EventJournal.append(owner, "Code Red WARNING: Android alarm service unavailable"); return; }
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                // AlarmManager still provides a wake-up even when exact-alarm access
                // is restricted; it may arrive late. The 10-minute recovery window
                // then prevents the silent 15-second failure in V2.0.31.
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, handoffIntent());
                EventJournal.append(owner, "Code Red scheduled inexact wake-up (grant Alarms & reminders permission for precise 30:05)");
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, handoffIntent());
                EventJournal.append(owner, "Code Red scheduled exact 30:05 Android wake-up");
            }
        } catch (SecurityException ex) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, handoffIntent());
            EventJournal.append(owner, "Code Red exact wake-up denied; using inexact backup: " + ex.getMessage());
        } catch (Exception ex) {
            EventJournal.append(owner, "Code Red wake-up scheduling FAILED; foreground callback retained: " + ex.getMessage());
        }
    }
    void onScheduledDeadline() {
        // Called by a non-exported receiver or the service after resurrection.
        // The same persisted session token guards against stale broadcasts.
        tryStartTimer();
    }
    boolean mayStartHandoffWhileOldSnoozeReported(int watchAlarmId) {
        long first = startedAt();
        return sessionId() > 0 && watchAlarmId == sessionId() && first > 0 && !canceled() &&
            prefs.getBoolean("snoozed", false) &&
            System.currentTimeMillis() >= first + CODE_RED_HANDOFF_AFTER_FIRST_FIRING_MS;
    }

    CodeRedGuard(WatchMonitorService owner) {
        this.owner = owner;
        this.prefs = owner.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        scheduleIfEligible();
        scheduleNoSnoozeIfEligible();
    }

    // IDs in the watch event stream are 1-based; web editor indexes are 0-based.
    // Called only after verified watch list readback. No watch configuration writes.
    void replaceVerifiedAlarmConfigurations(String json) {
        try {
            JSONArray alarms = new JSONArray(json);
            // An empty BLE list is not proof that a running watch alarm was
            // deleted. Never allow that read to erase phone-side protection.
            if (alarms.length() == 0 && activeEpisodePending()) {
                EventJournal.append(owner, "V3 Code Red: rejected empty alarm-list sync while backup is armed");
                return;
            }
            JSONObject enabled = new JSONObject();
            JSONObject names = new JSONObject();
            for (int i = 0; i < alarms.length(); i++) {
                JSONObject a = alarms.optJSONObject(i);
                if (a == null) continue;
                int id = a.optInt("id", 0);
                if (id != i + 1) continue;
                String name = a.optString("name", "").trim();
                if (!name.isEmpty()) names.put(String.valueOf(id), name);
                if (!a.optBoolean("enabled", false)) continue;
                String signature = a.optString("signature", "");
                if (signature.isEmpty()) continue;
                // Backward compatible: legacy Code Red rows had only enabled=true.
                // The watch itself never receives phone-side Code Red settings.
                // V3 has one Code Red mode: a five-minute watch backup.
                // MP3 is an optional extra, never a replacement for the timer.
                boolean backup = true;
                boolean mp3 = a.optBoolean("playMp3", false);
                String uri = a.optString("mp3Uri", "");
                boolean noSnooze = mp3 && a.optBoolean("noSnoozeMp3", false);
                int noSnoozeSeconds = Math.max(0, Math.min(120, a.optInt("noSnoozeSeconds", 10)));
                if (!backup && !mp3) continue;
                enabled.put(String.valueOf(id), new JSONObject()
                        .put("signature", signature).put("backup", backup)
                        .put("playMp3", mp3).put("mp3Uri", uri)
                        .put("noSnoozeMp3", noSnooze).put("noSnoozeSeconds", noSnoozeSeconds));
            }
            prefs.edit().putString("enabled_alarm_slots", enabled.toString())
                    .putString("verified_alarm_names", names.toString()).apply();
        } catch (Exception ex) {
            EventJournal.append(owner, "Code Red configuration not updated: " + ex.getMessage());
        }
    }

    String verifiedAlarmName(int watchId) {
        try {
            return new JSONObject(prefs.getString("verified_alarm_names", "{}"))
                    .optString(String.valueOf(watchId), "").trim();
        } catch (Exception ignored) { return ""; }
    }
    long activeEpisodeStart(int watchId) {
        return sessionId() == watchId && startedAt() > 0L && !canceled() ? startedAt() : 0L;
    }

    // A snapshot is taken at the FIRST watch-confirmed FIRING. After that,
    // rereads, Bluetooth loss and WebView restarts cannot change the handoff.
    private JSONObject verifiedSlotConfig(int watchId) {
        try {
            Object value = new JSONObject(prefs.getString("enabled_alarm_slots", "{}"))
                    .opt(String.valueOf(watchId));
            if (value instanceof JSONObject) {
                JSONObject result = (JSONObject) value;
                return result.optBoolean("backup", false) ? result : null;
            }
            // Migrate legacy timer-only metadata; never create MP3-only alarms.
            if (value instanceof String) return new JSONObject().put("backup", true);
        } catch (Exception ignored) { }
        return null;
    }
    private JSONObject activeEpisodeConfig() {
        if (sessionId() <= 0 || startedAt() <= 0L) return null;
        try {
            String raw = prefs.getString("episode_config", "");
            if (!raw.isEmpty() && prefs.getInt("episode_config_alarm_id", 0) == sessionId())
                return new JSONObject(raw);
        } catch (Exception ignored) { }
        // One-time migration: an armed V2 episode has already confirmed a
        // Code Red snooze. Preserve its five-minute backup even if its slot
        // list was destroyed by an empty read.
        if (prefs.getBoolean("snoozed", false) && !canceled()) {
            try { return new JSONObject().put("backup", true); }
            catch (Exception ignored) { }
        }
        return null;
    }
    private JSONObject configForId(int watchId) {
        if (watchId == sessionId() && startedAt() > 0L && !canceled()) {
            JSONObject locked = activeEpisodeConfig();
            if (locked != null) return locked;
        }
        return verifiedSlotConfig(watchId);
    }
    private boolean configuredForId(int watchId) { return verifiedSlotConfig(watchId) != null; }
    private boolean activeEpisodePending() {
        return sessionId() > 0 && startedAt() > 0L && !canceled()
                && prefs.getBoolean("snoozed", false) && !prefs.getBoolean("triggered", false)
                && System.currentTimeMillis() <= startedAt() + CODE_RED_HANDOFF_AFTER_FIRST_FIRING_MS
                    + CODE_RED_MAX_LATE_START_MS;
    }
    boolean ownsTimer() { return timerOwned(); }
    String activeTimerMp3Uri() {
        JSONObject config = timerOwned() ? configForId(sessionId()) : null;
        return config != null && config.optBoolean("playMp3", false) ? config.optString("mp3Uri", "") : "";
    }

    private int sessionId() { return prefs.getInt("session_alarm_id", 0); }
    private long startedAt() { return prefs.getLong("first_firing_ms", 0L); }
    private boolean canceled() { return prefs.getBoolean("canceled", false); }
    private boolean timerOwned() { return prefs.getBoolean("code_red_timer_owned", false); }

    void onConfirmedWatchAlarmEvent(int operation, int id) {
        if (id <= 0) return;
        final long now = System.currentTimeMillis();
        if (operation == 0x54) { // FIRST FIRING starts this alarm's 30m05s handoff clock
            boolean sameEpisode = sessionId() == id && startedAt() > 0L &&
                    !canceled() && now >= startedAt() && now - startedAt() <= 35L * 60L * 1000L;
            // Some firmware reports a final FIRING immediately before automatic
            // DISMISSED at +30:00. Never let it restart or cancel the 30:05 handoff.
            if (sameEpisode) {
                // A watch-confirmed Snooze terminates the prior MP3 countdown.
                // Arm the next countdown only when the watch FIRING resumes.
                // Preserve the original first-FIRING timestamp for the 30:05
                // backup timer; never rearm on an 8s repeat or cutoff artifact.
                if (prefs.getBoolean("no_snooze_waiting_refire", false) &&
                        now - startedAt() < CODE_RED_AUTO_DISMISS_WINDOW_MS) {
                    prefs.edit().putBoolean("no_snooze_waiting_refire", false)
                            .putLong("no_snooze_round_started_ms", now)
                            .putBoolean("no_snooze_triggered", false).commit();
                    EventJournal.append(owner, "Code Red watch alarm #" + id + " re-FIRING after Snooze; No Snooze MP3 delay restarted");
                    scheduleNoSnoozeIfEligible();
                }
                return; // repeats and cutoff FIRING stay in one episode
            }
            JSONObject selectedConfig = verifiedSlotConfig(id);
            if (selectedConfig == null || !owner.bridge().hasWatchConnection()) return;
            cancelHandoff();
            cancelNoSnooze();
            if (owner.codeRedAudio() != null) owner.codeRedAudio().command("stop");
            prefs.edit().putInt("session_alarm_id", id).putLong("first_firing_ms", now)
                    .putString("episode_config", selectedConfig.toString())
                    .putInt("episode_config_alarm_id", id)
                    .putBoolean("snoozed", false).putBoolean("canceled", false)
                    .putBoolean("triggered", false).putBoolean("code_red_timer_owned", false)
                    .putBoolean("no_snooze_triggered", false)
                    .putLong("no_snooze_round_started_ms", now)
                    .putBoolean("no_snooze_waiting_refire", false).commit();
            EventJournal.append(owner, "Code Red watch alarm #" + id + " first FIRING; 30m05s handoff clock started");
            scheduleNoSnoozeIfEligible();
        } else if (operation == 0x55) { // every watch-confirmed Snooze ends the active firing round
            if (sessionId() != id || startedAt() <= 0 || canceled()) return;
            boolean firstSnooze = !prefs.getBoolean("snoozed", false);
            // First Snooze arms the original +30:05 handoff. EVERY Snooze,
            // including later ones, silences any MP3 and makes the next
            // distinct watch FIRING eligible for a fresh X-second escalation.
            prefs.edit().putBoolean("snoozed", true)
                    .putBoolean("no_snooze_waiting_refire", true)
                    .putLong("no_snooze_round_started_ms", 0L)
                    .putBoolean("no_snooze_triggered", false).commit();
            cancelNoSnooze();
            if (owner.codeRedAudio() != null) owner.codeRedAudio().stopBeforeFirstSnooze();
            if (firstSnooze) {
                EventJournal.append(owner, "Code Red armed by watch-confirmed SNOOZED for alarm #" + id);
                scheduleIfEligible();
            } else {
                EventJournal.append(owner, "Code Red No Snooze MP3 rearmed for next watch FIRING after Snooze #" + id);
            }
        } else if (operation == 0x56) { // early dismissal = deliberate Stop; +30m cutoff is different
            if (sessionId() != id || startedAt() <= 0) return;
            if (now - startedAt() >= CODE_RED_AUTO_DISMISS_WINDOW_MS) {
                cancelNoSnooze();
                EventJournal.append(owner, "Code Red observed watch DISMISSED at/near 30-minute cutoff; not inferring manual Stop");
                return;
            }
            cancelHandoff();
            cancelNoSnooze();
            if (owner.codeRedAudio() != null) owner.codeRedAudio().stopBeforeFirstSnooze();
            prefs.edit().putBoolean("canceled", true).apply();
            if (timerOwned()) {
                prefs.edit().putBoolean("code_red_timer_owned", false).apply();
                owner.timerEngine().command("reset", new JSONObject());
                EventJournal.append(owner, "Code Red CANCELED: watch alarm #" + id +
                        " dismissed early; active backup timer reset. Origin: " + SnoozeGuard.stopOrigin(owner, id));
            } else {
                EventJournal.append(owner, "Code Red CANCELED: watch alarm #" + id +
                        " dismissed early; 30:05 wake-up canceled. Origin: " + SnoozeGuard.stopOrigin(owner, id));
            }
        }
    }

    private void scheduleIfEligible() {
        handler.removeCallbacks(trigger);
        if (sessionId() <= 0 || startedAt() <= 0L || canceled() ||
                !prefs.getBoolean("snoozed", false) || prefs.getBoolean("triggered", false)) return;
        long now = System.currentTimeMillis();
        long due = startedAt() + CODE_RED_HANDOFF_AFTER_FIRST_FIRING_MS;
        if (now > due + CODE_RED_MAX_LATE_START_MS) {
            prefs.edit().putBoolean("triggered", true).apply();
            cancelHandoff();
            EventJournal.append(owner, "Code Red missed 10-minute recovery window; stale handoff suppressed");
            return;
        }
        if (now >= due) {
            handler.post(trigger);
        } else {
            setHandoffAlarm(due);
            // Kept as a foreground-service fallback; AlarmManager provides the
            // wake-up when Android defers this main-looper callback.
            handler.postDelayed(trigger, due - now);
        }
    }

    /** V3 independent handoff. This is the ONLY transition that starts Code Red.
     *  It reads the locked episode snapshot, never the mutable watch alarm list.
     *  Timer start must succeed before the one-shot trigger is committed.
     */
    private void tryStartTimer() {
        if (sessionId() <= 0 || canceled() || !prefs.getBoolean("snoozed", false) ||
                prefs.getBoolean("triggered", false)) return;
        final long now = System.currentTimeMillis();
        final long due = startedAt() + CODE_RED_HANDOFF_AFTER_FIRST_FIRING_MS;
        if (now < due) { scheduleIfEligible(); return; }
        if (now - due > CODE_RED_MAX_LATE_START_MS) {
            prefs.edit().putBoolean("triggered", true).commit();
            cancelHandoff();
            EventJournal.append(owner, "Code Red FAILED: handoff exceeded 10-minute late recovery window");
            return;
        }
        EventJournal.append(owner, "Code Red handoff callback at +" + ((now-startedAt())/1000L)
                + "s, lateness " + Math.max(0L, (now-due)/1000L) + "s for alarm #" + sessionId());
        try {
            JSONObject config = activeEpisodeConfig();
            if (config == null) {
                // No MP3-only fallback. An already armed snooze must retain
                // the five-minute timer even during legacy metadata migration.
                config = new JSONObject().put("backup", true);
                EventJournal.append(owner, "Code Red recovered missing episode metadata with backup-timer defaults");
            }
            JSONObject timer = new JSONObject(owner.timerEngine().snapshot());
            if (!"ready".equals(timer.optString("phase", "ready"))) {
                prefs.edit().putBoolean("triggered", true).commit();
                cancelHandoff();
                EventJournal.append(owner, "Code Red FAILED: existing timer occupied the watch handoff slot");
                return;
            }
            JSONObject settings = new JSONObject()
                    .put("seconds", CODE_RED_TIMER_DURATION_SECONDS)
                    .put("buzz", CODE_RED_TIMER_BUZZ_COUNT)
                    .put("beep", CODE_RED_TIMER_BEEP_COUNT)
                    .put("zaps", CODE_RED_TIMER_ZAP_COUNT)
                    .put("intensity", CODE_RED_TIMER_ZAP_INTENSITY_PERCENT)
                    .put("interval", CODE_RED_TIMER_STIMULUS_INTERVAL_SECONDS)
                    .put("nativeFirst", CODE_RED_TIMER_USE_FIRMWARE_FIRST_STIMULUS)
                    .put("codeRedHandoff", true);
            try {
                JSONObject watch = new JSONObject(SnoozeGuard.snapshot(owner));
                if ("firing".equals(watch.optString("state", "unknown")))
                    EventJournal.append(owner, "Code Red: stale FIRING telemetry still reported at firmware cutoff; timed backup authorized by previously confirmed snooze");
            } catch (Exception ignored) { }
            owner.timerEngine().command("start", settings);
            JSONObject started = new JSONObject(owner.timerEngine().snapshot());
            if (!"countdown".equals(started.optString("phase")))
                throw new IllegalStateException("Timer engine did not enter countdown");
            // Persist success only AFTER NativeTimerEngine has committed the new
            // deadline. A failed start may retry during the recovery window.
            prefs.edit().putBoolean("triggered", true).putBoolean("code_red_timer_owned", true).commit();
            cancelHandoff();
            if (config.optBoolean("playMp3", false) && !config.optString("mp3Uri", "").isEmpty())
                EventJournal.append(owner, "Code Red MP3 armed for backup timer Times Up");
            if (CODE_RED_TIMER_START_CONFIRMATION_BUZZ && owner.bridge().hasWatchConnection()) {
                if (owner.bridge().queueTimerStimulus(1, CODE_RED_TIMER_START_CONFIRMATION_INTENSITY_PERCENT))
                    EventJournal.append(owner, "Code Red start confirmation buzz queued at " +
                            CODE_RED_TIMER_START_CONFIRMATION_INTENSITY_PERCENT + "%");
            }
            EventJournal.append(owner, "Code Red started independent " + CODE_RED_TIMER_DURATION_SECONDS +
                    "s native timer for alarm #" + sessionId() +
                    " (buzz " + CODE_RED_TIMER_BUZZ_COUNT + ", beep " + CODE_RED_TIMER_BEEP_COUNT +
                    ", zap " + CODE_RED_TIMER_ZAP_COUNT + ", intensity " + CODE_RED_TIMER_ZAP_INTENSITY_PERCENT +
                    "%, interval " + CODE_RED_TIMER_STIMULUS_INTERVAL_SECONDS + "s)");
        } catch (Exception ex) {
            EventJournal.append(owner, "Code Red timer start FAILED; 10s retry planned: " + ex.getMessage());
            // The receiver may have been the only active callback. Retry on the
            // service's main looper while keeping the persisted episode armed.
            if (System.currentTimeMillis() <= due + CODE_RED_MAX_LATE_START_MS - 10_000L)
                handler.postDelayed(trigger, 10_000L);
        }
    }

    // Normal timer controls have priority; never allow a future alarm Stop to
    // reset a timer the user manually started or took over from Code Red.
    void onManualTimerCommand(String action) {
        if ("start".equals(action) || "reset".equals(action))
            prefs.edit().putBoolean("code_red_timer_owned", false).apply();
    }

    void close() { handler.removeCallbacks(trigger); handler.removeCallbacks(noSnoozeTrigger);
        /* Keep OS alarms for process restoration. */ }
}
