package com.projectrcc.pavlokcontrol;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Non-exported Android wake-up receiver for Code Red's persisted 30:05 handoff. */
public final class CodeRedReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !(CodeRedGuard.ACTION_CODE_RED_DUE.equals(intent.getAction()) ||
                CodeRedGuard.ACTION_CODE_RED_NO_SNOOZE.equals(intent.getAction()))) return;
        try {
            WatchMonitorService service = WatchMonitorService.liveService();
            if (service != null && service.codeRedGuard() != null) {
                if (CodeRedGuard.ACTION_CODE_RED_NO_SNOOZE.equals(intent.getAction()))
                    service.codeRedGuard().onNoSnoozeDeadline();
                else service.codeRedGuard().onScheduledDeadline();
                return;
            }
            // Recreate the existing foreground monitoring service if the app UI
            // was swiped away. The service then checks the persisted session.
            Intent start = new Intent(context, WatchMonitorService.class)
                .setAction(intent.getAction());
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(start);
            else context.startService(start);
        } catch (Exception ex) {
            EventJournal.append(context, "Code Red wake-up receiver could not start monitor: " + ex.getMessage());
        }
    }
}
