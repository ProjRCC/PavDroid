package com.projectrcc.pavlokcontrol;

import android.app.Activity;
import android.app.AlarmManager;
import android.Manifest;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.provider.DocumentsContract;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import org.json.JSONObject;
import android.view.View;
import android.view.HapticFeedbackConstants;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Offline app UI. A foreground connected-device Service owns the BLE link. */
public final class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 962;
    private static final int PICK_MP3_REQUEST = 974;
    private static final int EXPORT_HISTORY_REQUEST = 975;
    private String pendingExportText;
    private WebView web;
    private NativeBleBridge ble;
    private Vibrator uiVibrator;

    /** Numeric timer entry should have a Done/Return key, not Next. */
    private static final class DoneWebView extends WebView {
        DoneWebView(Context context) { super(context); }
        @Override public InputConnection onCreateInputConnection(EditorInfo attributes) {
            InputConnection connection = super.onCreateInputConnection(attributes);
            attributes.imeOptions = (attributes.imeOptions & ~EditorInfo.IME_MASK_ACTION & ~EditorInfo.IME_FLAG_NO_ENTER_ACTION)
                    | EditorInfo.IME_ACTION_DONE;
            if (connection == null) return null;
            // Some Android keyboards emit an IME action instead of a DOM Enter key.
            // Handle both paths: the JS handler covers Enter, this wrapper covers Done.
            return new InputConnectionWrapper(connection, false) {
                @Override public boolean performEditorAction(int actionCode) {
                    if (actionCode == EditorInfo.IME_ACTION_DONE) {
                        post(() -> {
                            evaluateJavascript("if(typeof onNativeKeyboardDone==='function')onNativeKeyboardDone();", null);
                            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
                        });
                        return true;
                    }
                    return super.performEditorAction(actionCode);
                }
            };
        }
    }
    private boolean bound;
    private final ServiceConnection monitorConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName component, IBinder binder) {
            WatchMonitorService monitor = ((WatchMonitorService.LocalBinder) binder).service();
            ble = monitor.bridge();
            if (web == null) return;
            ble.attach(MainActivity.this, web);
            web.addJavascriptInterface(ble, "AndroidBle");
            web.loadUrl("file:///android_asset/index.html");
        }
        @Override public void onServiceDisconnected(ComponentName component) {
            if (ble != null && web != null) ble.detach(web);
            ble = null;
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11, 17, 27));
        getWindow().setNavigationBarColor(Color.rgb(11, 17, 27));
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (getIntent() != null && getIntent().getBooleanExtra("show_alarms", false)) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        web = new DoneWebView(this);
        web.setHapticFeedbackEnabled(true);
        // Do not show WebView's built-in transient focus highlight for touch.
        // The HTML still retains :focus-visible rings for keyboard navigation.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) web.setDefaultFocusHighlightEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager manager = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            uiVibrator = manager == null ? null : manager.getDefaultVibrator();
        } else {
            uiVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setBackgroundColor(Color.rgb(11, 17, 27));
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equals(request.getUrl().getScheme());
            }
            @Override public void onPageFinished(WebView view, String url) {
                showAlarmsIfRequested();
                // The page may finish loading after Activity.onResume. Recheck
                // exact-alarm access once the JavaScript UI actually exists.
                scheduleExactTimingUiRefresh();
            }
        });
        web.addJavascriptInterface(new UiKeyboardBridge(), "AndroidUi");
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
        bound = bindService(new Intent(this, WatchMonitorService.class), monitorConnection, Context.BIND_AUTO_CREATE);
    }

    private android.media.MediaPlayer musicPreview;
    private void stopMusicPreview() {
        if (musicPreview != null) {
            try { musicPreview.stop(); } catch (Exception ignored) {}
            try { musicPreview.release(); } catch (Exception ignored) {}
            musicPreview = null;
        }
    }

    public final class UiKeyboardBridge {
        /** A discreet PHONE-only tap, never a watch stimulus or Bluetooth write.
         * Uses Android's short touch vibration so WebView/JS buttons feel
         * consistent even when WebView does not consider itself focused.
         */
        @JavascriptInterface public void hapticTap() {
            runOnUiThread(() -> {
                if (web == null) return;
                try {
                    if (uiVibrator != null && uiVibrator.hasVibrator()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                                uiVibrator.areEffectsSupported(VibrationEffect.EFFECT_TICK)[0]
                                        == Vibrator.VIBRATION_EFFECT_SUPPORT_YES) {
                            uiVibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK));
                        } else {
                            // Low amplitude, short pulse. Does not activate the watch.
                            uiVibrator.vibrate(VibrationEffect.createOneShot(14, 70));
                        }
                        return;
                    }
                } catch (RuntimeException ignored) {
                    // Fall back to standard Android view feedback if vibration unavailable.
                }
                web.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY,
                        HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
            });
        }
        /** Code Red's 30:05 handoff requires Android's exact-alarm special access.
         * This is a capability query only; it does not change alarm scheduling.
         */
        @JavascriptInterface public boolean hasExactAlarmAccess() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
            AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            return manager != null && manager.canScheduleExactAlarms();
        }
        @JavascriptInterface public void openExactAlarmSettings() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
                try {
                    Intent exact = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(exact);
                } catch (Exception ex) {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception second) {
                        EventJournal.append(MainActivity.this,
                                "Code Red could not open exact-alarm settings: " + second.getMessage());
                    }
                }
            });
        }
        @JavascriptInterface public void setTimerMusicVolume(int percent) {
            getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE)
                .edit().putInt("timerVolume",Math.max(10,Math.min(100,percent))).apply();
        }
        @JavascriptInterface public void setSelectedMusicUri(String uri) {
            String safe=uri==null?"":uri;
            if(!safe.isEmpty()&&!safe.startsWith("content://"))return;
            getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE)
                .edit().putString("selectedUri",safe).apply();
        }
        @JavascriptInterface public void previewMusic(String uri, int percent) {
            runOnUiThread(() -> {
                stopMusicPreview();
                if(uri==null || !uri.startsWith("content://"))return;
                try {
                    android.media.MediaPlayer p=new android.media.MediaPlayer();
                    musicPreview=p;
                    p.setAudioAttributes(new android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    p.setDataSource(MainActivity.this,Uri.parse(uri));
                    float gain=Math.max(.01f,Math.min(1f,percent/100f));
                    p.setVolume(gain,gain);p.setOnCompletionListener(mp->stopMusicPreview());
                    p.prepare();p.start();
                } catch(Exception ex){stopMusicPreview();EventJournal.append(MainActivity.this,"Music preview failed: "+ex.getMessage());}
            });
        }
        @JavascriptInterface public void setMusicPreviewVolume(int percent) {
            runOnUiThread(() -> {
                if (musicPreview == null) return;
                try {
                    float gain = Math.max(.1f, Math.min(1f, percent / 100f));
                    musicPreview.setVolume(gain, gain);
                } catch (IllegalStateException ignored) { }
            });
        }
        @JavascriptInterface public void stopMusicPreview() {
            runOnUiThread(() -> MainActivity.this.stopMusicPreview());
        }
        @JavascriptInterface public void openNotificationSettings(String channel) {
            runOnUiThread(() -> {
                try {
                    Intent i;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && channel!=null && !channel.isEmpty()) {
                        i=new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
                        i.putExtra(Settings.EXTRA_CHANNEL_ID,channel);
                    } else {
                        i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
                    }
                    startActivity(i);
                } catch(Exception e){EventJournal.append(MainActivity.this,"Notification settings unavailable: "+e.getMessage());}
            });
        }
        @JavascriptInterface public void pickMp3(String preferredUri) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.setType("audio/mpeg");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    // DocumentsUI may open the last chosen file's folder. This is
                    // best-effort: Android's picker ultimately owns navigation.
                    String last = preferredUri == null || preferredUri.isEmpty()
                            ? getPreferences(Context.MODE_PRIVATE).getString("last_mp3_uri", "") : preferredUri;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                            last != null && last.startsWith("content://")) {
                        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, Uri.parse(last));
                    }
                    startActivityForResult(intent, PICK_MP3_REQUEST);
                } catch (Exception ex) {
                    EventJournal.append(MainActivity.this, "Code Red MP3 picker failed: " + ex.getMessage());
                }
            });
        }
        @JavascriptInterface public void exportText(String filename, String text) {
            runOnUiThread(() -> {
                try {
                    pendingExportText = text;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType("text/plain");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    startActivityForResult(intent, EXPORT_HISTORY_REQUEST);
                } catch (Exception ex) {
                    EventJournal.append(MainActivity.this, "History export failed: " + ex.getMessage());
                }
            });
        }
        @JavascriptInterface public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Pavlok event log", text));
            });
        }
        @JavascriptInterface public void hideKeyboard() {
            runOnUiThread(() -> {
                if (web == null) return;
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(web.getWindowToken(), 0);
                web.clearFocus();
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_MP3_REQUEST) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String label = "Selected MP3";
                try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst() && c.getString(0) != null) label = c.getString(0);
                }
                getPreferences(Context.MODE_PRIVATE).edit().putString("last_mp3_uri", uri.toString()).apply();
                String call = "if(typeof onMp3Picked==='function')onMp3Picked(" +
                    JSONObject.quote(uri.toString()) + "," + JSONObject.quote(label) + ");";
                if (web != null) web.evaluateJavascript(call, null);
            } catch (Exception ex) {
                EventJournal.append(this, "Code Red MP3 selection failed: " + ex.getMessage());
            }
        } else if (requestCode == EXPORT_HISTORY_REQUEST && pendingExportText != null) {
            try (OutputStream stream = getContentResolver().openOutputStream(uri, "w")) {
                if (stream == null) throw new IllegalStateException("Android document could not be opened");
                stream.write(pendingExportText.getBytes(StandardCharsets.UTF_8));
                EventJournal.append(this, "Alarm History exported to Android document picker");
            } catch (Exception ex) {
                EventJournal.append(this, "History export write failed: " + ex.getMessage());
            } finally { pendingExportText = null; }
        }
    }

    private void showAlarmsIfRequested() {
        Intent intent = getIntent();
        if (intent == null || web == null) return;
        if (intent.getBooleanExtra("show_timer", false)) {
            intent.removeExtra("show_timer");
            web.evaluateJavascript("if (typeof tab === 'function') tab('timer');", null);
        }
        if (intent.getBooleanExtra("show_alarms", false)) {
            intent.removeExtra("show_alarms");
            web.evaluateJavascript("if (typeof tab === 'function') tab('alarms');", null);
        }
        String key = intent.getStringExtra("disable_alarm_key");
        if (key != null) {
            intent.removeExtra("disable_alarm_key");
            web.evaluateJavascript("if(typeof handleReminderDisable === 'function') handleReminderDisable(" + JSONObject.quote(key) + ");", null);
        }
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra("show_alarms", false)) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        showAlarmsIfRequested();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (ble != null) ble.onPermissionsResult(requestCode);
    }
    /** Android may grant exact-alarm access while Settings is on screen.
     * Re-read the real AlarmManager capability after focus returns, not just
     * once before the settings activity has completely closed.
     * This only updates the notice in the open editor; it does not schedule
     * or alter any native alarms or watch commands.
     */
    private void scheduleExactTimingUiRefresh() {
        final WebView current = web;
        if (current == null) return;
        Runnable check = () -> {
            if (web != current) return;
            current.evaluateJavascript("if(typeof refreshCodeRedTimingAccess==='function')refreshCodeRedTimingAccess();", null);
        };
        current.post(check);
        current.postDelayed(check, 300);
        current.postDelayed(check, 1000);
    }
    @Override public void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            scheduleExactTimingUiRefresh();
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) scheduleExactTimingUiRefresh();
    }
    @Override public void onPause() {
        stopMusicPreview();
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override public void onDestroy() {
        stopMusicPreview();
        if (ble != null && web != null) ble.detach(web);
        if (bound) { unbindService(monitorConnection); bound = false; }
        if (web != null) {
            web.removeJavascriptInterface("AndroidBle");
            web.removeJavascriptInterface("AndroidUi");
            web.destroy(); web = null;
        }
        super.onDestroy();
    }
}
