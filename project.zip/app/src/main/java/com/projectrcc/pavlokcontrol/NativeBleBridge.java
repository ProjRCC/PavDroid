package com.projectrcc.pavlokcontrol;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayDeque;
import java.util.UUID;

/**
 * Android BLE transport for the existing JavaScript interface.
 * Only scans for Pavlok-3 devices; all watch writes originate from existing UI actions.
 * GATT transactions, including CCCD subscriptions, are serialized.
 */
public final class NativeBleBridge {
    private static final int REQUEST_PERMISSIONS = 941;
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final UUID ALARM_CONTROL_UUID = UUID.fromString("00005001-0000-1000-8000-00805f9b34fb");
    private static final UUID EVENT_STATUS_UUID = UUID.fromString("00002002-0000-1000-8000-00805f9b34fb");
    private static final UUID TIMER_COMMAND_UUID = UUID.fromString("00007001-0000-1000-8000-00805f9b34fb");
    private static final UUID VIBE_UUID = UUID.fromString("00001001-0000-1000-8000-00805f9b34fb");
    private static final UUID BEEP_UUID = UUID.fromString("00001002-0000-1000-8000-00805f9b34fb");
    private static final UUID ZAP_UUID = UUID.fromString("00001003-0000-1000-8000-00805f9b34fb");
    private static final UUID ALARM_STATUS_UUID = UUID.fromString("00005003-0000-1000-8000-00805f9b34fb");
    private static final long BLE_OPERATION_TIMEOUT_MS = 10000;
    private static final String PREFS = "pavlok_ble_v2";
    private static final String ADDRESS = "device_address";
    private static final String NAME = "device_name";

    // The Service owns the GATT link. The Activity/WebView may come and go.
    private final WatchMonitorService owner;
    private final Context context;
    private volatile Activity activity;
    private volatile WebView web;
    private Runnable reconnectTask;
    private long reconnectDelayMs = 7000;
    private int pendingClientConnect = -1;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private String currentAddress;
    private int pendingConnect = -1;
    private int pendingScan = -1;
    private Runnable afterPermission;
    private int permissionRequest = -1;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private Runnable scanTimeout;
    private volatile boolean connected;
    private boolean disposed;
    private final ArrayDeque<Operation> operations = new ArrayDeque<>();
    private int lastNamedAlarmId = -1;
    private long lastNamedAlarmAt = 0L;
    private boolean namedAlarmDismissed = true;
    // Firmware timer operation reset is sent only on actual timer Stop/Snooze,
    // never as an automatic delayed retry or a new firmware snooze timer.
    private static final byte[] TIMER_RESET_PACKET = new byte[]{0x13, 0x03, 0x11, 0x02, 0x12, 0x02};
    private Operation active;
    private Runnable operationTimeout;

    private static final class Operation {
        final int requestId;
        final String action;
        final UUID characteristic;
        final byte[] payload;
        Operation(int id, String action, UUID charUuid, byte[] payload) {
            this.requestId = id;
            this.action = action;
            this.characteristic = charUuid;
            this.payload = payload;
        }
    }

    NativeBleBridge(WatchMonitorService owner) {
        this.owner = owner;
        this.context = owner.getApplicationContext();
        BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
    }

    void attach(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    void detach(WebView web) {
        if (this.web == web) {
            this.web = null;
            this.activity = null;
            this.afterPermission = null;
            this.permissionRequest = -1;
        }
    }

    @JavascriptInterface public String savedDevice() {
        String addr = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ADDRESS, null);
        if (addr == null) return "null";
        String name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(NAME, "Pavlok-3");
        try {
            return new JSONObject().put("id", addr).put("name", name).toString();
        } catch (Exception ignored) { return "null"; }
    }

    @JavascriptInterface public String alarmSnapshot() {
        return SnoozeGuard.snapshot(context);
    }
    @JavascriptInterface public boolean isWatchConnected() { return hasWatchConnection(); }
    @JavascriptInterface public String eventHistory() { return EventJournal.read(context); }
    @JavascriptInterface public String savedSessionEvents() { return EventJournal.readArchive(context); }
    @JavascriptInterface public void clearSavedSessionEvents() { EventJournal.clearArchive(context); }
    @JavascriptInterface public void appendEvent(String message) { EventJournal.append(context, message); }
    @JavascriptInterface public void clearEvents() { EventJournal.clear(context); }
    @JavascriptInterface public void syncVerifiedAlarmSchedule(String json) {
        // This is called only after JavaScript's readAlarms() parses a confirmed watch response.
        // PavDroid Android alarm schedules are persisted through saveAndroidAlarms.
    }

    @JavascriptInterface public void syncCodeRedAlarmList(String json) {
        // The UI passes only a VERIFIED watch-list snapshot; the watch packets
        // themselves contain no phone-side Code Red flags.
        // PavDroid has no Code Red/firmware-alarm configuration.
    }
    @JavascriptInterface public String androidAlarms() { return owner.alarmEngine().alarmsJson(); }
    @JavascriptInterface public String androidAlarmSnapshot() { return owner.alarmEngine().snapshot(); }
    @JavascriptInterface public boolean hasAndroidExactAlarmAccess() { return owner.alarmEngine().exactAllowed(); }
    @JavascriptInterface public void saveAndroidAlarms(int requestId, String json) {
        main.post(() -> { try { owner.alarmEngine().replace(json); succeed(requestId, owner.alarmEngine().alarmsJson()); }
                      catch (Exception e) { fail(requestId, e.getMessage()); } });
    }
    @JavascriptInterface public void androidAlarmAction(int requestId, String action) {
        main.post(() -> { try {
            if ("snooze".equals(action)) owner.alarmEngine().snooze();
            else if ("stop".equals(action)) owner.alarmEngine().stop("phone button");
            else throw new IllegalArgumentException("Unknown Android alarm action");
            succeed(requestId, owner.alarmEngine().snapshot());
        } catch(Exception e) { fail(requestId, e.getMessage()); } });
    }
    @JavascriptInterface public String timerSnapshot() {
        return owner.timerEngine().snapshot();
    }
    @JavascriptInterface public void timerAction(int requestId, String action, String jsonConfig) {
        main.post(() -> {
            try {
                owner.timerEngine().command(action, new JSONObject(jsonConfig));
                // Only relinquish Code Red timer ownership after a command succeeds.
                // No firmware timer/Code Red side effects.
                succeed(requestId, owner.timerEngine().snapshot());
            } catch (Exception e) { fail(requestId, "Timer command failed: " + e.getMessage()); }
        });
    }
    boolean hasWatchConnection() { return connected && gatt != null; }
    boolean queueTimerStimulus(int type, int pct) {
        if (!hasWatchConnection()) return false;
        UUID uuid = type == 1 ? VIBE_UUID : type == 2 ? BEEP_UUID : ZAP_UUID;
        if (characteristic(uuid) == null) return false;
        byte[] bytes = type == 3 ? new byte[] {(byte)0x81, (byte)pct}
                : new byte[] {(byte)0x81, 1, (byte)pct, 0x16, 0x16};
        enqueue(-3, "write", uuid.toString(), bytes);
        return true; // queued only; watch execution is not confirmed by this return
    }
    /** Pending native timer stimuli are not allowed to fire after Snooze/Stop. */
    void discardQueuedTimerStimuli() {
        Runnable discard = () -> {
            int before = operations.size();
            operations.removeIf(op -> op.requestId == -3 && "write".equals(op.action) &&
                (VIBE_UUID.equals(op.characteristic) || BEEP_UUID.equals(op.characteristic) || ZAP_UUID.equals(op.characteristic)));
            int discarded = before - operations.size();
            if (discarded > 0) EventJournal.append(context, "Discarded " + discarded + " pending timer stimulus commands");
            // An already transmitted BLE command cannot be retracted.
        };
        if (Looper.myLooper() == Looper.getMainLooper()) discard.run();
        else main.post(discard);
    }
    /** Existing watch-alarm packets (not firmware timer). Queued != confirmed. */
    boolean queueAlarmControlFromNotification(String command) {
        if (!"snooze".equals(command) && !"stop".equals(command)) return false;
        if (!hasWatchConnection() || characteristic(ALARM_CONTROL_UUID) == null) return false;
        byte[] packet = "snooze".equals(command) ? new byte[]{0x03, 0x01} : new byte[]{0x02, 0x00};
        enqueue(-4, "write", ALARM_CONTROL_UUID.toString(), packet);
        if ("stop".equals(command)) SnoozeGuard.notePhoneStop(context);
        return true;
    }

    /** Legacy firmware timer commands (start/pause/resume/reset) used only
     *  for a manually started timer, not for the five-minute Snooze cycle.
     */
    void queueTimerFirmwareOp(int op) {
        if (hasWatchConnection()) enqueue(-3, "write", TIMER_COMMAND_UUID.toString(),
            new byte[]{0x13, 0x03, 0x11, 0x02, (byte)op, 0x02});
    }

    /** Priority firmware reset: Stop must outrank pending timer stimuli or
     *  older timer-start traffic. This does not touch scheduled watch alarms.
     *  The reset ACK confirms a GATT write, not execution on the watch.
     */
    private boolean queuePriorityTimerReset(int requestId) {
        operations.removeIf(op -> op.requestId == -3 && "write".equals(op.action) &&
            (TIMER_COMMAND_UUID.equals(op.characteristic) || VIBE_UUID.equals(op.characteristic) ||
             BEEP_UUID.equals(op.characteristic) || ZAP_UUID.equals(op.characteristic)));
        if (!hasWatchConnection() || characteristic(TIMER_COMMAND_UUID) == null) return false;
        operations.addFirst(new Operation(requestId, "write", TIMER_COMMAND_UUID, TIMER_RESET_PACKET.clone()));
        pump();
        return true;
    }

    boolean queuePriorityTimerFirmwareStop() { return queuePriorityTimerReset(-5); }

    /** Snooze is exclusively a phone-owned five-minute countdown. Reset the
     *  initial firmware timer; NEVER create a second firmware timer for snooze.
     *  Code Red already demonstrated repeated physical snoozes this way.
     */
    boolean queueFirmwareResetAtSnooze() {
        boolean queued = queuePriorityTimerReset(-7);
        EventJournal.append(context, queued
            ? "Watch firmware timer reset queued for Snooze; native 5-minute countdown owns next alert"
            : "Watch firmware timer reset unavailable at Snooze; native countdown still active");
        return queued;
    }

    private void js(String script) {
        if (disposed) return;
        main.post(() -> {
            WebView target = web;
            if (!disposed && target != null) target.evaluateJavascript(script, null);
        });
    }
    private void succeed(int id, String jsonResult) {
        if (id < 0) return;
        js("window.PavlokNative._complete(" + id + ",true," + JSONObject.quote(jsonResult) + ");");
    }
    private void fail(int id, String message) {
        if (id < 0) return;
        js("window.PavlokNative._complete(" + id + ",false," + JSONObject.quote(message) + ");");
    }
    private void notifyCharacteristic(UUID uuid, byte[] data) {
        // PavDroid never responds to firmware scheduled-alarm state. Those
        // alarms may still exist on a previously configured watch and must be
        // cleared separately with Pavlok Control.
        if (ALARM_STATUS_UUID.equals(uuid) && data != null && data.length >= 4) {
            EventJournal.append(context, "Pre-existing WATCH FIRMWARE alarm notification observed (not managed by PavDroid)");
        }
        if (EVENT_STATUS_UUID.equals(uuid)) {
            if (!owner.alarmEngine().onButton(data)) owner.timerEngine().onWatchEvent(data);
        }
        js("window.PavlokNative._notify(" + JSONObject.quote(uuid.toString()) + "," + bytesJson(data) + ");");
    }
    private void notifyDisconnected() { js("window.PavlokNative._disconnected();"); }
    private static String bytesJson(byte[] data) {
        JSONArray a = new JSONArray();
        for (byte b : data) a.put(b & 0xff);
        return a.toString();
    }

    private boolean permissionsAvailable() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                   context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void requirePermissions(int id, Runnable next) {
        if (permissionsAvailable()) { next.run(); return; }
        if (afterPermission != null) { fail(id, "Nearby devices permission is already being requested"); return; }
        if (activity == null) { fail(id, "Open PavDroid to grant Bluetooth permission"); return; }
        permissionRequest = id;
        afterPermission = next;
        if (Build.VERSION.SDK_INT >= 31)
            activity.requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        else
            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
    }
    void onPermissionsResult(int code) {
        if (code != REQUEST_PERMISSIONS) return;
        Runnable next = afterPermission;
        int id = permissionRequest;
        afterPermission = null;
        permissionRequest = -1;
        if (next == null) return;
        if (permissionsAvailable()) next.run();
        else fail(id, "Nearby devices permission was denied. Enable it in Android Settings to connect.");
    }
    private boolean ready(int id) {
        if (adapter == null) { fail(id, "This phone does not support Bluetooth"); return false; }
        try {
            if (!adapter.isEnabled()) { fail(id, "Turn on Bluetooth and try again"); return false; }
        } catch (SecurityException ex) { fail(id, "Nearby devices permission required"); return false; }
        return true;
    }

    /** First-time pairing/selection. Auto reconnect uses savedDevice(), not a new scan. */
    @JavascriptInterface public void scan(int requestId, String prefix) {
        main.post(() -> requirePermissions(requestId, () -> startScan(requestId, prefix)));
    }
    @SuppressLint("MissingPermission")
    private void startScan(int id, String prefix) {
        if (!ready(id)) return;
        if (scanCallback != null) { fail(id, "Device scan already in progress"); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { fail(id, "Bluetooth scanner unavailable"); return; }
        final String expectedPrefix = (prefix == null || !prefix.startsWith("Pavlok-3-")) ? "Pavlok-3-" : prefix;
        final java.util.Set<BluetoothDevice> seen = new java.util.HashSet<>();
        final java.util.Set<BluetoothDevice> named = new java.util.HashSet<>();
        pendingScan = id;
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device == null) return;
                String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
                seen.add(device);
                if (name != null && !name.isEmpty()) named.add(device);
                if (name == null || !name.regionMatches(true, 0, expectedPrefix, 0, expectedPrefix.length())) {
                    try { name = device.getName(); } catch (SecurityException ignored) { }
                }
                if (name != null && !name.isEmpty()) named.add(device);
                if (name == null || !name.regionMatches(true, 0, expectedPrefix, 0, expectedPrefix.length())) return;
                final String foundName = name;
                main.post(() -> {
                    if (pendingScan != id) return;
                    stopScanning();
                    String addr = device.getAddress();
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString(ADDRESS, addr).putString(NAME, foundName).apply();
                    try { succeed(id, new JSONObject().put("id", addr).put("name", foundName).toString()); }
                    catch (Exception e) { fail(id, "Unable to save discovered watch"); }
                });
            }
            @Override public void onScanFailed(int errorCode) {
                main.post(() -> {
                    if (pendingScan != id) return;
                    stopScanning();
                    fail(id, "Bluetooth scan failed (" + errorCode + ")");
                });
            }
        };
        try {
            scanner.startScan(null, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback);
            scanTimeout = () -> {
                if (pendingScan != id) return;
                stopScanning();
                fail(id, "No matching watch in 30 seconds. Android reported " + seen.size() + " distinct nearby devices, " + named.size() + " with names.");
            };
            main.postDelayed(scanTimeout, 30000);
        } catch (Exception e) {
            stopScanning();
            fail(id, "Bluetooth scanning failed: " + e.getMessage());
        }
    }
    @SuppressLint("MissingPermission")
    private void stopScanning() {
        if (scanTimeout != null) main.removeCallbacks(scanTimeout);
        scanTimeout = null;
        if (scanner != null && scanCallback != null) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        scanCallback = null; scanner = null; pendingScan = -1;
    }

    @JavascriptInterface public void connect(int requestId, String address) {
        main.post(() -> requirePermissions(requestId, () -> startConnect(requestId, address)));
    }
    @SuppressLint("MissingPermission")
    private void startConnect(int id, String address) {
        if (!ready(id)) { if (id == -2) scheduleReconnect(); return; }
        if (address == null || !android.bluetooth.BluetoothAdapter.checkBluetoothAddress(address)) {
            fail(id, "Invalid saved watch address"); return;
        }
        if (connected && gatt != null && address.equalsIgnoreCase(currentAddress)) {
            succeed(id, "true"); return;
        }
        if (pendingConnect != -1) {
            if (pendingConnect == -2 && address.equalsIgnoreCase(currentAddress) && id >= 0) {
                pendingClientConnect = id; return;
            }
            fail(id, "Watch connection already in progress"); return;
        }
        if (reconnectTask != null) { main.removeCallbacks(reconnectTask); reconnectTask = null; }
        if (!owner.beginMonitoring()) { fail(id, "Cannot start Bluetooth background monitoring. Check Nearby devices permission."); return; }
        closeGatt(false);
        currentAddress = address;
        pendingConnect = id;
        try {
            BluetoothDevice device = adapter.getRemoteDevice(address);
            gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE);
            if (gatt == null) { pendingConnect = -1; fail(id, "Android could not start BLE connection"); scheduleReconnect(); }
            else main.postDelayed(() -> {
                if (pendingConnect == id && !connected) {
                    fail(id, "Bluetooth connection timed out");
                    closeGatt(true);
                }
            }, 17000);
        } catch (Exception e) {
            pendingConnect = -1; closeGatt(false);
            fail(id, "Connection failed: " + e.getMessage());
            scheduleReconnect();
        }
    }

    @SuppressLint("MissingPermission")
    private void closeGatt(boolean announce) {
        boolean hadLink = connected;
        connected = false;
        int pending = pendingConnect;
        pendingConnect = -1;
        if (gatt != null) {
            BluetoothGatt old = gatt;
            gatt = null;
            try { old.disconnect(); } catch (Exception ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
        while (!operations.isEmpty()) fail(operations.removeFirst().requestId, "Watch disconnected");
        if (active != null) { fail(active.requestId, "Watch disconnected"); active = null; }
        if (operationTimeout != null) main.removeCallbacks(operationTimeout);
        operationTimeout = null;
        if (pending != -1 && pending != -2) fail(pending, "Watch disconnected before connecting");
        if (pendingClientConnect != -1) { fail(pendingClientConnect, "Watch disconnected before connecting"); pendingClientConnect = -1; }
        if (announce && hadLink){
            EventJournal.append(context,"PavDroid watch disconnected; direct stimuli unavailable");
            notifyDisconnected();
        }
        if (announce) scheduleReconnect();
        owner.timerEngine().onLinkChanged(false);
    }
    @JavascriptInterface public void disconnect() {
        main.post(() -> {
            owner.endMonitoring();
            if (reconnectTask != null) { main.removeCallbacks(reconnectTask); reconnectTask = null; }
            closeGatt(true);
        });
    }

    /** Target a saved address. Fast only around a scheduled/due alarm. */
    void prioritizeReconnect(){
        main.post(()->{
            if(connected||disposed||!permissionsAvailable())return;
            if(reconnectTask!=null){main.removeCallbacks(reconnectTask);reconnectTask=null;}
            reconnectDelayMs=3500L;
            restoreBackgroundConnection();
            if(pendingConnect==-1)scheduleReconnect();
        });
    }
    private void scheduleReconnect() {
        if (!owner.isMonitoring() || disposed || currentAddress == null || reconnectTask != null) return;
        owner.updateMonitorStatus(false);
        final boolean priority=owner.alarmEngine()!=null&&owner.alarmEngine().connectionPriorityNow();
        final long delay=priority?Math.min(7000L,reconnectDelayMs):reconnectDelayMs;
        reconnectDelayMs=Math.min(priority?7000L:90000L,reconnectDelayMs*2);
        reconnectTask = () -> {
            reconnectTask = null;
            if (owner.isMonitoring() && !connected && pendingConnect == -1 && permissionsAvailable())
                startConnect(-2, currentAddress);
        };
        main.postDelayed(reconnectTask, delay);
    }

    void restoreBackgroundConnection() {
        main.post(() -> {
            if (disposed || connected || pendingConnect != -1 || !permissionsAvailable()) return;
            String saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ADDRESS, null);
            if (saved != null) startConnect(-2, saved);
        });
    }


    private static UUID normalized(String uuid) {
        if ("battery_service".equalsIgnoreCase(uuid)) uuid = "0000180f-0000-1000-8000-00805f9b34fb";
        if ("battery_level".equalsIgnoreCase(uuid)) uuid = "00002a19-0000-1000-8000-00805f9b34fb";
        return UUID.fromString(uuid);
    }
    private BluetoothGattCharacteristic characteristic(UUID uuid) {
        if (!connected || gatt == null) return null;
        for (android.bluetooth.BluetoothGattService service : gatt.getServices()) {
            BluetoothGattCharacteristic c = service.getCharacteristic(uuid);
            if (c != null) return c;
        }
        return null;
    }
    @JavascriptInterface public void service(int requestId, String serviceUUID) {
        main.post(() -> {
            if (!connected || gatt == null) { fail(requestId, "Not connected"); return; }
            try {
                if (gatt.getService(normalized(serviceUUID)) == null) fail(requestId, "Watch service not available: " + serviceUUID);
                else succeed(requestId, "true");
            } catch (Exception e) { fail(requestId, e.getMessage()); }
        });
    }
    @JavascriptInterface public void characteristic(int requestId, String charUUID) {
        main.post(() -> {
            try {
                if (characteristic(normalized(charUUID)) == null) fail(requestId, "Characteristic unavailable: " + charUUID);
                else succeed(requestId, "true");
            } catch (Exception e) { fail(requestId, e.getMessage()); }
        });
    }
    @JavascriptInterface public void subscribe(int requestId, String charUUID) { enqueue(requestId, "subscribe", charUUID, null); }
    @JavascriptInterface public void read(int requestId, String charUUID) { enqueue(requestId, "read", charUUID, null); }
    @JavascriptInterface public void write(int requestId, String charUUID, String jsonBytes) {
        byte[] bytes;
        try {
            JSONArray array = new JSONArray(jsonBytes);
            if (array.length() > 512) { fail(requestId, "BLE command exceeds 512 bytes"); return; }
            bytes = new byte[array.length()];
            for (int i = 0; i < bytes.length; ++i) bytes[i] = (byte) (array.getInt(i) & 255);
        } catch (Exception e) { fail(requestId, "Invalid Bluetooth command"); return; }
        // Audit only the native alarm STOP packet (not timer reset).
        if (ALARM_CONTROL_UUID.toString().equalsIgnoreCase(charUUID) && bytes.length == 2
                && (bytes[0] & 0xff) == 0x02 && (bytes[1] & 0xff) == 0x00)
            SnoozeGuard.notePhoneStop(context);
        enqueue(requestId, "write", charUUID, bytes);
    }
    private void enqueue(int id, String action, String charUUID, byte[] payload) {
        main.post(() -> {
            try {
                UUID uuid = normalized(charUUID);
                if ("write".equals(action) && (ALARM_CONTROL_UUID.equals(uuid) ||
                        uuid.toString().equals("00005002-0000-1000-8000-00805f9b34fb") ||
                        TIMER_COMMAND_UUID.equals(uuid))) {
                    fail(id, "PavDroid blocks watch firmware alarm/timer commands"); return;
                }
                // The app only exposes characteristics already used by Pavlok Control V1.9.2.
                String key = uuid.toString();
                if (!key.startsWith("0000100") && !key.startsWith("0000200") &&
                    !key.startsWith("0000500") && !key.startsWith("0000700") &&
                    !key.startsWith("00002a19")) {
                    fail(id, "Characteristic not allowed"); return;
                }
                // V2.0.31: configuration write START (0x01,0x00) rewrites the
                // entire saved watch-alarm list. Never begin it during a
                // watch-confirmed FIRING/SNOOZED round. Read and alarm button
                // packets (Snooze 0x03/0x01, Stop 0x02/0x00) are unaffected.
                if ("write".equals(action) && ALARM_CONTROL_UUID.equals(uuid) &&
                        payload != null && payload.length >= 2 &&
                        (payload[0] & 0xff) == 0x01 && (payload[1] & 0xff) == 0x00) {
                    JSONObject state = new JSONObject(SnoozeGuard.snapshot(context));
                    String watchState = state.optString("state", "unknown");
                    if ("firing".equals(watchState) || "snoozed".equals(watchState)) {
                        EventJournal.append(context, "Native alarm-list write BLOCKED during watch " + watchState);
                        fail(id, "Alarm changes are unavailable while an alarm is firing or snoozing.");
                        return;
                    }
                    JSONObject timer = new JSONObject(owner.timerEngine().snapshot());
                    if (!"ready".equals(timer.optString("phase", "ready"))) {
                        EventJournal.append(context, "Native alarm-list write BLOCKED during active timer");
                        fail(id, "Alarm changes are unavailable while a timer is active.");
                        return;
                    }
                }
                // Block an app-initiated firmware timer START before a BLE write can
                // interfere with a currently FIRING/SNOOZED watch alarm. Code Red
                // starts its own Android native timer after the watch cutoff and
                // does not send a firmware timer-start packet through this path.
                if ("write".equals(action) && TIMER_COMMAND_UUID.equals(uuid) &&
                        payload != null && (payload.length > 0 && (
                            (payload[0] & 0xff) == 0x22 ||
                            (payload.length >= 6 && (payload[0] & 0xff) == 0x13 &&
                             (payload[4] & 0xff) == 0x11)))) {
                    JSONObject alarm = new JSONObject(SnoozeGuard.snapshot(context));
                    String alarmState = alarm.optString("state", "unknown");
                    if ("firing".equals(alarmState) || "snoozed".equals(alarmState)) {
                        EventJournal.append(context, "Native firmware timer start BLOCKED during active watch alarm");
                        fail(id, "A timer cannot start while a watch alarm is firing or snoozing.");
                        return;
                    }
                }
                operations.addLast(new Operation(id, action, uuid, payload));
                pump();
            } catch (Exception e) { fail(id, "Unsupported characteristic UUID"); }
        });
    }

    @SuppressLint("MissingPermission")
    private void pump() {
        if (active != null) return;
        if (!connected || gatt == null) {
            while (!operations.isEmpty()) fail(operations.removeFirst().requestId, "Watch disconnected");
            return;
        }
        active = operations.pollFirst();
        if (active == null) return;
        BluetoothGattCharacteristic c = characteristic(active.characteristic);
        if (c == null) { completeOperation(false, "Characteristic not found"); return; }
        boolean started = false;
        try {
            switch (active.action) {
                case "read":
                    started = gatt.readCharacteristic(c);
                    break;
                case "subscribe":
                    if (!gatt.setCharacteristicNotification(c, true)) break;
                    BluetoothGattDescriptor cccd = c.getDescriptor(CCCD);
                    if (cccd == null) { completeOperation(true, "true"); return; }
                    byte[] value = ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
                            ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = gatt.writeDescriptor(cccd, value) == BluetoothStatusCodes.SUCCESS;
                    } else {
                        cccd.setValue(value);
                        started = gatt.writeDescriptor(cccd);
                    }
                    break;
                case "write":
                    int type = ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
                            ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                            : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = gatt.writeCharacteristic(c, active.payload, type) == BluetoothStatusCodes.SUCCESS;
                    } else {
                        c.setWriteType(type);
                        c.setValue(active.payload);
                        started = gatt.writeCharacteristic(c);
                    }
                    if (started && type == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) {
                        // Some Android firmware omits onCharacteristicWrite for write-without-response.
                        // A successful enqueue is NOT proof the watch executed this command.
                        final Operation noResponse = active;
                        main.postDelayed(() -> {
                            if (active == noResponse) completeOperation(true, "true");
                        }, 180);
                    }
                    break;
                default:
                    completeOperation(false, "Unknown GATT operation"); return;
            }
        } catch (Exception e) { completeOperation(false, "Android BLE error: " + e.getMessage()); return; }
        if (!started) { completeOperation(false, "Android refused GATT operation"); return; }
        final Operation expected = active;
        operationTimeout = () -> {
            if (active == expected) {
                // Recover the whole BLE connection rather than overlapping stale GATT operations.
                fail(active.requestId, "Bluetooth command timed out; reconnect the watch");
                active = null;
                closeGatt(true);
            }
        };
        main.postDelayed(operationTimeout, BLE_OPERATION_TIMEOUT_MS);
    }
    private void completeOperation(boolean ok, String payload) {
        if (active == null) return;
        Operation finished = active;
        active = null;
        if (operationTimeout != null) main.removeCallbacks(operationTimeout);
        operationTimeout = null;
        if (finished.requestId == -5) {
            EventJournal.append(context, ok
                ? "Priority watch timer Stop BLE write accepted (watch execution not confirmed)"
                : "Priority watch timer Stop BLE write FAILED: " + payload);
        } else if (finished.requestId == -7) {
            EventJournal.append(context, ok
                ? "Snooze firmware timer reset BLE write accepted (watch execution not confirmed)"
                : "Snooze firmware timer reset BLE write FAILED: " + payload);
        }
        if (ok) succeed(finished.requestId, payload);
        else fail(finished.requestId, payload);
        pump();
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            main.post(() -> {
                if (g != gatt) return;
                if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    try {
                        if (!g.discoverServices()) { if (pendingConnect != -1) fail(pendingConnect, "Service discovery did not start"); closeGatt(true); }
                    } catch (Exception e) { if (pendingConnect != -1) fail(pendingConnect, e.getMessage()); closeGatt(true); }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                    closeGatt(true);
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            main.post(() -> {
                if (g != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    if (pendingConnect != -1) fail(pendingConnect, "Service discovery failed (" + status + ")");
                    closeGatt(true); return;
                }
                connected = true;
                EventJournal.append(context, "Watch BLE connected; subscribing to native alarm and button events");
                reconnectDelayMs=7000L;
                owner.updateMonitorStatus(true);
                owner.timerEngine().onLinkChanged(true);
                owner.alarmEngine().onLinkChanged(true);
                // Restore the alarm CCCD from native code even with no WebView.
                // The watch can drop this subscription whenever GATT reconnects.
                enqueue(-2, "subscribe", ALARM_STATUS_UUID.toString(), null);
                enqueue(-3, "subscribe", EVENT_STATUS_UUID.toString(), null);
                int id = pendingConnect;
                pendingConnect = -1;
                if (id >= 0) succeed(id, "true");
                if (pendingClientConnect >= 0) { succeed(pendingClientConnect, "true"); pendingClientConnect = -1; }
            });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] b = c.getValue();
            if (b != null) main.post(() -> { if (g == gatt) notifyCharacteristic(c.getUuid(), b); });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            final byte[] b = value.clone();
            main.post(() -> { if (g == gatt) notifyCharacteristic(c.getUuid(), b); });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            byte[] b = c.getValue();
            finishRead(g, c, b, status);
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) {
            finishRead(g, c, value, status);
        }
        private void finishRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] bytes, int status) {
            final byte[] data = bytes == null ? new byte[0] : bytes.clone();
            main.post(() -> {
                if (g != gatt || active == null || !"read".equals(active.action) || !c.getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, bytesJson(data));
                else completeOperation(false, "Characteristic read failed (" + status + ")");
            });
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            main.post(() -> {
                if (g != gatt || active == null || !"write".equals(active.action) || !c.getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, "true");
                else completeOperation(false, "Characteristic write failed (" + status + ")");
            });
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            main.post(() -> {
                if (g != gatt || active == null || !"subscribe".equals(active.action) || !d.getCharacteristic().getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, "true");
                else completeOperation(false, "Notification subscription failed (" + status + ")");
            });
        }
    };

    void close() {
        main.post(() -> {
            disposed = true;
            if (reconnectTask != null) main.removeCallbacks(reconnectTask);
            reconnectTask = null;
            stopScanning();
            closeGatt(false);
        });
    }
}
