package com.projectrcc.pavlokcontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;

import org.json.JSONObject;

/**
 * Owns timer deadlines and repeated watch stimuli outside the Activity/WebView.
 * All mutations and scheduled actions run on the main looper; snapshots read persisted state.
 * Nothing in this class modifies scheduled watch alarms or their snooze state.
 */
final class NativeTimerEngine {
    private static final String PREFS = "pavlok_native_timer_v2012";
    private static final String CHANNEL = "pavlok_timer_watch_unavailable_v2012";
    private static final int WARNING_ID = 21212;
    private static final int MAX_ZAPS = 12;
    private final WatchMonitorService owner;
    private final Context context;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable scheduled;
    private Runnable shortPress;
    private long lastLongPress;
    private long lastShortPress;

    private String phase = "ready";
    private int baseSeconds = 300, seconds = 300, remaining = 300;
    private int buzz = 3, beep = 3, zaps = 1, intensity = 40, intervalSeconds = 8;
    private long deadline;
    private int index, cycle, zapsSent;
    private long nextPulseAt, groupStartedAt;
    private boolean skipNativeFirst;
    private boolean warningShown;
    private int snoozeSeconds = 420, snoozes = 0, musicDelay = 10, musicAfterSnoozes = 0, musicVolume = 100, musicRisePercent = 10, musicRiseSeconds = 15, musicCurrentVolume = 100, zapsAfterSnoozes = 0;
    private long sessionId;
    private boolean smartTimeout = true, music = false;
    private String musicUri = "";
    private long timeoutAt, musicDue, musicRiseAt;
    boolean isSessionActive() { return active(); }

    NativeTimerEngine(WatchMonitorService owner) {
        this.owner = owner;
        this.context = owner.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
        channel();
        schedule();
        TimerNotifications.update(context, phase, deadline, remainingNow());
        if ("alerting".equals(phase)) TimerNotifications.timesUp(context, false, music && !musicUri.isEmpty());
    }

    private static int bound(int n, int min, int max) { return Math.min(max, Math.max(min, n)); }
    private boolean active() { return !"ready".equals(phase); }
    private long now() { return System.currentTimeMillis(); }
    private int remainingNow() {
        return ("countdown".equals(phase) || "snoozing".equals(phase))
            ? (int)Math.max(0, Math.ceil((deadline - now()) / 1000.0))
            : ("alerting".equals(phase) ? 0 : remaining);
    }
    private int sequenceLength() { return buzz + beep + (snoozes>=zapsAfterSnoozes?zaps:0); }
    private int stimulusType(int at) {
        if (at < buzz) return 1;
        if (at < buzz + beep) return 2;
        return 3;
    }
    private void load() {
        phase = prefs.getString("phase", "ready");
        baseSeconds = bound(prefs.getInt("base", 300), 1, 86399);
        seconds = bound(prefs.getInt("seconds", baseSeconds), 1, 86399);
        remaining = bound(prefs.getInt("remaining", baseSeconds), 0, 86399);
        deadline = prefs.getLong("deadline", 0);
        buzz = bound(prefs.getInt("buzz", 3), 0, 5);
        beep = bound(prefs.getInt("beep", 3), 0, 5);
        zaps = bound(prefs.getInt("zaps", 1), 0, 5);
        intensity = bound(prefs.getInt("intensity", 40), 10, 100);
        intervalSeconds = bound(prefs.getInt("interval", 8), Math.max(3, Math.max(buzz, beep)+1), 30);
        cycle = Math.max(0, prefs.getInt("cycle", 0));
        index = Math.max(0, prefs.getInt("index", 0));
        zapsSent = bound(prefs.getInt("sent", 0), 0, MAX_ZAPS);
        nextPulseAt = prefs.getLong("next", 0);
        groupStartedAt = prefs.getLong("groupStart", 0);
        skipNativeFirst = prefs.getBoolean("skip", false);
        warningShown = prefs.getBoolean("warning", false);
        snoozeSeconds = bound(prefs.getInt("snoozeSeconds", 420), 60, 3600);
        musicDelay = 10; musicAfterSnoozes = bound(prefs.getInt("musicAfterSnoozes",0),0,99);
        musicVolume=bound(prefs.getInt("musicVolume",100),10,100);
        musicRisePercent=bound(prefs.getInt("musicRisePercent",0),0,50);
        musicRiseSeconds=bound(prefs.getInt("musicRiseSeconds",15),3,120);
        musicCurrentVolume=bound(prefs.getInt("musicCurrentVolume",musicVolume),10,100);
        zapsAfterSnoozes=bound(prefs.getInt("zapsAfterSnoozes",0),0,99);
        musicRiseAt=prefs.getLong("musicRiseAt",0);
        sessionId = prefs.getLong("sessionId",0);
        snoozes = Math.max(0, prefs.getInt("snoozes", 0));
        timeoutAt = prefs.getLong("timeoutAt", 0); musicDue = prefs.getLong("musicDue", 0);
        smartTimeout = prefs.getBoolean("smartTimeout", true);
        music = prefs.getBoolean("music", false); musicUri = prefs.getString("musicUri", "");
        if (!("countdown".equals(phase) || "snoozing".equals(phase) || "paused".equals(phase) || "alerting".equals(phase)) ||
                (deadline > 0 && deadline > now() + 86400000L)) {
            phase = "ready"; remaining = baseSeconds; deadline = 0;
        }
        if ("alerting".equals(phase)) {
            nextPulseAt = Math.max(now() + 1000, nextPulseAt);
            if (groupStartedAt <= 0) groupStartedAt = now();
        }
    }
    private void persist() {
        prefs.edit().putString("phase", phase).putInt("base", baseSeconds).putInt("seconds", seconds)
            .putInt("remaining", remaining).putLong("deadline", deadline)
            .putInt("buzz", buzz).putInt("beep", beep).putInt("zaps", zaps)
            .putInt("intensity", intensity).putInt("interval", intervalSeconds)
            .putInt("cycle", cycle).putInt("index", index)
            .putInt("sent", zapsSent).putLong("next", nextPulseAt).putLong("groupStart", groupStartedAt)
            .putBoolean("skip", skipNativeFirst).putBoolean("warning", warningShown)
            .putInt("snoozeSeconds", snoozeSeconds).putInt("musicDelay",musicDelay).putInt("musicAfterSnoozes",musicAfterSnoozes).putInt("musicVolume",musicVolume).putInt("musicRisePercent",musicRisePercent).putInt("musicRiseSeconds",musicRiseSeconds).putInt("musicCurrentVolume",musicCurrentVolume).putInt("zapsAfterSnoozes",zapsAfterSnoozes).putLong("musicRiseAt",musicRiseAt).putLong("sessionId",sessionId)
            .putInt("snoozes", snoozes).putLong("timeoutAt",timeoutAt).putLong("musicDue", musicDue)
            .putBoolean("smartTimeout",smartTimeout).putBoolean("music",music).putString("musicUri",musicUri).apply();
    }
    String snapshot() {
        // SharedPreferences are thread-safe; this method is called from WebView's JS interface thread.
        String p = prefs.getString("phase", "ready");
        int base = prefs.getInt("base", 300);
        long due = prefs.getLong("deadline", 0);
        int rest = prefs.getInt("remaining", base);
        if ("countdown".equals(p) || "snoozing".equals(p))
            rest = (int)Math.max(0, Math.ceil((due - System.currentTimeMillis()) / 1000.0));
        if ("alerting".equals(p)) rest = 0;
        try {
            return new JSONObject().put("phase", p).put("active", !"ready".equals(p))
                .put("baseSeconds", base).put("seconds", prefs.getInt("seconds", base))
                .put("remaining", rest).put("deadline", due)
                .put("buzz", prefs.getInt("buzz", 3)).put("beep", prefs.getInt("beep", 3))
                .put("zaps", prefs.getInt("zaps", 1)).put("intensity", prefs.getInt("intensity", 40))
                .put("interval", prefs.getInt("interval", 8))
                .put("cycle", prefs.getInt("cycle", 0)).put("zapsSent", prefs.getInt("sent", 0))
                .put("snoozes",prefs.getInt("snoozes",0)).put("snoozeSeconds",prefs.getInt("snoozeSeconds",420))
                .toString();
        } catch (Exception e) { return "null"; }
    }

    void command(String action, JSONObject config) {
        if ("start".equals(action)) {
            // Do not silently replace an existing manual or Code Red countdown.
            if (!"ready".equals(phase))
                throw new IllegalStateException("A timer is already in progress.");
            if (owner.alarmEngine().isActive())
                throw new IllegalStateException("An Android alarm is activated or snoozing.");
            int duration = bound(config.optInt("seconds", 300), 1, 86399);
            int b = bound(config.optInt("buzz", 3), 0, 5);
            int p = bound(config.optInt("beep", 3), 0, 5);
            int z = bound(config.optInt("zaps", 1), 0, 5);
            if (b + p + z == 0) throw new IllegalArgumentException("Select at least one stimulus");
            baseSeconds = duration; seconds = duration; remaining = duration;
            buzz = b; beep = p; zaps = z; intensity = bound(config.optInt("intensity", 40), 10, 100);
            intervalSeconds = bound(config.optInt("interval", 8), Math.max(3, Math.max(buzz, beep)+1), 30);
            skipNativeFirst = false;
            snoozeSeconds = bound(config.optInt("snoozeSeconds", 420),60,3600);
            musicDelay = 10; musicAfterSnoozes=bound(config.optInt("musicAfterSnoozes",0),0,99); snoozes=0;
            musicVolume=bound(config.optInt("musicStartVolume",PavDroidAudio.timerVolume(context)),10,100);
            musicRisePercent=bound(config.optInt("musicRisePercent",10),0,50);
            musicRiseSeconds=bound(config.optInt("musicRiseSeconds",15),3,120);
            musicCurrentVolume=musicVolume;
            zapsAfterSnoozes=bound(config.optInt("zapsAfterSnoozes",0),0,99);
            musicRiseAt=0;
            sessionId=now();
            smartTimeout = config.optBoolean("smartTimeout",true);
            music = config.optBoolean("music",false); musicUri=PavDroidAudio.selectedUri(context,config.optString("musicUri",""));musicDue=0;
            timeoutAt = 0L; // Countdown is not an alert; start initial 1h on Times Up.
            startCountdown("countdown", duration);
        } else if ("snooze".equals(action)) {
            // Snooze only the actual Times Up state. Re-pressing the watch button
            // during an existing snooze must never restart its five-minute clock.
            if (!"alerting".equals(phase))
                throw new IllegalStateException("Snooze is available only after time expires");
            // A new snooze round gets a fresh 12-zap ceiling, as before.
            snoozes++;
            if(smartTimeout)timeoutAt=now()+7200000L;
            musicDue=0;musicRiseAt=0;owner.audio().stop();
            seconds = snoozeSeconds;
            skipNativeFirst = false;
            startCountdown("snoozing", seconds);
            PavDroidHistory.record(context,"timer",sessionId,"snoozing","Timer","Phone snooze "+snoozes);
        } else if ("pause".equals(action)) {
            if ("snoozing".equals(phase) || "alerting".equals(phase)) {
                EventJournal.append(context, "Timer pause ignored during snooze/Time Expired; Stop remains available");
                return;
            }
            if ("countdown".equals(phase)) {
                remaining = remainingNow(); deadline = 0; phase = "paused";
                PavDroidHistory.record(context,"timer",sessionId,"paused","Timer","Paused");
            }
            persist(); schedule();
            TimerNotifications.update(context, phase, deadline, remainingNow());
        } else if ("resume".equals(action)) {
            if (!"paused".equals(phase)) return;
            if (remaining <= 0) beginAlert();
            else { deadline = now() + remaining * 1000L; phase = "countdown";
                PavDroidHistory.record(context,"timer",sessionId,"countdown","Timer","Resumed");persist(); schedule();
                TimerNotifications.update(context, phase, deadline, remainingNow()); }
        } else if ("reset".equals(action)) {
            stopTimer("app or notification Stop");
        } else throw new IllegalArgumentException("Unknown timer action");
    }

    /** Screen, notification and physical-watch Stop all use the same code.
     *  Each performs one local reset plus one priority firmware reset command.
     *  Automatic safety resets remain local and do not enqueue another command.
     */
    private void stopTimer(String source) {
        String stoppedPhase = phase;
        if(active())PavDroidHistory.record(context,"timer",sessionId,"stopped","Timer",source+" (was "+stoppedPhase+")");
        reset();
        EventJournal.append(context, "PavDroid timer Stop from " + source +
                " (was " + stoppedPhase + "); Android timer reset only");
    }
    private void startCountdown(String state, int duration) {
        cancelScheduled();
        owner.bridge().discardQueuedTimerStimuli();
        phase = state; seconds = duration; remaining = duration; deadline = now() + duration * 1000L;
        cycle = 0; index = 0; zapsSent = 0; nextPulseAt = 0; groupStartedAt = 0; warningShown = false;
        cancelWarning(); persist(); schedule();
        TimerNotifications.update(context, phase, deadline, remainingNow());

        EventJournal.append(context, "Timer status notification: " + state);
        if("countdown".equals(state))PavDroidHistory.record(context,"timer",sessionId,"countdown","Timer","Countdown started: "+duration+"s");
    }
    private void reset() {
        cancelScheduled();
        owner.bridge().discardQueuedTimerStimuli();
        phase = "ready"; seconds = baseSeconds; remaining = baseSeconds; deadline = 0;
        cycle = 0; index = 0; zapsSent = 0; nextPulseAt = 0; groupStartedAt = 0; warningShown = false;
        cancelWarning(); persist();
        TimerNotifications.update(context, phase, deadline, remainingNow());
        owner.audio().stop(); timeoutAt=0;musicDue=0;musicRiseAt=0;snoozes=0;sessionId=0;persist();
    }
    void onLinkChanged(boolean connected) {
        if (connected) {
            cancelWarning(); warningShown = false; persist();
        }
        schedule();
    }
    private void cancelScheduled() {
        if (scheduled != null) handler.removeCallbacks(scheduled);
        scheduled = null;
    }
    private void schedule() {
        cancelScheduled();
        long delay;
        if ("countdown".equals(phase) || "snoozing".equals(phase))
            delay = Math.min(1000L, Math.max(0, deadline - now()));
        else if ("alerting".equals(phase)) {
            long next=Math.max(0,nextPulseAt-now());
            delay=musicDue>0?Math.min(next,Math.max(0,musicDue-now())):next;
            if(musicRiseAt>0)delay=Math.min(delay,Math.max(0,musicRiseAt-now()));
        }
        else return;
        scheduled = this::tick;
        handler.postDelayed(scheduled, Math.min(delay, 30000L));
    }
    private void tick() {
        scheduled = null;
        if("alerting".equals(phase) && musicDue>0 && now()>=musicDue){
            musicDue=0;musicCurrentVolume=musicVolume;
            boolean played=owner.audio().start(musicUri,musicCurrentVolume);
            musicRiseAt=played&&musicRisePercent>0&&musicCurrentVolume<100?now()+musicRiseSeconds*1000L:0;
            PavDroidHistory.record(context,"timer",sessionId,"music","Timer",played?"MP3 started · "+owner.audio().playbackVolumeDetails():"MP3 FAILED; see Connection log");persist();
        }
        if("alerting".equals(phase)&&musicRiseAt>0&&now()>=musicRiseAt){
            int steps=(int)Math.min(100,1+(now()-musicRiseAt)/(musicRiseSeconds*1000L));
            int next=bound(musicCurrentVolume+steps*musicRisePercent,10,100);
            if(next>musicCurrentVolume){musicCurrentVolume=next;
                String report=owner.audio().adjustVolume(next);
                PavDroidHistory.record(context,"timer",sessionId,"volume","Timer","Volume increased · "+report);}
            musicRiseAt=next>=100?0:musicRiseAt+steps*musicRiseSeconds*1000L;persist();
        }
        if("alerting".equals(phase)&&smartTimeout&&timeoutAt>0&&now()>=timeoutAt){stopTimer("Smart Timeout");return;}
        if (("countdown".equals(phase) || "snoozing".equals(phase)) && now() >= deadline) beginAlert();
        else if ("alerting".equals(phase)) performPulse();
        else {
            // Text-only countdown refresh. No BLE write, watch timer change,
            // stimulus delivery, or snooze logic is performed here.
            if ("countdown".equals(phase) || "snoozing".equals(phase))
                TimerNotifications.update(context, phase, deadline, remainingNow());
            schedule();
        }
    }
    private void beginAlert() {
        phase = "alerting"; remaining = 0; deadline = 0;
        index = skipNativeFirst ? 1 : 0;
        zapsSent = skipNativeFirst && buzz == 0 && beep == 0 && zaps > 0 ? 1 : 0;
        cycle = 1; groupStartedAt = now(); nextPulseAt = groupStartedAt + (skipNativeFirst ? 1000 : 0);
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { stopTimer("automatic stimulus safety limit"); return; }
            index = 0; cycle = 2; groupStartedAt = now() + intervalSeconds * 1000L; nextPulseAt = groupStartedAt;
        }
        persist(); schedule();
        TimerNotifications.timesUp(context, true, music && !musicUri.isEmpty());
        musicDue=music&&!musicUri.isEmpty()&&snoozes>=musicAfterSnoozes?now()+10_000L:0;musicRiseAt=0;musicCurrentVolume=musicVolume;
        PavDroidHistory.record(context,"timer",sessionId,"alerting","Timer","Time Expired");
        if(zaps > 0 && snoozes < zapsAfterSnoozes){
            EventJournal.append(context, "PavDroid timer zaps held: " + snoozes + "/" + zapsAfterSnoozes + " completed snoozes; buzz/beep remain active");
        } else if(zaps > 0){
            EventJournal.append(context, "PavDroid timer zaps eligible after " + snoozes + " snoozes; ramp 10% to " + intensity + "%");
        }
        if(smartTimeout){
            if(timeoutAt==0)timeoutAt=now()+3600000L;
            else if(timeoutAt<now()+120000L)timeoutAt=now()+120000L;
        }
        persist();
    }
    /**
     * The configured interval separates the START of each stimulus group
     * (buzzes, beeps, zaps) and each subsequent cycle. Within a group,
     * individual stimuli remain 1s apart, up to five per group. The interval
     * is always at least one second greater than the larger buzz/beep count
     * (and no less than three seconds), so sequential groups do not overlap.
     * Example with 8s interval: buzz at 0/1/2s, beep at 8/9/10s,
     * zap at 16s, next buzz at 24s. This gives time to snooze before zaps.
     */
    private boolean afterPulse(int justSentType) {
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { stopTimer("automatic stimulus safety limit"); return true; }
            index = 0;
            cycle++;
            groupStartedAt = Math.max(now() + 1000L, groupStartedAt + intervalSeconds * 1000L);
            nextPulseAt = groupStartedAt;
        } else if (stimulusType(index) != justSentType) {
            groupStartedAt = Math.max(now() + 1000L, groupStartedAt + intervalSeconds * 1000L);
            nextPulseAt = groupStartedAt;
        } else {
            nextPulseAt = now() + 1000L;
        }
        return false;
    }
    private void performPulse() {
        if (!"alerting".equals(phase)) return;
        if (now() < nextPulseAt) { schedule(); return; }
        if (sequenceLength() == 0) { nextPulseAt=now()+intervalSeconds*1000L;persist();schedule();return; }
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { stopTimer("automatic stimulus safety limit"); return; }
            index = 0; cycle++;
            groupStartedAt = now() + intervalSeconds * 1000L;
            nextPulseAt = groupStartedAt;
            persist(); schedule(); return;
        }
        if (!owner.bridge().hasWatchConnection()) {
            warnDisconnected();
            nextPulseAt = now() + 2000L;
            persist(); schedule(); return;
        }
        cancelWarning(); warningShown = false;
        int type = stimulusType(index);
        // Defense in depth: even if a restored/stale index points at a Zap,
        // NEVER queue it before the user-selected number of completed snoozes.
        if (type == 3 && snoozes < zapsAfterSnoozes) {
            EventJournal.append(context,"PavDroid timer blocked a zap before snooze threshold (" + snoozes + "/" + zapsAfterSnoozes + ")");
            index++;
            if (afterPulse(type)) return;
            persist(); schedule(); return;
        }
        if (type == 3 && zapsSent >= MAX_ZAPS) {
            index++;
            if (afterPulse(type)) return;
            persist(); schedule(); return;
        }
        int pct=type==3?Math.min(intensity,10+10*zapsSent):100;
        boolean sent = owner.bridge().queueTimerStimulus(type,pct);
        if (!sent) {
            warnDisconnected(); nextPulseAt = now() + 2000L; persist(); schedule(); return;
        }
        if (type == 3){zapsSent++;PavDroidHistory.record(context,"timer",sessionId,"stimulus","Timer","Zap "+pct+"% queued ("+zapsSent+"/12 this launch)");}
        index++;
        if (afterPulse(type)) return;
        persist(); schedule();
    }
    void onWatchEvent(byte[] b) {
        if (b == null || b.length < 2) return;
        // Observe (but do not act on) firmware timer telemetry for three
        // seconds after a physical Stop. Android Ready by itself does not
        // prove the watch's firmware has stopped.
        if (b[0] == 0x0d && b.length >= 7 && b[1] == 2 && lastLongPress > 0 &&
                now() - lastLongPress >= 0 && now() - lastLongPress < 3000 && "ready".equals(phase)) {
            boolean firmwareRunning = (b[2] & 0x80) != 0;
            int elapsed = (b[3] & 0xff) | ((b[4] & 0xff) << 8) | ((b[5] & 0xff) << 16);
            EventJournal.append(context, "Post-hold watch timer telemetry: firmware " +
                    (firmwareRunning ? "RUNNING" : "not running") + ", elapsed=" + elapsed + "s");
            return;
        }
        if (b[0] != 0x05 || (b[1] & 0xf0) != 0x20) return;
        // Audit the physical watch button BEFORE checking timer ownership.
        // During a watch alarm the native timer correctly ignores the button,
        // but the History must still know if the firmware sent a long-press packet.

        if (!active())return;
        // Watch button presses must not hijack an actual scheduled alarm.
        if(owner.alarmEngine().isActive())return;
        int press = b[1] & 0x0f;
        long t = now();
        if (press == 3) {
            // A held middle button is Stop in every active timer state.
            if (t - lastLongPress < 750) return;
            lastLongPress = t;
            if (shortPress != null) handler.removeCallbacks(shortPress);
            shortPress = null;
            stopTimer("middle-button long press");
            // Android-owned timer: no watch firmware reset.
        } else if (press == 1) {
            // Physical short presses ONLY snooze when Times Up is alerting.
            // A press during a running countdown or existing snooze does not
            // refresh the five-minute deadline or change firmware timer state.
            if (!"alerting".equals(phase)) {
                EventJournal.append(context, "Timer short press ignored during " + phase +
                        "; existing countdown deadline preserved");
                return;
            }
            if (t - lastShortPress < 750 || shortPress != null) return;
            lastShortPress = t;
            // Hold further queued stimuli while distinguishing a tap from a
            // hold; the subsequent long-press event cancels this callback.
            cancelScheduled(); owner.bridge().discardQueuedTimerStimuli();
            shortPress = () -> {
                shortPress = null;
                if (!"alerting".equals(phase)) return;
                snoozes++;
                if(smartTimeout)timeoutAt=now()+7200000L;
                musicDue=0;musicRiseAt=0;owner.audio().stop();
                seconds = snoozeSeconds; skipNativeFirst = false;
                startCountdown("snoozing", seconds);
                PavDroidHistory.record(context,"timer",sessionId,"snoozing","Timer","Watch snooze "+snoozes);
                EventJournal.append(context, "PavDroid timer snoozed by middle-button tap");
            };
            handler.postDelayed(shortPress, 950);
        }
    }
    private void channel() {
        NotificationManager m = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (m != null) {
            NotificationGroups.ensure(context, m);
        // Optional watch-disconnect warning: off on a fresh installation.
        // Timer countdown/alerts use separate channels and remain enabled.
        NotificationChannel c = new NotificationChannel(CHANNEL, "Timer connection warning", NotificationManager.IMPORTANCE_NONE);
        c.setGroup(NotificationGroups.CONNECTIONS);
            c.setDescription("Warns if a timer finishes while its Pavlok watch is disconnected");
            c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            m.createNotificationChannel(c);
        }
    }
    private void warnDisconnected() {
        if (warningShown) return;
        warningShown = true;
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) return;
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, WARNING_ID, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nm.notify(WARNING_ID, new Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Timer ended — check watch")
            .setContentText("Pavlok is disconnected. Watch vibration, beeps and zaps cannot be confirmed.")
            .setContentIntent(pending).setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true).build());
    }
    private void cancelWarning() {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(WARNING_ID);
    }
    void close() { cancelScheduled(); if (shortPress != null) handler.removeCallbacks(shortPress); }
}
