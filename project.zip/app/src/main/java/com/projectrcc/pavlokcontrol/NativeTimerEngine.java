package com.projectrcc.pavlokcontrol;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;

import org.json.JSONObject;

/**
 * Owns timer deadlines and repeated watch stimuli outside the Activity/WebView.
 * All mutations and scheduled actions run on the main looper; snapshots read persisted state.
 * Nothing in this class modifies scheduled watch alarms or their snooze state.
 */
final class NativeTimerEngine {
    private static final String PREFS = "pavlok_native_timer_v2012";
    private static final String CHANNEL = "pavlok_timer_watch_unavailable_v2012";
    private static final int WARNING_ID = 21212;
    private static final int MAX_ZAPS = 12;
    private final WatchMonitorService owner;
    private final Context context;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable scheduled;
    private Runnable shortPress;
    private long lastLongPress;
    private long lastShortPress;

    private String phase = "ready";
    private int baseSeconds = 300, seconds = 300, remaining = 300;
    private int buzz = 3, beep = 3, zaps = 1, intensity = 40, intervalSeconds = 8;
    private long deadline;
    private int index, cycle, zapsSent;
    private long nextPulseAt, groupStartedAt;
    private boolean skipNativeFirst;
    private boolean warningShown;

    NativeTimerEngine(WatchMonitorService owner) {
        this.owner = owner;
        this.context = owner.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
        channel();
        schedule();
        TimerNotifications.update(context, phase, deadline, remainingNow());
        if ("alerting".equals(phase)) TimerNotifications.timesUp(context, false);
    }

    private static int bound(int n, int min, int max) { return Math.min(max, Math.max(min, n)); }
    private boolean active() { return !"ready".equals(phase); }
    private long now() { return System.currentTimeMillis(); }
    private int remainingNow() {
        return ("countdown".equals(phase) || "snoozing".equals(phase))
            ? (int)Math.max(0, Math.ceil((deadline - now()) / 1000.0))
            : ("alerting".equals(phase) ? 0 : remaining);
    }
    private int sequenceLength() { return buzz + beep + zaps; }
    private int stimulusType(int at) {
        if (at < buzz) return 1;
        if (at < buzz + beep) return 2;
        return 3;
    }
    private void load() {
        phase = prefs.getString("phase", "ready");
        baseSeconds = bound(prefs.getInt("base", 300), 1, 86399);
        seconds = bound(prefs.getInt("seconds", baseSeconds), 1, 86399);
        remaining = bound(prefs.getInt("remaining", baseSeconds), 0, 86399);
        deadline = prefs.getLong("deadline", 0);
        buzz = bound(prefs.getInt("buzz", 3), 0, 5);
        beep = bound(prefs.getInt("beep", 3), 0, 5);
        zaps = bound(prefs.getInt("zaps", 1), 0, 5);
        intensity = bound(prefs.getInt("intensity", 40), 10, 100);
        intervalSeconds = bound(prefs.getInt("interval", 8), 5, 30);
        cycle = Math.max(0, prefs.getInt("cycle", 0));
        index = Math.max(0, prefs.getInt("index", 0));
        zapsSent = bound(prefs.getInt("sent", 0), 0, MAX_ZAPS);
        nextPulseAt = prefs.getLong("next", 0);
        groupStartedAt = prefs.getLong("groupStart", 0);
        skipNativeFirst = prefs.getBoolean("skip", false);
        warningShown = prefs.getBoolean("warning", false);
        if (!("countdown".equals(phase) || "snoozing".equals(phase) || "paused".equals(phase) || "alerting".equals(phase)) ||
                (deadline > 0 && deadline > now() + 86400000L)) {
            phase = "ready"; remaining = baseSeconds; deadline = 0;
        }
        if ("alerting".equals(phase)) {
            nextPulseAt = Math.max(now() + 1000, nextPulseAt);
            if (groupStartedAt <= 0) groupStartedAt = now();
        }
    }
    private void persist() {
        prefs.edit().putString("phase", phase).putInt("base", baseSeconds).putInt("seconds", seconds)
            .putInt("remaining", remaining).putLong("deadline", deadline)
            .putInt("buzz", buzz).putInt("beep", beep).putInt("zaps", zaps)
            .putInt("intensity", intensity).putInt("interval", intervalSeconds)
            .putInt("cycle", cycle).putInt("index", index)
            .putInt("sent", zapsSent).putLong("next", nextPulseAt).putLong("groupStart", groupStartedAt)
            .putBoolean("skip", skipNativeFirst).putBoolean("warning", warningShown).apply();
    }
    String snapshot() {
        // SharedPreferences are thread-safe; this method is called from WebView's JS interface thread.
        String p = prefs.getString("phase", "ready");
        int base = prefs.getInt("base", 300);
        long due = prefs.getLong("deadline", 0);
        int rest = prefs.getInt("remaining", base);
        if ("countdown".equals(p) || "snoozing".equals(p))
            rest = (int)Math.max(0, Math.ceil((due - System.currentTimeMillis()) / 1000.0));
        if ("alerting".equals(p)) rest = 0;
        try {
            return new JSONObject().put("phase", p).put("active", !"ready".equals(p))
                .put("baseSeconds", base).put("seconds", prefs.getInt("seconds", base))
                .put("remaining", rest).put("deadline", due)
                .put("buzz", prefs.getInt("buzz", 3)).put("beep", prefs.getInt("beep", 3))
                .put("zaps", prefs.getInt("zaps", 1)).put("intensity", prefs.getInt("intensity", 40))
                .put("interval", prefs.getInt("interval", 8))
                .put("cycle", prefs.getInt("cycle", 0)).put("zapsSent", prefs.getInt("sent", 0))
                .toString();
        } catch (Exception e) { return "null"; }
    }

    void command(String action, JSONObject config) {
        if ("start".equals(action)) {
            // Do not silently replace an existing manual or Code Red countdown.
            if (!"ready".equals(phase))
                throw new IllegalStateException("A timer is already in progress.");
            try {
                JSONObject alarm = new JSONObject(SnoozeGuard.snapshot(context));
                String state = alarm.optString("state", "unknown");
                if ("firing".equals(state) || "snoozed".equals(state)) {
                    boolean safeCodeRedHandoff = config.optBoolean("codeRedHandoff", false)
                        && owner.codeRedGuard() != null
                        && owner.codeRedGuard().mayStartHandoffWhileOldSnoozeReported(alarm.optInt("id", -1));
                    if (!safeCodeRedHandoff)
                        throw new IllegalStateException("An alarm is currently firing or snoozing.");
                }
            } catch (org.json.JSONException ignored) { }
            int duration = bound(config.optInt("seconds", 300), 1, 86399);
            int b = bound(config.optInt("buzz", 3), 0, 5);
            int p = bound(config.optInt("beep", 3), 0, 5);
            int z = bound(config.optInt("zaps", 1), 0, 5);
            if (b + p + z == 0) throw new IllegalArgumentException("Select at least one stimulus");
            baseSeconds = duration; seconds = duration; remaining = duration;
            buzz = b; beep = p; zaps = z; intensity = bound(config.optInt("intensity", 40), 10, 100);
            intervalSeconds = bound(config.optInt("interval", 8), 5, 30);
            skipNativeFirst = config.optBoolean("nativeFirst", false);
            startCountdown("countdown", duration);
        } else if ("snooze".equals(action)) {
            // Snooze only the actual Times Up state. Re-pressing the watch button
            // during an existing snooze must never restart its five-minute clock.
            if (!"alerting".equals(phase))
                throw new IllegalStateException("Snooze is available only while Times Up is alerting");
            // A new snooze round gets a fresh 12-zap ceiling, as before.
            seconds = 300;
            skipNativeFirst = false;
            startCountdown("snoozing", 300);
            // The 5-minute snooze belongs to this native engine. Do not start a
            // second timer on the watch (the V2.0.34 double-timer failure).
            owner.bridge().queueFirmwareResetAtSnooze();
        } else if ("pause".equals(action)) {
            if ("snoozing".equals(phase) || "alerting".equals(phase)) {
                EventJournal.append(context, "Timer pause ignored during snooze/Times Up; Stop remains available");
                return;
            }
            if ("countdown".equals(phase)) {
                remaining = remainingNow(); deadline = 0; phase = "paused";
            }
            persist(); schedule();
            TimerNotifications.update(context, phase, deadline, remainingNow());
        } else if ("resume".equals(action)) {
            if (!"paused".equals(phase)) return;
            if (remaining <= 0) beginAlert();
            else { deadline = now() + remaining * 1000L; phase = "countdown"; persist(); schedule();
                TimerNotifications.update(context, phase, deadline, remainingNow()); }
        } else if ("reset".equals(action)) {
            stopTimer("app or notification Stop");
        } else throw new IllegalArgumentException("Unknown timer action");
    }

    /** Screen, notification and physical-watch Stop all use the same code.
     *  Each performs one local reset plus one priority firmware reset command.
     *  Automatic safety resets remain local and do not enqueue another command.
     */
    private void stopTimer(String source) {
        String stoppedPhase = phase;
        reset();
        boolean queued = owner.bridge().queuePriorityTimerFirmwareStop();
        EventJournal.append(context, "Timer Stop from " + source + " (was " + stoppedPhase +
                "); restored to " + baseSeconds + "s; shared priority watch reset " +
                (queued ? "queued (execution not confirmed)" : "NOT sent (watch disconnected)"));
    }
    private void startCountdown(String state, int duration) {
        cancelScheduled();
        owner.bridge().discardQueuedTimerStimuli();
        phase = state; seconds = duration; remaining = duration; deadline = now() + duration * 1000L;
        cycle = 0; index = 0; zapsSent = 0; nextPulseAt = 0; groupStartedAt = 0; warningShown = false;
        cancelWarning(); persist(); schedule();
        TimerNotifications.update(context, phase, deadline, remainingNow());
        if ("snoozing".equals(state) && owner.codeRedAudio() != null)
            owner.codeRedAudio().onTimerSnoozed();
        EventJournal.append(context, "Timer status notification: " + state);
    }
    private void reset() {
        cancelScheduled();
        owner.bridge().discardQueuedTimerStimuli();
        phase = "ready"; seconds = baseSeconds; remaining = baseSeconds; deadline = 0;
        cycle = 0; index = 0; zapsSent = 0; nextPulseAt = 0; groupStartedAt = 0; warningShown = false;
        cancelWarning(); persist();
        TimerNotifications.update(context, phase, deadline, remainingNow());
        if (owner.codeRedAudio() != null) owner.codeRedAudio().onTimerStopped();
    }
    void onLinkChanged(boolean connected) {
        if (connected) {
            cancelWarning(); warningShown = false; persist();
        }
        schedule();
    }
    private void cancelScheduled() {
        if (scheduled != null) handler.removeCallbacks(scheduled);
        scheduled = null;
    }
    private void schedule() {
        cancelScheduled();
        long delay;
        if ("countdown".equals(phase) || "snoozing".equals(phase))
            delay = Math.min(1000L, Math.max(0, deadline - now()));
        else if ("alerting".equals(phase)) delay = Math.max(0, nextPulseAt - now());
        else return;
        scheduled = this::tick;
        handler.postDelayed(scheduled, Math.min(delay, 30000L));
    }
    private void tick() {
        scheduled = null;
        if (("countdown".equals(phase) || "snoozing".equals(phase)) && now() >= deadline) beginAlert();
        else if ("alerting".equals(phase)) performPulse();
        else {
            // Text-only countdown refresh. No BLE write, watch timer change,
            // stimulus delivery, or snooze logic is performed here.
            if ("countdown".equals(phase) || "snoozing".equals(phase))
                TimerNotifications.update(context, phase, deadline, remainingNow());
            schedule();
        }
    }
    private void beginAlert() {
        phase = "alerting"; remaining = 0; deadline = 0;
        index = skipNativeFirst ? 1 : 0;
        zapsSent = skipNativeFirst && buzz == 0 && beep == 0 && zaps > 0 ? 1 : 0;
        cycle = 1; groupStartedAt = now(); nextPulseAt = groupStartedAt + (skipNativeFirst ? 1000 : 0);
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { reset(); return; }
            index = 0; cycle = 2; groupStartedAt = now() + intervalSeconds * 1000L; nextPulseAt = groupStartedAt;
        }
        persist(); schedule();
        TimerNotifications.timesUp(context, true);
        if (owner.codeRedAudio() != null && owner.codeRedGuard() != null)
            owner.codeRedAudio().onTimerAlerting(owner.codeRedGuard().activeTimerMp3Uri());
    }
    /**
     * The configured interval separates the START of each stimulus group
     * (buzzes, beeps, zaps) and each subsequent cycle. Within a group,
     * individual stimuli remain 1s apart, max five, so 5s is a safe minimum.
     * Example with 8s interval: buzz at 0/1/2s, beep at 8/9/10s,
     * zap at 16s, next buzz at 24s. This gives time to snooze before zaps.
     */
    private boolean afterPulse(int justSentType) {
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { reset(); return true; }
            index = 0;
            cycle++;
            groupStartedAt = Math.max(now() + 1000L, groupStartedAt + intervalSeconds * 1000L);
            nextPulseAt = groupStartedAt;
        } else if (stimulusType(index) != justSentType) {
            groupStartedAt = Math.max(now() + 1000L, groupStartedAt + intervalSeconds * 1000L);
            nextPulseAt = groupStartedAt;
        } else {
            nextPulseAt = now() + 1000L;
        }
        return false;
    }
    private void performPulse() {
        if (!"alerting".equals(phase)) return;
        if (now() < nextPulseAt) { schedule(); return; }
        if (sequenceLength() == 0) { reset(); return; }
        if (index >= sequenceLength()) {
            if (buzz == 0 && beep == 0 && zapsSent >= MAX_ZAPS) { reset(); return; }
            index = 0; cycle++;
            groupStartedAt = now() + intervalSeconds * 1000L;
            nextPulseAt = groupStartedAt;
            persist(); schedule(); return;
        }
        if (!owner.bridge().hasWatchConnection()) {
            warnDisconnected();
            nextPulseAt = now() + 2000L;
            persist(); schedule(); return;
        }
        cancelWarning(); warningShown = false;
        int type = stimulusType(index);
        if (type == 3 && zapsSent >= MAX_ZAPS) {
            index++;
            if (afterPulse(type)) return;
            persist(); schedule(); return;
        }
        boolean sent = owner.bridge().queueTimerStimulus(type, type == 3 ? intensity : 100);
        if (!sent) {
            warnDisconnected(); nextPulseAt = now() + 2000L; persist(); schedule(); return;
        }
        if (type == 3) zapsSent++;
        index++;
        if (afterPulse(type)) return;
        persist(); schedule();
    }
    void onWatchEvent(byte[] b) {
        if (b == null || b.length < 2) return;
        // Observe (but do not act on) firmware timer telemetry for three
        // seconds after a physical Stop. Android Ready by itself does not
        // prove the watch's firmware has stopped.
        if (b[0] == 0x0d && b.length >= 7 && b[1] == 2 && lastLongPress > 0 &&
                now() - lastLongPress >= 0 && now() - lastLongPress < 3000 && "ready".equals(phase)) {
            boolean firmwareRunning = (b[2] & 0x80) != 0;
            int elapsed = (b[3] & 0xff) | ((b[4] & 0xff) << 8) | ((b[5] & 0xff) << 16);
            EventJournal.append(context, "Post-hold watch timer telemetry: firmware " +
                    (firmwareRunning ? "RUNNING" : "not running") + ", elapsed=" + elapsed + "s");
            return;
        }
        if (b[0] != 0x05 || (b[1] & 0xf0) != 0x20) return;
        // Audit the physical watch button BEFORE checking timer ownership.
        // During a watch alarm the native timer correctly ignores the button,
        // but the History must still know if the firmware sent a long-press packet.
        if ((b[1] & 0x0f) == 3) SnoozeGuard.noteWatchMiddleLongPress(context);
        if (!active()) {
            // A Code Red audio-only handoff has no Android timer: the watch
            // button must still Snooze/Stop its local MP3 playback.
            if (owner.codeRedAudio() != null) owner.codeRedAudio().onAudioOnlyButton(b[1] & 0x0f);
            return;
        }
        // Watch button presses must not hijack an actual scheduled alarm.
        try {
            String alarmPhase = new JSONObject(SnoozeGuard.snapshot(context)).optString("state", "");
            if (("firing".equals(alarmPhase) || "snoozed".equals(alarmPhase)) &&
                    (owner.codeRedGuard() == null || !owner.codeRedGuard().ownsTimer())) return;
        } catch (Exception ignored) { }
        int press = b[1] & 0x0f;
        long t = now();
        if (press == 3) {
            // A held middle button is Stop in every active timer state.
            if (t - lastLongPress < 750) return;
            lastLongPress = t;
            if (shortPress != null) handler.removeCallbacks(shortPress);
            shortPress = null;
            stopTimer("middle-button long press");
            owner.codeRedGuard().onManualTimerCommand("reset");
        } else if (press == 1) {
            // Physical short presses ONLY snooze when Times Up is alerting.
            // A press during a running countdown or existing snooze does not
            // refresh the five-minute deadline or change firmware timer state.
            if (!"alerting".equals(phase)) {
                EventJournal.append(context, "Timer short press ignored during " + phase +
                        "; existing countdown deadline preserved");
                return;
            }
            if (t - lastShortPress < 750 || shortPress != null) return;
            lastShortPress = t;
            // Hold further queued stimuli while distinguishing a tap from a
            // hold; the subsequent long-press event cancels this callback.
            cancelScheduled(); owner.bridge().discardQueuedTimerStimuli();
            shortPress = () -> {
                shortPress = null;
                if (!"alerting".equals(phase)) return;
                seconds = 300; skipNativeFirst = false;
                startCountdown("snoozing", 300);
                // Kill the initial watch firmware timer instead of re-arming it
                // for 300 seconds. Android owns repeated snoozes (like Code Red).
                owner.bridge().queueFirmwareResetAtSnooze();
                EventJournal.append(context, "Timer snoozed by middle-button tap for 5 minutes (no firmware restart)");
            };
            handler.postDelayed(shortPress, 950);
        }
    }
    private void channel() {
        NotificationManager m = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (m != null) {
            NotificationGroups.ensure(context, m);
        // Optional watch-disconnect warning: off on a fresh installation.
        // Timer countdown/alerts use separate channels and remain enabled.
        NotificationChannel c = new NotificationChannel(CHANNEL, "Timer connection warning", NotificationManager.IMPORTANCE_NONE);
        c.setGroup(NotificationGroups.CONNECTIONS);
            c.setDescription("Warns if a timer finishes while its Pavlok watch is disconnected");
            c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            m.createNotificationChannel(c);
        }
    }
    private void warnDisconnected() {
        if (warningShown) return;
        warningShown = true;
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) return;
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, WARNING_ID, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nm.notify(WARNING_ID, new Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Timer ended — check watch")
            .setContentText("Pavlok is disconnected. Watch vibration, beeps and zaps cannot be confirmed.")
            .setContentIntent(pending).setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true).build());
    }
    private void cancelWarning() {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(WARNING_ID);
    }
    void close() { cancelScheduled(); if (shortPress != null) handler.removeCallbacks(shortPress); }
}
