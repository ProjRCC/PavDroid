package com.projectrcc.pavlokcontrol;

import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.Context;

/** Android Settings-only grouping for existing notification channels.
 * Grouping does not change channel IDs, importance, sound, actions or delivery.
 * Android can assign a group to an existing channel only if it has no group yet.
 */
final class NotificationGroups {
    static final String CONNECTIONS = "pavlok_group_connections";
    static final String ALARM = "pavlok_group_alarm";
    static final String TIMER = "pavlok_group_timer";
    static final String CODE_RED = "pavlok_group_code_red";
    private NotificationGroups() { }
    static void ensure(Context context, NotificationManager manager) {
        if (manager == null) return;
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CONNECTIONS, "Connections"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(ALARM, "Alarm"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(TIMER, "Timer"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CODE_RED, "Code Red"));
    }
}
