package com.projectrcc.pavlokcontrol;

import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.Context;

/** Android Settings-only grouping for existing notification channels.
 * Grouping does not change channel IDs, importance, sound, actions or delivery.
 * Android can assign a group to an existing channel only if it has no group yet.
 */
final class NotificationGroups {
    static final String CONNECTIONS = "pavlok_group_connections";
    static final String ALARM_TIMER = "pavlok_group_alarm_timer_v116";
    static final String ALARM = ALARM_TIMER;
    static final String TIMER = ALARM_TIMER;
    static final String SNOOZE_CHANNEL = "pavdroid_snooze_countdown_v116";
    static final String CODE_RED = "pavlok_group_code_red";
    private NotificationGroups() { }
    static void ensure(Context context, NotificationManager manager) {
        if (manager == null) return;
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CONNECTIONS, "Connections"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(ALARM_TIMER, "Alarm & Timer"));
        // Existing channels cannot change groups on upgrade without losing user settings.
        // Keep old group IDs rather than forcibly deleting and recreating any channels.
        manager.createNotificationChannelGroup(new NotificationChannelGroup("pavlok_group_alarm", "Alarm"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup("pavlok_group_timer", "Timer"));
        android.app.NotificationChannel snooze = new android.app.NotificationChannel(
                SNOOZE_CHANNEL,"Snooze Countdown",NotificationManager.IMPORTANCE_LOW);
        snooze.setGroup(ALARM_TIMER);
        snooze.setDescription("Silent countdown after snoozing an alarm or timer");
        snooze.setSound(null,null);
        snooze.enableVibration(false);
        manager.createNotificationChannel(snooze);
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CODE_RED, "Code Red"));
        // One-time migration from the old watch-firmware alarm notification UI.
        // These IDs are never used by PavDroid's Android-owned alarm engine.
        // Keep pavdroid_active_alarm untouched to preserve user notification settings.
        android.content.SharedPreferences preferences = context.getApplicationContext()
                .getSharedPreferences("pavdroid_notification_migration", Context.MODE_PRIVATE);
        if (!preferences.getBoolean("retired_firmware_alarm_channels_v103", false)) {
            manager.deleteNotificationChannel("pavlok_watch_alarm_alerts_v208");
            manager.deleteNotificationChannel("pavlok_alarm_snooze_v218");
            preferences.edit().putBoolean("retired_firmware_alarm_channels_v103", true).apply();
        }
    }
}
