package com.projectrcc.pavlokcontrol;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

/** Android is the only source of scheduled alarms. Watch BLE is direct output/input only. */
final class PavDroidAlarmEngine {
    static final String ACTION_WAKE = "com.projrcc.pavdroid.ALARM_WAKE";
    static final String ACTION_SNOOZE_END = "com.projrcc.pavdroid.ALARM_SNOOZE_END";
    static final String ACTION_STOP = "com.projrcc.pavdroid.ALARM_STOP";
    static final String ACTION_SNOOZE = "com.projrcc.pavdroid.ALARM_SNOOZE";
    static final String ACTION_TIMEOUT = "com.projrcc.pavdroid.ALARM_TIMEOUT";
    private static final String PREF = "pavdroid_android_alarms_v1";
    private static final String CHANNEL = "pavdroid_active_alarm";
    private static final int NOTICE = 39081;
    private final WatchMonitorService owner;
    private final Context context;
    private final SharedPreferences preferences;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AlarmManager alarms;
    private final NotificationManager nm;
    private Runnable tick;
    private Runnable pendingTap;
    private PowerManager.WakeLock wakeLock;
    private long lastButtonAt, lastLongPressAt;
    private JSONArray list = new JSONArray();
    private String phase = "ready";
    private int activeIndex = -1, roundIndex, zapSent, snoozes;
    private long startedAt, snoozeUntil, timeoutAt, nextPulseAt, lastGroupAt, musicDue, musicRiseAt;
    private long historyId, lastHandledDue;
    private String name = "", musicUri = "";
    private int snoozeMinutes = 7, musicDelay = 10, musicAfterSnoozes = 0;
    private int musicStartVolume = 30, musicRisePercent = 10, musicRiseSeconds = 15, musicCurrentVolume = 30, zapsAfterSnoozes = 0;
    private int interval = 8, buzz = 5, beep = 5, zaps = 1, intensity = 40;
    private boolean escalate = true, smartTimeout = true, music = false, musicStarted = false;

    PavDroidAlarmEngine(WatchMonitorService service) {
        owner = service;
        context = service.getApplicationContext();
        preferences = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        try { list = new JSONArray(preferences.getString("alarms", "[]")); } catch (Exception ignored) { list = new JSONArray(); }
        if (nm != null) {
            NotificationGroups.ensure(context, nm);
            NotificationChannel firing = new NotificationChannel(CHANNEL, "PavDroid alarm firing", NotificationManager.IMPORTANCE_HIGH);
            firing.setGroup(NotificationGroups.ALARM);
            firing.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(firing); // Same ID preserves user-selected channel settings.
        }
        load();
        reschedule();
        if (!"ready".equals(phase)) {
            holdCpu();
            if(music && musicStarted && !musicUri.isEmpty()) owner.audio().start(musicUri, activeMusicVolume());
            refresh();
        }
    }

    private static int within(int n,int lo,int hi) { return Math.max(lo,Math.min(hi,n)); }
    boolean isActive() { return !"ready".equals(phase); }
    boolean isFiring() { return "firing".equals(phase); }
    void onLinkChanged(boolean nowConnected) {
        if(isActive()) PavDroidHistory.record(context,"alarm",historyId,"link",name,
            nowConnected ? "Watch connected; native stimuli can resume while alert is active" :
                           "Watch disconnected; Android alarm remains active");
    }
    String alarmsJson() { return preferences.getString("alarms", "[]"); }
    String snapshot() {
        try { return new JSONObject().put("phase",phase).put("active",isActive()).put("id",activeIndex)
            .put("name",name).put("snoozes",snoozes).put("startedAt",startedAt)
            .put("snoozeUntil",snoozeUntil).put("timeoutAt",timeoutAt).put("music",music)
            .toString(); }
        catch(Exception e) { return "{}"; }
    }
    private void load() {
        String saved = preferences.getString("session", "{}");
        try {
            JSONObject s = new JSONObject(saved);
            phase = s.optString("phase","ready"); activeIndex=s.optInt("id",-1);
            name=s.optString("name",""); startedAt=s.optLong("startedAt",0);
            snoozeUntil=s.optLong("snoozeUntil",0); timeoutAt=s.optLong("timeoutAt",0);
            musicDue=s.optLong("musicDue",0);musicRiseAt=s.optLong("musicRiseAt",0); snoozes=s.optInt("snoozes",0);
            snoozeMinutes=within(s.optInt("snoozeMinutes",7),1,60);
            musicDelay=10;
            musicAfterSnoozes=within(s.optInt("musicAfterSnoozes",0),0,99);
            musicStartVolume=within(s.optInt("musicStartVolume",100),10,100);
            // Existing V1.0.9 sessions retain their previous level; only newly
            // configured sessions use within-firing escalation.
            musicRisePercent=within(s.optInt("musicRisePercent",0),0,50);
            musicRiseSeconds=within(s.optInt("musicRiseSeconds",15),3,120);
            musicCurrentVolume=within(s.optInt("musicCurrentVolume",musicStartVolume),10,100);
            zapsAfterSnoozes=within(s.optInt("zapsAfterSnoozes",0),0,99);
            buzz=within(s.optInt("buzz",5),0,5);
            beep=within(s.optInt("beep",5),0,5); zaps=within(s.optInt("zaps",1),0,5);
            interval=within(s.optInt("interval",8),Math.max(3,Math.max(buzz,beep)+1),30);
            intensity=within(s.optInt("intensity",40),10,100);
            escalate=s.optBoolean("escalate",true); smartTimeout=s.optBoolean("smartTimeout",true);
            music=s.optBoolean("music",false); musicUri=s.optString("musicUri","");musicStarted=s.optBoolean("musicStarted",false);
            roundIndex=within(s.optInt("roundIndex",0),0,10000); zapSent=within(s.optInt("zapSent",0),0,12);
            nextPulseAt=s.optLong("nextPulseAt",0);lastGroupAt=s.optLong("lastGroupAt",0);
            historyId=s.optLong("historyId",startedAt);lastHandledDue=s.optLong("lastHandledDue",0);
            if(s.optLong("waitingUntil",0)>0)
                EventJournal.append(context,"V1.0.1 legacy waiting-alarm state cleared during V1.0.2 upgrade; no surprise late firing");
            if(activeIndex<0 || activeIndex>=list.length() || (!"firing".equals(phase) && !"snoozing".equals(phase))) phase="ready";
        } catch(Exception e) { phase="ready"; }
    }
    private void persist() {
        try {
            JSONObject s=new JSONObject().put("phase",phase).put("id",activeIndex).put("name",name)
             .put("startedAt",startedAt).put("snoozeUntil",snoozeUntil).put("timeoutAt",timeoutAt)
             .put("musicDue",musicDue).put("musicRiseAt",musicRiseAt).put("snoozes",snoozes).put("snoozeMinutes",snoozeMinutes)
             .put("musicDelay",musicDelay).put("musicAfterSnoozes",musicAfterSnoozes)
             .put("musicStartVolume",musicStartVolume).put("musicRisePercent",musicRisePercent).put("musicRiseSeconds",musicRiseSeconds).put("musicCurrentVolume",musicCurrentVolume).put("zapsAfterSnoozes",zapsAfterSnoozes).put("interval",interval).put("buzz",buzz).put("beep",beep)
             .put("zaps",zaps).put("intensity",intensity).put("escalate",escalate)
             .put("smartTimeout",smartTimeout).put("music",music).put("musicUri",musicUri).put("musicStarted",musicStarted)
             .put("roundIndex",roundIndex).put("zapSent",zapSent).put("nextPulseAt",nextPulseAt)
             .put("lastGroupAt",lastGroupAt).put("historyId",historyId).put("lastHandledDue",lastHandledDue);
            preferences.edit().putString("session",s.toString()).apply();
        } catch(Exception ignored) {}
    }
    void replace(String json) throws Exception {
        if(isActive()) throw new IllegalStateException("Stop the active alarm before editing alarms.");
        if(owner.timerEngine().isSessionActive())throw new IllegalStateException("Stop the running timer before changing alarms.");
        JSONArray incoming=new JSONArray(json);
        if(incoming.length()>64)throw new IllegalArgumentException("Maximum 64 alarms");
        for(int i=0;i<incoming.length();i++){
            JSONObject a=incoming.getJSONObject(i);
            if(a.optString("name","").trim().isEmpty() || !a.optString("time","").matches("[0-2][0-9]:[0-5][0-9]"))
                throw new IllegalArgumentException("Invalid alarm name or time");
        }
        list=incoming;
        preferences.edit().putString("alarms",list.toString()).commit();
        reschedule(); EventJournal.append(context,"PavDroid saved "+list.length()+" Android alarms (no watch firmware writes)");
    }
    /** Arm precisely one Android AlarmClock due time, independent of BLE state. */
    synchronized void reschedule() {
        if(alarms==null)return;
        alarms.cancel(pi(ACTION_WAKE,0,0L));
        // Cleanup legacy V1.0.1 alarms so they cannot wake the app later.
        alarms.cancel(pi("com.projrcc.pavdroid.ALARM_PRECONNECT",13));
        alarms.cancel(pi("com.projrcc.pavdroid.ALARM_EXPIRE",14));
        long best=Long.MAX_VALUE;
        for(int i=0;i<list.length();i++){
            JSONObject a=list.optJSONObject(i); if(a==null||!a.optBoolean("enabled",true))continue;
            long when=nextOccurrence(a,System.currentTimeMillis());
            if(when<best)best=when;
        }
        if(best==Long.MAX_VALUE)return;
        if(!exactAllowed()){
            EventJournal.append(context,"PavDroid exact alarm permission missing; schedules saved but precise wake not armed");return;
        }
        try { Intent open=new Intent(context,MainActivity.class);
            PendingIntent show=PendingIntent.getActivity(context,39082,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            alarms.setAlarmClock(new AlarmManager.AlarmClockInfo(best,show),pi(ACTION_WAKE,0,best));
        } catch(Exception e){EventJournal.append(context,"PavDroid scheduling failed: "+e.getMessage());}
    }
    boolean exactAllowed(){return Build.VERSION.SDK_INT<31 || (alarms!=null && alarms.canScheduleExactAlarms());}
    private long nextOccurrence(JSONObject a,long now) {
        String time=a.optString("time","07:00");int hour=7,min=0;
        try{hour=Integer.parseInt(time.substring(0,2));min=Integer.parseInt(time.substring(3,5));}catch(Exception ignored){}
        int days=a.optInt("days",0)&127;
        Calendar c=Calendar.getInstance();c.setTimeInMillis(now);c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,min);
        c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        for(int shift=0;shift<8;shift++){
            if(shift>0)c.add(Calendar.DAY_OF_MONTH,1);
            int mask=1<<(c.get(Calendar.DAY_OF_WEEK)-1);
            if(c.getTimeInMillis()>now+900 && (days==0 || (days&mask)!=0))return c.getTimeInMillis();
        }
        return Long.MAX_VALUE;
    }
    private PendingIntent pi(String action,int request) { return pi(action,request,0L); }
    private PendingIntent pi(String action,int request,long due) {
        Intent i=new Intent(context,PavDroidReceiver.class).setAction(action);
        if(ACTION_WAKE.equals(action) && due>0) i.putExtra("scheduled_due",due);
        return PendingIntent.getBroadcast(context,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    /** Android alarm fires on its due time even if the watch is unavailable. */
    void onWake(long due) {
        long now=System.currentTimeMillis();int chosen=-1;
        if(due>0 && due<=now+30000L) {
            for(int i=0;i<list.length();i++) {
                JSONObject a=list.optJSONObject(i);if(a==null||!a.optBoolean("enabled",true))continue;
                long match=nextOccurrence(a,due-2000L);
                if(Math.abs(match-due)<1000L){chosen=i;break;}
            }
        }
        if(chosen>=0){
            if(due==lastHandledDue){EventJournal.append(context,"PavDroid duplicate wake ignored");reschedule();return;}
            lastHandledDue=due;persist();
            JSONObject a=list.optJSONObject(chosen);
            if(a!=null&&a.optInt("days",0)==0){
                try{a.put("enabled",false);preferences.edit().putString("alarms",list.toString()).commit();}catch(Exception ignored){}
            }
            if(isActive()||owner.timerEngine().isSessionActive()){
                PavDroidHistory.record(context,"alarm",due,"missed",a.optString("name","Alarm"),"Another session already active");
                EventJournal.append(context,"PavDroid scheduled alarm skipped: another session active");
            } else {
                historyId=due;start(chosen,a);
                if(now-due>1500)PavDroidHistory.record(context,"alarm",historyId,"late",name,"Android alarm callback " +(now-due)/1000+"s after scheduled time");
                if(!owner.bridge().hasWatchConnection()){
                    PavDroidHistory.record(context,"alarm",historyId,"link",name,"Watch disconnected; alarm still firing on Android; stimuli resume when watch returns");
                    EventJournal.append(context,"PavDroid alarm started on time WITHOUT watch link: "+name+"; watch output pending normal reconnection");
                }
            }
        } else EventJournal.append(context,"PavDroid stale/unknown Android wake ignored (due="+due+"); rescheduling");
        reschedule();
    }
    private void start(int i,JSONObject a) {
        activeIndex=i;name=a.optString("name","Alarm");phase="firing";
        buzz=within(a.optInt("buzz",5),0,5);beep=within(a.optInt("beep",5),0,5);zaps=within(a.optInt("zaps",1),0,5);
        intensity=within(a.optInt("max",40),10,100);
        interval=within(a.optInt("interval",8),Math.max(3,Math.max(buzz,beep)+1),30);
        escalate=a.optBoolean("escalate",true);snoozeMinutes=within(a.optInt("snoozeMinutes",7),1,60);
        musicDelay=10;
        musicAfterSnoozes=within(a.optInt("musicAfterSnoozes",0),0,99);
        musicStartVolume=within(a.optInt("musicStartVolume",100),10,100);
        musicRisePercent=within(a.optInt("musicRisePercent",0),0,50);
        musicRiseSeconds=within(a.optInt("musicRiseSeconds",15),3,120);
        musicCurrentVolume=musicStartVolume;
        zapsAfterSnoozes=within(a.optInt("zapsAfterSnoozes",0),0,99);
        smartTimeout=a.optBoolean("smartTimeout",true);music=a.optBoolean("music",false);
        musicUri=PavDroidAudio.selectedUri(context,a.optString("musicUri",""));
        startedAt=System.currentTimeMillis();if(historyId<=0)historyId=startedAt;snoozes=0;snoozeUntil=0;
        musicDue=nextMusicDue(startedAt);musicRiseAt=0;musicStarted=false;
        timeoutAt=smartTimeout?startedAt+3_600_000L:0;
        roundIndex=0;zapSent=0;lastGroupAt=startedAt;nextPulseAt=startedAt;
        persist();PavDroidHistory.record(context,"alarm",historyId,"firing",name,"Started (Android owns schedule)");
        holdCpu();refresh();EventJournal.append(context,"PavDroid alarm FIRING: "+name);
    }
    private int activeMusicVolume(){return musicCurrentVolume;}
    private int eligibleZaps(){return snoozes>=zapsAfterSnoozes?zaps:0;}
    private void rampMusic(long now){
        if(!musicStarted||musicRisePercent<=0||musicRiseAt<=0||now<musicRiseAt)return;
        int steps=(int)Math.min(100,1+(now-musicRiseAt)/(musicRiseSeconds*1000L));
        int raised=within(musicCurrentVolume+steps*musicRisePercent,10,100);
        if(raised>musicCurrentVolume){
            musicCurrentVolume=raised;
            String report=owner.audio().adjustVolume(raised);
            PavDroidHistory.record(context,"alarm",historyId,"volume",name,"Volume increased · "+report);
        }
        musicRiseAt=raised>=100?0:musicRiseAt+steps*musicRiseSeconds*1000L;
        persist();
    }
    private long nextMusicDue(long firedAt){
        return music&&!musicUri.isEmpty()&&snoozes>=musicAfterSnoozes ? firedAt+10_000L : 0;
    }
    private void holdCpu(){
        if(wakeLock!=null&&wakeLock.isHeld())return;
        try{PowerManager pm=(PowerManager)context.getSystemService(Context.POWER_SERVICE);
            if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"PavDroid:AlarmSession");wakeLock.acquire(3L*60L*60L*1000L);}}
        catch(Exception e){EventJournal.append(context,"PavDroid wake lock unavailable: "+e.getMessage());}
    }
    private void releaseCpu(){if(wakeLock!=null&&wakeLock.isHeld()){try{wakeLock.release();}catch(Exception ignored){}}}
    void snooze(){
        if(!isFiring())return;
        snoozes++;phase="snoozing";snoozeUntil=System.currentTimeMillis()+snoozeMinutes*60_000L;
        if(smartTimeout)timeoutAt=System.currentTimeMillis()+2L*60L*60L*1000L;
        owner.bridge().discardQueuedTimerStimuli();
        musicDue=0;musicRiseAt=0;musicStarted=false;owner.audio().stop();
        persist();PavDroidHistory.record(context,"alarm",historyId,"snoozing",name,"Snooze "+snoozes+" for "+snoozeMinutes+"m");
        refresh();EventJournal.append(context,"PavDroid alarm SNOOZED: "+name+" for "+snoozeMinutes+"m");
    }
    void stop(String reason){
        if(!isActive())return;
        String old=name;PavDroidHistory.record(context,"alarm",historyId,"stopped",old,reason);phase="ready";activeIndex=-1;historyId=0;snoozeUntil=0;timeoutAt=0;musicDue=0;musicRiseAt=0;musicStarted=false;
        if(pendingTap!=null){handler.removeCallbacks(pendingTap);pendingTap=null;}
        if(tick!=null)handler.removeCallbacks(tick);tick=null;
        owner.audio().stop();owner.bridge().discardQueuedTimerStimuli();persist();releaseCpu();
        if(nm!=null)nm.cancel(NOTICE);
        EventJournal.append(context,"PavDroid alarm STOPPED ("+reason+"): "+old);
    }
    void onDeadline(String action,long scheduledDue){
        if(ACTION_WAKE.equals(action)){onWake(scheduledDue);return;}
        if(ACTION_SNOOZE.equals(action)){snooze();return;}
        if(ACTION_STOP.equals(action)){stop("notification");return;}
        refresh();
    }
    /** Event 05 21 is a tap; 05 23 is a middle-button hold. */
    boolean onButton(byte[] b){
        if(b==null||b.length<2 || b[0]!=(byte)0x05 || !isActive())return false;
        int action=b[1]&0xff;long now=System.currentTimeMillis();
        if(action==0x23){if(now-lastLongPressAt<650)return true;lastLongPressAt=now;
            if(pendingTap!=null)handler.removeCallbacks(pendingTap);pendingTap=null;stop("middle-button hold");return true;}
        if(action==0x21){if(!isFiring()||now-lastButtonAt<650)return true;lastButtonAt=now;
            if(pendingTap!=null)handler.removeCallbacks(pendingTap);
            pendingTap=()->{pendingTap=null;snooze();};handler.postDelayed(pendingTap,920);return true;}
        return false;
    }
    private void refresh(){
        if(tick!=null)handler.removeCallbacks(tick);tick=null;
        if(!isActive())return;
        long now=System.currentTimeMillis();
        if("firing".equals(phase) && musicDue>0 && now>=musicDue){
            musicDue=0;musicCurrentVolume=musicStartVolume;
            musicStarted=owner.audio().start(musicUri,activeMusicVolume());
            musicRiseAt=musicStarted&&musicRisePercent>0&&musicCurrentVolume<100?now+musicRiseSeconds*1000L:0;
            PavDroidHistory.record(context,"alarm",historyId,"music",name,musicStarted?"MP3 started · "+owner.audio().playbackVolumeDetails():"MP3 FAILED; see Connection log");persist();
        }
        if("firing".equals(phase))rampMusic(now);
        if("snoozing".equals(phase) && now>=snoozeUntil){
            phase="firing";snoozeUntil=0;zapSent=0;roundIndex=0;lastGroupAt=now;nextPulseAt=now;
            musicDue=nextMusicDue(now);musicRiseAt=0;musicStarted=false;musicCurrentVolume=musicStartVolume;
            if(zaps>0 && snoozes>=zapsAfterSnoozes) EventJournal.append(context,"PavDroid zaps enabled after "+snoozes+" snoozes; ramp 10% to "+intensity+"%");
            if(smartTimeout&&timeoutAt>0&&timeoutAt<now+120_000L)timeoutAt=now+120_000L;
            persist();PavDroidHistory.record(context,"alarm",historyId,"firing",name,"Re-fired after snooze "+snoozes);
            EventJournal.append(context,"PavDroid alarm RE-FIRING after snooze: "+name);
        }
        if("firing".equals(phase) && smartTimeout && timeoutAt>0 && now>=timeoutAt){stop("Smart Timeout");return;}
        if("firing".equals(phase) && now>=nextPulseAt)emit();
        notifyState();
        tick=this::refresh;handler.postDelayed(tick,Math.max(250,Math.min(900,Math.max(0,"snoozing".equals(phase)?snoozeUntil-System.currentTimeMillis():nextPulseAt-System.currentTimeMillis()))));
    }
    private int count(){return buzz+beep+eligibleZaps();}
    private int type(int n){return n<buzz?1:n<buzz+beep?2:3;}
    private void emit(){
        if(count()==0){nextPulseAt=System.currentTimeMillis()+interval*1000L;return;}
        int n=roundIndex%count();int kind=type(n);
        if(kind==3&&zapSent>=12){roundIndex++;nextPulseAt=System.currentTimeMillis()+1000L;return;}
        int pct=kind==3?Math.min(intensity,10+10*zapSent):100; // native 10-point zap ramp per firing
        boolean sent=owner.bridge().queueTimerStimulus(kind,pct);
        if(!sent){nextPulseAt=System.currentTimeMillis()+2000L;return;}
        if(kind==3){zapSent++;
            PavDroidHistory.record(context,"alarm",historyId,"stimulus",name,"Zap "+pct+"% queued ("+zapSent+"/12 this firing)");}
        roundIndex++;
        int next=roundIndex%count();
        if(next==0 || type(next)!=kind){lastGroupAt=Math.max(System.currentTimeMillis()+1000L,lastGroupAt+interval*1000L);nextPulseAt=lastGroupAt;}
        else nextPulseAt=System.currentTimeMillis()+1000L;
        persist();
    }
    private static String formatRemaining(long due){long sec=Math.max(0,(due-System.currentTimeMillis()+999L)/1000L);return String.format(java.util.Locale.US,"%d:%02d",sec/60,sec%60);}
    private void notifyState(){
        if(nm==null || (Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED))return;
        Intent open=new Intent(context,MainActivity.class);PendingIntent show=PendingIntent.getActivity(context,NOTICE,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        boolean connected=owner.bridge().hasWatchConnection();
        Notification.Builder b=new Notification.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("snoozing".equals(phase)?name+" · Snoozing":name+" · Alarm firing")
            .setContentText("snoozing".equals(phase) ?
                    formatRemaining(snoozeUntil)+" remaining"+(connected?"":" · Watch disconnected") :
                    (connected?"Watch connected":"Watch disconnected · No watch output"))
            .setContentIntent(show).setOngoing(true).setCategory(Notification.CATEGORY_ALARM).setOnlyAlertOnce(true);
        // Put the destructive action first (left). Keep Android's native action layout,
        // which controls real button widths on Samsung lock screens.
        b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"STOP",pi(ACTION_STOP,2)).build());
        if(isFiring()) b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,
            music && !musicUri.isEmpty() ? "Snooze / Mute" : "Snooze",pi(ACTION_SNOOZE,1)).build());
        nm.notify(NOTICE,b.build());
    }
    void close(){if(tick!=null)handler.removeCallbacks(tick);if(pendingTap!=null)handler.removeCallbacks(pendingTap);releaseCpu();}
}
