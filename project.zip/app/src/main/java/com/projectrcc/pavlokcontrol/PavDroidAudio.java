package com.projectrcc.pavlokcontrol;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.net.Uri;

/** User-selected persistent URI, looping only until the owner stops its session. */
final class PavDroidAudio {
    private final Context context;
    private MediaPlayer player;
    private AudioManager volume;
    private int previousMediaVolume = -1;
    private String lastPlaybackVolume = "";
    PavDroidAudio(Context context){this.context=context.getApplicationContext();}
    static String selectedUri(Context context, String fallback) {
        android.content.SharedPreferences pref=context.getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE);
        // Upgrade: only use old per-alarm URI until the global library has been initialized.
        if(!pref.contains("selectedUri"))return fallback==null?"":fallback;
        String selected=pref.getString("selectedUri", "");
        return selected==null?"":selected;
    }
    static int timerVolume(Context context){
        return Math.max(10,Math.min(100,context.getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE)
            .getInt("timerVolume",100)));
    }
    String playbackVolumeDetails(){ return lastPlaybackVolume; }
    private static String describeVolume(AudioManager manager,int stream,int requested){
        if(manager==null)return "Media volume unavailable";
        int actual=manager.getStreamVolume(stream);
        int maximum=Math.max(1,manager.getStreamMaxVolume(stream));
        return "Media requested "+requested+"%, Android "+Math.round(actual*100f/maximum)+"% ("+actual+"/"+maximum+")";
    }
    boolean start(String uri){ return start(uri, 100); }
    boolean start(String uri, int percent){
        if(player!=null)return true;
        if(uri==null || uri.isEmpty())return false;
        try{
            volume=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(volume!=null && previousMediaVolume<0){
                previousMediaVolume=volume.getStreamVolume(AudioManager.STREAM_MUSIC);
                int max=Math.max(1,volume.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
                int target=Math.max(1,Math.min(max,Math.round(max*Math.max(10,Math.min(100,percent))/100f)));
                volume.setStreamVolume(AudioManager.STREAM_MUSIC,target,0);
                lastPlaybackVolume=describeVolume(volume,AudioManager.STREAM_MUSIC,percent);
                EventJournal.append(context,"PavDroid music: "+lastPlaybackVolume);
            }else if(volume==null)lastPlaybackVolume="Media volume unavailable";
            MediaPlayer m=new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(context,Uri.parse(uri));m.setLooping(true);
            // Media stream matches Android's visible Media slider, not the hidden Alarm stream.
            m.setVolume(1f,1f);m.prepare();m.start();player=m;
            EventJournal.append(context,"PavDroid MP3 playback started · "+lastPlaybackVolume);return true;
        }catch(Exception e){EventJournal.append(context,"PavDroid MP3 playback failed: "+e.getMessage());stop();return false;}
    }
    void stop(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}
        if(volume!=null&&previousMediaVolume>=0){
            try{
                int prior=previousMediaVolume;
                volume.setStreamVolume(AudioManager.STREAM_MUSIC,prior,0);
                int actual=volume.getStreamVolume(AudioManager.STREAM_MUSIC);
                EventJournal.append(context,"PavDroid restored Media volume to "+actual+"/"+Math.max(1,volume.getStreamMaxVolume(AudioManager.STREAM_MUSIC)));
            }catch(Exception e){EventJournal.append(context,"PavDroid Media volume restore unavailable: "+e.getMessage());}
            previousMediaVolume=-1;
        }
        volume=null;
    }
}
