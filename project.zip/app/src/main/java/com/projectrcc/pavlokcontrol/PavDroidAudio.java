package com.projectrcc.pavlokcontrol;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;

/** User-selected persistent URI, looping only until the owner stops its session. */
final class PavDroidAudio {
    private final Context context;
    private MediaPlayer player;
    PavDroidAudio(Context context){this.context=context.getApplicationContext();}
    void start(String uri){
        if(player!=null || uri==null || uri.isEmpty())return;
        try{
            MediaPlayer m=new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(context,Uri.parse(uri));m.setLooping(true);m.prepare();m.start();player=m;
            EventJournal.append(context,"PavDroid user-selected MP3 playback started");
        }catch(Exception e){EventJournal.append(context,"PavDroid MP3 playback failed: "+e.getMessage());stop();}
    }
    void stop(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
}
