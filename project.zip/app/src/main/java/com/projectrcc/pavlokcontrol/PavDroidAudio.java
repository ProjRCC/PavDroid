package com.projectrcc.pavlokcontrol;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.net.Uri;

/** User-selected persistent URI, looping only until the owner stops its session. */
final class PavDroidAudio {
    private final Context context;
    private MediaPlayer player;
    private AudioManager volume;
    private int previousAlarmVolume = -1;
    PavDroidAudio(Context context){this.context=context.getApplicationContext();}
    boolean start(String uri){
        if(player!=null)return true;
        if(uri==null || uri.isEmpty())return false;
        try{
            volume=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(volume!=null && previousAlarmVolume<0){
                previousAlarmVolume=volume.getStreamVolume(AudioManager.STREAM_ALARM);
                volume.setStreamVolume(AudioManager.STREAM_ALARM,volume.getStreamMaxVolume(AudioManager.STREAM_ALARM),0);
            }
            MediaPlayer m=new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(context,Uri.parse(uri));m.setLooping(true);m.prepare();m.start();player=m;
            EventJournal.append(context,"PavDroid user-selected MP3 playback started");return true;
        }catch(Exception e){EventJournal.append(context,"PavDroid MP3 playback failed: "+e.getMessage());stop();return false;}
    }
    void stop(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}
        if(volume!=null&&previousAlarmVolume>=0){
            try{volume.setStreamVolume(AudioManager.STREAM_ALARM,previousAlarmVolume,0);}catch(Exception ignored){}
            previousAlarmVolume=-1;
        }
    }
}
