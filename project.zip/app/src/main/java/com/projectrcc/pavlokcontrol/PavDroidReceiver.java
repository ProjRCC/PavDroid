package com.projectrcc.pavlokcontrol;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** System wakeup and snooze/stop notifications enter through one explicit receiver. */
public final class PavDroidReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent incoming) {
        if(incoming==null)return;
        String action=incoming.getAction();
        if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action)){
            PavDroidAlarmSchedule.rearm(context);return;
        }
        if(action==null||!action.startsWith("com.projrcc.pavdroid.ALARM_"))return;
        Intent start=new Intent(context,WatchMonitorService.class).setAction(action);
        try{if(Build.VERSION.SDK_INT>=26)context.startForegroundService(start);else context.startService(start);}
        catch(Exception e){EventJournal.append(context,"PavDroid wake service launch failed: "+e.getMessage());}
    }
}
