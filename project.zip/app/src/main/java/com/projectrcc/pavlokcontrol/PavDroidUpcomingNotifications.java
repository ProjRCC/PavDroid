package com.projectrcc.pavlokcontrol;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Separate Android-owned reminder, never reads watch-firmware alarm slots. */
final class PavDroidUpcomingNotifications {
    static final String ACTION_REMIND = "com.projrcc.pavdroid.ALARM_UPCOMING_REMINDER";
    private static final String CHANNEL = "pavdroid_upcoming_alarm_v116";
    private static final int ID = 39116, REQUEST = 39117;
    private static final long WINDOW = 9L * 60L * 60L * 1000L;
    private PavDroidUpcomingNotifications() { }

    private static PendingIntent intent(Context context) {
        Intent i = new Intent(context, PavDroidReceiver.class).setAction(ACTION_REMIND);
        return PendingIntent.getBroadcast(context,REQUEST,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static void onReminder(Context context) { rearm(context); }
    static synchronized void rearm(Context context) {
        AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (am==null || nm==null) return;
        am.cancel(intent(context));
        NotificationGroups.ensure(context,nm);
        NotificationChannel channel = new NotificationChannel(CHANNEL,"Alarm Upcoming",NotificationManager.IMPORTANCE_LOW);
        channel.setGroup(NotificationGroups.ALARM_TIMER);
        channel.setDescription("Silent reminder beginning nine hours before the next enabled alarm");
        channel.setSound(null,null);channel.enableVibration(false);
        nm.createNotificationChannel(channel);
        long now = System.currentTimeMillis(), next = Long.MAX_VALUE;
        String name = "Alarm";
        SharedPreferences p=context.getSharedPreferences("pavdroid_android_alarms_v1",Context.MODE_PRIVATE);
        try {
            JSONArray saved = new JSONArray(p.getString("alarms","[]"));
            for (int i=0;i<saved.length();i++) {
                JSONObject alarm=saved.optJSONObject(i);
                if (alarm==null || !alarm.optBoolean("enabled",true)) continue;
                String time=alarm.optString("time","07:00");
                if(!time.matches("[0-2][0-9]:[0-5][0-9]"))continue;
                int hour=Integer.parseInt(time.substring(0,2)),minute=Integer.parseInt(time.substring(3));
                int mask=alarm.optInt("days",0)&127;
                Calendar c=Calendar.getInstance();c.setTimeInMillis(now);
                c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);
                c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
                for(int day=0;day<8;day++){
                    if(day>0)c.add(Calendar.DAY_OF_MONTH,1);
                    int bit=1<<(c.get(Calendar.DAY_OF_WEEK)-1);
                    if(c.getTimeInMillis()>now+900 && (mask==0 || (mask&bit)!=0)){
                        if(c.getTimeInMillis()<next){next=c.getTimeInMillis();name=alarm.optString("name","Alarm");}
                        break;
                    }
                }
            }
        }catch(Exception e){EventJournal.append(context,"Upcoming alarm scan error: "+e.getMessage());}
        if(next==Long.MAX_VALUE){nm.cancel(ID);return;}
        long showAt=next-WINDOW;
        if(showAt>now){
            nm.cancel(ID);
            // Nine-hour reminders may drift under Android battery policies;
            // the actual alarm uses the independent exact AlarmClock schedule.
            try{am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,showAt,intent(context));}
            catch(Exception e){EventJournal.append(context,"Upcoming reminder schedule error: "+e.getMessage());}
            return;
        }
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        if(!nm.areNotificationsEnabled())return;
        NotificationChannel configured=nm.getNotificationChannel(CHANNEL);
        if(configured==null || configured.getImportance()==NotificationManager.IMPORTANCE_NONE){nm.cancel(ID);return;}
        Intent main = new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open=PendingIntent.getActivity(context,REQUEST,main,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String scheduled=new SimpleDateFormat("EEE, h:mm a",Locale.US).format(new Date(next));
        Notification notification = new Notification.Builder(context,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Alarm Upcoming")
                .setContentText(name+" · "+scheduled)
                .setContentIntent(open).setCategory(Notification.CATEGORY_REMINDER)
                .setOngoing(false).setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setWhen(next).setShowWhen(true).build();
        nm.notify(ID,notification);
    }
}
