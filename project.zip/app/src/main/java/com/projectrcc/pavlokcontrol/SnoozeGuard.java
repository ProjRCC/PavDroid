package com.projectrcc.pavlokcontrol;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Watch-event ledger and phone-only fallback if native snooze doesn't re-fire.
 * Never sends snooze/stop/start/watch-stimulus commands. No exact-alarm permission.
 */
final class SnoozeGuard {
    private static final String PREFS = "pavlok_alarm_watch_guard_v210";
    private static final long ESTIMATED_SNOOZE_MS = 5 * 60 * 1000L;
    private static final long GRACE_MS = 30 * 1000L;
    private static final int REQUEST_CODE = 21010;

    private SnoozeGuard() { }
    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    static synchronized boolean onWatchEvent(Context context, int operation, int id) {
        if (id <= 0 || (operation != 0x54 && operation != 0x55 && operation != 0x56)) return false;
        SharedPreferences pref = prefs(context);
        long now = System.currentTimeMillis();
        int previousOperation = pref.getInt("operation", -1);
        int previousId = pref.getInt("id", -1);
        long previousUpdated = pref.getLong("updated", 0);
        // Time of the FIRST firing remains fixed across 5-minute snoozes.
        // It is independent of the Code Red setting so all alarms can be audited.
        long firstFiring = pref.getLong("first_firing", 0L);
        if (operation == 0x54 && (previousId != id || previousOperation == 0x56 ||
                firstFiring <= 0 || now - firstFiring > 35L * 60_000L)) firstFiring = now;
        // BLE can deliver duplicate indications. In particular, repeated SNOOZE
        // telemetry during one countdown must NOT extend the protection window.
        if (previousOperation == operation && previousId == id) {
            // A reconnect replay of DISMISSED is not a second stop event.
            if (operation == 0x56) return false;
            if (now - previousUpdated < 1200L) return false;
            if (operation == 0x55 && now < pref.getLong("until",0L)) return false;
        }
        int count = (previousId == id && now - previousUpdated < 30*60*1000L)
                ? pref.getInt("count", 0) : 0;
        long until = 0L;
        if (operation == 0x55) { count++; until = now + ESTIMATED_SNOOZE_MS; }
        // The firmware can repeat FIRING telemetry every few seconds. A notification
        // action must remain valid for that *same firing round*, not become stale
        // every time a new FIRING packet updates the last-event timestamp.
        long roundStarted = operation == 0x54 && previousId == id && previousOperation == 0x54
                ? pref.getLong("round_started", previousUpdated) : now;
        if (roundStarted <= 0L) roundStarted = now;
        pref.edit().putInt("operation", operation).putInt("id", id)
                .putLong("updated", now).putLong("round_started", roundStarted)
                .putLong("first_firing", firstFiring)
                .putInt("count", count).putLong("until", until)
                .putLong("warned_at", 0L).apply();
        cancelPending(context);
        if (operation == 0x55) schedulePending(context, id, now, until + GRACE_MS);
        return true;
    }
    static String snapshot(Context context) {
        SharedPreferences pref = prefs(context);
        int operation = pref.getInt("operation", -1);
        String state = operation == 0x54 ? "firing" : operation == 0x55 ? "snoozed"
                : operation == 0x56 ? "dismissed" : "unknown";
        return new JSONObjectBuilder().add("state",state).add("id",pref.getInt("id",0))
                .add("updated",pref.getLong("updated",0L))
                .add("roundStarted",pref.getLong("round_started",pref.getLong("updated",0L)))
                .add("until",pref.getLong("until",0L))
                .add("count",pref.getInt("count",0))
                .add("firstFiring",pref.getLong("first_firing",0L))
                .add("lastPhoneStop",pref.getLong("last_phone_stop",0L))
                .add("lastWatchLongPress",pref.getLong("last_watch_long_press",0L)).build();
    }
    static void notePhoneStop(Context context) {
        prefs(context).edit().putLong("last_phone_stop", System.currentTimeMillis()).apply();
    }
    // A watch's alarm DISMISSED status has no hardware-provided cause code.
    // Record a physical long press only when the watch actually emits one.
    // If the packet is absent, label an early dismissal INFERRED, not confirmed.
    static synchronized boolean noteWatchMiddleLongPress(Context context) {
        SharedPreferences pref = prefs(context);
        long now = System.currentTimeMillis();
        if (now - pref.getLong("last_watch_long_press", 0L) < 1200L) return false;
        pref.edit().putLong("last_watch_long_press", now).apply();
        int id = pref.getInt("id", 0);
        long lastDismissal = pref.getLong("updated", 0L);
        EventJournal.append(context, "Watch middle button LONG press confirmed by BLE telemetry");
        if (id > 0 && pref.getInt("operation", -1) == 0x56 &&
                now >= lastDismissal && now - lastDismissal <= 5000L) {
            EventJournal.append(context, "Alarm stop source #" + id +
                    ": WATCH_LONG_PRESS_CONFIRMED (button packet arrived after dismissal)");
        }
        return true;
    }
    static String stopOrigin(Context context, int id) {
        SharedPreferences pref = prefs(context);
        long now = System.currentTimeMillis();
        // A queued phone Stop is an intent, not the watch's acknowledgment.
        long first = pref.getLong("first_firing", 0L);
        long phone = pref.getLong("last_phone_stop", 0L);
        if (first > 0 && phone >= first && now >= phone && now - phone <= 10000L)
            return "PHONE_STOP_CONFIRMED";
        long longPress = pref.getLong("last_watch_long_press", 0L);
        if (first > 0 && longPress >= first && now >= longPress && now - longPress <= 10000L)
            return "WATCH_LONG_PRESS_CONFIRMED";
        if (pref.getInt("id", 0) == id && first > 0 && now >= first && now - first <= 35L*60_000L) {
            return now - first >= 29L*60_000L + 55_000L ?
                "AUTO_CUTOFF_INFERRED" : "WATCH_STOP_INFERRED";
        }
        return "UNKNOWN";
    }

    private static PendingIntent pending(Context context, int id, long started) {
        Intent intent = new Intent(context, SnoozeSafetyReceiver.class);
        intent.putExtra("alarm_id", id).putExtra("snoozed_at", started);
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static void schedulePending(Context context, int id, long started, long deadline) {
        AlarmManager am=(AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        // Inexact while-idle scheduling: no special exact-alarm permission needed.
        // Android may delay this backup; it is not guaranteed to fire at a precise second.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, deadline, pending(context, id, started));
    }
    private static void cancelPending(Context context) {
        AlarmManager am=(AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pending(context, 0, 0));
    }
    static synchronized void onSafetyTimeout(Context context, int id, long started) {
        SharedPreferences pref=prefs(context);
        if (id <= 0 || pref.getInt("id",0) != id || pref.getInt("operation",-1) != 0x55
                || pref.getLong("updated",0) != started || pref.getLong("warned_at",0) == started) return;
        pref.edit().putLong("warned_at",started).apply();
        AlarmNotifications.safetyWarning(context, id);
    }
    // Avoid JSON string-concatenation / unsafe characters.
    private static final class JSONObjectBuilder {
        private final JSONObject object = new JSONObject();
        JSONObjectBuilder add(String key,Object value){try{object.put(key,value);}catch(Exception ignored){}return this;}
        String build(){return object.toString();}
    }
}
