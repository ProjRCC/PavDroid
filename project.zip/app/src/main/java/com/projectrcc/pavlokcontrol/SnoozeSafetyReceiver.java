package com.projectrcc.pavlokcontrol;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Checks that a snoozed watch alarm has fired or dismissed; warns only if unresolved. */
public final class SnoozeSafetyReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        SnoozeGuard.onSafetyTimeout(context, intent.getIntExtra("alarm_id",0),
                intent.getLongExtra("snoozed_at",0));
    }
}
