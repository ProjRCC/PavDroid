package com.projectrcc.pavlokcontrol;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Scheduled reminder refresh and Cancel (no watch writes). */
public final class UpcomingAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(intent==null)return;
        String action=intent.getAction();
        if(UpcomingAlarmReminders.ACTION_CANCEL.equals(action))
            UpcomingAlarmReminders.cancelOnly(context,intent.getStringExtra("reminder_key"));
        else if(UpcomingAlarmReminders.ACTION_CHECK.equals(action) ||
            Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_TIMEZONE_CHANGED.equals(action) ||
            Intent.ACTION_TIME_CHANGED.equals(action)) UpcomingAlarmReminders.reconcile(context);
    }
}
