package com.projectrcc.pavlokcontrol;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Phone-side, read-only schedule based on the last verified watch alarm list. */
final class UpcomingAlarmReminders {
    static final String ACTION_CHECK = "com.projectrcc.pavlokcontrol.REMINDER_CHECK";
    static final String ACTION_CANCEL = "com.projectrcc.pavlokcontrol.REMINDER_CANCEL";
    private static final String PREFS = "pavlok_upcoming_watch_alarms_v218";
    private static final String CHANNEL = "pavlok_upcoming_alarm_v218";
    private static final int ID = 21830;
    private static final int ALARM_REQ = 21831;
    private static final long WINDOW = 9L * 60 * 60 * 1000;
    private UpcomingAlarmReminders() { }
    private static SharedPreferences pref(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    static synchronized void replaceVerifiedSchedule(Context context, String json) {
        try {
            JSONArray input = new JSONArray(json);
            if (input.length() > 64) throw new IllegalArgumentException("Too many watch alarms");
            JSONArray safe = new JSONArray();
            for (int i = 0; i < input.length(); i++) {
                JSONObject a = input.getJSONObject(i);
                String time = a.optString("time", "");
                if (!time.matches("([01]\\d|2[0-3]):[0-5]\\d")) throw new IllegalArgumentException("Invalid alarm time");
                int days = a.optInt("days", 0);
                if (days < 0 || days > 127) throw new IllegalArgumentException("Invalid repeat days");
                safe.put(new JSONObject().put("name", a.optString("name", "Alarm").substring(0, Math.min(40, a.optString("name", "Alarm").length())))
                    .put("time", time).put("days", days).put("enabled", a.optBoolean("enabled", false))
                    .put("index", i));
            }
            SharedPreferences current = pref(context);
            boolean changed = !safe.toString().equals(current.getString("verified_alarms", ""));
            current.edit().putString("verified_alarms", safe.toString()).putLong("verified_at", System.currentTimeMillis()).apply();
            if (changed) EventJournal.append(context, "Upcoming reminders synced from " + safe.length() + " verified watch alarms");
            // A disabled one-shot readback confirms that its old firing round ended.
            // Clear only that suppression, allowing a future explicit re-enable.
            Set<String> consumed = new HashSet<>(current.getStringSet("consumed_once", new HashSet<>()));
            for (int i=0;i<safe.length();i++) {
                JSONObject alarm = safe.getJSONObject(i);
                if (alarm.optInt("days",0)==0 && !alarm.optBoolean("enabled",false))
                    consumed.remove(oneShotKey(alarm.optInt("index",i), alarm.optString("name","Alarm"), alarm.optString("time","")));
            }
            current.edit().putStringSet("consumed_once", consumed).apply();
            reconcile(context);
        } catch (Exception e) { EventJournal.append(context, "Upcoming reminder sync rejected: " + e.getMessage()); }
    }
    /** Names come from the last verified full watch read, including during background BLE events. */
    static synchronized String nameForWatchAlarm(Context context, int watchAlarmId) {
        String fallback = watchAlarmId > 0 ? "Alarm " + watchAlarmId : "Alarm";
        if (watchAlarmId <= 0) return fallback;
        try {
            JSONArray alarms = new JSONArray(pref(context).getString("verified_alarms", "[]"));
            int slot = watchAlarmId - 1;
            if (slot < alarms.length()) {
                JSONObject a = alarms.optJSONObject(slot);
                if (a != null && a.optInt("index", slot) == slot) {
                    String name = a.optString("name", "").trim();
                    if (!name.isEmpty()) return name;
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }
    private static final class Candidate {
        long due;
        String key, name, time;
        int index;
        Candidate(long due, String key, String name, String time, int index) {
            this.due=due;this.key=key;this.name=name;this.time=time;this.index=index;
        }
    }
    private static String oneShotKey(int index, String name, String time) {
        return index + ":" + name + ":" + time;
    }
    private static Candidate findNext(Context context, long now, Set<String> ignored) {
        JSONArray alarms;
        try { alarms = new JSONArray(pref(context).getString("verified_alarms", "[]")); }
        catch (Exception e) { return null; }
        Candidate best = null;
        Set<String> consumedOnce = pref(context).getStringSet("consumed_once", new HashSet<>());
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);
        for(int i=0;i<alarms.length();i++) {
            JSONObject a=alarms.optJSONObject(i);
            if (a==null || !a.optBoolean("enabled",false)) continue;
            String time=a.optString("time", "");
            int days=a.optInt("days",0);
            if (!time.matches("([01]\\d|2[0-3]):[0-5]\\d")) continue;
            int hour=Integer.parseInt(time.substring(0,2)), minute=Integer.parseInt(time.substring(3,5));
            String name=a.optString("name", "Alarm");
            int index=a.optInt("index",i);
            if (days==0 && consumedOnce.contains(oneShotKey(index,name,time))) continue;
            for(int day=0;day<=7;day++) {
                Calendar c=(Calendar)today.clone();c.add(Calendar.DAY_OF_YEAR,day);
                int mask=1<<(c.get(Calendar.DAY_OF_WEEK)-1); // Sunday 1, Monday 2, ... Saturday 64
                if(days!=0 && (days&mask)==0)continue;
                c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);
                long due=c.getTimeInMillis();
                if(due<=now)continue;
                // A one-time watch alarm is the next daily occurrence only.
                if(days==0 && day>1)continue;
                String key=due+":"+index+":"+name+":"+time+":"+days;
                if(ignored.contains(key)){
                    // Dismissing a one-time reminder must not create a false
                    // reminder for the following day.
                    if(days==0)break;
                    continue;
                }
                if(best==null || due<best.due)best=new Candidate(due,key,name,time,index);
                if(days==0)break;
            }
        }
        return best;
    }
    private static PendingIntent checkIntent(Context context) {
        return PendingIntent.getBroadcast(context, ALARM_REQ,
            new Intent(context, UpcomingAlarmReceiver.class).setAction(ACTION_CHECK),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static void scheduleCheck(Context context, long when) {
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(am!=null) try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, checkIntent(context)); }
        catch (RuntimeException e) { EventJournal.append(context, "Upcoming reminder scheduling FAILED: " + e.getMessage()); }
    }
    private static void cancelCheck(Context context) {
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(am!=null)am.cancel(checkIntent(context));
    }
    private static boolean watchConnected() {
        WatchMonitorService service = WatchMonitorService.liveService();
        return service!=null && service.bridge()!=null && service.bridge().hasWatchConnection();
    }
    private static void channel(Context context) {
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        NotificationGroups.ensure(context, nm);
        NotificationChannel c=new NotificationChannel(CHANNEL,"Upcoming alarms",NotificationManager.IMPORTANCE_LOW);
        c.setGroup(NotificationGroups.ALARM);
        c.setDescription("Shows the next enabled watch alarm during the 9 hours before it starts");
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(c);
    }
    static synchronized void reconcile(Context context) {
        SharedPreferences p=pref(context);
        long now=System.currentTimeMillis();
        Set<String> seen=new HashSet<>(p.getStringSet("dismissed",new HashSet<>()));
        seen.removeIf(k->{try{return Long.parseLong(k.substring(0,k.indexOf(':')))<now-86400000L;}catch(Exception e){return true;}});
        if(seen.size()!=p.getStringSet("dismissed",new HashSet<>()).size())p.edit().putStringSet("dismissed",seen).apply();
        Candidate next=findNext(context,now,seen);
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(next==null){cancelCheck(context);if(nm!=null)nm.cancel(ID);p.edit().remove("displayed").apply();return;}
        long showFrom=next.due-WINDOW;
        if(now<showFrom){cancelCheck(context);scheduleCheck(context,showFrom);if(nm!=null)nm.cancel(ID);p.edit().remove("displayed").apply();return;}
        // Check shortly after the scheduled alarm to remove an expired reminder.
        cancelCheck(context);scheduleCheck(context,next.due+1000L);
        if(nm==null)return;
        channel(context);
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            if(!next.key.equals(p.getString("blocked",""))){EventJournal.append(context,"Upcoming reminder BLOCKED: notification permission missing");p.edit().putString("blocked",next.key).apply();}
            return;
        }
        if(!nm.areNotificationsEnabled() || nm.getNotificationChannel(CHANNEL).getImportance()==NotificationManager.IMPORTANCE_NONE){
            if(!next.key.equals(p.getString("blocked",""))){EventJournal.append(context,"Upcoming reminder BLOCKED: notification channel disabled");p.edit().putString("blocked",next.key).apply();}
            return;
        }
        Intent open=new Intent(context,MainActivity.class).putExtra("show_alarms",true);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content=PendingIntent.getActivity(context,21832,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        boolean connected=watchConnected();
        PendingIntent action;
        String actionName;
        if(connected){
            Intent disable=new Intent(context,MainActivity.class).putExtra("show_alarms",true).putExtra("disable_alarm_key",next.key);
            disable.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            disable.setData(Uri.parse("pavlok://reminder/disable"));
            action=PendingIntent.getActivity(context,21833,disable,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            actionName="Disable";
        } else {
            Intent cancel=new Intent(context,UpcomingAlarmReceiver.class).setAction(ACTION_CANCEL).putExtra("reminder_key",next.key);
            action=PendingIntent.getBroadcast(context,21834,cancel,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            actionName="Cancel";
        }
        String label=next.name+" · "+new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new java.util.Date(next.due));
        Notification n=new Notification.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("ALARM - " + next.name + " - Upcoming")
            .setContentText("Scheduled for " + new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new java.util.Date(next.due)))
            .setSubText(connected?"Watch connected":"Watch disconnected · Cancel only hides reminder")
            .setContentIntent(content).setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setOnlyAlertOnce(true)
            .setWhen(next.due).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,actionName,action).build()).build();
        try{
            nm.notify(ID,n);
            if(!next.key.equals(p.getString("displayed","")))EventJournal.append(context,"Upcoming alarm reminder POSTED: "+label+" (9-hour window)");
            p.edit().putString("displayed",next.key).apply();
        }catch(RuntimeException e){EventJournal.append(context,"Upcoming reminder FAILED: "+e.getMessage());}
    }
    /** Retire the matching near-due reminder after a watch-confirmed firing. */
    static synchronized void onWatchFiring(Context context, int watchAlarmId) {
        SharedPreferences p = pref(context);
        // The watch itself owns this alarm. Suppress a speculative *next-day*
        // reminder after an ONCE alarm actually fired; never disable or delete
        // the watch record from a phone-side event.
        try {
            JSONArray verified = new JSONArray(p.getString("verified_alarms", "[]"));
            JSONObject fired = verified.optJSONObject(watchAlarmId - 1);
            if (fired != null && fired.optInt("days", -1) == 0) {
                String key = oneShotKey(fired.optInt("index",watchAlarmId - 1),
                        fired.optString("name","Alarm"), fired.optString("time",""));
                Set<String> consumed = new HashSet<>(p.getStringSet("consumed_once",new HashSet<>()));
                if (consumed.add(key)) p.edit().putStringSet("consumed_once",consumed).apply();
            }
        } catch (Exception ignored) { }
        String displayed = p.getString("displayed", "");
        if (!displayed.isEmpty()) {
            try {
                int colon = displayed.indexOf(':');
                long due = Long.parseLong(displayed.substring(0,colon));
                int indexEnd = displayed.indexOf(':', colon + 1);
                int index = Integer.parseInt(displayed.substring(colon+1,indexEnd));
                if (index + 1 == watchAlarmId && Math.abs(due - System.currentTimeMillis()) < 15 * 60 * 1000L) {
                    Set<String> ignored = new HashSet<>(p.getStringSet("dismissed",new HashSet<>()));
                    ignored.add(displayed);
                    p.edit().putStringSet("dismissed",ignored).remove("displayed").apply();
                    EventJournal.append(context, "Upcoming alarm reminder retired on confirmed watch firing");
                }
            } catch (Exception ignored) { }
        }
        reconcile(context);
    }

    static synchronized void cancelOnly(Context context, String key){
        SharedPreferences p=pref(context);
        String showing=p.getString("displayed", "");
        if(key==null || !key.equals(showing)){EventJournal.append(context,"Stale reminder Cancel ignored");return;}
        // Never writes to the watch. Cancel mutes this occurrence only.
        Set<String> seen=new HashSet<>(p.getStringSet("dismissed",new HashSet<>()));seen.add(key);
        p.edit().putStringSet("dismissed",seen).remove("displayed").apply();
        EventJournal.append(context,"Upcoming reminder canceled on phone; watch alarm stays enabled");
        reconcile(context);
    }
}
