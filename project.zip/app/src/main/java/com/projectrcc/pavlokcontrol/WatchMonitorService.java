package com.projectrcc.pavlokcontrol;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;

/** Owns one BLE connection independently of the visible WebView.
 * A connectedDevice foreground service is needed to monitor watch alarm events
 * when the screen is off or the user leaves the app.
 */
public final class WatchMonitorService extends Service {
    private static final String ACTION_START = "com.projectrcc.pavlokcontrol.START_MONITOR";
    static final String ACTION_WATCH_ALARM = "com.projectrcc.pavlokcontrol.WATCH_ALARM_ACTION";
    static final String EXTRA_WATCH_ALARM_ID = "watch_alarm_id";
    static final String EXTRA_WATCH_ALARM_UPDATED = "watch_alarm_updated";
    static final String EXTRA_WATCH_ALARM_COMMAND = "watch_alarm_command";
    private static final String CHANNEL = "pavlok_ble_monitor_v208";
    private static final int NOTIFICATION_ID = 20801;
    private final IBinder binder = new LocalBinder();
    private NativeBleBridge bridge;
    private NativeTimerEngine timerEngine;
    private CodeRedGuard codeRedGuard;
    private CodeRedAudio codeRedAudio;
    private boolean monitoring;
    private boolean showingForeground;
    private static volatile WatchMonitorService live;
    static WatchMonitorService liveService() { return live; }

    final class LocalBinder extends Binder {
        WatchMonitorService service() { return WatchMonitorService.this; }
    }

    @Override public void onCreate() {
        super.onCreate();
        live = this;
        bridge = new NativeBleBridge(this);
        timerEngine = new NativeTimerEngine(this);
        codeRedGuard = new CodeRedGuard(this);
        codeRedAudio = new CodeRedAudio(this);
        TimerNotifications.createChannels(this);
        AlarmNotifications.restoreSnoozeIfActive(this);
        UpcomingAlarmReminders.reconcile(this);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            NotificationGroups.ensure(this, manager);
        // User preference: a new installation should start with this optional status
        // notification disabled. Android may elevate a foreground-service channel
        // to LOW when monitoring begins; that is OS-controlled and cannot be
        // prevented safely by removing the required foreground notification.
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Watch connection", NotificationManager.IMPORTANCE_NONE);
        channel.setGroup(NotificationGroups.CONNECTIONS);
            channel.setDescription("Keeps the Pavlok connection available for alarm notifications while the app is in the background");
            manager.createNotificationChannel(channel);
        }
    }

    NativeBleBridge bridge() { return bridge; }
    NativeTimerEngine timerEngine() { return timerEngine; }
    CodeRedGuard codeRedGuard() { return codeRedGuard; }
    CodeRedAudio codeRedAudio() { return codeRedAudio; }
    boolean isMonitoring() { return monitoring; }

    boolean beginMonitoring() {
        if (monitoring) return true;
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return false;
        monitoring = true;
        try {
            Intent start = new Intent(this, WatchMonitorService.class).setAction(ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
            else startService(start);
            return true;
        } catch (Exception ex) {
            monitoring = false;
            return false;
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY may recreate the service after system process reclamation.
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            if (intent != null && ACTION_WATCH_ALARM.equals(intent.getAction()))
                AlarmNotifications.actionWarning(this, intent.getIntExtra(EXTRA_WATCH_ALARM_ID, 0),
                        "Bluetooth permission missing. Use the watch button directly.");
            monitoring = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        boolean restoring = intent == null;
        monitoring = true;
        try {
            showForeground("Monitoring Pavlok watch alarms");
        } catch (Exception ex) {
            monitoring = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && CodeRedGuard.ACTION_CODE_RED_DUE.equals(intent.getAction())) {
            codeRedGuard.onScheduledDeadline();
        } else if (intent != null && CodeRedGuard.ACTION_CODE_RED_NO_SNOOZE.equals(intent.getAction())) {
            codeRedGuard.onNoSnoozeDeadline();
        } else if (intent != null && CodeRedAudio.ACTION_AUDIO.equals(intent.getAction())) {
            codeRedAudio.command(intent.getStringExtra(CodeRedAudio.EXTRA_COMMAND));
        } else if (intent != null && TimerNotifications.ACTION_TIMER.equals(intent.getAction())) {
            handleTimerNotificationAction(intent.getStringExtra(TimerNotifications.EXTRA_COMMAND));
        } else if (intent != null && ACTION_WATCH_ALARM.equals(intent.getAction())) {
            handleWatchAlarmNotificationAction(intent);
        }
        if (restoring) bridge.restoreBackgroundConnection();
        UpcomingAlarmReminders.reconcile(this);
        return START_STICKY;
    }

    private void handleWatchAlarmNotificationAction(Intent intent) {
        String command = intent.getStringExtra(EXTRA_WATCH_ALARM_COMMAND);
        int id = intent.getIntExtra(EXTRA_WATCH_ALARM_ID, 0);
        long updated = intent.getLongExtra(EXTRA_WATCH_ALARM_UPDATED, 0L);
        if (id <= 0 || updated <= 0L || (!"snooze".equals(command) && !"stop".equals(command))) return;
        try {
            org.json.JSONObject watch = new org.json.JSONObject(SnoozeGuard.snapshot(this));
            String state = watch.optString("state", "unknown");
            int reportedId = watch.optInt("id", -1);
            long reportedToken = "firing".equals(state)
                    ? watch.optLong("roundStarted", -1L) : watch.optLong("updated", -1L);
            // Match the immutable firing-round token, not the changing timestamp
            // of every repeated FIRING indication. Snoozed Stop uses snooze time.
            if (reportedId != id || reportedToken != updated ||
                    !("firing".equals(state) || ("stop".equals(command) && "snoozed".equals(state))) ||
                    System.currentTimeMillis() - updated > 30L * 60L * 1000L) {
                EventJournal.append(this, "Watch alarm " + command + " notification action IGNORED: stale or mismatched watch state");
                AlarmNotifications.actionWarning(this, id,
                        "Alarm state changed. Check the watch before trying again.");
                return;
            }
            if (!bridge.queueAlarmControlFromNotification(command)) {
                AlarmNotifications.actionWarning(this, id,
                        "Command not sent. Reconnect or use the middle watch button.");
                return;
            }
            EventJournal.append(this, "Watch alarm #" + id + " " + command + " requested from notification; awaiting watch confirmation");
            // This is only a confirmation watchdog. Never change the watch state or cancel
            // the alarm notification unless a real watch event is received.
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                try {
                    org.json.JSONObject latest = new org.json.JSONObject(SnoozeGuard.snapshot(this));
                    boolean confirmed = latest.optInt("id", -1) == id &&
                            latest.optLong("updated", 0L) > updated &&
                            ("stop".equals(command) ? "dismissed".equals(latest.optString("state")) :
                              ("snoozed".equals(latest.optString("state")) ||
                               "dismissed".equals(latest.optString("state"))));
                    if (!confirmed) AlarmNotifications.actionWarning(this, id,
                            "Watch has not confirmed " + command + ". Check the watch directly.");
                } catch (Exception ex) { EventJournal.append(this, "Alarm action confirmation check failed: " + ex.getMessage()); }
            }, 7000L);
        } catch (Exception ex) {
            AlarmNotifications.actionWarning(this, id, "Watch alarm action failed. Check the watch directly.");
            EventJournal.append(this, "Watch alarm notification action FAILED: " + ex.getMessage());
        }
    }

    private void handleTimerNotificationAction(String command) {
        if (command == null) return;
        try {
            String phase = new org.json.JSONObject(timerEngine.snapshot()).optString("phase", "ready");
            if ("ready".equals(phase) ||
                    ("snoozing".equals(phase) && ("pause".equals(command) || "resume".equals(command))) ||
                    ("alerting".equals(phase) && "pause".equals(command)) ||
                    ("pause".equals(command) && "paused".equals(phase)) ||
                    ("resume".equals(command) && !"paused".equals(phase)) ||
                    ("snooze".equals(command) && !"alerting".equals(phase))) {
                EventJournal.append(this, "Timer notification action ignored for phase " + phase + ": " + command);
                return;
            }
            if (!"pause".equals(command) && !"resume".equals(command) &&
                !"reset".equals(command) && !"snooze".equals(command)) return;
            // A watch alarm takes precedence over timer firmware commands.
            String alarmState = new org.json.JSONObject(SnoozeGuard.snapshot(this)).optString("state", "unknown");
            if (("firing".equals(alarmState) || "snoozed".equals(alarmState)) &&
                    (codeRedGuard == null || !codeRedGuard.ownsTimer())) {
                EventJournal.append(this, "Timer notification action blocked during watch alarm: " + command);
                return;
            }
            // Keep the watch's firmware timer in sync when Bluetooth is available.
            if (bridge.hasWatchConnection()) {
                // Snooze firmware cleanup is owned by NativeTimerEngine.command;
                // don't start a duplicate five-minute watch-side timer here.
                if (!"snooze".equals(command) && !"reset".equals(command)) bridge.queueTimerFirmwareOp("pause".equals(command) ? 0x13 :
                    "resume".equals(command) ? 0x14 : 0x12);
            } else EventJournal.append(this, "Timer notification command applied on phone; watch disconnected");
            timerEngine.command(command, new org.json.JSONObject());
            codeRedGuard.onManualTimerCommand(command);
            EventJournal.append(this, "Timer notification action: " + command + " (watch command queued if connected)");
        } catch(Exception ex) { EventJournal.append(this, "Timer notification action FAILED: " + ex.getMessage()); }
    }

    void updateMonitorStatus(boolean connected) {
        UpcomingAlarmReminders.reconcile(this);
        if (monitoring && showingForeground) {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID, statusNotification(connected ? "Watch connected · alarm monitoring on" : "Reconnecting to Pavlok watch"));
        }
    }

    private Notification statusNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 20801, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Pavlok Control")
                .setContentText(text)
                .setContentIntent(pending)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(false) // Permit dismissal on supported Android versions without stopping background BLE monitoring
                .setOnlyAlertOnce(true)
                .build();
    }

    private void showForeground(String text) {
        Notification notification = statusNotification(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else startForeground(NOTIFICATION_ID, notification);
        showingForeground = true;
    }

    void endMonitoring() {
        // An explicit disconnect must stop phone-only audio and restore the
        // original alarm volume; a temporary OS service restart is different.
        if (codeRedAudio != null) codeRedAudio.command("stop");
        monitoring = false;
        showingForeground = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onDestroy() {
        if (codeRedAudio != null) codeRedAudio.close();
        if (codeRedGuard != null) codeRedGuard.close();
        if (timerEngine != null) timerEngine.close();
        if (bridge != null) bridge.close();
        monitoring = false;
        if (live == this) live = null;
        super.onDestroy();
    }
}
