package com.projrcc.pavdroid;

import android.app.Notification;
import android.content.Context;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Locale;

/** One countdown, in the same decorated content for collapsed and expanded notifications. */
final class CountdownNotification {
    private CountdownNotification() {}
    static void apply(Context context, Notification.Builder b, String title, String detail, long deadline, int remaining, boolean paused) {
        RemoteViews view = new RemoteViews(context.getPackageName(), R.layout.notification_countdown);
        view.setTextViewText(R.id.countdown_title, title);
        view.setTextViewText(R.id.countdown_detail, detail);
        view.setViewVisibility(R.id.countdown_detail, detail.isEmpty()?View.GONE:View.VISIBLE);
        view.setViewVisibility(R.id.countdown_live, paused?View.GONE:View.VISIBLE);
        view.setViewVisibility(R.id.countdown_paused, paused?View.VISIBLE:View.GONE);
        if (paused) {
            int s=Math.max(0,remaining);
            view.setTextViewText(R.id.countdown_paused, s>=3600 ? String.format(Locale.US,"%d:%02d:%02d",s/3600,s/60%60,s%60):String.format(Locale.US,"%02d:%02d",s/60,s%60));
        } else {
            // Android Chronometer counts against elapsed realtime. Convert the actual wall-clock deadline.
            long base=SystemClock.elapsedRealtime()+Math.max(0,deadline-System.currentTimeMillis());
            view.setChronometer(R.id.countdown_live,base,null,true);
            view.setChronometerCountDown(R.id.countdown_live,true);
        }
        b.setShowWhen(false).setUsesChronometer(false)
            .setStyle(new Notification.DecoratedCustomViewStyle())
            .setCustomContentView(view).setCustomBigContentView(view.clone());
    }
}
