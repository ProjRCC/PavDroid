package com.projrcc.pavdroid;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Append-only phone-local diagnostic journal. Only the user's Clear action removes it.
 *  Native BLE events are logged even when the WebView is not present.
 */
final class EventJournal {
    private static final String FILE = "pd2_watch_events.tsv";
    // Separate durable record of the source events for saved Alarm/Timer History.
    // Connection > Clear must NEVER erase this archive.
    private static final String ARCHIVE = "pd2_session_events.tsv";
    private EventJournal() { }
    private static File file(Context context) { return new File(context.getApplicationContext().getFilesDir(), FILE); }
    private static File archiveFile(Context context) { return new File(context.getApplicationContext().getFilesDir(), ARCHIVE); }
    private static void ensureArchive(Context context) {
        // Fresh PavDroid 2.0 package: no firmware-era journal migration is needed.
        File archive = archiveFile(context);
        if (archive.exists()) return;
        try { archive.createNewFile(); } catch (IOException ignored) { }
    }
    private static void writeLine(File target, String record) {
        try (FileOutputStream stream = new FileOutputStream(target, true)) {
            stream.write(record.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }
    static synchronized void append(Context context, String message) {
        if (message == null) return;
        final String cleaned = message.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
        final String record = System.currentTimeMillis() + "\t" + cleaned + "\n";
        ensureArchive(context);
        writeLine(file(context), record);
        writeLine(archiveFile(context), record);
    }
    static synchronized String read(Context context) { return readFromFile(file(context)); }
    static synchronized String readArchive(Context context) {
        ensureArchive(context);
        return readFromFile(archiveFile(context));
    }
    private static String readFromFile(File source) {
        JSONArray entries = new JSONArray();
        if (!source.exists()) return "[]";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(source), StandardCharsets.UTF_8))) {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            for (String line; (line = reader.readLine()) != null;) {
                int split = line.indexOf('\t');
                if (split <= 0) continue;
                try {
                    long millis = Long.parseLong(line.substring(0,split));
                    JSONObject event = new JSONObject();
                    event.put("millis",millis);
                    event.put("at",formatter.format(new Date(millis)));
                    event.put("msg",line.substring(split+1));
                    entries.put(event);
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return entries.toString();
    }
    static synchronized void clear(Context context) {
        ensureArchive(context);
        try (FileOutputStream ignored = new FileOutputStream(file(context), false)) {
            // Preserve the file but truncate its content. Archived sessions survive.
        } catch (Exception ignored) { }
    }
    static synchronized void clearArchive(Context context) {
        ensureArchive(context);
        try (FileOutputStream ignored = new FileOutputStream(archiveFile(context), false)) {
            // History > Delete All wipes the independent archive only.
        } catch (Exception ignored) { }
    }
}
