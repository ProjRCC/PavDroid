package com.projrcc.pavdroid;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Android BLE transport for the PavDroid-native JavaScript interface.
 * Scans for Pavlok-3 devices; only direct watch effect writes are exposed.
 * GATT transactions, including CCCD subscriptions, are serialized.
 */
public final class NativeBleBridge {
    private static final int REQUEST_PERMISSIONS = 941;
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final UUID EVENT_STATUS_UUID = UUID.fromString("00002002-0000-1000-8000-00805f9b34fb");
    // Confirmed ON/OFF transitions on the Shock Clock 3: 4th byte 1=plugged, 0=unplugged.
    private static final UUID CHARGE_STATUS_UUID = UUID.fromString("00000001-0000-1000-8000-00805f9b34fb");
    private static final UUID VIBE_UUID = UUID.fromString("00001001-0000-1000-8000-00805f9b34fb");
    private static final UUID BEEP_UUID = UUID.fromString("00001002-0000-1000-8000-00805f9b34fb");
    private static final UUID ZAP_UUID = UUID.fromString("00001003-0000-1000-8000-00805f9b34fb");
    private static final long BLE_OPERATION_TIMEOUT_MS = 10000;
    private static final String PREFS = "pd2_ble_v1";
    private static final String ADDRESS = "device_address";
    private static final String NAME = "device_name";

    // The Service owns the GATT link. The Activity/WebView may come and go.
    private final WatchMonitorService owner;
    private final Context context;
    private volatile Activity activity;
    private volatile WebView web;
    private Runnable reconnectTask;
    // Background reconnection is owned by one native GATT client. A passive
    // autoConnect request stays armed while the phone is locked/out of range.
    private long reconnectDelayMs = 7000;
    private long nextRetryAt = 0L;
    private boolean gattAutoConnect = false;
    private int nativeAttempts = 0;
    private static final String CONNECTED_AT = "native_last_connected_ms";
    private static final String DISCONNECTED_AT = "native_last_disconnected_ms";
    private int pendingClientConnect = -1;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private String currentAddress;
    private int pendingConnect = -1;
    private int pendingScan = -1;
    private Runnable afterPermission;
    private int permissionRequest = -1;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private Runnable scanTimeout;
    private volatile boolean connected;
    private boolean disposed;
    private final ArrayDeque<Operation> operations = new ArrayDeque<>();
    private Operation active;
    private Runnable operationTimeout;
    // Optional, user-initiated passive notification diagnostics. Not firmware commands.
    private final Set<UUID> diagnosticSubscribed = new HashSet<>();
    // Owned by the native BLE service, not by the WebView or temporary diagnostic test.
    private volatile boolean chargeKnown;
    private volatile boolean charging;

    private static final class Operation {
        final int requestId;
        final String action;
        final UUID characteristic;
        final byte[] payload;
        Operation(int id, String action, UUID charUuid, byte[] payload) {
            this.requestId = id;
            this.action = action;
            this.characteristic = charUuid;
            this.payload = payload;
        }
    }

    NativeBleBridge(WatchMonitorService owner) {
        this.owner = owner;
        this.context = owner.getApplicationContext();
        BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
    }

    void attach(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    void detach(WebView web) {
        if (this.web == web) {
            this.web = null;
            this.activity = null;
            this.afterPermission = null;
            this.permissionRequest = -1;
        }
    }

    @JavascriptInterface public String savedDevice() {
        String addr = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ADDRESS, null);
        if (addr == null) return "null";
        String name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(NAME, "Pavlok-3");
        try {
            return new JSONObject().put("id", addr).put("name", name).toString();
        } catch (Exception ignored) { return "null"; }
    }

    @JavascriptInterface public boolean isWatchConnected() { return hasWatchConnection(); }
    /** Read-only status; never estimates charging from battery percentage. */
    @JavascriptInterface public String chargingSnapshot() {
        try { return new JSONObject().put("known", hasWatchConnection() && chargeKnown)
                .put("charging", hasWatchConnection() && chargeKnown && charging).toString(); }
        catch (Exception ignored) { return "{\"known\":false,\"charging\":false}"; }
    }
    /** Native truth; does not require WebView timers or a visible Activity. */
    @JavascriptInterface public String connectionSnapshot() {
        String state = hasWatchConnection() ? "connected" :
                (gattAutoConnect && gatt != null ? "waiting" :
                 (pendingConnect != -1 ? "connecting" :
                  (reconnectTask != null ? "retry" : "disconnected")));
        android.content.SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try { return new JSONObject()
                .put("state", state).put("monitoring", owner.isMonitoring())
                .put("attempts", nativeAttempts).put("retryAt", nextRetryAt)
                .put("lastConnected", p.getLong(CONNECTED_AT, 0L))
                .put("lastDisconnected", p.getLong(DISCONNECTED_AT, 0L))
                .put("name", p.getString(NAME, "Pavlok-3")).toString(); }
        catch (Exception e) { return "{}"; }
    }
    @JavascriptInterface public String eventHistory() { return EventJournal.read(context); }
    @JavascriptInterface public String savedSessionEvents() { return EventJournal.readArchive(context); }
    /** Passive inventory: list already-discovered UUIDs and property bits only. No GATT operation. */
    @JavascriptInterface public String chargingDiagnosticInventory() {
        try {
            JSONObject result = new JSONObject().put("connected", hasWatchConnection());
            JSONArray all = new JSONArray(), readable = new JSONArray(), notifiable = new JSONArray();
            if (!hasWatchConnection() || gatt == null) return result.put("characteristics", all).put("readable", readable).put("notifiable", notifiable).toString();
            for (android.bluetooth.BluetoothGattService svc : gatt.getServices()) {
                for (BluetoothGattCharacteristic c : svc.getCharacteristics()) {
                    if (all.length() >= 96) break;
                    int properties = c.getProperties();
                    all.put(new JSONObject().put("uuid", c.getUuid().toString()).put("properties", properties));
                    if (readable.length() < 12 && isSafeDiagnosticCharacteristic(svc.getUuid(), c))
                        readable.put(c.getUuid().toString());
                    if (notifiable.length() < 18 && eligibleDiagnosticNotify(c.getUuid()))
                        notifiable.put(c.getUuid().toString());
                }
            }
            return result.put("characteristics", all).put("readable", readable).put("notifiable", notifiable).toString();
        } catch (Exception e) { return "{\"connected\":false,\"characteristics\":[],\"readable\":[]}"; }
    }
    /** Explicitly selected proprietary status streams; excludes stimulation and watch-button endpoints. */
    private boolean eligibleDiagnosticNotify(UUID uuid) {
        if (!hasWatchConnection() || gatt == null) return false;
        String value = uuid.toString().toLowerCase(java.util.Locale.ROOT);
        if (isStimulus(uuid) || EVENT_STATUS_UUID.equals(uuid) || CHARGE_STATUS_UUID.equals(uuid)) return false;
        // Charging status is permanently managed by the native service; Diagnostics cannot unsubscribe it.
        // Exclude standard GATT service-changed and identifying characteristics.
        if (!(value.startsWith("000020") || value.startsWith("000040") ||
              value.startsWith("000050") || value.startsWith("000060") ||
              value.startsWith("000070") || value.startsWith("00000001-"))) return false;
        for (android.bluetooth.BluetoothGattService service : gatt.getServices()) {
            BluetoothGattCharacteristic c = service.getCharacteristic(uuid);
            if (c == null) continue;
            int flags = BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE;
            return (c.getProperties() & flags) != 0 && c.getDescriptor(CCCD) != null;
        }
        return false;
    }
    @JavascriptInterface public void diagnosticSubscribe(int requestId, String uuid) {
        enqueue(requestId, "diagnostic-subscribe", uuid, null);
    }
    @JavascriptInterface public void diagnosticUnsubscribe(int requestId, String uuid) {
        enqueue(requestId, "diagnostic-unsubscribe", uuid, null);
    }
    /** Restricted read-only diagnostic for proprietary GATT status. Never enables notifications or writes. */
    @JavascriptInterface public void diagnosticRead(int requestId, String uuid) {
        enqueue(requestId, "diagnostic-read", uuid, null);
    }
    private boolean isSafeDiagnosticCharacteristic(UUID serviceUuid, BluetoothGattCharacteristic c) {
        String s = serviceUuid.toString().toLowerCase(java.util.Locale.ROOT);
        // Standard Generic Access, Generic Attribute and Device Information can contain device identifiers.
        if (s.startsWith("00001800-") || s.startsWith("00001801-") || s.startsWith("0000180a-")) return false;
        if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) == 0) return false;
        return !isStimulus(c.getUuid());
    }
    private boolean eligibleDiagnosticRead(UUID uuid) {
        if (!hasWatchConnection() || gatt == null || owner.alarmEngine().isActive() || owner.timerEngine().isSessionActive()) return false;
        for (android.bluetooth.BluetoothGattService service : gatt.getServices()) {
            BluetoothGattCharacteristic c = service.getCharacteristic(uuid);
            if (c != null) return isSafeDiagnosticCharacteristic(service.getUuid(), c);
        }
        return false;
    }
    @JavascriptInterface public void clearSavedSessionEvents() { EventJournal.clearArchive(context); }
    @JavascriptInterface public void appendEvent(String message) { EventJournal.append(context, message); }
    @JavascriptInterface public void clearEvents() { EventJournal.clear(context); }
    @JavascriptInterface public String androidAlarms() { return owner.alarmEngine().alarmsJson(); }
    @JavascriptInterface public String androidAlarmSnapshot() { return owner.alarmEngine().snapshot(); }
    @JavascriptInterface public boolean hasAndroidExactAlarmAccess() { return owner.alarmEngine().exactAllowed(); }
    @JavascriptInterface public void saveAndroidAlarms(int requestId, String json) {
        main.post(() -> { try { owner.alarmEngine().replace(json); succeed(requestId, owner.alarmEngine().alarmsJson()); }
                      catch (Exception e) { fail(requestId, e.getMessage()); } });
    }
    @JavascriptInterface public void androidAlarmAction(int requestId, String action) {
        main.post(() -> { try {
            if ("snooze".equals(action)) owner.alarmEngine().snooze();
            else if ("stop".equals(action)) owner.alarmEngine().stop("phone button");
            else throw new IllegalArgumentException("Unknown Android alarm action");
            succeed(requestId, owner.alarmEngine().snapshot());
        } catch(Exception e) { fail(requestId, e.getMessage()); } });
    }
    @JavascriptInterface public String timerSnapshot() {
        return owner.timerEngine().snapshot();
    }
    @JavascriptInterface public void timerAction(int requestId, String action, String jsonConfig) {
        main.post(() -> {
            try {
                owner.timerEngine().command(action, new JSONObject(jsonConfig));
                succeed(requestId, owner.timerEngine().snapshot());
            } catch (Exception e) { fail(requestId, "Timer command failed: " + e.getMessage()); }
        });
    }
    boolean hasWatchConnection() { return connected && gatt != null; }
    boolean queueTimerStimulus(int type, int pct) {
        if (!hasWatchConnection()) return false;
        UUID uuid = type == 1 ? VIBE_UUID : type == 2 ? BEEP_UUID : ZAP_UUID;
        if (characteristic(uuid) == null) return false;
        byte[] bytes = type == 3 ? new byte[] {(byte)0x81, (byte)pct}
                : new byte[] {(byte)0x81, 1, (byte)pct, 0x16, 0x16};
        enqueue(-3, "write", uuid.toString(), bytes);
        return true; // queued only; watch execution is not confirmed by this return
    }
    /** Pending native timer stimuli are not allowed to fire after Snooze/Stop. */
    void discardQueuedTimerStimuli() {
        Runnable discard = () -> {
            int before = operations.size();
            operations.removeIf(op -> op.requestId == -3 && "write".equals(op.action) &&
                (VIBE_UUID.equals(op.characteristic) || BEEP_UUID.equals(op.characteristic) || ZAP_UUID.equals(op.characteristic)));
            int discarded = before - operations.size();
            if (discarded > 0) EventJournal.append(context, "Discarded " + discarded + " pending timer stimulus commands");
            // An already transmitted BLE command cannot be retracted.
        };
        if (Looper.myLooper() == Looper.getMainLooper()) discard.run();
        else main.post(discard);
    }
    private void js(String script) {
        if (disposed) return;
        main.post(() -> {
            WebView target = web;
            if (!disposed && target != null) target.evaluateJavascript(script, null);
        });
    }
    private void succeed(int id, String jsonResult) {
        if (id < 0) return;
        js("window.PavDroidTransport._complete(" + id + ",true," + JSONObject.quote(jsonResult) + ");");
    }
    private void fail(int id, String message) {
        if (id < 0) return;
        js("window.PavDroidTransport._complete(" + id + ",false," + JSONObject.quote(message) + ");");
    }
    private void notifyCharacteristic(UUID uuid, byte[] data) {
        if (EVENT_STATUS_UUID.equals(uuid)) {
            if (!owner.alarmEngine().onButton(data)) owner.timerEngine().onWatchEvent(data);
        } else if (CHARGE_STATUS_UUID.equals(uuid) && data != null && data.length == 4 &&
                (data[3] == 0 || data[3] == 1)) {
            boolean next = data[3] == 1;
            boolean changed = !chargeKnown || charging != next;
            chargeKnown = true;
            charging = next;
            if (changed) EventJournal.append(context, "Watch charge connection " + (next ? "PLUGGED" : "UNPLUGGED") + " (BLE 0001 byte 4)");
        }
        js("window.PavDroidTransport._notify(" + JSONObject.quote(uuid.toString()) + "," + bytesJson(data) + ");");
    }
    private void notifyDisconnected() { js("window.PavDroidTransport._disconnected();"); }
    private static String bytesJson(byte[] data) {
        JSONArray a = new JSONArray();
        for (byte b : data) a.put(b & 0xff);
        return a.toString();
    }

    private boolean permissionsAvailable() {
        if (Build.VERSION.SDK_INT >= 31) {
            return context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                   context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void requirePermissions(int id, Runnable next) {
        if (permissionsAvailable()) { next.run(); return; }
        if (afterPermission != null) { fail(id, "Nearby devices permission is already being requested"); return; }
        if (activity == null) { fail(id, "Open PavDroid to grant Bluetooth permission"); return; }
        permissionRequest = id;
        afterPermission = next;
        if (Build.VERSION.SDK_INT >= 31)
            activity.requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        else
            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
    }
    void onPermissionsResult(int code) {
        if (code != REQUEST_PERMISSIONS) return;
        Runnable next = afterPermission;
        int id = permissionRequest;
        afterPermission = null;
        permissionRequest = -1;
        if (next == null) return;
        if (permissionsAvailable()) next.run();
        else fail(id, "Nearby devices permission was denied. Enable it in Android Settings to connect.");
    }
    private boolean ready(int id) {
        if (adapter == null) { fail(id, "This phone does not support Bluetooth"); return false; }
        try {
            if (!adapter.isEnabled()) { fail(id, "Turn on Bluetooth and try again"); return false; }
        } catch (SecurityException ex) { fail(id, "Nearby devices permission required"); return false; }
        return true;
    }

    /** First-time pairing/selection. Auto reconnect uses savedDevice(), not a new scan. */
    @JavascriptInterface public void scan(int requestId, String prefix) {
        main.post(() -> requirePermissions(requestId, () -> startScan(requestId, prefix)));
    }
    @SuppressLint("MissingPermission")
    private void startScan(int id, String prefix) {
        if (!ready(id)) return;
        if (scanCallback != null) { fail(id, "Device scan already in progress"); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { fail(id, "Bluetooth scanner unavailable"); return; }
        final String expectedPrefix = (prefix == null || !prefix.startsWith("Pavlok-3-")) ? "Pavlok-3-" : prefix;
        final java.util.Set<BluetoothDevice> seen = new java.util.HashSet<>();
        final java.util.Set<BluetoothDevice> named = new java.util.HashSet<>();
        pendingScan = id;
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (device == null) return;
                String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
                seen.add(device);
                if (name != null && !name.isEmpty()) named.add(device);
                if (name == null || !name.regionMatches(true, 0, expectedPrefix, 0, expectedPrefix.length())) {
                    try { name = device.getName(); } catch (SecurityException ignored) { }
                }
                if (name != null && !name.isEmpty()) named.add(device);
                if (name == null || !name.regionMatches(true, 0, expectedPrefix, 0, expectedPrefix.length())) return;
                final String foundName = name;
                main.post(() -> {
                    if (pendingScan != id) return;
                    stopScanning();
                    String addr = device.getAddress();
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString(ADDRESS, addr).putString(NAME, foundName).apply();
                    try { succeed(id, new JSONObject().put("id", addr).put("name", foundName).toString()); }
                    catch (Exception e) { fail(id, "Unable to save discovered watch"); }
                });
            }
            @Override public void onScanFailed(int errorCode) {
                main.post(() -> {
                    if (pendingScan != id) return;
                    stopScanning();
                    fail(id, "Bluetooth scan failed (" + errorCode + ")");
                });
            }
        };
        try {
            scanner.startScan(null, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback);
            scanTimeout = () -> {
                if (pendingScan != id) return;
                stopScanning();
                fail(id, "No matching watch in 30 seconds. Android reported " + seen.size() + " distinct nearby devices, " + named.size() + " with names.");
            };
            main.postDelayed(scanTimeout, 30000);
        } catch (Exception e) {
            stopScanning();
            fail(id, "Bluetooth scanning failed: " + e.getMessage());
        }
    }
    @SuppressLint("MissingPermission")
    private void stopScanning() {
        if (scanTimeout != null) main.removeCallbacks(scanTimeout);
        scanTimeout = null;
        if (scanner != null && scanCallback != null) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        scanCallback = null; scanner = null; pendingScan = -1;
    }

    @JavascriptInterface public void connect(int requestId, String address) {
        main.post(() -> requirePermissions(requestId, () -> startConnect(requestId, address)));
    }
    @SuppressLint("MissingPermission")
    private void startConnect(int id, String address) {
        if (!ready(id)) { if (id == -2) scheduleReconnect(); return; }
        if (address == null || !android.bluetooth.BluetoothAdapter.checkBluetoothAddress(address)) {
            fail(id, "Invalid saved watch address"); return;
        }
        if (connected && gatt != null && address.equalsIgnoreCase(currentAddress)) {
            succeed(id, "true"); return;
        }
        if (pendingConnect != -1) {
            // A page reopening must join the existing native autoConnect instead
            // of cancelling its scan/connection and creating a competing GATT.
            if (pendingConnect == -2 && address.equalsIgnoreCase(currentAddress) && id >= 0) {
                // The system will notify JS after a later actual connection.
                // Don't leave a WebView promise pending indefinitely out of range.
                fail(id, "Native automatic reconnect is armed; waiting for watch to return");
                return;
            }
            if (id >= 0) fail(id, "Watch connection already in progress");
            return;
        }
        if (reconnectTask != null) { main.removeCallbacks(reconnectTask); reconnectTask = null; }
        nextRetryAt = 0L;
        if (!owner.beginMonitoring()) { fail(id, "Cannot start Bluetooth background monitoring. Check Nearby devices permission."); return; }
        closeGatt(false);
        currentAddress = address;
        pendingConnect = id;
        // Only a user/initial connection is direct. Every background re-arm is
        // passive, letting Android reconnect while the CPU is asleep.
        final boolean automatic = id == -2;
        gattAutoConnect = automatic;
        nativeAttempts++;
        EventJournal.append(context, "BLE native " + (automatic ? "automatic GATT armed" : "direct connect started") +
                " (attempt " + nativeAttempts + ", saved watch " +
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(NAME, "Pavlok-3") + ")");
        try {
            BluetoothDevice device = adapter.getRemoteDevice(address);
            gatt = device.connectGatt(context, automatic, callback, BluetoothDevice.TRANSPORT_LE);
            if (gatt == null) {
                pendingConnect = -1;
                EventJournal.append(context, "BLE GATT request failed: Android returned null");
                fail(id, "Android could not start BLE connection");
                scheduleReconnect();
            } else if (!automatic) {
                // A direct connect can time out; passive autoConnect cannot:
                // it may wait out of range for minutes/hours by design.
                main.postDelayed(() -> {
                    if (pendingConnect == id && !connected) {
                        EventJournal.append(context, "BLE direct connect timed out after 17s");
                        fail(id, "Bluetooth connection timed out; native auto reconnect armed");
                        closeGatt(true);
                    }
                }, 17000);
            }
        } catch (Exception e) {
            pendingConnect = -1;
            EventJournal.append(context, "BLE connection request failed: " + e.getMessage());
            closeGatt(true);
            fail(id, "Connection failed: " + e.getMessage());
        }
    }

    /** Keep an existing automatic GATT registered through normal range loss. */
    private void passiveLinkLost() {
        boolean hadLink = connected;
        connected = false;
        chargeKnown = false; charging = false;
        pendingConnect = -2;
        operations.removeIf(op -> { fail(op.requestId, "Watch disconnected"); return true; });
        if (active != null) { fail(active.requestId, "Watch disconnected"); active = null; }
        if (operationTimeout != null) main.removeCallbacks(operationTimeout);
        operationTimeout = null;
        if (pendingClientConnect >= 0) {
            fail(pendingClientConnect, "Still out of range; native Bluetooth will reconnect automatically");
            pendingClientConnect = -1;
        }
        if (hadLink) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(DISCONNECTED_AT, System.currentTimeMillis()).apply();
            EventJournal.append(context, "BLE link lost (out of range or watch unavailable); Android autoConnect remains armed");
            notifyDisconnected();
            owner.updateMonitorStatus(false);
            owner.alarmEngine().onLinkChanged(false);
            owner.timerEngine().onLinkChanged(false);
        }
    }

    @SuppressLint("MissingPermission")
    private void closeGatt(boolean announce) {
        boolean hadLink = connected;
        connected = false;
        chargeKnown = false; charging = false;
        diagnosticSubscribed.clear();
        gattAutoConnect = false;
        int pending = pendingConnect;
        pendingConnect = -1;
        if (gatt != null) {
            BluetoothGatt old = gatt;
            gatt = null;
            try { old.disconnect(); } catch (Exception ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
        while (!operations.isEmpty()) fail(operations.removeFirst().requestId, "Watch disconnected");
        if (active != null) { fail(active.requestId, "Watch disconnected"); active = null; }
        if (operationTimeout != null) main.removeCallbacks(operationTimeout);
        operationTimeout = null;
        if (pending != -1 && pending != -2) fail(pending, "Watch disconnected before connecting");
        if (pendingClientConnect != -1) { fail(pendingClientConnect, "Watch disconnected before connecting"); pendingClientConnect = -1; }
        if (announce && hadLink){
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(DISCONNECTED_AT, System.currentTimeMillis()).apply();
            EventJournal.append(context,"PavDroid watch disconnected; direct stimuli unavailable");
            notifyDisconnected();
        }
        if (announce) {
            owner.updateMonitorStatus(false);
            scheduleReconnect();
        }
        owner.timerEngine().onLinkChanged(false);
        owner.alarmEngine().onLinkChanged(false);
    }
    @JavascriptInterface public void disconnect() {
        main.post(() -> {
            owner.endMonitoring();
            if (reconnectTask != null) { main.removeCallbacks(reconnectTask); reconnectTask = null; }
            closeGatt(true);
        });
    }

    private void scheduleReconnect() {
        if (!owner.isMonitoring() || disposed || currentAddress == null || reconnectTask != null || gatt != null) return;
        owner.updateMonitorStatus(false);
        long delay = reconnectDelayMs;
        reconnectDelayMs = Math.min(90000L, reconnectDelayMs * 2L);
        nextRetryAt = System.currentTimeMillis() + delay;
        EventJournal.append(context, "BLE native GATT re-arm scheduled in " + delay / 1000L + "s (Android sleep may delay callback)");
        reconnectTask = () -> {
            reconnectTask = null;
            nextRetryAt = 0L;
            if (owner.isMonitoring() && !connected && pendingConnect == -1 && permissionsAvailable())
                startConnect(-2, currentAddress);
        };
        main.postDelayed(reconnectTask, delay);
    }

    void restoreBackgroundConnection() {
        main.post(() -> {
            if (disposed || connected || pendingConnect != -1 || !permissionsAvailable()) return;
            String saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ADDRESS, null);
            if (saved != null) {
                EventJournal.append(context, "BLE native service restore: re-arming background connection");
                startConnect(-2, saved);
            }
        });
    }


    private static UUID normalized(String uuid) {
        if ("battery_service".equalsIgnoreCase(uuid)) uuid = "0000180f-0000-1000-8000-00805f9b34fb";
        if ("battery_level".equalsIgnoreCase(uuid)) uuid = "00002a19-0000-1000-8000-00805f9b34fb";
        return UUID.fromString(uuid);
    }
    private BluetoothGattCharacteristic characteristic(UUID uuid) {
        if (!connected || gatt == null) return null;
        for (android.bluetooth.BluetoothGattService service : gatt.getServices()) {
            BluetoothGattCharacteristic c = service.getCharacteristic(uuid);
            if (c != null) return c;
        }
        return null;
    }
    @JavascriptInterface public void service(int requestId, String serviceUUID) {
        main.post(() -> {
            if (!connected || gatt == null) { fail(requestId, "Not connected"); return; }
            try {
                if (gatt.getService(normalized(serviceUUID)) == null) fail(requestId, "Watch service not available: " + serviceUUID);
                else succeed(requestId, "true");
            } catch (Exception e) { fail(requestId, e.getMessage()); }
        });
    }
    @JavascriptInterface public void characteristic(int requestId, String charUUID) {
        main.post(() -> {
            try {
                if (characteristic(normalized(charUUID)) == null) fail(requestId, "Characteristic unavailable: " + charUUID);
                else succeed(requestId, "true");
            } catch (Exception e) { fail(requestId, e.getMessage()); }
        });
    }
    @JavascriptInterface public void subscribe(int requestId, String charUUID) { enqueue(requestId, "subscribe", charUUID, null); }
    @JavascriptInterface public void read(int requestId, String charUUID) { enqueue(requestId, "read", charUUID, null); }
    @JavascriptInterface public void write(int requestId, String charUUID, String jsonBytes) {
        byte[] bytes;
        try {
            JSONArray array = new JSONArray(jsonBytes);
            if (array.length() > 512) { fail(requestId, "BLE command exceeds 512 bytes"); return; }
            bytes = new byte[array.length()];
            for (int i = 0; i < bytes.length; ++i) bytes[i] = (byte) (array.getInt(i) & 255);
        } catch (Exception e) { fail(requestId, "Invalid Bluetooth command"); return; }
        enqueue(requestId, "write", charUUID, bytes);
    }
    private boolean isStimulus(UUID uuid) {
        return VIBE_UUID.equals(uuid) || BEEP_UUID.equals(uuid) || ZAP_UUID.equals(uuid);
    }
    private boolean isBattery(UUID uuid) {
        return uuid.toString().equals("00002a19-0000-1000-8000-00805f9b34fb") ||
               uuid.toString().equals("00002a1a-0000-1000-8000-00805f9b34fb") ||
               uuid.toString().equals("00002bed-0000-1000-8000-00805f9b34fb");
    }
    private void enqueue(int id, String action, String charUUID, byte[] payload) {
        main.post(() -> {
            try {
                UUID uuid = normalized(charUUID);
                // This BLE adapter has no API for watch firmware alarms or timers.
                // Only the event/button characteristic and battery values may be read;
                // only the three direct-effect characteristics may be written.
                if ("write".equals(action) && !isStimulus(uuid)) {
                    fail(id, "Only direct watch stimuli can be written"); return;
                }
                if ("read".equals(action) && !isBattery(uuid)) {
                    fail(id, "Only battery data can be read"); return;
                }
                if ("diagnostic-read".equals(action) && !eligibleDiagnosticRead(uuid)) {
                    fail(id, "Diagnostic read unavailable, prohibited, or alarm/timer in progress"); return;
                }
                if ("subscribe".equals(action) && !EVENT_STATUS_UUID.equals(uuid)) {
                    fail(id, "Only watch button events can be subscribed"); return;
                }
                if ("charge-subscribe".equals(action) && !CHARGE_STATUS_UUID.equals(uuid)) {
                    fail(id, "Only watch charging status can be subscribed"); return;
                }
                if ("diagnostic-subscribe".equals(action) &&
                    (owner.alarmEngine().isActive() || owner.timerEngine().isSessionActive() || !eligibleDiagnosticNotify(uuid))) {
                    fail(id, "Diagnostic stream unavailable, prohibited, or a session is active"); return;
                }
                if ("diagnostic-unsubscribe".equals(action) && !diagnosticSubscribed.contains(uuid)) {
                    fail(id, "Diagnostic stream is not subscribed"); return;
                }
                operations.addLast(new Operation(id, action, uuid, payload));
                pump();
            } catch (Exception e) { fail(id, "Unsupported characteristic UUID"); }
        });
    }

    @SuppressLint("MissingPermission")
    private void pump() {
        if (active != null) return;
        if (!connected || gatt == null) {
            while (!operations.isEmpty()) fail(operations.removeFirst().requestId, "Watch disconnected");
            return;
        }
        active = operations.pollFirst();
        if (active == null) return;
        if ("diagnostic-read".equals(active.action) && !eligibleDiagnosticRead(active.characteristic)) {
            completeOperation(false, "Diagnostic interrupted or characteristic unavailable"); return;
        }
        if (("diagnostic-subscribe".equals(active.action) || "diagnostic-unsubscribe".equals(active.action)) &&
            (owner.alarmEngine().isActive() || owner.timerEngine().isSessionActive() ||
             ("diagnostic-subscribe".equals(active.action) && !eligibleDiagnosticNotify(active.characteristic)))) {
            completeOperation(false, "Diagnostic subscription interrupted by an active session or unavailable"); return;
        }
        BluetoothGattCharacteristic c = characteristic(active.characteristic);
        if (c == null) { completeOperation(false, "Characteristic not found"); return; }
        boolean started = false;
        try {
            switch (active.action) {
                case "read":
                case "diagnostic-read":
                    started = gatt.readCharacteristic(c);
                    break;
                case "subscribe":
                case "charge-subscribe":
                case "diagnostic-subscribe":
                case "diagnostic-unsubscribe":
                    final boolean enable = !"diagnostic-unsubscribe".equals(active.action);
                    if (!gatt.setCharacteristicNotification(c, enable)) break;
                    BluetoothGattDescriptor cccd = c.getDescriptor(CCCD);
                    if (cccd == null) {
                        if (!"subscribe".equals(active.action)) {completeOperation(false, "Charge/diagnostic CCCD unavailable");return;}
                        completeOperation(true, "true");return;
                    }
                    byte[] value = !enable ? BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE :
                            ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
                            ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = gatt.writeDescriptor(cccd, value) == BluetoothStatusCodes.SUCCESS;
                    } else {
                        cccd.setValue(value);
                        started = gatt.writeDescriptor(cccd);
                    }
                    break;
                case "write":
                    int type = ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
                            ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                            : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;
                    if (Build.VERSION.SDK_INT >= 33) {
                        started = gatt.writeCharacteristic(c, active.payload, type) == BluetoothStatusCodes.SUCCESS;
                    } else {
                        c.setWriteType(type);
                        c.setValue(active.payload);
                        started = gatt.writeCharacteristic(c);
                    }
                    if (started && type == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) {
                        // Some Android firmware omits onCharacteristicWrite for write-without-response.
                        // A successful enqueue is NOT proof the watch executed this command.
                        final Operation noResponse = active;
                        main.postDelayed(() -> {
                            if (active == noResponse) completeOperation(true, "true");
                        }, 180);
                    }
                    break;
                default:
                    completeOperation(false, "Unknown GATT operation"); return;
            }
        } catch (Exception e) { completeOperation(false, "Android BLE error: " + e.getMessage()); return; }
        if (!started) { completeOperation(false, "Android refused GATT operation"); return; }
        final Operation expected = active;
        operationTimeout = () -> {
            if (active == expected) {
                // Recover the whole BLE connection rather than overlapping stale GATT operations.
                fail(active.requestId, "Bluetooth command timed out; reconnect the watch");
                active = null;
                closeGatt(true);
            }
        };
        main.postDelayed(operationTimeout, BLE_OPERATION_TIMEOUT_MS);
    }
    private void completeOperation(boolean ok, String payload) {
        if (active == null) return;
        Operation finished = active;
        active = null;
        if (operationTimeout != null) main.removeCallbacks(operationTimeout);
        operationTimeout = null;
        if ("charge-subscribe".equals(finished.action)) {
            if (!ok) EventJournal.append(context, "Watch charging status subscription unavailable: " + payload);
        }
        if (ok && "diagnostic-subscribe".equals(finished.action)) diagnosticSubscribed.add(finished.characteristic);
        if (ok && "diagnostic-unsubscribe".equals(finished.action)) diagnosticSubscribed.remove(finished.characteristic);
        if (ok) succeed(finished.requestId, payload);
        else fail(finished.requestId, payload);
        pump();
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            main.post(() -> {
                if (g != gatt) return;
                if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    try {
                        if (!g.discoverServices()) { if (pendingConnect != -1) fail(pendingConnect, "Service discovery did not start"); closeGatt(true); }
                    } catch (Exception e) { if (pendingConnect != -1) fail(pendingConnect, e.getMessage()); closeGatt(true); }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                    if (gattAutoConnect) {
                        // The same GATT client remains registered for background
                        // autoConnect when the peripheral returns to range.
                        passiveLinkLost();
                    } else {
                        // Direct GATT connections cannot recover themselves. Arm
                        // autoConnect NOW in this native callback (before Doze
                        // can defer a Handler retry while the screen is locked).
                        boolean hadLink = connected;
                        String address = currentAddress;
                        closeGatt(false);
                        if (hadLink) {
                            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                                .putLong(DISCONNECTED_AT, System.currentTimeMillis()).apply();
                            EventJournal.append(context, "BLE direct link lost; registering Android automatic GATT immediately");
                            notifyDisconnected();
                            owner.updateMonitorStatus(false);
                        }
                        if (owner.isMonitoring() && permissionsAvailable())
                            startConnect(-2, address);
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                    EventJournal.append(context, "BLE native GATT error: status=" + status +
                            ", newState=" + newState + "; scheduling native re-arm");
                    closeGatt(true);
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            main.post(() -> {
                if (g != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    if (pendingConnect != -1) fail(pendingConnect, "Service discovery failed (" + status + ")");
                    closeGatt(true); return;
                }
                connected = true;
                chargeKnown = false; charging = false;
                nextRetryAt = 0L;
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putLong(CONNECTED_AT, System.currentTimeMillis()).apply();
                EventJournal.append(context, "BLE native CONNECTED (" +
                    (gattAutoConnect ? "automatic background GATT" : "direct connection") +
                    "); watch services discovered; subscriptions requested");
                reconnectDelayMs=7000L;
                owner.updateMonitorStatus(true);
                owner.timerEngine().onLinkChanged(true);
                owner.alarmEngine().onLinkChanged(true);
                // Existing physical button subscription retains first priority.
                enqueue(-3, "subscribe", EVENT_STATUS_UUID.toString(), null);
                // One passive status stream; remains live even when the WebView closes.
                enqueue(-3, "charge-subscribe", CHARGE_STATUS_UUID.toString(), null);
                int id = pendingConnect;
                pendingConnect = -1;
                if (id >= 0) succeed(id, "true");
                if (pendingClientConnect >= 0) { succeed(pendingClientConnect, "true"); pendingClientConnect = -1; }
                js("window.PavDroidTransport._connected();");
            });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] b = c.getValue();
            if (b != null) main.post(() -> { if (g == gatt) notifyCharacteristic(c.getUuid(), b); });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            final byte[] b = value.clone();
            main.post(() -> { if (g == gatt) notifyCharacteristic(c.getUuid(), b); });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            byte[] b = c.getValue();
            finishRead(g, c, b, status);
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) {
            finishRead(g, c, value, status);
        }
        private void finishRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] bytes, int status) {
            final byte[] data = bytes == null ? new byte[0] : bytes.clone();
            main.post(() -> {
                if (g != gatt || active == null || !("read".equals(active.action) || "diagnostic-read".equals(active.action)) || !c.getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, bytesJson(data));
                else completeOperation(false, "Characteristic read failed (" + status + ")");
            });
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            main.post(() -> {
                if (g != gatt || active == null || !"write".equals(active.action) || !c.getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, "true");
                else completeOperation(false, "Characteristic write failed (" + status + ")");
            });
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            main.post(() -> {
                if (g != gatt || active == null ||
                    !("subscribe".equals(active.action) || "charge-subscribe".equals(active.action) || "diagnostic-subscribe".equals(active.action) || "diagnostic-unsubscribe".equals(active.action)) ||
                    !d.getCharacteristic().getUuid().equals(active.characteristic)) return;
                if (status == BluetoothGatt.GATT_SUCCESS) completeOperation(true, "true");
                else completeOperation(false, "Notification subscription failed (" + status + ")");
            });
        }
    };

    void close() {
        main.post(() -> {
            disposed = true;
            if (reconnectTask != null) main.removeCallbacks(reconnectTask);
            reconnectTask = null;
            stopScanning();
            closeGatt(false);
        });
    }
}
