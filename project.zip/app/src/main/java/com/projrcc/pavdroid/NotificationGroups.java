package com.projrcc.pavdroid;

import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.Context;

/** Android Settings-only grouping for existing notification channels.
 * Grouping keeps Alarm & Timer and Connections notification preferences separated.
 */
final class NotificationGroups {
    static final String CONNECTIONS = "pavlok_group_connections";
    static final String ALARM_TIMER = "pavlok_group_alarm_timer_v116";
    static final String ALARM = ALARM_TIMER;
    static final String TIMER = ALARM_TIMER;
    static final String SNOOZE_CHANNEL = "pavdroid_snooze_countdown_v116";
    private NotificationGroups() { }
    static void ensure(Context context, NotificationManager manager) {
        if (manager == null) return;
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CONNECTIONS, "Connections"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(ALARM_TIMER, "Alarm & Timer"));
        android.app.NotificationChannel snooze = new android.app.NotificationChannel(
                SNOOZE_CHANNEL,"Snooze Countdown",NotificationManager.IMPORTANCE_LOW);
        snooze.setGroup(ALARM_TIMER);
        snooze.setDescription("Silent countdown after snoozing an alarm or timer");
        snooze.setSound(null,null);
        snooze.enableVibration(false);
        manager.createNotificationChannel(snooze);
        

    }
}
