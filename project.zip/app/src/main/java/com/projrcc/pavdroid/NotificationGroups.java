package com.projrcc.pavdroid;

import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.Context;
import android.util.Log;

/** Android Settings-only grouping for existing notification channels.
 * Grouping keeps Alarm & Timer and Connections notification preferences separated.
 */
final class NotificationGroups {
    static final String CONNECTIONS = "pavlok_group_connections";
    static final String ALARM_TIMER = "pavlok_group_alarm_timer_v116";
    static final String ALARM = ALARM_TIMER;
    static final String TIMER = ALARM_TIMER;
    static final String SNOOZE_CHANNEL = "pavdroid_snooze_countdown_v116";
    private NotificationGroups() { }

    /** Retire only the three channel IDs used by the pre-2.0.9 refresh releases.
     * Called after current channels are registered; no current channel is reset.
     * Idempotent on new installs and repeat service starts.
     */
    static void removeRetiredDuplicates(NotificationManager manager) {
        if (manager == null) return;
        removeRetired(manager, "pavdroid_active_alarm", "pavdroid_active_alarm_v209");
        removeRetired(manager, "pavlok_timer_finished_v218", "pavlok_timer_finished_v209");
        removeRetired(manager, "pavlok_timer_progress_v218", "pavlok_timer_progress_v209");
    }

    private static void removeRetired(NotificationManager manager, String retired, String current) {
        try {
            if (manager.getNotificationChannel(current) != null
                    && manager.getNotificationChannel(retired) != null) {
                manager.deleteNotificationChannel(retired);
            }
        } catch (RuntimeException ex) {
            // Notification settings cleanup must never prevent alarm/service startup.
            Log.w("PavDroid", "Could not retire notification channel " + retired, ex);
        }
    }

    static void ensure(Context context, NotificationManager manager) {
        if (manager == null) return;
        manager.createNotificationChannelGroup(new NotificationChannelGroup(CONNECTIONS, "Connections"));
        manager.createNotificationChannelGroup(new NotificationChannelGroup(ALARM_TIMER, "Alarm & Timer"));
        android.app.NotificationChannel snooze = new android.app.NotificationChannel(
                SNOOZE_CHANNEL,"Snooze Countdown",NotificationManager.IMPORTANCE_LOW);
        snooze.setGroup(ALARM_TIMER);
        snooze.setDescription("Silent countdown after snoozing an alarm or timer");
        snooze.setSound(null,null);
        snooze.enableVibration(false);
        manager.createNotificationChannel(snooze);
        

    }
}
