package com.projrcc.pavdroid;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

/** Schedules saved alarms after a device reboot even before the BLE service has started. */
final class PavDroidAlarmSchedule {
    static void rearm(Context context){
        SharedPreferences p=context.getSharedPreferences("pavdroid_android_alarms_v1",Context.MODE_PRIVATE);
        try{
            JSONArray saved=new JSONArray(p.getString("alarms","[]"));long now=System.currentTimeMillis();long nearest=Long.MAX_VALUE;
            for(int i=0;i<saved.length();i++){
                JSONObject a=saved.getJSONObject(i);if(!a.optBoolean("enabled",true))continue;
                String[] hm=a.optString("time","07:00").split(":");
                int hour=Integer.parseInt(hm[0]),minute=Integer.parseInt(hm[1]);
                int mask=a.optInt("days",0)&127;
                Calendar c=Calendar.getInstance();c.setTimeInMillis(now);c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
                for(int x=0;x<8;x++){if(x>0)c.add(Calendar.DAY_OF_MONTH,1);int bit=1<<(c.get(Calendar.DAY_OF_WEEK)-1);
                    if(c.getTimeInMillis()>now+900 && (mask==0 || (mask&bit)!=0)) {nearest=Math.min(nearest,c.getTimeInMillis());break;}}
            }
            AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if(alarm==null)return;
            // On reboot, cancel the old schedule and carry its exact due time
            // in the new broadcast. Never add a special pre-alarm BLE window.
            Intent intent=new Intent(context,PavDroidReceiver.class).setAction(PavDroidAlarmEngine.ACTION_WAKE);
            PendingIntent old=PendingIntent.getBroadcast(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            alarm.cancel(old);
            PavDroidUpcomingNotifications.rearm(context);
            if(nearest==Long.MAX_VALUE)return;
            if(Build.VERSION.SDK_INT>=31&&!alarm.canScheduleExactAlarms()){
                EventJournal.append(context,"Reboot: exact alarm access required for PavDroid");return;
            }
            PendingIntent open=PendingIntent.getActivity(context,39082,new Intent(context,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            intent.putExtra("scheduled_due", nearest);
            PendingIntent receiver=PendingIntent.getBroadcast(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            alarm.setAlarmClock(new AlarmManager.AlarmClockInfo(nearest,open),receiver);
        }catch(Exception e){EventJournal.append(context,"PavDroid reboot scheduling error: "+e.getMessage());}
    }
}
