package com.projrcc.pavdroid;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.net.Uri;
import org.json.JSONObject;
import org.json.JSONArray;

/** User-selected persistent URI, looping only until the owner stops its session. */
final class PavDroidAudio {
    private final Context context;
    private MediaPlayer player;
    private AudioManager volume;
    private int previousMediaVolume = -1;
    private String lastPlaybackVolume = "";
    PavDroidAudio(Context context){this.context=context.getApplicationContext();}
    static String selectedUri(Context context, String configuredForSession) {
        android.content.SharedPreferences pref=context.getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE);
        String selected=pref.getString("selectedUri", "");
        // Music now lives in one shared Settings library. Keep per-session URIs
        // only as a compatibility fallback for migrated V2.0.9 alarms.
        if(selected!=null&&!selected.isEmpty())return selected;
        return configuredForSession==null?"":configuredForSession;
    }
    static int musicSetting(Context context,String key,int fallback){
        try {
            String json=context.getSharedPreferences("pavdroid_music_library",Context.MODE_PRIVATE).getString("musicPlaylist","{}");
            JSONObject music=new JSONObject(json).optJSONObject("playback");
            if(music!=null&&music.has(key))return music.optInt(key,fallback);
        } catch(Exception ignored) {}
        return fallback;
    }
    static String rotatedUri(Context context,String configured,int snoozes){
        android.content.SharedPreferences pref=context.getSharedPreferences("pavdroid_music_library",Context.MODE_PRIVATE);
        try{
            JSONObject settings=new JSONObject(pref.getString("musicPlaylist","{}"));
            if(!settings.optBoolean("rotate",false))return selectedUri(context,configured);
            JSONArray tracks=settings.optJSONArray("tracks");if(tracks==null)return selectedUri(context,configured);
            java.util.ArrayList<String> choices=new java.util.ArrayList<>();
            // User Added tracks first, then built-in sounds, in their chosen order.
            for(int group=0;group<2;group++)for(int i=0;i<tracks.length();i++){
                JSONObject t=tracks.optJSONObject(i);if(t==null||!t.optBoolean("enabled",true))continue;
                boolean builtin="builtin".equals(t.optString("source","user"));if(builtin!=(group==1))continue;
                String uri=t.optString("uri","");if(!uri.isEmpty())choices.add(uri);
            }
            if(!choices.isEmpty())return choices.get(Math.max(0,snoozes)%choices.size());
        }catch(Exception e){EventJournal.append(context,"Music rotation lookup unavailable: "+e.getMessage());}
        return selectedUri(context,configured);
    }
    static int timerVolume(Context context){
        return Math.max(10,Math.min(100,context.getSharedPreferences("pavdroid_music_library", Context.MODE_PRIVATE)
            .getInt("timerVolume",100)));
    }
    String playbackVolumeDetails(){ return lastPlaybackVolume; }
    private static String describeVolume(AudioManager manager,int stream,int requested){
        if(manager==null)return "Media volume unavailable";
        int actual=manager.getStreamVolume(stream);
        int maximum=Math.max(1,manager.getStreamMaxVolume(stream));
        return "Media requested "+requested+"%, Android "+Math.round(actual*100f/maximum)+"% ("+actual+"/"+maximum+")";
    }
    boolean start(String uri){ return start(uri, 100); }
    boolean start(String uri, int percent){
        if(player!=null)return true;
        if(uri==null || uri.isEmpty())return false;
        try{
            volume=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(volume!=null && previousMediaVolume<0){
                previousMediaVolume=volume.getStreamVolume(AudioManager.STREAM_MUSIC);
                int max=Math.max(1,volume.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
                int target=Math.max(1,Math.min(max,Math.round(max*Math.max(10,Math.min(100,percent))/100f)));
                volume.setStreamVolume(AudioManager.STREAM_MUSIC,target,0);
                lastPlaybackVolume=describeVolume(volume,AudioManager.STREAM_MUSIC,percent);
                EventJournal.append(context,"PavDroid music: "+lastPlaybackVolume);
            }else if(volume==null)lastPlaybackVolume="Media volume unavailable";
            MediaPlayer m=new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(context,Uri.parse(uri));m.setLooping(true);
            // Media stream matches Android's visible Media slider, not the hidden Alarm stream.
            m.setVolume(1f,1f);m.prepare();m.start();player=m;
            EventJournal.append(context,"PavDroid MP3 playback started · "+lastPlaybackVolume);return true;
        }catch(Exception e){EventJournal.append(context,"PavDroid MP3 playback failed: "+e.getMessage());stop();return false;}
    }
    /** Change the running player's Android Media stream level; keep the original level for Stop. */
    String adjustVolume(int percent) {
        if(player==null || volume==null)return "Media playback not active";
        int requested=Math.max(10,Math.min(100,percent));
        try {
            int max=Math.max(1,volume.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            int target=Math.max(1,Math.min(max,Math.round(max*requested/100f)));
            volume.setStreamVolume(AudioManager.STREAM_MUSIC,target,0);
            lastPlaybackVolume=describeVolume(volume,AudioManager.STREAM_MUSIC,requested);
            EventJournal.append(context,"PavDroid music level: "+lastPlaybackVolume);
            return lastPlaybackVolume;
        } catch(Exception e) {
            EventJournal.append(context,"PavDroid music level change failed: "+e.getMessage());
            return "Media level change failed";
        }
    }
    void stop(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}
        if(volume!=null&&previousMediaVolume>=0){
            try{
                int prior=previousMediaVolume;
                volume.setStreamVolume(AudioManager.STREAM_MUSIC,prior,0);
                int actual=volume.getStreamVolume(AudioManager.STREAM_MUSIC);
                EventJournal.append(context,"PavDroid restored Media volume to "+actual+"/"+Math.max(1,volume.getStreamMaxVolume(AudioManager.STREAM_MUSIC)));
            }catch(Exception e){EventJournal.append(context,"PavDroid Media volume restore unavailable: "+e.getMessage());}
            previousMediaVolume=-1;
        }
        volume=null;
    }
}
