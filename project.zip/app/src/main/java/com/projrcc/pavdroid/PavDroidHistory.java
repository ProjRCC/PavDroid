package com.projrcc.pavdroid;

import android.content.Context;
import org.json.JSONObject;

/** Stable, parseable session transitions in the existing separate History archive.
 * Never infer a session from firmware telemetry or from a BLE command enqueue. */
final class PavDroidHistory {
    private PavDroidHistory() {}
    static void record(Context context, String type, long session, String state, String label, String detail) {
        if (session <= 0) return;
        try {
            JSONObject item = new JSONObject();
            item.put("type", type).put("session", session).put("state", state)
                .put("label", label == null ? "" : label)
                .put("detail", detail == null ? "" : detail);
            EventJournal.append(context, "PDH|" + item.toString());
        } catch (Exception ignored) { }
    }
}
