package com.projrcc.pavdroid;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** A phone-only, optional spoken Snooze acknowledgment. Does not affect BLE stimuli or Snooze timing. */
final class PavDroidSpeech {
    private static final String PREF = "pavdroid_time_readout_v1";
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech engine;
    private boolean ready;
    private boolean initializing;
    private String pendingText;
    private int pendingVolume;
    private AudioManager audio;
    private int previousMediaVolume = -1;
    private int generation;

    PavDroidSpeech(Context context) { this.context=context.getApplicationContext(); }

    static void saveSettings(Context context, int start, int increase) {
        int beginning = clamp10(start);
        int step = Math.max(0,Math.min(50,increase));
        step=Math.min(step,100-beginning);
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putInt("start",beginning).putInt("increase",step).apply();
    }
    private static int clamp10(int value) { return Math.max(10,Math.min(100,value)); }

    private static String ordinal(int number) {
        String[] first = {"", "First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth",
                "Tenth", "Eleventh", "Twelfth", "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth", "Eighteenth", "Nineteenth"};
        if(number>0 && number<first.length)return first[number];
        String[] tens={"", "", "Twentieth", "Thirtieth", "Fortieth", "Fiftieth", "Sixtieth", "Seventieth", "Eightieth", "Ninetieth"};
        String[] prefix={"", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
        if(number>=20 && number<100){int t=number/10,u=number%10;return u==0?tens[t]:prefix[t]+"-"+first[u].toLowerCase(Locale.US);}
        return "Snooze " + number;
    }

    /** Call only AFTER the existing MP3 has stopped and AFTER a real Snooze was accepted. */
    void onSnooze(boolean enabled, int snoozeCount) {
        if(!enabled || snoozeCount<1)return;
        SharedPreferences p=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        int start=clamp10(p.getInt("start",20));
        int rise=Math.max(0,Math.min(100-start,p.getInt("increase",10)));
        int volume=Math.min(100,start+Math.max(0,snoozeCount-1)*rise);
        String time=new SimpleDateFormat("h:mm a",Locale.US).format(new Date(System.currentTimeMillis()));
        String text=ordinal(snoozeCount)+" snooze. "+time+".";
        main.post(()->enqueue(text,volume));
    }

    private void enqueue(String text, int volume) {
        cancelInternal();
        pendingText=text;pendingVolume=volume;
        if(ready && engine!=null){speakPending();return;}
        if(initializing)return;
        initializing=true;
        try {
            engine=new TextToSpeech(context,status->main.post(()->{
                initializing=false;
                if(status==TextToSpeech.SUCCESS && engine!=null){
                    ready=true;
                    engine.setLanguage(Locale.US);
                    engine.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    engine.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                        @Override public void onStart(String id) {}
                        @Override public void onDone(String id) { main.post(()->finished(id)); }
                        @Override public void onError(String id) { main.post(()->finished(id)); }
                    });
                    speakPending();
                } else {
                    EventJournal.append(context,"Time Readout unavailable: Android Text-to-Speech engine did not initialize");
                    pendingText=null;
                    if(engine!=null){engine.shutdown();engine=null;}
                }
            }));
        } catch(RuntimeException error){
            initializing=false;pendingText=null;
            EventJournal.append(context,"Time Readout failed to initialize: "+error.getMessage());
        }
    }

    private void speakPending() {
        if(pendingText==null || engine==null || !ready)return;
        String text=pendingText;int volume=pendingVolume;pendingText=null;
        String id="pavdroid-snooze-"+(++generation);
        try {
            audio=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(audio!=null){
                previousMediaVolume=audio.getStreamVolume(AudioManager.STREAM_MUSIC);
                int max=Math.max(1,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,
                        Math.max(1,Math.min(max,Math.round(max*volume/100f))),0);
            }
            int status=engine.speak(text,TextToSpeech.QUEUE_FLUSH,null,id);
            if(status!=TextToSpeech.SUCCESS){restoreVolume();EventJournal.append(context,"Time Readout speech request failed");}
            else EventJournal.append(context,"Time Readout: "+text+" · requested Media "+volume+"%");
        } catch(RuntimeException error){
            restoreVolume();EventJournal.append(context,"Time Readout playback failed: "+error.getMessage());
        }
    }
    private void finished(String id) {
        if(id.equals("pavdroid-snooze-"+generation))restoreVolume();
    }
    private void restoreVolume() {
        if(audio!=null && previousMediaVolume>=0){
            try{audio.setStreamVolume(AudioManager.STREAM_MUSIC,previousMediaVolume,0);}catch(RuntimeException ignored){}
        }
        previousMediaVolume=-1;audio=null;
    }
    private void cancelInternal() {
        generation++;
        pendingText=null;
        if(engine!=null && ready)try{engine.stop();}catch(RuntimeException ignored){}
        restoreVolume();
    }
    void cancel() { main.post(this::cancelInternal); }
    void close() { main.post(()->{cancelInternal();if(engine!=null){engine.shutdown();engine=null;}ready=false;initializing=false;}); }
}
