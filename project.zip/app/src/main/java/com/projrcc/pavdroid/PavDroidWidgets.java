package com.projrcc.pavdroid;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.content.res.Configuration;
import android.util.SizeF;
import java.util.LinkedHashMap;
import java.util.Map;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Launcher presentation only. All session mutations use the existing service engines. */
public final class PavDroidWidgets {
    static final String ACTION_SERVICE="com.projrcc.pavdroid.WIDGET_COMMAND";
    private static final String ACTION_CLICK="com.projrcc.pavdroid.WIDGET_CLICK";
    private static final int NORMAL=0xffafbed1, BLUE=0xff89b9ef, AMBER=0xffd9a33d;
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static boolean queued;
    private static String lastSignature="";
    private static SharedPreferences alarmPrefs(Context c){return c.getSharedPreferences("pavdroid_android_alarms_v1",Context.MODE_PRIVATE);}
    private static SharedPreferences timerPrefs(Context c){return c.getSharedPreferences("pd2_native_timer_v1",Context.MODE_PRIVATE);}
    private static JSONObject json(String raw){try{return new JSONObject(raw);}catch(Exception e){return new JSONObject();}}
    private static JSONObject alarmSession(Context c){return json(alarmPrefs(c).getString("session","{}"));}
    private static String timerPhase(Context c){return timerPrefs(c).getString("phase","ready");}
    private static String alarmPhase(Context c){return alarmSession(c).optString("phase","ready");}
    private static boolean idle(Context c){return "ready".equals(timerPhase(c))&&"ready".equals(alarmPhase(c));}
    private static final class Next {
        int index=-1; long due=Long.MAX_VALUE; JSONObject alarm;
        Next(Context c){try{JSONArray list=new JSONArray(alarmPrefs(c).getString("alarms","[]"));long now=System.currentTimeMillis();
            for(int i=0;i<list.length();i++){JSONObject a=list.optJSONObject(i);if(a==null||!a.optBoolean("enabled",true))continue;
                long n=PavDroidAlarmSchedule.nextOccurrence(a,now);if(n<due){index=i;due=n;alarm=a;}}
        }catch(Exception ignored){}}
    }
    public static final class Alarm extends Provider { public Alarm(){super(R.layout.widget_alarm,true,false);} }
    public static final class Timer extends Provider { public Timer(){super(R.layout.widget_timer,false,true);} }
    public static final class Combined extends Provider { public Combined(){super(R.layout.widget_combined,true,true);} }
    public static final class Expanded extends Provider { public Expanded(){super(R.layout.widget_combined_expanded,true,true);} }
    public abstract static class Provider extends AppWidgetProvider {
        final int layout;final boolean alarm,timer;
        Provider(int layout,boolean alarm,boolean timer){this.layout=layout;this.alarm=alarm;this.timer=timer;}
        @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id,layout,alarm,timer);}
        @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){render(c,m,id,layout,alarm,timer);}
        @Override public void onEnabled(Context c){refresh(c);}
    }
    static void refresh(Context context){Context c=context.getApplicationContext();MAIN.post(()->{
        if(queued)return;queued=true;MAIN.postDelayed(()->{queued=false;try{updateAll(c);}catch(Exception e){EventJournal.append(c,"Widget refresh failed: "+e.getMessage());}},100);
    });}
    private static void updateAll(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        int[] a=m.getAppWidgetIds(new ComponentName(c,Alarm.class)),t=m.getAppWidgetIds(new ComponentName(c,Timer.class)),b=m.getAppWidgetIds(new ComponentName(c,Combined.class)),e=m.getAppWidgetIds(new ComponentName(c,Expanded.class));
        if(a.length+t.length+b.length+e.length==0){lastSignature="";return;}
        JSONObject as=alarmSession(c);SharedPreferences ts=timerPrefs(c);Next n=new Next(c);
        String key=as.optString("phase")+"|"+as.optString("name")+"|"+as.optLong("startedAt")+"|"+as.optLong("snoozeUntil")+"|"+as.optInt("snoozes")+"|"+n.index+"|"+n.due+"|"+n.alarm+"|"+ts.getString("phase","ready")+"|"+ts.getLong("deadline",0)+"|"+ts.getInt("remaining",0)+"|"+ts.getLong("sessionId",0)+"|"+WidgetTimerConfig.read(c)+"|"+java.util.Arrays.toString(a)+java.util.Arrays.toString(t)+java.util.Arrays.toString(b)+java.util.Arrays.toString(e);
        if(key.equals(lastSignature))return;lastSignature=key;
        for(int id:a)render(c,m,id,R.layout.widget_alarm,true,false);
        for(int id:t)render(c,m,id,R.layout.widget_timer,false,true);
        for(int id:b)render(c,m,id,R.layout.widget_combined,true,true);
        for(int id:e)render(c,m,id,R.layout.widget_combined_expanded,true,true);
    }
    private static PendingIntent open(Context c,int id,String route,Next n){
        Intent i=new Intent(c,MainActivity.class).setAction("com.projrcc.pavdroid.WIDGET_OPEN").setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .setData(Uri.parse("pavdroid://widget/"+id+"/open/"+route)).putExtra("widget_route",route);
        if(n!=null&&n.alarm!=null)i.putExtra("widget_alarm_index",n.index).putExtra("widget_alarm_expected",n.alarm.toString());
        return PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent click(Context c,int id,String cmd,String phase,long session){
        int round="snoozing".equals(phase)?(cmd.startsWith("alarm_")?alarmSession(c).optInt("snoozes"):timerPrefs(c).getInt("snoozes",0)):-1;
        Intent i=new Intent(c,Commands.class).setAction(ACTION_CLICK).setData(Uri.parse("pavdroid://widget/"+id+"/"+cmd+"/"+phase+"/"+session+"/"+round))
            .putExtra("command",cmd).putExtra("phase",phase).putExtra("session",session).putExtra("snooze_round",round);
        return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void button(RemoteViews v,int view,String text,PendingIntent action,boolean primary){
        v.setViewVisibility(view,View.VISIBLE);v.setTextViewText(view,text);v.setTextColor(view,primary?0xff101c2d:0xffedf4ff);
        v.setInt(view,"setBackgroundResource",primary?R.drawable.widget_primary:R.drawable.widget_button);v.setOnClickPendingIntent(view,action);
    }
    private static void value(RemoteViews v,int text,int chrono,String display,long due){
        boolean live=due>System.currentTimeMillis();v.setViewVisibility(text,live?View.GONE:View.VISIBLE);v.setViewVisibility(chrono,live?View.VISIBLE:View.GONE);
        v.setTextViewText(text,display);v.setChronometerCountDown(chrono,true);
        v.setChronometer(chrono,SystemClock.elapsedRealtime()+Math.max(0,due-System.currentTimeMillis()),null,live);
    }
    private static String time(int n){return String.format(Locale.US,"%d:%02d",Math.max(0,n)/60,Math.max(0,n)%60);}
    private static void render(Context c,AppWidgetManager m,int id,int layout,boolean hasAlarm,boolean hasTimer){
        boolean single=hasAlarm!=hasTimer;
        boolean expanded=layout==R.layout.widget_combined_expanded;
        if(Build.VERSION.SDK_INT>=31){
            // The launcher chooses the layout that fits its actual size, including rotation.
            Map<SizeF,RemoteViews> variants=new LinkedHashMap<>();
            if(single){
                variants.put(new SizeF(1,1),build(c,id,layout,hasAlarm,hasTimer));
                variants.put(new SizeF(1,66),build(c,id,hasAlarm?R.layout.widget_alarm_roomy:R.layout.widget_timer_roomy,hasAlarm,hasTimer));
                variants.put(new SizeF(1,100),build(c,id,hasAlarm?R.layout.widget_alarm_large_fit:R.layout.widget_timer_large_fit,hasAlarm,hasTimer));
                variants.put(new SizeF(1,118),build(c,id,hasAlarm?R.layout.widget_alarm_large:R.layout.widget_timer_large,hasAlarm,hasTimer));
            }else if(expanded){
                variants.put(new SizeF(1,1),build(c,id,R.layout.widget_combined_expanded_fit,true,true));
                variants.put(new SizeF(1,228),build(c,id,R.layout.widget_combined_expanded,true,true));
            }else{
                variants.put(new SizeF(1,1),build(c,id,R.layout.widget_combined_compact,true,true));
                variants.put(new SizeF(1,150),build(c,id,R.layout.widget_combined_medium,true,true));
                variants.put(new SizeF(1,180),build(c,id,R.layout.widget_combined,true,true));
            }
            m.updateAppWidget(id,new RemoteViews(variants));
        }else{
            Bundle options=m.getAppWidgetOptions(id);
            boolean portrait=c.getResources().getConfiguration().orientation!=Configuration.ORIENTATION_LANDSCAPE;
            int height=options.getInt(portrait?AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT:AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,56);
            if(single){if(height>=118)layout=hasAlarm?R.layout.widget_alarm_large:R.layout.widget_timer_large;
                else if(height>=100)layout=hasAlarm?R.layout.widget_alarm_large_fit:R.layout.widget_timer_large_fit;
                else if(height>=66)layout=hasAlarm?R.layout.widget_alarm_roomy:R.layout.widget_timer_roomy;}
            else if(expanded)layout=height>=228?R.layout.widget_combined_expanded:R.layout.widget_combined_expanded_fit;
            else if(height<180)layout=height>=150?R.layout.widget_combined_medium:R.layout.widget_combined_compact;
            m.updateAppWidget(id,build(c,id,layout,hasAlarm,hasTimer));
        }
    }
    private static void disabled(RemoteViews v,int icon,int disabledIcon,int[] labels,int[] buttons,int[] containers){
        v.setImageViewResource(icon,disabledIcon);
        v.setOnClickPendingIntent(icon,null);
        v.setBoolean(icon,"setEnabled",false);
        for(int view:labels){v.setTextColor(view,0xff828b97);v.setOnClickPendingIntent(view,null);v.setBoolean(view,"setEnabled",false);}
        for(int view:buttons){v.setTextColor(view,0xff828b97);v.setInt(view,"setBackgroundResource",R.drawable.widget_button_disabled);v.setOnClickPendingIntent(view,null);v.setBoolean(view,"setEnabled",false);}
        for(int view:containers){v.setOnClickPendingIntent(view,null);v.setBoolean(view,"setEnabled",false);}
    }
    private static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    private static RemoteViews build(Context c,int id,int layout,boolean hasAlarm,boolean hasTimer){
        boolean single=hasAlarm!=hasTimer;
        RemoteViews v=new RemoteViews(c.getPackageName(),layout);
        // At narrow widths with enlarged system text, the section icon already identifies
        // the session type. Use the state alone instead of truncating the state name.
        boolean compactCombined=layout==R.layout.widget_combined||layout==R.layout.widget_combined_medium||layout==R.layout.widget_combined_compact;
        int minWidth=AppWidgetManager.getInstance(c).getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,250);
        boolean shortState=compactCombined&&minWidth<280&&c.getResources().getConfiguration().fontScale>=1.2f;

        boolean alarmBusy=!"ready".equals(alarmPhase(c)),timerBusy=!"ready".equals(timerPhase(c));
        int alarmBorder=R.drawable.widget_bg,timerBorder=R.drawable.widget_bg;
        if(hasAlarm){JSONObject s=alarmSession(c);String phase=s.optString("phase","ready");long session=s.optLong("startedAt",0);Next n=new Next(c);
            boolean firing="firing".equals(phase),snoozing="snoozing".equals(phase);boolean active=firing||snoozing;
            v.setTextViewText(R.id.wa_title,snoozing?(shortState?"Snoozing":"Alarm · Snoozing"):active?"Alarm":n.alarm==null?"No alarm":"Upcoming Alarm");v.setTextColor(R.id.wa_title,firing?BLUE:snoozing?AMBER:NORMAL);
            String display=active?(firing?"Activated":"0:00"):n.alarm==null?"—":new SimpleDateFormat("EEE · h:mm a",Locale.US).format(new Date(n.due));
            value(v,R.id.wa_value,R.id.wa_chrono,display,snoozing?s.optLong("snoozeUntil",0):0);
            PendingIntent alarmPage=open(c,id,"alarms",null);
            v.setOnClickPendingIntent(R.id.wa_root,active?null:alarmPage);
            v.setInt(R.id.wa_title,"setMaxLines",active?1:2);
            for(int view:new int[]{R.id.wa_info,R.id.wa_icon,R.id.wa_title,R.id.wa_value,R.id.wa_chrono})v.setOnClickPendingIntent(view,alarmPage);
            if(active)alarmBorder=firing?R.drawable.widget_bg_active:R.drawable.widget_bg_snoozing;
            v.setTextColor(R.id.wa_value,active?(firing?BLUE:AMBER):0xffedf4ff);v.setTextColor(R.id.wa_chrono,AMBER);
            v.setViewVisibility(R.id.wa_middle,View.GONE);
            if(active){
                button(v,R.id.wa_first,"STOP",click(c,id,"alarm_stop",phase,session),false);
                if(snoozing){button(v,R.id.wa_middle,"+1 min",click(c,id,"alarm_add_minute",phase,session),false);v.setViewVisibility(R.id.wa_second,View.GONE);}
                else button(v,R.id.wa_second,s.optBoolean("music")?"Snooze / Mute":"Snooze",click(c,id,"alarm_snooze",phase,session),false);
            }else{
                button(v,R.id.wa_first,"+ New alarm",open(c,id,"new_alarm",null),false);
                if(n.alarm!=null)button(v,R.id.wa_second,"Edit alarm",open(c,id,"edit_alarm",n),false);else v.setViewVisibility(R.id.wa_second,View.INVISIBLE);
            }
        }
        if(hasTimer){SharedPreferences p=timerPrefs(c);String phase=p.getString("phase","ready");long session=p.getLong("sessionId",0);boolean ready="ready".equals(phase),running="countdown".equals(phase),paused="paused".equals(phase),snooze="snoozing".equals(phase),expired="alerting".equals(phase);JSONObject cfg=WidgetTimerConfig.read(c);
            int sec=ready?cfg.optInt("seconds",0):p.getInt("remaining",0);long due=running||snooze?p.getLong("deadline",0):0;
            v.setTextViewText(R.id.wt_title,ready?"Timer":running?(shortState?"Running":"Timer · Running"):paused?(shortState?"Paused":"Timer · Paused"):snooze?(shortState?"Snoozing":"Timer · Snoozing"):"Time Expired");v.setTextColor(R.id.wt_title,snooze?AMBER:expired?BLUE:NORMAL);
            value(v,R.id.wt_value,R.id.wt_chrono,expired?"":ready&&sec==0?"—":time(sec),due);
            if(expired){v.setViewVisibility(R.id.wt_value,View.GONE);v.setViewVisibility(R.id.wt_chrono,View.GONE);}
            v.setViewVisibility(R.id.wt_minus,ready?View.VISIBLE:View.GONE);v.setViewVisibility(R.id.wt_plus,ready?View.VISIBLE:View.GONE);
            v.setOnClickPendingIntent(R.id.wt_minus,click(c,id,"minus","ready",0));v.setOnClickPendingIntent(R.id.wt_plus,click(c,id,"plus","ready",0));
            PendingIntent timerPage=open(c,id,"timer",null);
            v.setOnClickPendingIntent(R.id.wt_root,ready?timerPage:null);
            for(int view:new int[]{R.id.wt_info,R.id.wt_value,R.id.wt_chrono,R.id.wt_title,R.id.wt_icon})v.setOnClickPendingIntent(view,timerPage);
            if(snooze||expired)timerBorder=snooze?R.drawable.widget_bg_snoozing:R.drawable.widget_bg_active;
            v.setTextColor(R.id.wt_value,snooze?AMBER:expired?BLUE:0xffedf4ff);v.setTextColor(R.id.wt_chrono,snooze?AMBER:expired?BLUE:0xffedf4ff);
            v.setViewVisibility(R.id.wt_middle,View.GONE);
            if(ready){button(v,R.id.wt_first,"Edit timer",timerPage,false);button(v,R.id.wt_second,"Start timer",click(c,id,"timer_start",phase,WidgetTimerConfig.revision(c)),true);}
            else{
                button(v,R.id.wt_first,"STOP",click(c,id,"timer_reset",phase,session),false);
                if(running||paused||snooze)button(v,R.id.wt_middle,"+1 min",click(c,id,snooze?"timer_snooze_add_minute":"timer_add_minute",phase,session),false);
                if(snooze)v.setViewVisibility(R.id.wt_second,View.GONE);
                else button(v,R.id.wt_second,running?"Pause":paused?"Resume":"Snooze",click(c,id,running?"timer_pause":paused?"timer_resume":"timer_snooze",phase,session),false);
            }
        }
        if(hasAlarm){
            boolean blocked=timerBusy&&!alarmBusy;
            int icon=R.id.wa_icon;
            v.setImageViewResource(icon,R.drawable.widget_icon_alarm);
            for(int view:new int[]{icon,R.id.wa_title,R.id.wa_value,R.id.wa_chrono,R.id.wa_first,R.id.wa_middle,R.id.wa_second,R.id.wa_info,R.id.wa_root})v.setBoolean(view,"setEnabled",true);
            if(blocked)disabled(v,icon,R.drawable.widget_icon_alarm_disabled,new int[]{R.id.wa_title,R.id.wa_value,R.id.wa_chrono},new int[]{R.id.wa_first,R.id.wa_middle,R.id.wa_second},new int[]{R.id.wa_info,R.id.wa_root});
            v.setInt(R.id.wa_root,"setBackgroundResource",single?alarmBorder:android.R.color.transparent);
            int pad=single&&(layout==R.layout.widget_alarm_large||layout==R.layout.widget_alarm_large_fit)?dp(c,6):0;
            v.setViewPadding(R.id.wa_root,0,pad,0,pad);
        }
        if(hasTimer){
            boolean blocked=alarmBusy&&!timerBusy;
            int icon=R.id.wt_icon;
            v.setImageViewResource(icon,R.drawable.widget_icon_timer);
            for(int view:new int[]{icon,R.id.wt_title,R.id.wt_value,R.id.wt_chrono,R.id.wt_first,R.id.wt_middle,R.id.wt_second,R.id.wt_minus,R.id.wt_plus,R.id.wt_info,R.id.wt_root})v.setBoolean(view,"setEnabled",true);
            for(int view:new int[]{R.id.wt_minus,R.id.wt_plus}){v.setTextColor(view,0xffedf4ff);v.setInt(view,"setBackgroundResource",R.drawable.widget_button);}
            if(blocked)disabled(v,icon,R.drawable.widget_icon_timer_disabled,new int[]{R.id.wt_title,R.id.wt_value,R.id.wt_chrono},new int[]{R.id.wt_first,R.id.wt_middle,R.id.wt_second,R.id.wt_minus,R.id.wt_plus},new int[]{R.id.wt_info,R.id.wt_root});
            v.setInt(R.id.wt_root,"setBackgroundResource",single?timerBorder:android.R.color.transparent);
            int pad=single&&(layout==R.layout.widget_timer_large||layout==R.layout.widget_timer_large_fit)?dp(c,6):0;
            v.setViewPadding(R.id.wt_root,0,pad,0,pad);
        }
        if(!single){
            // Draw the status stroke on the actual outer widget shape, not on the inner sections.
            // Snoozing takes precedence if an inconsistent restored snapshot contains both states.
            int combinedBorder=(alarmBorder==R.drawable.widget_bg_snoozing||timerBorder==R.drawable.widget_bg_snoozing)
                ?R.drawable.widget_bg_snoozing:(alarmBorder==R.drawable.widget_bg_active||timerBorder==R.drawable.widget_bg_active)
                ?R.drawable.widget_bg_active:R.drawable.widget_bg;
            v.setInt(R.id.wc_root,"setBackgroundResource",combinedBorder);
            int outerPad=layout==R.layout.widget_combined?8:layout==R.layout.widget_combined_medium?6:layout==R.layout.widget_combined_compact?4:3;
            v.setViewPadding(R.id.wc_root,0,dp(c,outerPad),0,dp(c,outerPad));
        }
        if(layout==R.layout.widget_combined_expanded||layout==R.layout.widget_combined_expanded_fit){
            nav(v,c,id,R.id.wn_home_cell,R.id.wn_home,R.id.wn_home_label,"home",false,R.drawable.widget_icon_home,R.drawable.widget_icon_home);
            nav(v,c,id,R.id.wn_alarms_cell,R.id.wn_alarms,R.id.wn_alarms_label,"alarms",timerBusy&&!alarmBusy,R.drawable.widget_icon_alarm,R.drawable.widget_icon_alarm_disabled);
            nav(v,c,id,R.id.wn_timer_cell,R.id.wn_timer,R.id.wn_timer_label,"timer",alarmBusy&&!timerBusy,R.drawable.widget_icon_timer,R.drawable.widget_icon_timer_disabled);
            nav(v,c,id,R.id.wn_history_cell,R.id.wn_history,R.id.wn_history_label,"history",false,R.drawable.widget_icon_history,R.drawable.widget_icon_history);
        }
        return v;
    }
    private static void nav(RemoteViews v,Context c,int id,int cell,int iconView,int label,String route,boolean blocked,int icon,int disabledIcon){
        v.setImageViewResource(iconView,blocked?disabledIcon:icon);
        v.setTextColor(label,blocked?0xff687584:NORMAL);
        PendingIntent action=blocked?null:open(c,id,route,null);
        for(int view:new int[]{cell,iconView,label}){
            v.setBoolean(view,"setEnabled",!blocked);
            v.setOnClickPendingIntent(view,action);
        }
    }
    private static void failure(Context c,Exception e){EventJournal.append(c,"Widget action rejected: "+e.getMessage());Toast.makeText(c,e.getMessage()==null?"Open PavDroid to continue.":e.getMessage(),Toast.LENGTH_SHORT).show();refresh(c);}
    public static final class Commands extends BroadcastReceiver {
        @Override public void onReceive(Context c,Intent i){if(i==null||!ACTION_CLICK.equals(i.getAction()))return;
            try{String cmd=i.getStringExtra("command");if("plus".equals(cmd)||"minus".equals(cmd)){
                    if(!idle(c))throw new IllegalStateException("Stop the current session first.");WidgetTimerConfig.adjust(c,"plus".equals(cmd)?1:-1);return;}
                Intent service=new Intent(c,WatchMonitorService.class).setAction(ACTION_SERVICE).putExtras(i);
                WatchMonitorService live=WatchMonitorService.liveService();if(live!=null&&live.isMonitoring())execute(live,service);else c.startForegroundService(service);
            }catch(Exception e){failure(c,e);}
        }
    }
    static void execute(WatchMonitorService owner,Intent i){
        try{String cmd=i.getStringExtra("command"),phase=i.getStringExtra("phase");long session=i.getLongExtra("session",-1);
            if("timer_start".equals(cmd)){
                if(!idle(owner)||session!=WidgetTimerConfig.revision(owner))throw new IllegalStateException("Timer or alarm state changed. Try again.");
                JSONObject cfg=WidgetTimerConfig.read(owner);if(cfg.optInt("seconds",0)<1)throw new IllegalStateException("Open PavDroid to initialize Quick Timer.");
                if(cfg.optInt("buzz")+cfg.optInt("beep")+cfg.optInt("zaps")==0)throw new IllegalStateException("Select at least one stimulus in PavDroid.");
                if(cfg.optBoolean("music")&&new JSONArray(cfg.optString("musicPlaylist","[]")).length()==0)throw new IllegalStateException("Select timer music in PavDroid.");
                if(cfg.optInt("interval")<Math.max(3,Math.max(cfg.optInt("buzz"),cfg.optInt("beep"))+1))throw new IllegalStateException("Stimulus interval is too short.");
                owner.timerEngine().command("start",cfg);
            }else if(cmd!=null&&cmd.startsWith("timer_")){
                if(session<=0||session!=owner.timerEngine().sessionId()||!timerPhase(owner).equals(phase)||owner.alarmEngine().isActive())throw new IllegalStateException("Timer state changed. Try again.");
                String action=cmd.substring(6);if(!("pause".equals(action)||"resume".equals(action)||"snooze".equals(action)||"reset".equals(action)||"add_minute".equals(action)||"snooze_add_minute".equals(action)))return;
                if("snooze_add_minute".equals(action)&&i.getIntExtra("snooze_round",-1)!=timerPrefs(owner).getInt("snoozes",0))throw new IllegalStateException("Snooze state changed. Try again.");
                owner.timerEngine().command(action,new JSONObject());
            }else if(cmd!=null&&cmd.startsWith("alarm_")){
                JSONObject s=json(owner.alarmEngine().snapshot());if(session<=0||session!=s.optLong("startedAt")||!s.optString("phase").equals(phase)||!s.optBoolean("active"))throw new IllegalStateException("Alarm state changed. Try again.");
                if("alarm_stop".equals(cmd))owner.alarmEngine().stop("widget Stop");else if("alarm_snooze".equals(cmd))owner.alarmEngine().snooze();else if("alarm_add_minute".equals(cmd)&&i.getIntExtra("snooze_round",-1)==s.optInt("snoozes"))owner.alarmEngine().extendSnooze(session);
            }
            refresh(owner);
        }catch(Exception e){failure(owner,e);}
    }
}
