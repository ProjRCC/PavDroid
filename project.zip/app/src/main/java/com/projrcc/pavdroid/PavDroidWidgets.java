package com.projrcc.pavdroid;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Launcher presentation only. All session mutations use the existing service engines. */
public final class PavDroidWidgets {
    static final String ACTION_SERVICE="com.projrcc.pavdroid.WIDGET_COMMAND";
    private static final String ACTION_CLICK="com.projrcc.pavdroid.WIDGET_CLICK";
    private static final int NORMAL=0xffafbed1, BLUE=0xff89b9ef, AMBER=0xffd9a33d;
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static boolean queued;
    private static String lastSignature="";
    private static SharedPreferences alarmPrefs(Context c){return c.getSharedPreferences("pavdroid_android_alarms_v1",Context.MODE_PRIVATE);}
    private static SharedPreferences timerPrefs(Context c){return c.getSharedPreferences("pd2_native_timer_v1",Context.MODE_PRIVATE);}
    private static JSONObject json(String raw){try{return new JSONObject(raw);}catch(Exception e){return new JSONObject();}}
    private static JSONObject alarmSession(Context c){return json(alarmPrefs(c).getString("session","{}"));}
    private static String timerPhase(Context c){return timerPrefs(c).getString("phase","ready");}
    private static String alarmPhase(Context c){return alarmSession(c).optString("phase","ready");}
    private static boolean idle(Context c){return "ready".equals(timerPhase(c))&&"ready".equals(alarmPhase(c));}
    private static final class Next {
        int index=-1; long due=Long.MAX_VALUE; JSONObject alarm;
        Next(Context c){try{JSONArray list=new JSONArray(alarmPrefs(c).getString("alarms","[]"));long now=System.currentTimeMillis();
            for(int i=0;i<list.length();i++){JSONObject a=list.optJSONObject(i);if(a==null||!a.optBoolean("enabled",true))continue;
                long n=PavDroidAlarmSchedule.nextOccurrence(a,now);if(n<due){index=i;due=n;alarm=a;}}
        }catch(Exception ignored){}}
    }
    public static final class Alarm extends Provider { public Alarm(){super(R.layout.widget_alarm,true,false);} }
    public static final class Timer extends Provider { public Timer(){super(R.layout.widget_timer,false,true);} }
    public static final class Combined extends Provider { public Combined(){super(R.layout.widget_combined,true,true);} }
    public abstract static class Provider extends AppWidgetProvider {
        final int layout;final boolean alarm,timer;
        Provider(int layout,boolean alarm,boolean timer){this.layout=layout;this.alarm=alarm;this.timer=timer;}
        @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,m,id,layout,alarm,timer);}
        @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){render(c,m,id,layout,alarm,timer);}
        @Override public void onEnabled(Context c){refresh(c);}
    }
    static void refresh(Context context){Context c=context.getApplicationContext();MAIN.post(()->{
        if(queued)return;queued=true;MAIN.postDelayed(()->{queued=false;try{updateAll(c);}catch(Exception e){EventJournal.append(c,"Widget refresh failed: "+e.getMessage());}},100);
    });}
    private static void updateAll(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        int[] a=m.getAppWidgetIds(new ComponentName(c,Alarm.class)),t=m.getAppWidgetIds(new ComponentName(c,Timer.class)),b=m.getAppWidgetIds(new ComponentName(c,Combined.class));
        if(a.length+t.length+b.length==0){lastSignature="";return;}
        JSONObject as=alarmSession(c);SharedPreferences ts=timerPrefs(c);Next n=new Next(c);
        String key=as.optString("phase")+"|"+as.optString("name")+"|"+as.optLong("startedAt")+"|"+as.optLong("snoozeUntil")+"|"+as.optInt("snoozes")+"|"+n.index+"|"+n.due+"|"+n.alarm+"|"+ts.getString("phase","ready")+"|"+ts.getLong("deadline",0)+"|"+ts.getInt("remaining",0)+"|"+ts.getLong("sessionId",0)+"|"+WidgetTimerConfig.read(c)+"|"+java.util.Arrays.toString(a)+java.util.Arrays.toString(t)+java.util.Arrays.toString(b);
        if(key.equals(lastSignature))return;lastSignature=key;
        for(int id:a)render(c,m,id,R.layout.widget_alarm,true,false);
        for(int id:t)render(c,m,id,R.layout.widget_timer,false,true);
        for(int id:b)render(c,m,id,R.layout.widget_combined,true,true);
    }
    private static PendingIntent open(Context c,int id,String route,Next n){
        Intent i=new Intent(c,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .setData(Uri.parse("pavdroid://widget/"+id+"/open/"+route)).putExtra("widget_route",route);
        if(n!=null&&n.alarm!=null)i.putExtra("widget_alarm_index",n.index).putExtra("widget_alarm_expected",n.alarm.toString());
        return PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent click(Context c,int id,String cmd,String phase,long session){
        Intent i=new Intent(c,Commands.class).setAction(ACTION_CLICK).setData(Uri.parse("pavdroid://widget/"+id+"/"+cmd+"/"+phase+"/"+session))
            .putExtra("command",cmd).putExtra("phase",phase).putExtra("session",session);
        return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void button(RemoteViews v,int view,String text,PendingIntent action,boolean primary){
        v.setViewVisibility(view,View.VISIBLE);v.setTextViewText(view,text);v.setTextColor(view,primary?0xff101c2d:0xffedf4ff);
        v.setInt(view,"setBackgroundResource",primary?R.drawable.widget_primary:R.drawable.widget_button);v.setOnClickPendingIntent(view,action);
    }
    private static void value(RemoteViews v,int text,int chrono,String display,long due){
        boolean live=due>System.currentTimeMillis();v.setViewVisibility(text,live?View.GONE:View.VISIBLE);v.setViewVisibility(chrono,live?View.VISIBLE:View.GONE);
        v.setTextViewText(text,display);v.setChronometerCountDown(chrono,true);
        v.setChronometer(chrono,SystemClock.elapsedRealtime()+Math.max(0,due-System.currentTimeMillis()),null,live);
    }
    private static String time(int n){return String.format(Locale.US,"%d:%02d",Math.max(0,n)/60,Math.max(0,n)%60);}
    private static void render(Context c,AppWidgetManager m,int id,int layout,boolean hasAlarm,boolean hasTimer){
        RemoteViews v=new RemoteViews(c.getPackageName(),layout);
        if(hasAlarm){JSONObject s=alarmSession(c);String phase=s.optString("phase","ready");long session=s.optLong("startedAt",0);Next n=new Next(c);
            boolean firing="firing".equals(phase),snoozing="snoozing".equals(phase);boolean active=firing||snoozing;
            v.setTextViewText(R.id.wa_title,firing?"Alarm Activated":snoozing?"Alarm Snoozing":"Upcoming Alarm");v.setTextColor(R.id.wa_title,firing?BLUE:snoozing?AMBER:NORMAL);
            String display=active?(firing?"Activated":"0:00"):n.alarm==null?"No alarm":new SimpleDateFormat("h:mm a",Locale.US).format(new Date(n.due));
            value(v,R.id.wa_value,R.id.wa_chrono,display,snoozing?s.optLong("snoozeUntil",0):0);
            v.setTextViewText(R.id.wa_detail,active?s.optString("name","Alarm"):n.alarm==null?"No enabled alarms":new SimpleDateFormat("EEE",Locale.US).format(new Date(n.due))+" · "+n.alarm.optString("name","Alarm"));
            v.setOnClickPendingIntent(R.id.wa_info,open(c,id,"alarms",null));
            if(active){
                if(firing)button(v,R.id.wa_first,s.optBoolean("music")?"Snooze / Mute":"Snooze",click(c,id,"alarm_snooze",phase,session),false);else v.setViewVisibility(R.id.wa_first,View.INVISIBLE);
                button(v,R.id.wa_second,"STOP",click(c,id,"alarm_stop",phase,session),false);
            }else{
                if(n.alarm!=null)button(v,R.id.wa_first,"Edit alarm",open(c,id,"edit_alarm",n),false);else v.setViewVisibility(R.id.wa_first,View.INVISIBLE);
                button(v,R.id.wa_second,"+ New alarm",open(c,id,"new_alarm",null),false);
            }
        }
        if(hasTimer){SharedPreferences p=timerPrefs(c);String phase=p.getString("phase","ready");long session=p.getLong("sessionId",0);boolean ready="ready".equals(phase),running="countdown".equals(phase),paused="paused".equals(phase),snooze="snoozing".equals(phase),expired="alerting".equals(phase);JSONObject cfg=WidgetTimerConfig.read(c);
            int sec=ready?cfg.optInt("seconds",0):p.getInt("remaining",0);long due=running||snooze?p.getLong("deadline",0):0;
            v.setTextViewText(R.id.wt_title,ready?"Quick Timer":running?"Timer · Running":paused?"Timer · Paused":snooze?"Timer · Snoozing":"Time Expired");v.setTextColor(R.id.wt_title,snooze?AMBER:running||expired?BLUE:NORMAL);
            value(v,R.id.wt_value,R.id.wt_chrono,ready&&sec==0?"—":time(expired?0:sec),due);
            v.setViewVisibility(R.id.wt_minus,ready?View.VISIBLE:View.GONE);v.setViewVisibility(R.id.wt_plus,ready?View.VISIBLE:View.GONE);
            v.setOnClickPendingIntent(R.id.wt_minus,click(c,id,"minus","ready",0));v.setOnClickPendingIntent(R.id.wt_plus,click(c,id,"plus","ready",0));
            v.setOnClickPendingIntent(R.id.wt_value,open(c,id,"timer",null));v.setOnClickPendingIntent(R.id.wt_title,open(c,id,"timer",null));
            if(ready){button(v,R.id.wt_first,"Edit timer",open(c,id,"timer",null),false);button(v,R.id.wt_second,"Start timer",click(c,id,"timer_start",phase,WidgetTimerConfig.revision(c)),true);}
            else{if(snooze)v.setViewVisibility(R.id.wt_first,View.INVISIBLE);else button(v,R.id.wt_first,running?"Pause":paused?"Resume":p.getBoolean("music",false)?"Snooze / Mute":"Snooze",click(c,id,running?"timer_pause":paused?"timer_resume":"timer_snooze",phase,session),false);
                button(v,R.id.wt_second,"STOP",click(c,id,"timer_reset",phase,session),false);}
        }
        m.updateAppWidget(id,v);
    }
    private static void failure(Context c,Exception e){EventJournal.append(c,"Widget action rejected: "+e.getMessage());Toast.makeText(c,e.getMessage()==null?"Open PavDroid to continue.":e.getMessage(),Toast.LENGTH_SHORT).show();refresh(c);}
    public static final class Commands extends BroadcastReceiver {
        @Override public void onReceive(Context c,Intent i){if(i==null||!ACTION_CLICK.equals(i.getAction()))return;
            try{String cmd=i.getStringExtra("command");if("plus".equals(cmd)||"minus".equals(cmd)){
                    if(!idle(c))throw new IllegalStateException("Stop the current session first.");WidgetTimerConfig.adjust(c,"plus".equals(cmd)?1:-1);return;}
                Intent service=new Intent(c,WatchMonitorService.class).setAction(ACTION_SERVICE).putExtras(i);
                WatchMonitorService live=WatchMonitorService.liveService();if(live!=null&&live.isMonitoring())execute(live,service);else c.startForegroundService(service);
            }catch(Exception e){failure(c,e);}
        }
    }
    static void execute(WatchMonitorService owner,Intent i){
        try{String cmd=i.getStringExtra("command"),phase=i.getStringExtra("phase");long session=i.getLongExtra("session",-1);
            if("timer_start".equals(cmd)){
                if(!idle(owner)||session!=WidgetTimerConfig.revision(owner))throw new IllegalStateException("Timer or alarm state changed. Try again.");
                JSONObject cfg=WidgetTimerConfig.read(owner);if(cfg.optInt("seconds",0)<1)throw new IllegalStateException("Open PavDroid to initialize Quick Timer.");
                if(cfg.optInt("buzz")+cfg.optInt("beep")+cfg.optInt("zaps")==0)throw new IllegalStateException("Select at least one stimulus in PavDroid.");
                if(cfg.optBoolean("music")&&new JSONArray(cfg.optString("musicPlaylist","[]")).length()==0)throw new IllegalStateException("Select timer music in PavDroid.");
                if(cfg.optInt("interval")<Math.max(3,Math.max(cfg.optInt("buzz"),cfg.optInt("beep"))+1))throw new IllegalStateException("Stimulus interval is too short.");
                owner.timerEngine().command("start",cfg);
            }else if(cmd!=null&&cmd.startsWith("timer_")){
                if(session<=0||session!=owner.timerEngine().sessionId()||!timerPhase(owner).equals(phase)||owner.alarmEngine().isActive())throw new IllegalStateException("Timer state changed. Try again.");
                String action=cmd.substring(6);if(!("pause".equals(action)||"resume".equals(action)||"snooze".equals(action)||"reset".equals(action)))return;
                owner.timerEngine().command(action,new JSONObject());
            }else if(cmd!=null&&cmd.startsWith("alarm_")){
                JSONObject s=json(owner.alarmEngine().snapshot());if(session<=0||session!=s.optLong("startedAt")||!s.optString("phase").equals(phase)||!s.optBoolean("active"))throw new IllegalStateException("Alarm state changed. Try again.");
                if("alarm_stop".equals(cmd))owner.alarmEngine().stop("widget Stop");else if("alarm_snooze".equals(cmd))owner.alarmEngine().snooze();
            }
            refresh(owner);
        }catch(Exception e){failure(owner,e);}
    }
}
