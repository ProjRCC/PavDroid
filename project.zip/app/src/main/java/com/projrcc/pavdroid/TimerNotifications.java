package com.projrcc.pavdroid;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Android-native status and one high-importance alert for each completed timer round. */
final class TimerNotifications {
    static final String ACTION_TIMER = "com.projrcc.pavdroid.refresh.TIMER_NOTIFICATION_ACTION";
    static final String EXTRA_COMMAND = "timer_command";
    private static final String STATUS_CHANNEL = "pavlok_timer_progress_v218";
    private static final String ALERT_CHANNEL = "pavlok_timer_finished_v218";
    private static final int STATUS_ID = 21801;
    private static final int ALERT_ID = 21802;
    private TimerNotifications() { }

    static void createChannels(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationGroups.ensure(context, nm);
        NotificationChannel status = new NotificationChannel(STATUS_CHANNEL, "Timer countdown", NotificationManager.IMPORTANCE_LOW);
        status.setGroup(NotificationGroups.TIMER);
        status.setDescription("Persistent countdown and timer controls");
        status.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(status);
        NotificationChannel alert = new NotificationChannel(ALERT_CHANNEL, "Time Expired", NotificationManager.IMPORTANCE_HIGH);
        alert.setGroup(NotificationGroups.TIMER);
        alert.setDescription("Notifies once when a timer finishes, and again after each snooze");
        alert.enableVibration(true);
        alert.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(alert);
    }
    private static boolean allowed(Context context) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            EventJournal.append(context, "Timer notification BLOCKED: notification permission missing"); return false;
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) {
            EventJournal.append(context, "Timer notification BLOCKED: notifications disabled"); return false;
        }
        return true;
    }
    private static PendingIntent open(Context context) {
        Intent i = new Intent(context, MainActivity.class).putExtra("show_timer", true);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(context, 21800, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent action(Context context, String command, int request) {
        Intent i = new Intent(context, WatchMonitorService.class).setAction(ACTION_TIMER).putExtra(EXTRA_COMMAND, command);
        return PendingIntent.getForegroundService(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void update(Context context, String phase, long deadline, int remaining) {
        createChannels(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if ("ready".equals(phase)) { nm.cancel(STATUS_ID); nm.cancel(ALERT_ID); return; }
        if ("alerting".equals(phase)) { nm.cancel(STATUS_ID); return; }
        nm.cancel(ALERT_ID);
        if (!allowed(context)) return;
        boolean snooze = "snoozing".equals(phase);
        String channelId = snooze ? NotificationGroups.SNOOZE_CHANNEL : STATUS_CHANNEL;
        NotificationChannel c = nm.getNotificationChannel(channelId);
        if (c == null || c.getImportance() == NotificationManager.IMPORTANCE_NONE) {
            EventJournal.append(context,"Timer notification BLOCKED: " + (snooze ? "Snooze Countdown" : "Timer countdown") + " channel disabled"); return;
        }
        boolean paused = "paused".equals(phase);
        String title = paused ? "Timer · Paused"
            : snooze ? "Timer · Snoozing" : "Timer · Running";
        Notification.Builder b = new Notification.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(shortDuration(remaining) + " remaining")
            .setContentIntent(open(context)).setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setOnlyAlertOnce(true);
        // Snoozing is a fixed user-configured wait; Pause/Resume would corrupt
        // the next timer phase. During snooze, Stop is the only action.
        b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                "STOP", action(context, "reset", 21813)).build());
        if (!snooze) b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,
                paused ? "Resume" : "Pause", action(context, paused ? "resume" : "pause", paused ? 21811 : 21812)).build());
        // The native timer already updates the single visible M:SS in the notification body.
        // Hide Android's separate chronometer/timestamp to prevent duplicate, off-by-one displays.
        b.setShowWhen(false).setUsesChronometer(false);
        try { nm.notify(STATUS_ID, b.build()); }
        catch (RuntimeException e) { EventJournal.append(context, "Timer status notification FAILED: " + e.getMessage()); }
    }
    static void timesUp(Context context, boolean newRound, boolean withMusic) {
        createChannels(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.cancel(STATUS_ID);
        if (!allowed(context)) return;
        NotificationChannel c = nm.getNotificationChannel(ALERT_CHANNEL);
        if (c == null || c.getImportance() < NotificationManager.IMPORTANCE_HIGH) {
            EventJournal.append(context, "Timer notification BLOCKED: Time Expired channel not high-priority"); return;
        }
        Notification.Builder b = new Notification.Builder(context, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time Expired")
            .setContentText("PavDroid timer")
            .setContentIntent(open(context)).setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setPriority(Notification.PRIORITY_MAX)
            .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(!newRound)
            // STOP is deliberately on the left; the frequent Snooze / Mute action is rightmost.
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                "STOP", action(context, "reset", 21815)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play,
                withMusic ? "Snooze / Mute" : "Snooze", action(context, "snooze", 21814)).build());
        boolean fullScreen = Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent();
        if (fullScreen && newRound) b.setFullScreenIntent(open(context), true);
        try {
            nm.notify(ALERT_ID, b.build());
            if (newRound) EventJournal.append(context, "Timer notification POSTED: Time Expired" +
                (fullScreen ? " (full-screen allowed)" : " (heads-up only; full-screen unavailable)"));
        } catch (RuntimeException e) { EventJournal.append(context, "Timer notification FAILED: " + e.getMessage()); }
    }
    private static String shortDuration(int sec) {
        int s = Math.max(0, sec);
        return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60);
    }
    private static String duration(int sec) {
        int s = Math.max(0, sec);
        return String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60);
    }
}
