package com.projrcc.pavdroid;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;

/** Owns one BLE connection independently of the visible WebView.
 * A connectedDevice foreground service is needed to monitor watch button events
 * when the screen is off or the user leaves the app.
 */
public final class WatchMonitorService extends Service {
    private static final String ACTION_START = "com.projrcc.pavdroid.refresh.START_MONITOR";
    private static final String CHANNEL = "pavlok_ble_monitor_v208";
    private static final int NOTIFICATION_ID = 20801;
    private final IBinder binder = new LocalBinder();
    private NativeBleBridge bridge;
    private NativeTimerEngine timerEngine;
    private PavDroidAlarmEngine alarmEngine;
    private PavDroidAudio audio;
    private PavDroidSpeech speech;
    private boolean monitoring;
    private boolean showingForeground;
    private static volatile WatchMonitorService live;
    static WatchMonitorService liveService() { return live; }

    final class LocalBinder extends Binder {
        WatchMonitorService service() { return WatchMonitorService.this; }
    }

    @Override public void onCreate() {
        super.onCreate();
        live = this;
        bridge = new NativeBleBridge(this);
        audio = new PavDroidAudio(this);
        speech = new PavDroidSpeech(this);
        timerEngine = new NativeTimerEngine(this);
        alarmEngine = new PavDroidAlarmEngine(this);
        TimerNotifications.createChannels(this);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            NotificationGroups.ensure(this, manager);
        // Keep the required watch-monitor foreground service notification quiet.
        // The user controls visibility/alerts through Android notification settings.
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Watch connection", NotificationManager.IMPORTANCE_NONE);
        channel.setGroup(NotificationGroups.CONNECTIONS);
            channel.setDescription("Keeps the Pavlok connection available for alarm notifications while the app is in the background");
            manager.createNotificationChannel(channel);
            NotificationGroups.removeRetiredDuplicates(manager);
        }
    }

    NativeBleBridge bridge() { return bridge; }
    NativeTimerEngine timerEngine() { return timerEngine; }
    PavDroidAlarmEngine alarmEngine() { return alarmEngine; }
    PavDroidAudio audio(){return audio;}
    PavDroidSpeech speech(){return speech;}
    boolean isMonitoring() { return monitoring; }

    boolean beginMonitoring() {
        if (monitoring) return true;
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return false;
        monitoring = true;
        try {
            Intent start = new Intent(this, WatchMonitorService.class).setAction(ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
            else startService(start);
            return true;
        } catch (Exception ex) {
            monitoring = false;
            return false;
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY may recreate the service after system process reclamation.
        // Android-owned alarms must still notify the phone even when BLE is unavailable.
        // Direct watch stimulation needs Bluetooth permission, reported separately.
        if(Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED)
            EventJournal.append(this,"PavDroid BLE permission missing; Android alarm continues without watch output");
        monitoring = true;
        try {
            showForeground("PavDroid Android alarms and Bluetooth");
        } catch (Exception ex) {
            monitoring = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if(intent!=null && PavDroidUpcomingNotifications.ACTION_SKIP.equals(intent.getAction())) {
            alarmEngine.skipUpcoming(intent.getIntExtra("skip_index",-1),intent.getLongExtra("skip_due",0L),intent.getStringExtra("skip_expected"));
        } else if(intent!=null && intent.getAction()!=null && intent.getAction().startsWith("com.projrcc.pavdroid.ALARM_")) {
            alarmEngine.onDeadline(intent.getAction(), intent.getLongExtra("scheduled_due", 0L));
        } else if (intent != null && TimerNotifications.ACTION_TIMER.equals(intent.getAction())) {
            String command=intent.getStringExtra(TimerNotifications.EXTRA_COMMAND);
            if (!"add_minute".equals(command) || (timerEngine.sessionId()>0 && timerEngine.sessionId()==intent.getLongExtra("timer_session",0L)))
                handleTimerNotificationAction(command);
        }
        // Every service start (including START_STICKY recovery) restores the
        // saved GATT listener, independent of a visible Activity/WebView.
        bridge.restoreBackgroundConnection();
        return START_STICKY;
    }

    private void handleTimerNotificationAction(String command) {
        if (command == null) return;
        try {
            String phase = new org.json.JSONObject(timerEngine.snapshot()).optString("phase", "ready");
            if ("ready".equals(phase) ||
                    ("snoozing".equals(phase) && ("pause".equals(command) || "resume".equals(command))) ||
                    ("alerting".equals(phase) && "pause".equals(command)) ||
                    ("pause".equals(command) && "paused".equals(phase)) ||
                    ("resume".equals(command) && !"paused".equals(phase)) ||
                    ("snooze".equals(command) && !"alerting".equals(phase))) {
                EventJournal.append(this, "Timer notification action ignored for phase " + phase + ": " + command);
                return;
            }
            if (!"pause".equals(command) && !"resume".equals(command) &&
                !"reset".equals(command) && !"snooze".equals(command) && !"add_minute".equals(command)) return;
            if (alarmEngine.isActive())return;
            timerEngine.command(command, new org.json.JSONObject());
            EventJournal.append(this, "PavDroid timer notification action: " + command);
        } catch(Exception ex) { EventJournal.append(this, "Timer notification action FAILED: " + ex.getMessage()); }
    }

    void updateMonitorStatus(boolean connected) {
        if (monitoring && showingForeground) {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID, statusNotification(connected ? "Watch connected · Android alarm service" : "Reconnecting to Pavlok watch"));
        }
    }

    private Notification statusNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 20801, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("PavDroid")
                .setContentText(text)
                .setContentIntent(pending)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(false) // Permit dismissal on supported Android versions without stopping background BLE monitoring
                .setOnlyAlertOnce(true)
                .build();
    }

    private void showForeground(String text) {
        Notification notification = statusNotification(text);
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else startForeground(NOTIFICATION_ID, notification);
        showingForeground = true;
    }

    void endMonitoring() {
        // An explicit disconnect must stop phone-only audio and restore the
        // original alarm volume; a temporary OS service restart is different.

        monitoring = false;
        showingForeground = false;
        if(alarmEngine != null && alarmEngine.isActive())return;
        if(timerEngine != null && timerEngine.isSessionActive())return;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    @Override public void onDestroy() {
        if (speech != null) speech.close();
        if (timerEngine != null) timerEngine.close();
        if (alarmEngine != null) alarmEngine.close();
        if (audio != null) audio.stop();
        if (bridge != null) bridge.close();
        monitoring = false;
        if (live == this) live = null;
        super.onDestroy();
    }
}
