package com.projrcc.pavdroid;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

final class WidgetTimerConfig {
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("pd_widget_timer",Context.MODE_PRIVATE);}
    static synchronized JSONObject read(Context c){try{return new JSONObject(prefs(c).getString("config","{}"));}catch(Exception e){return new JSONObject();}}
    static synchronized long revision(Context c){return prefs(c).getLong("revision",0);}
    static synchronized boolean save(Context c,String raw,long expected){
        if(expected!=revision(c))return false;
        try {JSONObject v=new JSONObject(raw);int n=v.optInt("seconds",0);if(n<1||n>86399)return false;
            if(!raw.equals(prefs(c).getString("config",""))){prefs(c).edit().putString("config",raw).apply();PavDroidWidgets.refresh(c);}
            return true;
        }catch(Exception e){return false;}
    }
    static synchronized String snapshot(Context c){try{return new JSONObject().put("revision",revision(c)).put("seconds",read(c).optInt("seconds",0)).toString();}catch(Exception e){return "{}";}}
    // Widget-only grid. The full editor retains arbitrary seconds and its existing limits.
    static int minuteTarget(int s,int direction){
        if(s<60)return 60;
        if(s>3600)return 3600;
        if(direction>0)return Math.min(3600,(s/300+1)*300);
        int lower=((s+299)/300-1)*300;
        return Math.max(60,lower);
    }
    static synchronized void adjust(Context c,int direction)throws Exception{
        JSONObject v=read(c);int s=v.optInt("seconds",0);if(s<=0)throw new IllegalStateException("Open PavDroid to initialize Quick Timer.");
        int next=minuteTarget(s,direction);
        if(next!=s){v.put("seconds",next);prefs(c).edit().putString("config",v.toString()).putLong("revision",revision(c)+1).apply();}
        PavDroidWidgets.refresh(c);
    }
}
