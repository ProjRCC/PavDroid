package com.projrcc.pavdroid;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

final class WidgetTimerConfig {
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("pd_widget_timer",Context.MODE_PRIVATE);}
    static synchronized JSONObject read(Context c){try{return new JSONObject(prefs(c).getString("config","{}"));}catch(Exception e){return new JSONObject();}}
    static synchronized long revision(Context c){return prefs(c).getLong("revision",0);}
    static synchronized boolean save(Context c,String raw,long expected){
        if(expected!=revision(c))return false;
        try {JSONObject v=new JSONObject(raw);int n=v.optInt("seconds",0);if(n<1||n>86399)return false;
            if(!raw.equals(prefs(c).getString("config",""))){prefs(c).edit().putString("config",raw).apply();PavDroidWidgets.refresh(c);}
            return true;
        }catch(Exception e){return false;}
    }
    static synchronized String snapshot(Context c){try{return new JSONObject().put("revision",revision(c)).put("seconds",read(c).optInt("seconds",0)).toString();}catch(Exception e){return "{}";}}
    static int minuteTarget(int s,int direction){return s<60?(direction>0?60:s):direction>0?Math.min(86399,(s/60+1)*60):Math.max(60,((s+59)/60-1)*60);}
    static int fiveSecondTarget(int s,int direction){return Math.max(1,Math.min(86399,s+(direction>0?5:-5)));}
    static synchronized void adjustFive(Context c,int direction)throws Exception{adjustInternal(c,direction,true);}
    static synchronized void adjust(Context c,int direction)throws Exception{adjustInternal(c,direction,false);}
    private static void adjustInternal(Context c,int direction,boolean fine)throws Exception{
        JSONObject v=read(c);int s=v.optInt("seconds",0);if(s<=0)throw new IllegalStateException("Open PavDroid to initialize Quick Timer.");
        int next=fine?fiveSecondTarget(s,direction):minuteTarget(s,direction);
        if(next!=s){v.put("seconds",next);prefs(c).edit().putString("config",v.toString()).putLong("revision",revision(c)+1).apply();}
        PavDroidWidgets.refresh(c);
    }
}
